<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tree_ranks', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tree_species_id')
                ->constrained('tree_species')
                ->cascadeOnDelete();

            $table->string('name');
            $table->timestamps();

            $table->index(['tree_species_id', 'name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tree_ranks');
    }
};
