<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {
            if (!Schema::hasColumn('tyekafis', 'manual_quarter')) {
                $table->string('manual_quarter')->nullable()->after('liter_id');
            }

            if (!Schema::hasColumn('tyekafis', 'manual_liters')) {
                $table->string('manual_liters')->nullable()->after('manual_quarter');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {
            if (Schema::hasColumn('tyekafis', 'manual_liters')) {
                $table->dropColumn('manual_liters');
            }

            if (Schema::hasColumn('tyekafis', 'manual_quarter')) {
                $table->dropColumn('manual_quarter');
            }
        });
    }
};
