<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('regions')) {
            Schema::create('regions', function (Blueprint $table) {
                $table->id();
                $table->foreignId('governing_body_id')->constrained('governing_bodies')->cascadeOnDelete();
                $table->string('code', 50)->nullable();
                $table->string('name');
                $table->boolean('deleted_by_parent')->default(false);
                $table->softDeletes();
                $table->timestamps();
                $table->unique(['governing_body_id', 'code'], 'regions_gb_code_unique');
                $table->index(['governing_body_id', 'name'], 'regions_gb_name_index');
            });
        }

        Schema::table('forest_districts', function (Blueprint $table) {
            if (!Schema::hasColumn('forest_districts', 'region_id')) {
                $table->foreignId('region_id')->nullable()->after('governing_body_id')->constrained('regions')->nullOnDelete();
            }
        });

        Schema::table('tyekafis', function (Blueprint $table) {
            if (!Schema::hasColumn('tyekafis', 'region_id')) {
                $table->foreignId('region_id')->nullable()->after('governing_body_id')->constrained('regions')->nullOnDelete();
            }
        });

        // optional backfill: one default region per governing body for existing districts/tyekafis
        $gbs = DB::table('governing_bodies')->select('id', 'name')->get();
        foreach ($gbs as $gb) {
            $regionId = DB::table('regions')->where('governing_body_id', $gb->id)->where('name', 'რეგიონი')->value('id');
            if (!$regionId) {
                $regionId = DB::table('regions')->insertGetId([
                    'governing_body_id' => $gb->id,
                    'code' => '01',
                    'name' => 'რეგიონი',
                    'deleted_by_parent' => false,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            DB::table('forest_districts')->where('governing_body_id', $gb->id)->whereNull('region_id')->update(['region_id' => $regionId]);
            DB::table('tyekafis')->where('governing_body_id', $gb->id)->whereNull('region_id')->update(['region_id' => $regionId]);
        }
    }

    public function down(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {
            if (Schema::hasColumn('tyekafis', 'region_id')) {
                $table->dropConstrainedForeignId('region_id');
            }
        });

        Schema::table('forest_districts', function (Blueprint $table) {
            if (Schema::hasColumn('forest_districts', 'region_id')) {
                $table->dropConstrainedForeignId('region_id');
            }
        });

        Schema::dropIfExists('regions');
    }
};
