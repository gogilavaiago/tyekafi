<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {

            // თარიღები (FORM_IN)
            $table->date('marking_start_date')->nullable()->after('description');
            $table->date('marking_end_date')->nullable()->after('marking_start_date');

            // ტყითსარგებლობის საფუძველი
            $table->string('forest_use_basis')->nullable()->after('marking_end_date');

            // ტყითმოსარგებლე
            $table->string('forest_user_name')->nullable()->after('forest_use_basis');
            $table->string('forest_user_id_code')->nullable()->after('forest_user_name');
            $table->string('forest_user_address')->nullable()->after('forest_user_id_code');

            // ფართობი (ჰა)
            $table->decimal('area_ha', 12, 4)->nullable()->after('forest_user_address');

            // ჭრის პარამეტრები
            $table->string('cut_purpose')->nullable()->after('area_ha');
            $table->string('cut_type')->nullable()->after('cut_purpose');
            $table->string('cut_percent')->nullable()->after('cut_type');
            $table->string('szd')->nullable()->after('cut_percent');

            // სიხშირე (ფაქტ/ტყეთმოწყ)
            $table->decimal('frequency_actual', 6, 1)->nullable()->after('szd');
            $table->decimal('frequency_plan', 6, 1)->nullable()->after('frequency_actual');

            // მოზარდი/აღმონაცენი
            $table->string('regen_count_actual')->nullable()->after('frequency_plan');
            $table->string('regen_count_plan')->nullable()->after('regen_count_actual');

            // ხნოვანება / ექსპოზიცია / დაქანება (ფაქტ/ტყეთმოწყ)
            $table->string('age_actual')->nullable()->after('regen_count_plan');
            $table->string('age_plan')->nullable()->after('age_actual');

            $table->string('exposure_actual')->nullable()->after('age_plan');
            $table->string('exposure_plan')->nullable()->after('exposure_actual');

            $table->string('slope_actual')->nullable()->after('exposure_plan');
            $table->string('slope_plan')->nullable()->after('slope_actual');

            // GPS
            $table->string('gps_x1')->nullable()->after('slope_plan');
            $table->string('gps_y1')->nullable()->after('gps_x1');
            $table->string('gps_x2')->nullable()->after('gps_y1');
            $table->string('gps_y2')->nullable()->after('gps_x2');

            // აღრიცხვის მეთოდი / სანიმუშო ფართობები
            $table->string('inventory_method')->nullable()->after('gps_y2');
            $table->string('sample_plot_type')->nullable()->after('inventory_method');

            $table->decimal('sample_plot_area', 12, 4)->nullable()->after('sample_plot_type');
            $table->decimal('multiplier_coeff', 12, 4)->nullable()->after('sample_plot_area');
        });
    }

    public function down(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {
            $table->dropColumn([
                'marking_start_date', 'marking_end_date',
                'forest_use_basis',
                'forest_user_name', 'forest_user_id_code', 'forest_user_address',
                'area_ha',
                'cut_purpose', 'cut_type', 'cut_percent', 'szd',
                'frequency_actual', 'frequency_plan',
                'regen_count_actual', 'regen_count_plan',
                'age_actual', 'age_plan',
                'exposure_actual', 'exposure_plan',
                'slope_actual', 'slope_plan',
                'gps_x1', 'gps_y1', 'gps_x2', 'gps_y2',
                'inventory_method', 'sample_plot_type',
                'sample_plot_area', 'multiplier_coeff',
            ]);
        });
    }
};
