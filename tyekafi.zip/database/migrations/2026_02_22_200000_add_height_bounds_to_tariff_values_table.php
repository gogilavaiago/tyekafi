<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tariff_values', function (Blueprint $table) {
            if (!Schema::hasColumn('tariff_values', 'h_min_m')) {
                $table->decimal('h_min_m', 6, 1)->nullable()->after('dt_cm');
            }
            if (!Schema::hasColumn('tariff_values', 'h_max_m')) {
                $table->decimal('h_max_m', 6, 1)->nullable()->after('h_min_m');
            }
            if (!Schema::hasColumn('tariff_values', 'total_m3')) {
                $table->decimal('total_m3', 14, 6)->nullable()->after('crown_firewood_m3');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tariff_values', function (Blueprint $table) {
            if (Schema::hasColumn('tariff_values', 'h_min_m')) $table->dropColumn('h_min_m');
            if (Schema::hasColumn('tariff_values', 'h_max_m')) $table->dropColumn('h_max_m');
            if (Schema::hasColumn('tariff_values', 'total_m3')) $table->dropColumn('total_m3');
        });
    }
};