<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tyekafi_species_summaries', function (Blueprint $table) {
            if (!Schema::hasColumn('tyekafi_species_summaries', 'rank_method')) {
                $table->string('rank_method', 16)->nullable()->after('height_m');
            }

            if (!Schema::hasColumn('tyekafi_species_summaries', 'manual_rank_num')) {
                $table->unsignedSmallInteger('manual_rank_num')->nullable()->after('rank_method');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tyekafi_species_summaries', function (Blueprint $table) {
            if (Schema::hasColumn('tyekafi_species_summaries', 'manual_rank_num')) {
                $table->dropColumn('manual_rank_num');
            }
            if (Schema::hasColumn('tyekafi_species_summaries', 'rank_method')) {
                $table->dropColumn('rank_method');
            }
        });
    }
};
