<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('volume_tariffs', function (Blueprint $table) {
            $table->id();

            // Excel: "სახეობა"
            $table->string('species');

            // Excel: "თანრიგი" (შენთან "ხარისხი" ≈ "თანრიგი")
            $table->unsignedTinyInteger('rank');

            // Excel: "DT" (დიამეტრი, სმ)
            $table->unsignedSmallInteger('dt_cm');

            // Excel: "H" (საშ. სიმაღლე, მ) - optional, მაგრამ ვინახავთ
            $table->decimal('h_m', 6, 2)->nullable();

            // Excel: "ლიკვიდი", "შეშა ვარჯიდან"
            $table->decimal('liquid_m3', 12, 6)->default(0);
            $table->decimal('crown_firewood_m3', 12, 6)->default(0);

            $table->timestamps();

            $table->unique(['species', 'rank', 'dt_cm'], 'volume_tariffs_unique');
            $table->index(['species', 'rank']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('volume_tariffs');
    }
};