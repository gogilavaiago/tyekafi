<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Drop old table (id-based) and recreate as name-based
        Schema::dropIfExists('tariff_species_mappings');

        Schema::create('tariff_species_mappings', function (Blueprint $table) {
            $table->id();

            // name from Excel / UI label
            $table->string('species_name')->unique();

            $table->foreignId('tariff_table_id')
                ->constrained('tariff_tables')
                ->cascadeOnDelete();

            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('tariff_table_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tariff_species_mappings');
    }
};