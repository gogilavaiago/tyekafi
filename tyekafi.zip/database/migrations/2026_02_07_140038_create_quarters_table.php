<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('quarters', function (Blueprint $table) {
            $table->id();

            $table->foreignId('forest_id')
                ->constrained('forests')
                ->cascadeOnDelete();

            $table->string('name'); // შეგიძლია ნომერი/ტექსტი ჩაწერო: "12"
            $table->timestamps();

            $table->index(['forest_id', 'name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quarters');
    }
};
