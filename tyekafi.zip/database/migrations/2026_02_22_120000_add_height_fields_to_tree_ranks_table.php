<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tree_ranks', function (Blueprint $table) {
            $table->unsignedTinyInteger('rank_num')->nullable()->after('name');
            $table->decimal('h_min_m', 6, 2)->nullable()->after('rank_num');
            $table->decimal('h_max_m', 6, 2)->nullable()->after('h_min_m');
            $table->index(['tree_species_id', 'rank_num']);
        });

        $rows = DB::table('tree_ranks')->select('id', 'name', 'rank_num')->get();
        foreach ($rows as $r) {
            if (!is_null($r->rank_num)) continue;
            $digits = preg_replace('/\D+/', '', (string) $r->name);
            $num = (int) $digits;
            if ($num > 0 && $num <= 50) {
                DB::table('tree_ranks')->where('id', $r->id)->update(['rank_num' => $num]);
            }
        }
    }

    public function down(): void
    {
        Schema::table('tree_ranks', function (Blueprint $table) {
            $table->dropIndex(['tree_species_id', 'rank_num']);
            $table->dropColumn(['rank_num', 'h_min_m', 'h_max_m']);
        });
    }
};