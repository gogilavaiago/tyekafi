<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {
            $table->foreignId('governing_body_id')->nullable()->after('user_id')
                ->constrained('governing_bodies')->nullOnDelete();

            $table->foreignId('forest_district_id')->nullable()->after('governing_body_id')
                ->constrained('forest_districts')->nullOnDelete();

            $table->foreignId('forest_id')->nullable()->after('forest_district_id')
                ->constrained('forests')->nullOnDelete();

            $table->foreignId('quarter_id')->nullable()->after('forest_id')
                ->constrained('quarters')->nullOnDelete();

            $table->foreignId('liter_id')->nullable()->after('quarter_id')
                ->constrained('liters')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('tyekafis', function (Blueprint $table) {
            $table->dropConstrainedForeignId('liter_id');
            $table->dropConstrainedForeignId('quarter_id');
            $table->dropConstrainedForeignId('forest_id');
            $table->dropConstrainedForeignId('forest_district_id');
            $table->dropConstrainedForeignId('governing_body_id');
        });
    }
};
