<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('liters', function (Blueprint $table) {
            $table->id();

            $table->foreignId('quarter_id')
                ->constrained('quarters')
                ->cascadeOnDelete();

            $table->string('name'); // ლიტერი: "ა", "ბ", "გ" ან "1" როგორც გინდა
            $table->timestamps();

            $table->index(['quarter_id', 'name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('liters');
    }
};
