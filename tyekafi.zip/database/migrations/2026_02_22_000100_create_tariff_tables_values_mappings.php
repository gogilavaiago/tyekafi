<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tariff_tables', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();   // T1, T2...
            $table->string('name')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('tariff_values', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tariff_table_id')
                ->constrained('tariff_tables')
                ->cascadeOnDelete();

            $table->unsignedTinyInteger('rank');       // 1..9
            $table->unsignedSmallInteger('dt_cm');     // diameter cm

            $table->decimal('liquid_m3', 12, 6)->default(0);
            $table->decimal('crown_firewood_m3', 12, 6)->default(0);

            $table->timestamps();

            $table->unique(['tariff_table_id', 'rank', 'dt_cm'], 'tariff_values_unique');
            $table->index(['tariff_table_id', 'rank']);
        });

        Schema::create('tariff_species_mappings', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tree_species_id')
                ->constrained('tree_species')
                ->cascadeOnDelete()
                ->unique();

            $table->foreignId('tariff_table_id')
                ->constrained('tariff_tables')
                ->cascadeOnDelete();

            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('tariff_table_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tariff_species_mappings');
        Schema::dropIfExists('tariff_values');
        Schema::dropIfExists('tariff_tables');
    }
};