<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tyekafi_species_summaries', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tyekafi_id')
                ->constrained('tyekafis')
                ->cascadeOnDelete();

            $table->foreignId('tree_species_id')
                ->constrained('tree_species')
                ->cascadeOnDelete();

            $table->decimal('avg_diameter_cm', 10, 2)->nullable();
            $table->decimal('height_m', 6, 2)->nullable();

            $table->foreignId('tree_rank_id')
                ->nullable()
                ->constrained('tree_ranks')
                ->nullOnDelete();

            $table->decimal('liquid_m3', 14, 3)->nullable();
            $table->decimal('firewood_m3', 14, 3)->nullable();
            $table->decimal('issued_m3', 14, 3)->nullable();

            $table->timestamps();

            $table->unique(['tyekafi_id', 'tree_species_id'], 'tyekafi_species_unique');
            $table->index(['tyekafi_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tyekafi_species_summaries');
    }
};