<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tree_species', function (Blueprint $table) {
            if (!Schema::hasColumn('tree_species', 'short_name')) {
                $table->string('short_name')->nullable()->after('name');
            }

            if (!Schema::hasColumn('tree_species', 'latin_name')) {
                $table->string('latin_name')->nullable()->after('short_name');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tree_species', function (Blueprint $table) {
            if (Schema::hasColumn('tree_species', 'latin_name')) {
                $table->dropColumn('latin_name');
            }

            if (Schema::hasColumn('tree_species', 'short_name')) {
                $table->dropColumn('short_name');
            }
        });
    }
};