<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // ✅ Parent
        if (Schema::hasTable('governing_bodies')) {
            Schema::table('governing_bodies', function (Blueprint $table) {
                if (!Schema::hasColumn('governing_bodies', 'deleted_at')) {
                    $table->softDeletes();
                }
            });
        }

        // ✅ Child level 1
        if (Schema::hasTable('forest_districts')) {
            Schema::table('forest_districts', function (Blueprint $table) {
                if (!Schema::hasColumn('forest_districts', 'deleted_at')) {
                    $table->softDeletes();
                }
                if (!Schema::hasColumn('forest_districts', 'deleted_by_parent')) {
                    $table->boolean('deleted_by_parent')->default(false)->index();
                }
            });
        }

        // ✅ Child level 2
        if (Schema::hasTable('forests')) {
            Schema::table('forests', function (Blueprint $table) {
                if (!Schema::hasColumn('forests', 'deleted_at')) {
                    $table->softDeletes();
                }
                if (!Schema::hasColumn('forests', 'deleted_by_parent')) {
                    $table->boolean('deleted_by_parent')->default(false)->index();
                }
            });
        }

        // ✅ Child level 3
        if (Schema::hasTable('quarters')) {
            Schema::table('quarters', function (Blueprint $table) {
                if (!Schema::hasColumn('quarters', 'deleted_at')) {
                    $table->softDeletes();
                }
                if (!Schema::hasColumn('quarters', 'deleted_by_parent')) {
                    $table->boolean('deleted_by_parent')->default(false)->index();
                }
            });
        }

        // ✅ Child level 4
        if (Schema::hasTable('liters')) {
            Schema::table('liters', function (Blueprint $table) {
                if (!Schema::hasColumn('liters', 'deleted_at')) {
                    $table->softDeletes();
                }
                if (!Schema::hasColumn('liters', 'deleted_by_parent')) {
                    $table->boolean('deleted_by_parent')->default(false)->index();
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('liters')) {
            Schema::table('liters', function (Blueprint $table) {
                if (Schema::hasColumn('liters', 'deleted_by_parent')) {
                    $table->dropColumn('deleted_by_parent');
                }
                if (Schema::hasColumn('liters', 'deleted_at')) {
                    $table->dropSoftDeletes();
                }
            });
        }

        if (Schema::hasTable('quarters')) {
            Schema::table('quarters', function (Blueprint $table) {
                if (Schema::hasColumn('quarters', 'deleted_by_parent')) {
                    $table->dropColumn('deleted_by_parent');
                }
                if (Schema::hasColumn('quarters', 'deleted_at')) {
                    $table->dropSoftDeletes();
                }
            });
        }

        if (Schema::hasTable('forests')) {
            Schema::table('forests', function (Blueprint $table) {
                if (Schema::hasColumn('forests', 'deleted_by_parent')) {
                    $table->dropColumn('deleted_by_parent');
                }
                if (Schema::hasColumn('forests', 'deleted_at')) {
                    $table->dropSoftDeletes();
                }
            });
        }

        if (Schema::hasTable('forest_districts')) {
            Schema::table('forest_districts', function (Blueprint $table) {
                if (Schema::hasColumn('forest_districts', 'deleted_by_parent')) {
                    $table->dropColumn('deleted_by_parent');
                }
                if (Schema::hasColumn('forest_districts', 'deleted_at')) {
                    $table->dropSoftDeletes();
                }
            });
        }

        if (Schema::hasTable('governing_bodies')) {
            Schema::table('governing_bodies', function (Blueprint $table) {
                if (Schema::hasColumn('governing_bodies', 'deleted_at')) {
                    $table->dropSoftDeletes();
                }
            });
        }
    }
};