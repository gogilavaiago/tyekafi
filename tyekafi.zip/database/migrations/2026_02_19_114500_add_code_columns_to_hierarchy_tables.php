<?php

use Illuminate\Database\Migrations\Migration;

/**
 * NOTE:
 * ეს migration გახდა redundant, რადგან:
 * - code columns + unique indexes უკვე სწორად აკეთებს 2026_02_19_072425_add_codes_and_unique_indexes_to_hierarchy_tables.php
 * - ამ ფაილში index-ების დამატება მხოლოდ დუბლირებას და რისკს ქმნიდა.
 */
return new class extends Migration
{
    public function up(): void
    {
        // no-op
    }

    public function down(): void
    {
        // no-op
    }
};