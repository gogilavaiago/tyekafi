<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // governing_bodies
        Schema::table('governing_bodies', function (Blueprint $table) {
            if (!Schema::hasColumn('governing_bodies', 'code')) {
                $table->string('code', 50)->after('id')->nullable();
            }
        });

        // forest_districts
        Schema::table('forest_districts', function (Blueprint $table) {
            if (!Schema::hasColumn('forest_districts', 'code')) {
                $table->string('code', 50)->after('governing_body_id')->nullable();
            }
        });

        // forests
        Schema::table('forests', function (Blueprint $table) {
            if (!Schema::hasColumn('forests', 'code')) {
                $table->string('code', 50)->after('forest_district_id')->nullable();
            }
        });

        // quarters
        Schema::table('quarters', function (Blueprint $table) {
            if (!Schema::hasColumn('quarters', 'code')) {
                $table->string('code', 50)->after('forest_id')->nullable();
            }
        });

        // liters
        Schema::table('liters', function (Blueprint $table) {
            if (!Schema::hasColumn('liters', 'code')) {
                $table->string('code', 50)->after('quarter_id')->nullable();
            }
        });

        /**
         * ✅ Unique indexes
         * NOTE: თუ უკვე გაქვს დუბლიკატები DB-ში, migrate შეიძლება წაიქცეს.
         * მაშინ ჯერ უნდა გავასუფთაოთ დუბლიკატები ან კოდები შევავსოთ სწორად.
         */

        // governing_bodies(code) unique
        Schema::table('governing_bodies', function (Blueprint $table) {
            // nullable ველია, მაგრამ შენს UI-ში required გაქვს — ანუ რეალურად შეივსება.
            $table->unique(['code'], 'governing_bodies_code_unique');
        });

        // forest_districts(governing_body_id, code) unique
        Schema::table('forest_districts', function (Blueprint $table) {
            $table->unique(['governing_body_id', 'code'], 'forest_districts_gb_code_unique');
        });

        // forests(forest_district_id, code) unique
        Schema::table('forests', function (Blueprint $table) {
            $table->unique(['forest_district_id', 'code'], 'forests_district_code_unique');
        });

        // quarters(forest_id, code) unique
        Schema::table('quarters', function (Blueprint $table) {
            $table->unique(['forest_id', 'code'], 'quarters_forest_code_unique');
        });

        // liters(quarter_id, code) unique
        Schema::table('liters', function (Blueprint $table) {
            $table->unique(['quarter_id', 'code'], 'liters_quarter_code_unique');
        });
    }

    public function down(): void
    {
        // Drop unique indexes (თუ არსებობს)
        Schema::table('liters', function (Blueprint $table) {
            if (Schema::hasColumn('liters', 'code')) {
                $table->dropUnique('liters_quarter_code_unique');
            }
        });

        Schema::table('quarters', function (Blueprint $table) {
            if (Schema::hasColumn('quarters', 'code')) {
                $table->dropUnique('quarters_forest_code_unique');
            }
        });

        Schema::table('forests', function (Blueprint $table) {
            if (Schema::hasColumn('forests', 'code')) {
                $table->dropUnique('forests_district_code_unique');
            }
        });

        Schema::table('forest_districts', function (Blueprint $table) {
            if (Schema::hasColumn('forest_districts', 'code')) {
                $table->dropUnique('forest_districts_gb_code_unique');
            }
        });

        Schema::table('governing_bodies', function (Blueprint $table) {
            if (Schema::hasColumn('governing_bodies', 'code')) {
                $table->dropUnique('governing_bodies_code_unique');
            }
        });

        // Drop columns (თუ არსებობს)
        Schema::table('liters', function (Blueprint $table) {
            if (Schema::hasColumn('liters', 'code')) {
                $table->dropColumn('code');
            }
        });

        Schema::table('quarters', function (Blueprint $table) {
            if (Schema::hasColumn('quarters', 'code')) {
                $table->dropColumn('code');
            }
        });

        Schema::table('forests', function (Blueprint $table) {
            if (Schema::hasColumn('forests', 'code')) {
                $table->dropColumn('code');
            }
        });

        Schema::table('forest_districts', function (Blueprint $table) {
            if (Schema::hasColumn('forest_districts', 'code')) {
                $table->dropColumn('code');
            }
        });

        Schema::table('governing_bodies', function (Blueprint $table) {
            if (Schema::hasColumn('governing_bodies', 'code')) {
                $table->dropColumn('code');
            }
        });
    }
};
