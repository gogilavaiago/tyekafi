<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tree_species', function (Blueprint $table) {
            if (!Schema::hasColumn('tree_species', 'red_list')) {
                $table->string('red_list')->nullable()->after('latin_name');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tree_species', function (Blueprint $table) {
            if (Schema::hasColumn('tree_species', 'red_list')) {
                $table->dropColumn('red_list');
            }
        });
    }
};