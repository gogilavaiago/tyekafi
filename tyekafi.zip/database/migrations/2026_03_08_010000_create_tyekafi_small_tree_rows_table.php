<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tyekafi_small_tree_rows', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tyekafi_id')
                ->constrained('tyekafis')
                ->cascadeOnDelete();

            $table->foreignId('tree_species_id')
                ->nullable()
                ->constrained('tree_species')
                ->nullOnDelete();

            $table->unsignedInteger('quantity')->nullable();
            $table->unsignedInteger('row_order')->default(1);

            $table->timestamps();

            $table->index(['tyekafi_id', 'row_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tyekafi_small_tree_rows');
    }
};
