<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('forest_districts', function (Blueprint $table) {
            $table->id();

            $table->foreignId('governing_body_id')
                ->constrained('governing_bodies')
                ->cascadeOnDelete();

            $table->string('name');
            $table->timestamps();

            $table->index(['governing_body_id', 'name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('forest_districts');
    }
};
