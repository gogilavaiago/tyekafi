<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('forest_districts', function (Blueprint $table) {
            $table->index(['governing_body_id', 'code']);
            $table->index('deleted_at');
        });

        Schema::table('forests', function (Blueprint $table) {
            $table->index(['forest_district_id', 'code']);
            $table->index('deleted_at');
        });

        Schema::table('quarters', function (Blueprint $table) {
            $table->index(['forest_id', 'code']);
            $table->index('deleted_at');
        });

        Schema::table('liters', function (Blueprint $table) {
            $table->index(['quarter_id', 'code']);
            $table->index('deleted_at');
        });
    }

    public function down(): void
    {
        // optional rollback
    }
};