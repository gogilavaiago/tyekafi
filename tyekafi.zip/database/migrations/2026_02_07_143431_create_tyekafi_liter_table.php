<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tyekafi_liter', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tyekafi_id')
                ->constrained('tyekafis')
                ->cascadeOnDelete();

            $table->foreignId('liter_id')
                ->constrained('liters')
                ->cascadeOnDelete();

            $table->timestamps();

            $table->unique(['tyekafi_id', 'liter_id']);
            $table->index(['tyekafi_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tyekafi_liter');
    }
};
