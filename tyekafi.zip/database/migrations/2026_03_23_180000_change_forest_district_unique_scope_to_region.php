<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('forest_districts', function (Blueprint $table) {
            // ძველი ინდექსის წაშლა (GB + code)
            $table->dropUnique('forest_districts_gb_code_unique');

            // ახალი ინდექსი (region + code)
            $table->unique(
                ['region_id', 'code'],
                'forest_districts_region_code_unique'
            );
        });
    }

    public function down(): void
    {
        Schema::table('forest_districts', function (Blueprint $table) {
            // დაბრუნება ძველზე
            $table->dropUnique('forest_districts_region_code_unique');

            $table->unique(
                ['governing_body_id', 'code'],
                'forest_districts_gb_code_unique'
            );
        });
    }
};