<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('tyekafi_tree_rows', 'note')) {
            Schema::table('tyekafi_tree_rows', function (Blueprint $table) {
                $table->text('note')->nullable()->after('trees_count');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('tyekafi_tree_rows', 'note')) {
            Schema::table('tyekafi_tree_rows', function (Blueprint $table) {
                $table->dropColumn('note');
            });
        }
    }
};