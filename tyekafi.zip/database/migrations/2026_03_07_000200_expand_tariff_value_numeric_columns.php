<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("ALTER TABLE tariff_values MODIFY liquid_m3 DECIMAL(14,4) NULL");
        DB::statement("ALTER TABLE tariff_values MODIFY crown_firewood_m3 DECIMAL(14,4) NULL");
        DB::statement("ALTER TABLE tariff_values MODIFY total_m3 DECIMAL(14,4) NULL");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE tariff_values MODIFY liquid_m3 DECIMAL(10,4) NULL");
        DB::statement("ALTER TABLE tariff_values MODIFY crown_firewood_m3 DECIMAL(10,4) NULL");
        DB::statement("ALTER TABLE tariff_values MODIFY total_m3 DECIMAL(10,4) NULL");
    }
};