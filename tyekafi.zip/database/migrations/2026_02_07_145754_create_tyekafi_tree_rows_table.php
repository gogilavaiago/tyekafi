<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tyekafi_tree_rows', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tyekafi_id')
                ->constrained('tyekafis')
                ->cascadeOnDelete();

            $table->foreignId('tree_species_id')
                ->nullable()
                ->constrained('tree_species')
                ->nullOnDelete();

            $table->foreignId('tree_rank_id')
                ->nullable()
                ->constrained('tree_ranks')
                ->nullOnDelete();

            $table->decimal('diameter_cm', 10, 2)->nullable();
            $table->string('quality', 50)->nullable();
            $table->unsignedInteger('trees_count')->nullable();

            $table->decimal('liquid_m3', 14, 3)->nullable();
            $table->decimal('firewood_m3', 14, 3)->nullable();
            $table->decimal('issued_m3', 14, 3)->nullable();

            $table->unsignedInteger('row_order')->default(1);

            $table->timestamps();

            $table->index(['tyekafi_id', 'row_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tyekafi_tree_rows');
    }
};
