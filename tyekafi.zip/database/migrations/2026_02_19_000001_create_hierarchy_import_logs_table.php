<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hierarchy_import_logs', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('user_id')->nullable();

            $table->string('job_id', 64)->nullable()->index();
            $table->string('token', 64)->nullable()->index();
            $table->string('filename', 255)->nullable();

            $table->string('status', 20)->default('queued')->index(); // queued|running|done|error
            $table->text('error_message')->nullable();

            $table->unsignedInteger('rows_total')->default(0);
            $table->unsignedInteger('rows_ready')->default(0);
            $table->unsignedInteger('rows_skipped')->default(0);
            $table->unsignedInteger('rows_file_duplicates')->default(0);

            $table->json('stats_create')->nullable();
            $table->json('stats_exists')->nullable();
            $table->json('stats_created')->nullable();
            $table->json('time')->nullable();

            $table->timestamp('started_at')->nullable();
            $table->timestamp('finished_at')->nullable();

            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hierarchy_import_logs');
    }
};
