<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hierarchy_import_logs', function (Blueprint $table) {
            if (!Schema::hasColumn('hierarchy_import_logs', 'report_csv_path')) {
                $table->string('report_csv_path')->nullable()->after('time');
            }
            if (!Schema::hasColumn('hierarchy_import_logs', 'report_pdf_path')) {
                $table->string('report_pdf_path')->nullable()->after('report_csv_path');
            }
            if (!Schema::hasColumn('hierarchy_import_logs', 'error_message')) {
                $table->text('error_message')->nullable()->after('report_pdf_path');
            }
        });
    }

    public function down(): void
    {
        Schema::table('hierarchy_import_logs', function (Blueprint $table) {
            if (Schema::hasColumn('hierarchy_import_logs', 'report_csv_path')) {
                $table->dropColumn('report_csv_path');
            }
            if (Schema::hasColumn('hierarchy_import_logs', 'report_pdf_path')) {
                $table->dropColumn('report_pdf_path');
            }
            if (Schema::hasColumn('hierarchy_import_logs', 'error_message')) {
                $table->dropColumn('error_message');
            }
        });
    }
};