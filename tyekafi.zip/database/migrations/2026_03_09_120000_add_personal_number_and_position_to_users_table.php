<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('users', 'personal_number')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('personal_number', 11)->nullable()->after('surname');
            });
        }

        if (!Schema::hasColumn('users', 'position')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('position')->nullable()->after('personal_number');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('users', 'position')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('position');
            });
        }

        if (Schema::hasColumn('users', 'personal_number')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('personal_number');
            });
        }
    }
};