<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hierarchy_import_logs', function (Blueprint $table) {
            if (!Schema::hasColumn('hierarchy_import_logs', 'progress')) {
                $table->unsignedInteger('progress')->nullable()->after('status');
            }
        });
    }

    public function down(): void
    {
        Schema::table('hierarchy_import_logs', function (Blueprint $table) {
            if (Schema::hasColumn('hierarchy_import_logs', 'progress')) {
                $table->dropColumn('progress');
            }
        });
    }
};