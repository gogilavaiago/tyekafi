<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('governing_bodies', function (Blueprint $table) {
            if (!Schema::hasColumn('governing_bodies', 'deleted_at')) {
                $table->softDeletes();
            }
        });

        Schema::table('forest_districts', function (Blueprint $table) {
            if (!Schema::hasColumn('forest_districts', 'deleted_at')) {
                $table->softDeletes();
            }
        });

        Schema::table('forests', function (Blueprint $table) {
            if (!Schema::hasColumn('forests', 'deleted_at')) {
                $table->softDeletes();
            }
        });

        Schema::table('quarters', function (Blueprint $table) {
            if (!Schema::hasColumn('quarters', 'deleted_at')) {
                $table->softDeletes();
            }
        });

        Schema::table('liters', function (Blueprint $table) {
            if (!Schema::hasColumn('liters', 'deleted_at')) {
                $table->softDeletes();
            }
        });
    }

    public function down(): void
    {
        Schema::table('governing_bodies', function (Blueprint $table) {
            if (Schema::hasColumn('governing_bodies', 'deleted_at')) {
                $table->dropSoftDeletes();
            }
        });

        Schema::table('forest_districts', function (Blueprint $table) {
            if (Schema::hasColumn('forest_districts', 'deleted_at')) {
                $table->dropSoftDeletes();
            }
        });

        Schema::table('forests', function (Blueprint $table) {
            if (Schema::hasColumn('forests', 'deleted_at')) {
                $table->dropSoftDeletes();
            }
        });

        Schema::table('quarters', function (Blueprint $table) {
            if (Schema::hasColumn('quarters', 'deleted_at')) {
                $table->dropSoftDeletes();
            }
        });

        Schema::table('liters', function (Blueprint $table) {
            if (Schema::hasColumn('liters', 'deleted_at')) {
                $table->dropSoftDeletes();
            }
        });
    }
};