<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tyekafi_species_summaries', function (Blueprint $table) {
            if (!Schema::hasColumn('tyekafi_species_summaries', 'handwritten_sequence')) {
                $table->string('handwritten_sequence')->nullable()->after('tree_rank_id');
            }

            if (!Schema::hasColumn('tyekafi_species_summaries', 'applied_dt_cm')) {
                $table->unsignedSmallInteger('applied_dt_cm')->nullable()->after('avg_diameter_cm');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tyekafi_species_summaries', function (Blueprint $table) {
            if (Schema::hasColumn('tyekafi_species_summaries', 'handwritten_sequence')) {
                $table->dropColumn('handwritten_sequence');
            }

            if (Schema::hasColumn('tyekafi_species_summaries', 'applied_dt_cm')) {
                $table->dropColumn('applied_dt_cm');
            }
        });
    }
};