<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('forests', function (Blueprint $table) {
            $table->id();

            $table->foreignId('forest_district_id')
                ->constrained('forest_districts')
                ->cascadeOnDelete();

            $table->string('name');
            $table->timestamps();

            $table->index(['forest_district_id', 'name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('forests');
    }
};
