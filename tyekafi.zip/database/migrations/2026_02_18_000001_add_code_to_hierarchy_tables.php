<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        /**
         * NOTE:
         * ეს migration აღარ ქმნის unique/index-ებს, რომ შემდეგ migration-თან (072425) არ იყოს კონფლიქტი.
         * 072425 არის მთავარი ადგილი, სადაც unique-ები იწერება.
         */

        // governing_bodies
        Schema::table('governing_bodies', function (Blueprint $table) {
            if (!Schema::hasColumn('governing_bodies', 'code')) {
                $table->string('code', 50)->nullable()->after('id');
            }
        });

        // forest_districts
        Schema::table('forest_districts', function (Blueprint $table) {
            if (!Schema::hasColumn('forest_districts', 'code')) {
                $table->string('code', 50)->nullable()->after('id');
            }
        });

        // forests
        Schema::table('forests', function (Blueprint $table) {
            if (!Schema::hasColumn('forests', 'code')) {
                $table->string('code', 50)->nullable()->after('id');
            }
        });

        // quarters
        Schema::table('quarters', function (Blueprint $table) {
            if (!Schema::hasColumn('quarters', 'code')) {
                $table->string('code', 50)->nullable()->after('id');
            }
        });

        // liters
        Schema::table('liters', function (Blueprint $table) {
            if (!Schema::hasColumn('liters', 'code')) {
                $table->string('code', 50)->nullable()->after('id');
            }
        });
    }

    public function down(): void
    {
        // ამ migration-ის down არ ვშლით code-ს, რადგან ამას მართავს მთავარი migration (072425).
        // ასე უფრო უსაფრთხოა migrate rollback-ებზე.
    }
};