<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        Role::firstOrCreate(['name' => 'admin'], ['label' => 'ადმინი']);
        Role::firstOrCreate(['name' => 'user'], ['label' => 'მომხმარებელი']);
    }
}
