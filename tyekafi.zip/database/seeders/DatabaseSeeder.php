<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolesSeeder::class,
            PermissionsSeeder::class,
            HierarchyPermissionsSeeder::class, // ✅ added

            AdminUserSeeder::class,

            // სხვა Seeder-ები
            ForestUseBasisSeeder::class,
        ]);
    }
}