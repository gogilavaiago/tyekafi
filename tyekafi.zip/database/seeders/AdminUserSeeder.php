<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::firstOrCreate(
            ['email' => 'admin@tyekafi.local'],
            [
                'name' => 'Admin',
                'surname' => 'User',
                'password' => Hash::make('Admin12345!'),
                'signature_path' => null,
                'lastsession' => null,
            ]
        );

        $admin->assignRole('admin');

        // Admin-ს მიენიჭოს ყველა permission
        $allPermissionIds = Permission::query()->pluck('id')->all();
        $admin->permissions()->sync($allPermissionIds);
    }
}
