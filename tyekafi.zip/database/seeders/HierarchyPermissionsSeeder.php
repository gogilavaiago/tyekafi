<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Permission;

class HierarchyPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        Permission::query()->firstOrCreate(
            ['name' => 'hierarchy_manage'],
            ['label' => 'Hierarchy მართვა']
        );

        Permission::query()->firstOrCreate(
            ['name' => 'hierarchy_import'],
            ['label' => 'Hierarchy იმპორტი']
        );

        Permission::query()->firstOrCreate(
            ['name' => 'hierarchy_export'],
            ['label' => 'Hierarchy ექსპორტი']
        );
    }
}