<?php

namespace Database\Seeders;

use App\Models\ForestUseBasis;
use Illuminate\Database\Seeder;

class ForestUseBasisSeeder extends Seeder
{
    public function run(): void
    {
        ForestUseBasis::updateOrCreate(
            ['code' => 'decree_221'],
            [
                'title' => 'საქართველოს მთავრობის 2021 წლის 18 მაისის №221 დადგენილება „ტყითსარგებლობის წესის შესახებ“ დებულების დამტკიცების თაობაზე',
                'is_active' => true,
                'sort_order' => 10,
            ]
        );

        ForestUseBasis::updateOrCreate(
            ['code' => 'decree_383'],
            [
                'title' => 'საქართველოს მთავრობის 2021 წლის 27 ივლისის №383 დადგენილება ტყის დაცვის, აღდგენისა და მოვლის წესის შესახებ დებულების დამტკიცების თაობაზე',
                'is_active' => true,
                'sort_order' => 20,
            ]
        );

        ForestUseBasis::updateOrCreate(
            ['code' => 'decree_366'],
            [
                'title' => 'საქართველოს მთავრობის 2013 წლის 24 დეკემბერის №366 დადგენილება "ელექტრული ქსელების ხაზობრივი ნაგებობების დაცვის წესისა და მათი დაცვის ზონების დადგენის შესახებ"',
                'is_active' => true,
                'sort_order' => 30,
            ]
        );
    }
}