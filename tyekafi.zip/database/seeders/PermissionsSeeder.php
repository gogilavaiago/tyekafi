<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionsSeeder extends Seeder
{
    public function run(): void
    {
        Permission::firstOrCreate(['name' => 'view'], ['label' => 'დათვალიერება']);
        Permission::firstOrCreate(['name' => 'edit'], ['label' => 'რედაქტირება']);
        Permission::firstOrCreate(['name' => 'import_export'], ['label' => 'მონაცემების იმპორტ/ექსპორტი']);
        Permission::firstOrCreate(['name' => 'report_export'], ['label' => 'რეპორტების ექსპორტი']);
    }
}
