<?php

namespace App\Services\Hierarchy;

use App\DTO\Hierarchy\RegionData;
use App\Models\Region;
use Illuminate\Support\Facades\DB;

class RegionService
{
    public function create(RegionData $data): Region
    {
        return DB::transaction(function () use ($data) {
            $code = $data->code;

            if ($code === null) {
                $code = $this->generateNext2DigitCodeForGB($data->governingBodyId);
            } else {
                $exists = Region::query()
                    ->withTrashed()
                    ->where('governing_body_id', $data->governingBodyId)
                    ->where('code', $code)
                    ->exists();
                if ($exists) {
                    throw new \RuntimeException('Region კოდი უკვე არსებობს ამ GB-ში: ' . $code);
                }
            }

            return Region::query()->create([
                'governing_body_id' => $data->governingBodyId,
                'code' => $code,
                'name' => $data->name,
            ]);
        });
    }

    public function update(Region $region, RegionData $data): Region
    {
        return DB::transaction(function () use ($region, $data) {
            $code = $data->code;

            if ($code !== null) {
                $exists = Region::query()
                    ->withTrashed()
                    ->where('governing_body_id', $data->governingBodyId)
                    ->where('code', $code)
                    ->where('id', '!=', $region->id)
                    ->exists();
                if ($exists) {
                    throw new \RuntimeException('Region კოდი უკვე არსებობს ამ GB-ში: ' . $code);
                }
                $region->code = $code;
            }

            $region->governing_body_id = $data->governingBodyId;
            $region->name = $data->name;
            $region->save();
            return $region;
        });
    }

    public function softDelete(Region $region): void
    {
        DB::transaction(fn () => $region->delete());
    }

    public function restore(int $id): void
    {
        DB::transaction(function () use ($id) {
            $region = Region::withTrashed()->findOrFail($id);
            $region->restore();
        });
    }

    private function generateNext2DigitCodeForGB(int $gbId): string
    {
        $max = Region::query()->withTrashed()->where('governing_body_id', $gbId)->pluck('code')
            ->map(fn ($c) => $this->maxNumericCode($c))->max() ?? 0;
        $next = (int) $max + 1;
        while (Region::query()->withTrashed()->where('governing_body_id', $gbId)->where('code', $this->pad2($next))->exists()) {
            $next++;
        }
        return $this->pad2($next);
    }

    private function pad2(int $n): string
    {
        return str_pad((string) $n, 2, '0', STR_PAD_LEFT);
    }

    private function maxNumericCode(?string $code): int
    {
        if (!$code) return 0;
        $c = trim($code);
        if ($c === '' || !ctype_digit($c)) return 0;
        return (int) $c;
    }
}
