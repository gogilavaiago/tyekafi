<?php

namespace App\Services\Hierarchy;

use App\DTO\Hierarchy\ForestData;
use App\Models\Forest;
use Illuminate\Support\Facades\DB;

class ForestService
{
    public function create(ForestData $data): Forest
    {
        return DB::transaction(function () use ($data) {

            $code = $data->code;

            if ($code === null) {
                $code = $this->generateNext2DigitCodeForDistrict($data->forestDistrictId);
            } else {
                if (Forest::query()
                    ->withTrashed()
                    ->where('forest_district_id', $data->forestDistrictId)
                    ->where('code', $code)
                    ->exists()
                ) {
                    throw new \RuntimeException('Forest კოდი უკვე არსებობს ამ District-ში: ' . $code);
                }
            }

            return Forest::query()->create([
                'forest_district_id' => $data->forestDistrictId,
                'code' => $code,
                'name' => $data->name,
            ]);
        });
    }

    public function update(Forest $forest, ForestData $data): Forest
    {
        return DB::transaction(function () use ($forest, $data) {

            $code = $data->code;

            if ($code !== null) {
                $exists = Forest::query()
                    ->withTrashed()
                    ->where('forest_district_id', $data->forestDistrictId)
                    ->where('code', $code)
                    ->where('id', '!=', $forest->id)
                    ->exists();

                if ($exists) {
                    throw new \RuntimeException('Forest კოდი უკვე არსებობს ამ District-ში: ' . $code);
                }

                $forest->code = $code;
            }

            $forest->forest_district_id = $data->forestDistrictId;
            $forest->name = $data->name;
            $forest->save();

            return $forest;
        });
    }

    public function softDelete(Forest $forest): void
    {
        DB::transaction(function () use ($forest) {
            $forest->delete();
        });
    }

    public function restore(int $id): void
    {
        DB::transaction(function () use ($id) {
            $forest = Forest::withTrashed()->findOrFail($id);
            $forest->restore();
        });
    }

    private function generateNext2DigitCodeForDistrict(int $districtId): string
    {
        $max = Forest::query()
            ->withTrashed()
            ->where('forest_district_id', $districtId)
            ->pluck('code')
            ->map(fn ($c) => $this->maxNumericCode($c))
            ->max() ?? 0;

        $next = (int) $max + 1;

        while (Forest::query()
            ->withTrashed()
            ->where('forest_district_id', $districtId)
            ->where('code', $this->pad2($next))
            ->exists()
        ) {
            $next++;
        }

        return $this->pad2($next);
    }

    private function pad2(int $n): string
    {
        return str_pad((string) $n, 2, '0', STR_PAD_LEFT);
    }

    private function maxNumericCode(?string $code): int
    {
        if (!$code) return 0;
        $c = trim($code);
        if ($c === '' || !ctype_digit($c)) return 0;
        return (int) $c;
    }
}