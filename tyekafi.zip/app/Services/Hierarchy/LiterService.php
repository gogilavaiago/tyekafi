<?php

namespace App\Services\Hierarchy;

use App\DTO\Hierarchy\LiterData;
use App\Models\Liter;
use Illuminate\Support\Facades\DB;

class LiterService
{
    public function create(LiterData $data): Liter
    {
        return DB::transaction(function () use ($data) {

            $code = $data->code;

            if ($code === null) {
                $code = $this->generateNext3DigitCodeForQuarter($data->quarterId);
            } else {
                if (Liter::query()
                    ->withTrashed()
                    ->where('quarter_id', $data->quarterId)
                    ->where('code', $code)
                    ->exists()
                ) {
                    throw new \RuntimeException('Liter კოდი უკვე არსებობს ამ Quarter-ში: ' . $code);
                }
            }

            return Liter::query()->create([
                'quarter_id' => $data->quarterId,
                'code' => $code,
                'name' => $data->name,
            ]);
        });
    }

    public function update(Liter $liter, LiterData $data): Liter
    {
        return DB::transaction(function () use ($liter, $data) {

            $code = $data->code;

            if ($code !== null) {
                $exists = Liter::query()
                    ->withTrashed()
                    ->where('quarter_id', $data->quarterId)
                    ->where('code', $code)
                    ->where('id', '!=', $liter->id)
                    ->exists();

                if ($exists) {
                    throw new \RuntimeException('Liter კოდი უკვე არსებობს ამ Quarter-ში: ' . $code);
                }

                $liter->code = $code;
            }

            $liter->quarter_id = $data->quarterId;
            $liter->name = $data->name;
            $liter->save();

            return $liter;
        });
    }

    public function softDelete(Liter $liter): void
    {
        DB::transaction(function () use ($liter) {
            $liter->delete();
        });
    }

    public function restore(int $id): void
    {
        DB::transaction(function () use ($id) {
            $liter = Liter::withTrashed()->findOrFail($id);
            $liter->restore();
        });
    }

    private function generateNext3DigitCodeForQuarter(int $quarterId): string
    {
        $max = Liter::query()
            ->withTrashed()
            ->where('quarter_id', $quarterId)
            ->pluck('code')
            ->map(fn ($c) => $this->maxNumericCode($c))
            ->max() ?? 0;

        $next = (int) $max + 1;

        while (Liter::query()
            ->withTrashed()
            ->where('quarter_id', $quarterId)
            ->where('code', $this->pad3($next))
            ->exists()
        ) {
            $next++;
        }

        return $this->pad3($next);
    }

    private function pad3(int $n): string
    {
        return str_pad((string) $n, 3, '0', STR_PAD_LEFT);
    }

    private function maxNumericCode(?string $code): int
    {
        if (!$code) return 0;
        $c = trim($code);
        if ($c === '' || !ctype_digit($c)) return 0;
        return (int) $c;
    }
}