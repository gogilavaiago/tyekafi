<?php

namespace App\Services\Hierarchy;

use App\DTO\Hierarchy\GoverningBodyData;
use App\Models\GoverningBody;
use Illuminate\Support\Facades\DB;

class GoverningBodyService
{
    public function create(GoverningBodyData $data): GoverningBody
    {
        return DB::transaction(function () use ($data) {
            $code = $data->code;

            if ($code === null) {
                $code = $this->generateNext2DigitCode();
            } else {
                if (GoverningBody::query()->withTrashed()->where('code', $code)->exists()) {
                    throw new \RuntimeException('GB კოდი უკვე არსებობს: ' . $code);
                }
            }

            return GoverningBody::query()->create([
                'code' => $code,
                'name' => $data->name,
            ]);
        });
    }

    public function update(GoverningBody $gb, GoverningBodyData $data): GoverningBody
    {
        return DB::transaction(function () use ($gb, $data) {

            $code = $data->code;

            // თუ code ცარიელია (null) — არ ვუშვებთ null-ზე გადასვლას, ვტოვებთ არსებულს
            // (თუ გინდა რომ შეცვლა იძლეოდეს null-ს, მომწერე და ვაკეთებთ)
            if ($code !== null) {
                $exists = GoverningBody::query()
                    ->withTrashed()
                    ->where('code', $code)
                    ->where('id', '!=', $gb->id)
                    ->exists();

                if ($exists) {
                    throw new \RuntimeException('GB კოდი უკვე არსებობს: ' . $code);
                }

                $gb->code = $code;
            }

            $gb->name = $data->name;
            $gb->save();

            return $gb;
        });
    }

    public function softDelete(GoverningBody $gb): void
    {
        DB::transaction(function () use ($gb) {
            $gb->delete();
        });
    }

    public function restore(int $id): void
    {
        DB::transaction(function () use ($id) {
            $gb = GoverningBody::withTrashed()->findOrFail($id);
            $gb->restore();
        });
    }

    // ---------------- internal helpers ----------------

    private function generateNext2DigitCode(): string
    {
        $max = GoverningBody::query()
            ->withTrashed()
            ->pluck('code')
            ->map(fn ($c) => $this->maxNumericCode($c))
            ->max() ?? 0;

        $next = (int) $max + 1;

        while (GoverningBody::query()->withTrashed()->where('code', $this->pad2($next))->exists()) {
            $next++;
        }

        return $this->pad2($next);
    }

    private function pad2(int $n): string
    {
        return str_pad((string) $n, 2, '0', STR_PAD_LEFT);
    }

    private function maxNumericCode(?string $code): int
    {
        if (!$code) return 0;
        $c = trim($code);
        if ($c === '' || !ctype_digit($c)) return 0;
        return (int) $c;
    }
}