<?php

namespace App\Services\Hierarchy;

use App\DTO\Hierarchy\QuarterData;
use App\Models\Quarter;
use Illuminate\Support\Facades\DB;

class QuarterService
{
    public function create(QuarterData $data): Quarter
    {
        return DB::transaction(function () use ($data) {

            $code = $data->code;

            if ($code === null) {
                $code = $this->generateNext3DigitCodeForForest($data->forestId);
            } else {
                if (Quarter::query()
                    ->withTrashed()
                    ->where('forest_id', $data->forestId)
                    ->where('code', $code)
                    ->exists()
                ) {
                    throw new \RuntimeException('Quarter კოდი უკვე არსებობს ამ Forest-ში: ' . $code);
                }
            }

            return Quarter::query()->create([
                'forest_id' => $data->forestId,
                'code' => $code,
                'name' => $data->name,
            ]);
        });
    }

    public function update(Quarter $quarter, QuarterData $data): Quarter
    {
        return DB::transaction(function () use ($quarter, $data) {

            $code = $data->code;

            if ($code !== null) {
                $exists = Quarter::query()
                    ->withTrashed()
                    ->where('forest_id', $data->forestId)
                    ->where('code', $code)
                    ->where('id', '!=', $quarter->id)
                    ->exists();

                if ($exists) {
                    throw new \RuntimeException('Quarter კოდი უკვე არსებობს ამ Forest-ში: ' . $code);
                }

                $quarter->code = $code;
            }

            $quarter->forest_id = $data->forestId;
            $quarter->name = $data->name;
            $quarter->save();

            return $quarter;
        });
    }

    public function softDelete(Quarter $quarter): void
    {
        DB::transaction(function () use ($quarter) {
            $quarter->delete();
        });
    }

    public function restore(int $id): void
    {
        DB::transaction(function () use ($id) {
            $quarter = Quarter::withTrashed()->findOrFail($id);
            $quarter->restore();
        });
    }

    private function generateNext3DigitCodeForForest(int $forestId): string
    {
        $max = Quarter::query()
            ->withTrashed()
            ->where('forest_id', $forestId)
            ->pluck('code')
            ->map(fn ($c) => $this->maxNumericCode($c))
            ->max() ?? 0;

        $next = (int) $max + 1;

        while (Quarter::query()
            ->withTrashed()
            ->where('forest_id', $forestId)
            ->where('code', $this->pad3($next))
            ->exists()
        ) {
            $next++;
        }

        return $this->pad3($next);
    }

    private function pad3(int $n): string
    {
        return str_pad((string) $n, 3, '0', STR_PAD_LEFT);
    }

    private function maxNumericCode(?string $code): int
    {
        if (!$code) return 0;
        $c = trim($code);
        if ($c === '' || !ctype_digit($c)) return 0;
        return (int) $c;
    }
}