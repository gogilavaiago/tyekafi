<?php

namespace App\Services\Hierarchy;

use App\Models\ForestDistrict;

class ForestDistrictService
{
    public function firstOrCreate(array $data)
    {
        return ForestDistrict::firstOrCreate(
            [
                // მთავარი ცვლილება — region + code
                'region_id' => $data['region_id'],
                'code' => $data['code'],
            ],
            [
                'governing_body_id' => $data['governing_body_id'],
                'name' => $data['name'],
            ]
        );
    }
}