<?php

namespace App\Services;

use App\Models\TariffSpeciesMapping;
use App\Models\TariffTable;
use App\Models\TariffValue;
use App\Models\TreeSpecies;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;

class VolumeTariffImporter
{
    public function import(string $absolutePath, bool $truncateFirst = false): array
    {
        $spreadsheet = IOFactory::load($absolutePath);

        $result = [
            'tables_inserted' => 0,
            'tables_updated' => 0,
            'values_inserted' => 0,
            'values_updated' => 0,
            'mappings_inserted' => 0,
            'mappings_updated' => 0,
            'species_inserted' => 0,
            'species_updated' => 0,
            'species_deleted' => 0,
            'species_kept_used' => 0,
            'skipped' => 0,
        ];

        return DB::transaction(function () use ($spreadsheet, $truncateFirst, $result) {
            if ($truncateFirst) {
                TariffValue::query()->delete();
                TariffSpeciesMapping::query()->delete();
                TariffTable::query()->delete();
            }

            $tablesSheet = $spreadsheet->getSheetByName('TariffTables');
            $mapSheet = $spreadsheet->getSheetByName('SpeciesMap');
            $valuesSheet = $spreadsheet->getSheetByName('TariffValues');

            if ($tablesSheet) {
                $result = $this->importTables($tablesSheet, $result);
            } else {
                $result = $this->ensureTablesFromAvailableSheets($mapSheet, $valuesSheet, $result);
            }

            $tableIdByCode = TariffTable::query()
                ->pluck('id', 'code')
                ->mapWithKeys(fn ($id, $code) => [trim((string) $code) => (int) $id])
                ->all();

            $speciesNamesFromExcel = [];

            if ($mapSheet) {
                [$result, $speciesNamesFromExcel] = $this->importSpeciesMap($mapSheet, $tableIdByCode, $result);
            }

            if ($valuesSheet) {
                $result = $this->importValues($valuesSheet, $tableIdByCode, $result);
            }

            if (!empty($speciesNamesFromExcel)) {
                $result = $this->cleanupTreeSpecies($speciesNamesFromExcel, $result);
            }

            return $result;
        });
    }

    private function importTables($sheet, array $result): array
    {
        [$headerMap, $firstDataRow, $lastRow] = $this->buildHeaderMap($sheet);

        $colCode = $this->col($headerMap, ['table_code*', 'table_code', 'code']);
        $colName = $this->col($headerMap, ['table_name', 'name']);
        $colNotes = $this->col($headerMap, ['notes', 'note']);

        if (!$colCode) {
            $result['skipped']++;
            return $result;
        }

        for ($r = $firstDataRow; $r <= $lastRow; $r++) {
            $code = $this->str($sheet->getCellByColumnAndRow($colCode, $r)->getValue());
            if ($code === '') {
                continue;
            }

            $name = $colName ? $this->str($sheet->getCellByColumnAndRow($colName, $r)->getValue()) : null;
            $notes = $colNotes ? $this->str($sheet->getCellByColumnAndRow($colNotes, $r)->getValue()) : null;

            $existing = TariffTable::query()->where('code', $code)->first();

            if (!$existing) {
                TariffTable::create([
                    'code' => $code,
                    'name' => $name ?: $code,
                    'notes' => $notes,
                ]);
                $result['tables_inserted']++;
            } else {
                $existing->update([
                    'name' => $name ?: $existing->name,
                    'notes' => $notes,
                ]);
                $result['tables_updated']++;
            }
        }

        return $result;
    }

    private function ensureTablesFromAvailableSheets($mapSheet, $valuesSheet, array $result): array
    {
        $codes = [];

        if ($mapSheet) {
            $codes = array_merge($codes, $this->extractTableCodes($mapSheet));
        }

        if ($valuesSheet) {
            $codes = array_merge($codes, $this->extractTableCodes($valuesSheet));
        }

        $codes = array_values(array_unique(array_filter(array_map(
            fn ($v) => $this->str($v),
            $codes
        ))));

        sort($codes, SORT_NATURAL);

        foreach ($codes as $code) {
            $existing = TariffTable::query()->where('code', $code)->first();

            if (!$existing) {
                TariffTable::create([
                    'code' => $code,
                    'name' => $code,
                    'notes' => 'Auto-created from Excel.',
                ]);
                $result['tables_inserted']++;
            }
        }

        return $result;
    }

    private function extractTableCodes($sheet): array
    {
        [$headerMap, $firstDataRow, $lastRow] = $this->buildHeaderMap($sheet);

        $colCode = $this->col($headerMap, ['table_code*', 'table_code', 'code']);
        if (!$colCode) {
            return [];
        }

        $codes = [];

        for ($r = $firstDataRow; $r <= $lastRow; $r++) {
            $code = $this->str($sheet->getCellByColumnAndRow($colCode, $r)->getValue());
            if ($code !== '') {
                $codes[] = $code;
            }
        }

        return $codes;
    }

    private function importSpeciesMap($sheet, array $tableIdByCode, array $result): array
    {
        [$headerMap, $firstDataRow, $lastRow] = $this->buildHeaderMap($sheet);

        $colSpecies = $this->col($headerMap, ['species_name*', 'species_name', 'species']);
        $colShort = $this->col($headerMap, ['short_name', 'short__name', 'shortname']);
        $colLatin = $this->col($headerMap, ['scientific_name', 'latin_name', 'scientificname']);
        $colRedList = $this->col($headerMap, ['red_list', 'redlist']);
        $colCode = $this->col($headerMap, ['table_code*', 'table_code', 'code']);
        $colNotes = $this->col($headerMap, ['notes', 'note']);

        if (!$colSpecies || !$colCode) {
            $result['skipped']++;
            return [$result, []];
        }

        $speciesNamesFromExcel = [];

        for ($r = $firstDataRow; $r <= $lastRow; $r++) {
            $speciesName = $this->str($sheet->getCellByColumnAndRow($colSpecies, $r)->getValue());
            $tableCode = $this->str($sheet->getCellByColumnAndRow($colCode, $r)->getValue());

            if ($speciesName === '' || $tableCode === '') {
                continue;
            }

            $speciesNamesFromExcel[] = $speciesName;

            $tariffTableId = $tableIdByCode[$tableCode] ?? null;
            if (!$tariffTableId) {
                $result['skipped']++;
                continue;
            }

            $shortName = $colShort
                ? $this->nullableString($sheet->getCellByColumnAndRow($colShort, $r)->getValue())
                : null;

            $latinName = $colLatin
                ? $this->nullableString($sheet->getCellByColumnAndRow($colLatin, $r)->getValue())
                : null;

            $redListRaw = $colRedList
    ? $sheet->getCellByColumnAndRow($colRedList, $r)->getValue()
    : null;

$redList = null;

if ($redListRaw !== null) {
    $value = trim((string)$redListRaw);

    if ($value === '1') {
        $redList = 'წითელი ნუსხა';
    }
}

            $species = TreeSpecies::query()->where('name', $speciesName)->first();

            if (!$species) {
                TreeSpecies::create([
                    'name' => $speciesName,
                    'short_name' => $shortName,
                    'latin_name' => $latinName,
                    'red_list' => $redList,
                ]);
                $result['species_inserted']++;
            } else {
                $payload = [];
                $changed = false;

                if ($species->short_name !== $shortName) {
                    $payload['short_name'] = $shortName;
                    $changed = true;
                }

                if ($species->latin_name !== $latinName) {
                    $payload['latin_name'] = $latinName;
                    $changed = true;
                }

                if (($species->red_list ?? null) !== $redList) {
                    $payload['red_list'] = $redList;
                    $changed = true;
                }

                if ($changed) {
                    $species->update($payload);
                    $result['species_updated']++;
                }
            }

            $notes = $colNotes ? $this->str($sheet->getCellByColumnAndRow($colNotes, $r)->getValue()) : null;

            $existing = TariffSpeciesMapping::query()
                ->where('species_name', $speciesName)
                ->first();

            $payload = [
                'species_name' => $speciesName,
                'tariff_table_id' => $tariffTableId,
                'notes' => $notes,
            ];

            if (!$existing) {
                TariffSpeciesMapping::create($payload);
                $result['mappings_inserted']++;
            } else {
                $existing->update($payload);
                $result['mappings_updated']++;
            }
        }

        $speciesNamesFromExcel = array_values(array_unique(array_filter(array_map(
            fn ($v) => $this->str($v),
            $speciesNamesFromExcel
        ))));

        return [$result, $speciesNamesFromExcel];
    }

    private function cleanupTreeSpecies(array $speciesNamesFromExcel, array $result): array
    {
        $excelNamesMap = [];
        foreach ($speciesNamesFromExcel as $name) {
            $excelNamesMap[$name] = true;
        }

        $allSpecies = TreeSpecies::query()->get(['id', 'name']);

        foreach ($allSpecies as $species) {
            if (isset($excelNamesMap[$species->name])) {
                continue;
            }

            $isUsedInTreeRows = DB::table('tyekafi_tree_rows')
                ->where('tree_species_id', $species->id)
                ->exists();

            $isUsedInSmallTreeRows = DB::table('tyekafi_small_tree_rows')
                ->where('tree_species_id', $species->id)
                ->exists();

            $isUsedInSummaries = DB::table('tyekafi_species_summaries')
                ->where('tree_species_id', $species->id)
                ->exists();

            $isUsed = $isUsedInTreeRows || $isUsedInSmallTreeRows || $isUsedInSummaries;

            if ($isUsed) {
                $result['species_kept_used']++;
                continue;
            }

            TariffSpeciesMapping::query()
                ->where('species_name', $species->name)
                ->delete();

            $species->delete();
            $result['species_deleted']++;
        }

        return $result;
    }

    private function importValues($sheet, array $tableIdByCode, array $result): array
    {
        [$headerMap, $firstDataRow, $lastRow] = $this->buildHeaderMap($sheet);

        $colCode = $this->col($headerMap, ['table_code*', 'table_code', 'code']);
        $colRank = $this->col($headerMap, ['rank*', 'rank', 'rank_num']);
        $colDt = $this->col($headerMap, ['dt_cm*', 'dt_cm', 'diameter_cm']);
        $colHmin = $this->col($headerMap, ['h_min_m', 'hmin_m', 'hmin', 'h_min']);
        $colHmax = $this->col($headerMap, ['h_max_m', 'hmax_m', 'hmax', 'h_max']);
        $colLiquid = $this->col($headerMap, ['liquid_m3*', 'liquid_m3', 'liquid']);
        $colCrown = $this->col($headerMap, ['crown_firewood_m3*', 'crown_firewood_m3', 'crown']);
        $colTotal = $this->col($headerMap, ['total_m3*', 'total_m3', 'total']);

        if (!$colCode || !$colRank || !$colDt || !$colLiquid || !$colCrown) {
            $result['skipped']++;
            return $result;
        }

        for ($r = $firstDataRow; $r <= $lastRow; $r++) {
            $tableCode = $this->str($sheet->getCellByColumnAndRow($colCode, $r)->getValue());
            if ($tableCode === '') {
                continue;
            }

            $tariffTableId = $tableIdByCode[$tableCode] ?? null;
            if (!$tariffTableId) {
                $result['skipped']++;
                continue;
            }

            $rank = $this->int($sheet->getCellByColumnAndRow($colRank, $r)->getValue());
            $dt = $this->int($sheet->getCellByColumnAndRow($colDt, $r)->getValue());

            if (!$rank || !$dt) {
                continue;
            }

            $hMin = $colHmin ? $this->float($sheet->getCellByColumnAndRow($colHmin, $r)->getValue()) : null;
            $hMax = $colHmax ? $this->float($sheet->getCellByColumnAndRow($colHmax, $r)->getValue()) : null;

            $liquid = $this->float($sheet->getCellByColumnAndRow($colLiquid, $r)->getValue());
            $crown = $this->float($sheet->getCellByColumnAndRow($colCrown, $r)->getValue());

            if ($liquid === null || $crown === null) {
                continue;
            }

            $total = $colTotal ? $this->float($sheet->getCellByColumnAndRow($colTotal, $r)->getValue()) : null;
            if ($total === null) {
                $total = $liquid + $crown;
            }

            $existing = TariffValue::query()
                ->where('tariff_table_id', $tariffTableId)
                ->where('rank', $rank)
                ->where('dt_cm', $dt)
                ->first();

            $payload = [
                'tariff_table_id' => $tariffTableId,
                'rank' => $rank,
                'dt_cm' => $dt,
                'h_min_m' => $hMin,
                'h_max_m' => $hMax,
                'liquid_m3' => $liquid,
                'crown_firewood_m3' => $crown,
                'total_m3' => $total,
            ];

            if (!$existing) {
                TariffValue::create($payload);
                $result['values_inserted']++;
            } else {
                $existing->update($payload);
                $result['values_updated']++;
            }
        }

        return $result;
    }

    private function buildHeaderMap($sheet): array
    {
        $highestRow = $sheet->getHighestRow();
        $highestCol = Coordinate::columnIndexFromString($sheet->getHighestColumn());

        $headerRow = 1;

        $headerMap = [];
        for ($c = 1; $c <= $highestCol; $c++) {
            $raw = $sheet->getCellByColumnAndRow($c, $headerRow)->getValue();
            $key = $this->norm($raw);
            if ($key !== '') {
                $headerMap[$key] = $c;
            }
        }

        $lastRow = $highestRow;
        while ($lastRow > 1) {
            $rowHas = false;
            for ($c = 1; $c <= $highestCol; $c++) {
                $v = $sheet->getCellByColumnAndRow($c, $lastRow)->getValue();
                if ($v !== null && trim((string) $v) !== '') {
                    $rowHas = true;
                    break;
                }
            }
            if ($rowHas) {
                break;
            }
            $lastRow--;
        }

        return [$headerMap, 2, max(2, $lastRow)];
    }

    private function col(array $headerMap, array $candidates): ?int
    {
        foreach ($candidates as $cand) {
            $k = $this->norm($cand);
            if (isset($headerMap[$k])) {
                return (int) $headerMap[$k];
            }
        }

        return null;
    }

    private function norm($v): string
    {
        $s = strtolower(trim((string) $v));
        $s = str_replace([' ', '-', '—'], '_', $s);
        $s = preg_replace('/[^a-z0-9_\*]+/i', '', $s);
        return $s;
    }

    private function str($v): string
    {
        return trim((string) ($v ?? ''));
    }

    private function nullableString($v): ?string
    {
        $s = trim((string) ($v ?? ''));
        return $s === '' ? null : $s;
    }

    private function int($v): ?int
    {
        if ($v === null || trim((string) $v) === '') {
            return null;
        }

        $s = str_replace(',', '.', trim((string) $v));
        if (!is_numeric($s)) {
            return null;
        }

        return (int) round((float) $s);
    }

    private function float($v): ?float
    {
        if ($v === null || trim((string) $v) === '') {
            return null;
        }

        $s = str_replace(',', '.', trim((string) $v));
        if (!is_numeric($s)) {
            return null;
        }

        return (float) $s;
    }
}