<?php

namespace App\Services;

use App\Models\Project;
use App\Models\TariffSpeciesMapping;
use App\Models\TariffValue;
use App\Models\TreeSpecies;
use App\Models\Tyekafi;
use Illuminate\Support\Collection;

class ProjectCompensationSummaryService
{
    public function __construct(private readonly CompensationCalculator $calculator)
    {
    }

    public function build(Project $project, Collection $tyekafis, ?string $selectedYearsRange = null): array
    {
        $yearsRange = $this->normalizeYearsRange($selectedYearsRange);

        $bodyGroups = [];
        $tyekafiCompensations = [];
        $woodCompensation = 0.0;
        $areaCompensation = 0.0;
        $totalCompensation = 0.0;

        foreach ($tyekafis as $tyekafi) {
            $reportRows = $this->buildReportRows($tyekafi);
            $smallRows = $this->buildSmallDiameterRows($tyekafi);
            $compensation = $this->calculator->calculateForTyekafi($tyekafi, $reportRows, $smallRows, $yearsRange);

            $bodyName = trim((string) ($tyekafi->governingBody?->name ?? ''));
            if (!$this->shouldIncludeBodyInCompensationReport($bodyName)) {
                continue;
            }

            $bodyName = $bodyName !== '' ? $bodyName : 'მართვის ორგანო არ არის მითითებული';

            $woodValue = (float) ($compensation['wood_compensation'] ?? 0);
            $areaValue = (float) ($compensation['area_compensation'] ?? 0);
            $totalValue = (float) ($compensation['total_compensation'] ?? 0);
            $areaHa = (float) ($tyekafi->area_ha ?? 0);

            $tyekafiRow = [
                'tyekafi_id' => (int) $tyekafi->id,
                'name' => trim((string) ($tyekafi->name ?? '')) !== '' ? trim((string) $tyekafi->name) : ('ტყეკაფი #' . $tyekafi->id),
                'forest_user_name' => trim((string) ($tyekafi->forest_user_name ?? '')),
                'area_ha' => $areaHa,
                'wood_compensation' => $woodValue,
                'area_compensation' => $areaValue,
                'total_compensation' => $totalValue,
                'years_range' => $compensation['years_range'] ?? $yearsRange,
                'species_rows' => $compensation['species_rows'] ?? [],
                'red_list_species_count' => collect($compensation['species_rows'] ?? [])->where('is_red_list', true)->count(),
                'red_list_compensation' => round(collect($compensation['species_rows'] ?? [])->where('is_red_list', true)->sum('compensation'), 3),
            ];

            $tyekafiCompensations[] = $tyekafiRow;

            if (!isset($bodyGroups[$bodyName])) {
                $bodyGroups[$bodyName] = [
                    'name' => $bodyName,
                    'tyekafi_count' => 0,
                    'area_ha' => 0.0,
                    'wood_compensation' => 0.0,
                    'area_compensation' => 0.0,
                    'total_compensation' => 0.0,
                    'species_rows' => [],
                    'tyekafis' => [],
                    'red_list_species_count' => 0,
                    'red_list_compensation' => 0.0,
                    'red_list_volume' => 0.0,
                ];
            }

            $bodyGroups[$bodyName]['tyekafi_count']++;
            $bodyGroups[$bodyName]['area_ha'] += $areaHa;
            $bodyGroups[$bodyName]['wood_compensation'] += $woodValue;
            $bodyGroups[$bodyName]['area_compensation'] += $areaValue;
            $bodyGroups[$bodyName]['total_compensation'] += $totalValue;
            $bodyGroups[$bodyName]['tyekafis'][] = $tyekafiRow;
            $bodyGroups[$bodyName]['red_list_species_count'] += (int) ($tyekafiRow['red_list_species_count'] ?? 0);
            $bodyGroups[$bodyName]['red_list_compensation'] += (float) ($tyekafiRow['red_list_compensation'] ?? 0);

            foreach (($compensation['species_rows'] ?? []) as $speciesRow) {
                $speciesName = trim((string) ($speciesRow['species_name'] ?? ''));
                if ($speciesName === '') {
                    continue;
                }

                if (!isset($bodyGroups[$bodyName]['species_rows'][$speciesName])) {
                    $bodyGroups[$bodyName]['species_rows'][$speciesName] = [
                        'species_name' => $speciesName,
                        'species_latin_name' => trim((string) ($speciesRow['species_latin_name'] ?? '')),
                        'volume' => 0.0,
                        'compensation' => 0.0,
                        'is_red_list' => (bool) ($speciesRow['is_red_list'] ?? false),
                        'money_group' => $speciesRow['money_group'] ?? null,
                        'base_rate' => (float) ($speciesRow['base_rate'] ?? 0),
                        'body_multiplier' => (float) ($speciesRow['body_multiplier'] ?? 0),
                        'year_multiplier' => (float) ($speciesRow['year_multiplier'] ?? ($compensation['year_multiplier'] ?? 1)),
                        'compensation_before_years' => (float) ($speciesRow['compensation_before_years'] ?? 0),
                    ];
                }

                if (
                    trim((string) ($bodyGroups[$bodyName]['species_rows'][$speciesName]['species_latin_name'] ?? '')) === ''
                    && trim((string) ($speciesRow['species_latin_name'] ?? '')) !== ''
                ) {
                    $bodyGroups[$bodyName]['species_rows'][$speciesName]['species_latin_name'] = trim((string) ($speciesRow['species_latin_name'] ?? ''));
                }

                $bodyGroups[$bodyName]['species_rows'][$speciesName]['volume'] += (float) ($speciesRow['volume'] ?? 0);
                $bodyGroups[$bodyName]['species_rows'][$speciesName]['compensation'] += (float) ($speciesRow['compensation'] ?? 0);
                $bodyGroups[$bodyName]['species_rows'][$speciesName]['year_multiplier'] = (float) ($speciesRow['year_multiplier'] ?? 1);
                $bodyGroups[$bodyName]['species_rows'][$speciesName]['compensation_before_years'] = round(
                    (float) ($bodyGroups[$bodyName]['species_rows'][$speciesName]['compensation_before_years'] ?? 0) + (float) ($speciesRow['compensation_before_years'] ?? 0),
                    3
                );
                $bodyGroups[$bodyName]['species_rows'][$speciesName]['is_red_list'] = $bodyGroups[$bodyName]['species_rows'][$speciesName]['is_red_list']
                    || (bool) ($speciesRow['is_red_list'] ?? false);

                if (!empty($speciesRow['is_red_list'])) {
                    $bodyGroups[$bodyName]['red_list_volume'] += (float) ($speciesRow['volume'] ?? 0);
                }
            }

            $woodCompensation += $woodValue;
            $areaCompensation += $areaValue;
            $totalCompensation += $totalValue;
        }

        foreach ($bodyGroups as &$group) {
            foreach ($group['species_rows'] as &$speciesRow) {
                $speciesRow['volume'] = round((float) $speciesRow['volume'], 3);
                $speciesRow['compensation'] = round((float) $speciesRow['compensation'], 3);
                $speciesRow['compensation_before_years'] = round((float) ($speciesRow['compensation_before_years'] ?? 0), 3);
            }
            unset($speciesRow);

            uasort($group['species_rows'], function (array $a, array $b) {
                $cmp = ((float) ($b['compensation'] ?? 0)) <=> ((float) ($a['compensation'] ?? 0));
                if ($cmp !== 0) {
                    return $cmp;
                }

                return strnatcasecmp((string) ($a['species_name'] ?? ''), (string) ($b['species_name'] ?? ''));
            });

            usort($group['tyekafis'], function (array $a, array $b) {
                $cmp = ((float) ($b['total_compensation'] ?? 0)) <=> ((float) ($a['total_compensation'] ?? 0));
                if ($cmp !== 0) {
                    return $cmp;
                }

                return ((int) ($a['tyekafi_id'] ?? 0)) <=> ((int) ($b['tyekafi_id'] ?? 0));
            });
        }
        unset($group);

        $bodyGroups = collect($bodyGroups)
            ->sort(function (array $a, array $b) {
                $cmp = ((float) ($b['total_compensation'] ?? 0)) <=> ((float) ($a['total_compensation'] ?? 0));
                if ($cmp !== 0) {
                    return $cmp;
                }

                return strnatcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
            })
            ->values()
            ->all();

        usort($tyekafiCompensations, function (array $a, array $b) {
            $cmp = ((float) ($b['total_compensation'] ?? 0)) <=> ((float) ($a['total_compensation'] ?? 0));
            if ($cmp !== 0) {
                return $cmp;
            }

            return ((int) ($a['tyekafi_id'] ?? 0)) <=> ((int) ($b['tyekafi_id'] ?? 0));
        });

        return [
            'yearsRange' => $yearsRange,
            'woodCompensation' => round($woodCompensation, 3),
            'areaCompensation' => round($areaCompensation, 3),
            'totalCompensation' => round($totalCompensation, 3),
            'tyekafiCompensations' => $tyekafiCompensations,
            'governingBodyCompensations' => $bodyGroups,
        ];
    }


    private function shouldIncludeBodyInCompensationReport(?string $bodyName): bool
    {
        $bodyName = trim((string) $bodyName);
        if ($bodyName === '') {
            return false;
        }

        $allowedBodies = array_map(
            static fn ($value) => trim((string) $value),
            (array) config('compensation.eligible_governing_bodies_for_compensation_reports', [])
        );

        return in_array($bodyName, array_filter($allowedBodies), true);
    }

    private function normalizeYearsRange(?string $selectedYearsRange): string
    {
        $selectedYearsRange = trim((string) $selectedYearsRange);

        return in_array($selectedYearsRange, ['0-5', '6-15', '16-30', '31-49'], true)
            ? $selectedYearsRange
            : '0-5';
    }

    private function buildSmallDiameterRows(Tyekafi $tyekafi): array
    {
        $rows = $tyekafi->smallTreeRows ?? collect();
        $grouped = [];

        foreach ($rows as $row) {
            $speciesName = trim((string) ($row->species?->name ?? ''));
            if ($speciesName === '') {
                $speciesName = '—';
            }

            if (!isset($grouped[$speciesName])) {
                $grouped[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row->species?->latin_name ?? '')),
                    'count' => 0,
                    'volume' => 0.0,
                    'is_red_list' => trim((string) ($row->species?->red_list ?? '')) !== '',
                ];
            }

            $grouped[$speciesName]['count'] += (int) ($row->quantity ?? 0);
            $grouped[$speciesName]['volume'] += ((int) ($row->quantity ?? 0)) * 0.001;
            $grouped[$speciesName]['is_red_list'] = $grouped[$speciesName]['is_red_list']
                || trim((string) ($row->species?->red_list ?? '')) !== '';
        }

        foreach ($grouped as &$item) {
            $item['volume'] = round((float) $item['volume'], 3);
        }
        unset($item);

        ksort($grouped, SORT_NATURAL);

        return array_values($grouped);
    }

    private function buildReportRows(Tyekafi $tyekafi): array
    {
        $species = TreeSpecies::query()
            ->orderBy('name')
            ->get(['id', 'name', 'latin_name', 'red_list'])
            ->keyBy('id');

        $rows = $tyekafi->treeRows ?? collect();
        $summaries = ($tyekafi->speciesSummaries ?? collect())->keyBy('tree_species_id');
        $valid = $rows->filter(fn ($r) => !is_null($r->tree_species_id) && !is_null($r->diameter_cm) && (float) $r->diameter_cm > 0);

        $reportRows = [];
        $tariffTableIdBySpeciesName = [];

        foreach ($valid as $sourceRow) {
            $speciesId = (int) $sourceRow->tree_species_id;
            $speciesName = (string) ($species[$speciesId]->name ?? '—');
            $speciesLatinName = trim((string) ($species[$speciesId]->latin_name ?? ''));
            $isRedList = trim((string) ($species[$speciesId]->red_list ?? '')) !== '';
            $diameter = (int) round((float) $sourceRow->diameter_cm);

            $manualNote = trim((string) ($sourceRow->note ?? ''));
            $noteLines = [];
            if ($isRedList) {
                $noteLines[] = 'წითელი ნუსხა';
            }
            if ($manualNote !== '') {
                $noteLines[] = $manualNote;
            }
            $note = implode("\n", array_values(array_unique($noteLines)));

            $sum = $summaries->get($speciesId);
            $rankMethod = $sum?->rank_method;
            $rankMethod = ($rankMethod === '' || is_null($rankMethod)) ? 'h' : (string) $rankMethod;
            if (!in_array($rankMethod, ['h', 'manual'], true)) {
                $rankMethod = 'h';
            }

            $height = $sum?->height_m;
            $height = ($height === '' || is_null($height)) ? null : (float) $height;

            $manualRankNum = null;
            if ($sum && $sum->relationLoaded('rank') && $sum->rank && !is_null($sum->rank->rank_num)) {
                $manualRankNum = (int) $sum->rank->rank_num;
            } elseif (!is_null($sum?->manual_rank_num) && is_numeric($sum->manual_rank_num)) {
                $manualRankNum = (int) $sum->manual_rank_num;
            }

            if (!array_key_exists($speciesName, $tariffTableIdBySpeciesName)) {
                $mapping = TariffSpeciesMapping::query()
                    ->where('species_name', $speciesName)
                    ->first();

                $tariffTableIdBySpeciesName[$speciesName] = $mapping ? (int) $mapping->tariff_table_id : null;
            }

            $tariffTableId = $tariffTableIdBySpeciesName[$speciesName];
            $perLiquid = 0.0;
            $perFirewood = 0.0;
            $perTotal = 0.0;

            $canCalc =
                $tariffTableId
                && $diameter > 0
                && (
                    ($rankMethod === 'h' && !is_null($height) && $height > 0)
                    || ($rankMethod === 'manual' && !is_null($manualRankNum) && $manualRankNum > 0)
                );

            if ($canCalc) {
                $nearestDt = TariffValue::query()
                    ->where('tariff_table_id', $tariffTableId)
                    ->select('dt_cm')
                    ->distinct()
                    ->orderByRaw('ABS(CAST(dt_cm AS SIGNED) - ?) asc', [$diameter])
                    ->value('dt_cm');

                if (!is_null($nearestDt)) {
                    $tvQuery = TariffValue::query()
                        ->where('tariff_table_id', $tariffTableId)
                        ->where('dt_cm', (int) $nearestDt);

                    if ($rankMethod === 'h') {
                        $tvQuery = $tvQuery
                            ->where(function ($q) use ($height) {
                                $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $height);
                            })
                            ->where(function ($q) use ($height) {
                                $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $height);
                            })
                            ->orderByRaw('COALESCE(h_min_m, -999) desc');
                    } else {
                        $tvQuery = $tvQuery->where('rank', (int) $manualRankNum);
                    }

                    $tv = $tvQuery->first();

                    if ($tv) {
                        $perLiquid = (float) ($tv->liquid_m3 ?? 0);
                        $perFirewood = (float) ($tv->crown_firewood_m3 ?? 0);
                        $perTotal = is_null($tv->total_m3)
                            ? ($perLiquid + $perFirewood)
                            : (float) $tv->total_m3;
                    }
                }
            }

            $quality = is_null($sourceRow->quality) || $sourceRow->quality === '' ? null : (string) $sourceRow->quality;
            $count = max(1, (int) ($sourceRow->trees_count ?? 1));

            for ($i = 0; $i < $count; $i++) {
                $q1Count = $quality === '1' ? 1 : 0;
                $q2Count = $quality === '2' ? 1 : 0;
                $q1Liquid = $quality === '1' ? $perLiquid : 0.0;
                $q1Firewood = $quality === '1' ? $perFirewood : 0.0;
                $q2Liquid = $quality === '2' ? $perLiquid : 0.0;
                $q2Firewood = $quality === '2' ? $perFirewood : 0.0;

                $reportRows[] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => $speciesLatinName,
                    'diameter_cm' => $diameter,
                    'q1_count' => $q1Count,
                    'q1_liquid' => $q1Liquid,
                    'q1_firewood' => $q1Firewood,
                    'q1_total' => $quality === '1' ? $perTotal : 0.0,
                    'q2_count' => $q2Count,
                    'q2_liquid' => $q2Liquid,
                    'q2_firewood' => $q2Firewood,
                    'q2_total' => $quality === '2' ? $perTotal : 0.0,
                    'all_count' => $q1Count + $q2Count,
                    'all_liquid' => $q1Liquid + $q2Liquid,
                    'all_firewood' => $q1Firewood + $q2Firewood,
                    'all_total' => ($quality === '1' || $quality === '2') ? $perTotal : 0.0,
                    'note' => $note,
                ];
            }
        }

        return $reportRows;
    }
}