<?php

namespace App\Services;

use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use App\DTO\UserData;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserService
{
    public function create(UserData $data): User
    {
        return DB::transaction(function () use ($data) {

            $signaturePath = null;

            if ($data->signatureFile) {
                $signaturePath = $data->signatureFile->store('signatures', 'public');
            }

            $user = User::create([
                'name' => $data->name,
                'surname' => $data->surname,
                'personal_number' => $data->personalNumber,
                'position' => $data->position,
                'email' => $data->email,
                'password' => Hash::make($data->password),
                'signature_path' => $signaturePath,
            ]);

            $this->syncRolesAndPermissions($user, $data);

            return $user;
        });
    }

    public function update(User $user, UserData $data): User
    {
        return DB::transaction(function () use ($user, $data) {

            if ($data->removeSignature) {
                $user->signature_path = null;
            }

            if ($data->signatureFile) {
                $user->signature_path = $data->signatureFile->store('signatures', 'public');
            }

            if ($data->password) {
                $user->password = Hash::make($data->password);
            }

            $user->name = $data->name;
            $user->surname = $data->surname;
            $user->personal_number = $data->personalNumber;
            $user->position = $data->position;
            $user->email = $data->email;
            $user->save();

            $this->syncRolesAndPermissions($user, $data);

            return $user;
        });
    }

    private function syncRolesAndPermissions(User $user, UserData $data): void
    {
        $roleIds = Role::whereIn('name', $data->roles)->pluck('id')->all();
        $user->roles()->sync($roleIds);

        if (in_array('admin', $data->roles)) {
            $allPermissions = Permission::pluck('id')->all();
            $user->permissions()->sync($allPermissions);
            return;
        }

        $permissionIds = Permission::whereIn('name', $data->permissions)->pluck('id')->all();
        $user->permissions()->sync($permissionIds);
    }
}