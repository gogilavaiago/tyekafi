<?php

namespace App\Services;

use App\Models\Tyekafi;

class CompensationCalculator
{
    public function calculateForTyekafi(Tyekafi $tyekafi, array $reportRows, array $smallDiameterRows = [], ?string $selectedYearsRange = null): array
    {
        $yearsValue = $this->resolveUseYears($tyekafi);
        $selectedYearsRange = trim((string) $selectedYearsRange);
        $effectiveYearsRange = $this->resolveEffectiveYearsRange($selectedYearsRange, $yearsValue);
        $yearMultiplier = $this->resolveYearMultiplierByRange($effectiveYearsRange);

        $speciesRows = $this->buildSpeciesRows($tyekafi, $reportRows, $smallDiameterRows, $yearMultiplier);

        $woodCompensation = 0.0;
        foreach ($speciesRows as $row) {
            $woodCompensation += (float) ($row['compensation'] ?? 0);
        }

        $areaM2 = $this->resolveAreaM2($tyekafi);
        $baseAreaCompensation = $this->resolveAreaBaseCompensation($areaM2);
        $areaCompensation = round($baseAreaCompensation * $yearMultiplier, 3);

        return [
            'species_rows' => $speciesRows,
            'wood_compensation' => round($woodCompensation, 3),
            'area_m2' => $areaM2,
            'area_base_compensation' => round($baseAreaCompensation, 3),
            'area_compensation' => $areaCompensation,
            'years_value' => $yearsValue,
            'years_range' => $effectiveYearsRange,
            'year_multiplier' => $yearMultiplier,
            'total_compensation' => round($woodCompensation + $areaCompensation, 3),
            'notes' => $this->buildNotes($tyekafi, $yearsValue, $effectiveYearsRange),
        ];
    }

    private function buildSpeciesRows(Tyekafi $tyekafi, array $reportRows, array $smallDiameterRows = [], float $yearMultiplier = 1.0): array
    {
        $grouped = [];

        foreach ($reportRows as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? ''));
            if ($speciesName === '') {
                continue;
            }

            if (!isset($grouped[$speciesName])) {
                $grouped[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'volume' => 0.0,
                    'is_red_list' => false,
                ];
            }

            if (
                $grouped[$speciesName]['species_latin_name'] === ''
                && trim((string) ($row['species_latin_name'] ?? '')) !== ''
            ) {
                $grouped[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
            }

            $grouped[$speciesName]['volume'] += (float) ($row['all_total'] ?? 0);
            $grouped[$speciesName]['is_red_list'] = $grouped[$speciesName]['is_red_list']
                || $this->noteContainsRedList((string) ($row['note'] ?? ''));
        }

        foreach ($smallDiameterRows as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? ''));
            if ($speciesName === '') {
                continue;
            }

            if (!isset($grouped[$speciesName])) {
                $grouped[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'volume' => 0.0,
                    'is_red_list' => false,
                ];
            }

            if (
                $grouped[$speciesName]['species_latin_name'] === ''
                && trim((string) ($row['species_latin_name'] ?? '')) !== ''
            ) {
                $grouped[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
            }

            $grouped[$speciesName]['volume'] += (float) ($row['volume'] ?? 0);
            $grouped[$speciesName]['is_red_list'] = $grouped[$speciesName]['is_red_list']
                || (bool) ($row['is_red_list'] ?? false);
        }

        ksort($grouped, SORT_NATURAL);

        $rows = [];
        foreach ($grouped as $row) {
            $moneyGroup = $this->resolveSpeciesMoneyGroup($row['species_name'], $row['species_latin_name']);
            $baseRate = (float) (config('compensation.money_by_group.' . $moneyGroup, 0) ?: 0);
            $bodyMultiplier = $this->resolveGoverningBodyMultiplier(
                (string) ($tyekafi->governingBody?->name ?? ''),
                (bool) $row['is_red_list']
            );

            $volume = round((float) $row['volume'], 3);
            $compensationBeforeYears = round($volume * $baseRate * $bodyMultiplier, 3);
            $compensation = round($compensationBeforeYears * $yearMultiplier, 3);

            $rows[] = [
                'species_name' => $row['species_name'],
                'species_latin_name' => $row['species_latin_name'],
                'volume' => $volume,
                'is_red_list' => (bool) $row['is_red_list'],
                'money_group' => $moneyGroup,
                'base_rate' => $baseRate,
                'body_multiplier' => $bodyMultiplier,
                'year_multiplier' => $yearMultiplier,
                'compensation_before_years' => $compensationBeforeYears,
                'compensation' => $compensation,
            ];
        }

        usort($rows, function (array $a, array $b) {
            $cmp = ((float) ($b['compensation'] ?? 0)) <=> ((float) ($a['compensation'] ?? 0));
            if ($cmp !== 0) {
                return $cmp;
            }

            return strnatcasecmp((string) ($a['species_name'] ?? ''), (string) ($b['species_name'] ?? ''));
        });

        return $rows;
    }

    private function noteContainsRedList(string $note): bool
    {
        return str_contains($this->normalize($note), $this->normalize('წითელი ნუსხა'));
    }

    private function resolveSpeciesMoneyGroup(string $speciesName, string $latinName = ''): int
    {
        $map = config('compensation.species_group_map', []);

        foreach ([$speciesName, $latinName] as $candidate) {
            $key = $this->normalize($candidate);
            if ($key !== '' && array_key_exists($key, $map)) {
                return (int) $map[$key];
            }
        }

        return 5;
    }

    private function resolveGoverningBodyMultiplier(string $governingBodyName, bool $isRedList): float
    {
        $config = (array) config('compensation.governing_body_multipliers', []);
        $defaults = (array) ($config['defaults'] ?? []);
        $rules = (array) ($config['body_rules'] ?? []);

        $normalizedBody = $this->normalize($governingBodyName);

        foreach ($rules as $rule) {
            $keywords = array_map(
                fn ($value) => $this->normalize((string) $value),
                (array) ($rule['keywords'] ?? [])
            );

            foreach ($keywords as $keyword) {
                if ($keyword !== '' && str_contains($normalizedBody, $keyword)) {
                    return (float) (
                        $isRedList
                            ? ($rule['red_list'] ?? $defaults['red_list'] ?? 4.0)
                            : ($rule['normal'] ?? $defaults['normal'] ?? 3.0)
                    );
                }
            }
        }

        return (float) (
            $isRedList
                ? ($defaults['red_list'] ?? 4.0)
                : ($defaults['normal'] ?? 3.0)
        );
    }

    private function resolveUseYears(Tyekafi $tyekafi): ?int
    {
        foreach (['use_years', 'requested_years', 'forest_use_years', 'permit_years', 'duration_years'] as $field) {
            $value = data_get($tyekafi, $field);
            if (is_numeric($value) && (float) $value > 0) {
                return (int) round((float) $value);
            }
        }

        return null;
    }

    private function resolveEffectiveYearsRange(?string $selectedYearsRange, ?int $yearsValue): ?string
    {
        $selectedYearsRange = trim((string) $selectedYearsRange);
        $allowedLabels = ['0-5', '6-15', '16-30', '31-49'];

        if (in_array($selectedYearsRange, $allowedLabels, true)) {
            return $selectedYearsRange;
        }

        foreach ((array) config('compensation.year_multipliers', []) as $row) {
            $label = trim((string) ($row['label'] ?? ''));
            if ($label !== '' && $label === $selectedYearsRange) {
                return $label;
            }
        }

        if (is_null($yearsValue) || $yearsValue <= 0) {
            return null;
        }

        foreach ((array) config('compensation.year_multipliers', []) as $row) {
            $min = isset($row['min']) ? (int) $row['min'] : null;
            $max = isset($row['max']) && !is_null($row['max']) ? (int) $row['max'] : null;
            $label = trim((string) ($row['label'] ?? ''));

            if (!is_null($min) && $yearsValue < $min) {
                continue;
            }

            if (is_null($max) || $yearsValue <= $max) {
                if ($label !== '') {
                    return $label;
                }

                return match (true) {
                    $min === 0 && $max === 5 => '0-5',
                    $min === 6 && $max === 15 => '6-15',
                    $min === 16 && $max === 30 => '16-30',
                    $min === 31 && $max === 49 => '31-49',
                    default => null,
                };
            }
        }

        return null;
    }

    private function resolveYearMultiplierByRange(?string $rangeLabel): float
    {
        $rangeLabel = trim((string) $rangeLabel);

        foreach ((array) config('compensation.year_multipliers', []) as $row) {
            $label = trim((string) ($row['label'] ?? ''));
            if ($label !== '' && $label === $rangeLabel) {
                return (float) ($row['k'] ?? 1.0);
            }
        }

        return match ($rangeLabel) {
            '0-5' => 1.0,
            '6-15' => 2.0,
            '16-30' => 3.0,
            '31-49' => 4.0,
            default => 1.0,
        };
    }

    private function resolveAreaM2(Tyekafi $tyekafi): int
    {
        $areaHa = (float) ($tyekafi->area_ha ?? 0);
        if ($areaHa <= 0) {
            return 0;
        }

        return (int) round($areaHa * 10000);
    }

    private function resolveAreaBaseCompensation(int $areaM2): float
    {
        $areaRates = (array) config('compensation.area_rates', []);

        if ($areaM2 <= 0) {
            return 0.0;
        }

        foreach ($areaRates as $rate) {
            $min = isset($rate['min']) ? (int) $rate['min'] : null;
            $max = array_key_exists('max', $rate) ? $rate['max'] : null;

            if (!is_null($min) && $areaM2 < $min) {
                continue;
            }

            if (!is_null($max) && $areaM2 > (int) $max) {
                continue;
            }

            if (array_key_exists('amount', $rate)) {
                return round((float) $rate['amount'], 3);
            }

            if (array_key_exists('per_m2', $rate)) {
                $threshold = (int) ($rate['threshold'] ?? 0);
                $baseAmount = (float) ($rate['base_amount'] ?? 0);
                $perM2 = (float) ($rate['per_m2'] ?? 0);

                return round((($areaM2 - $threshold) * $perM2) + $baseAmount, 3);
            }
        }

        if ($areaM2 <= 500) {
            return 500.000;
        }

        if ($areaM2 <= 1000) {
            return 1000.000;
        }

        if ($areaM2 <= 5000) {
            return 1600.000;
        }

        return round((($areaM2 - 5000) * 0.36) + 1600, 3);
    }

    private function buildNotes(Tyekafi $tyekafi, ?int $yearsValue, ?string $effectiveYearsRange): array
    {
        $notes = [
            'ხემცენარეების საკომპენსაციო ნაწილი დათვლილია საბაზისო ტარიფის, K მართვის ორგანო / სახეობა და K სარგებლობის ვადის გამოყენებით.',
            'ფართობის საკომპენსაციო ნაწილი დათვლილია ფართობის ცხრილის მიხედვით და გამოყენებულია ფართობი კვ.მ-ში.',
        ];

        if (!is_null($effectiveYearsRange) && trim($effectiveYearsRange) !== '') {
            $notes[] = 'სარგებლობის ვადა გამოყენებულია ინტერვალით: ' . $effectiveYearsRange . '.';
        } elseif (is_null($yearsValue)) {
            $notes[] = 'წლების კოეფიციენტი გამოყენებულია როგორც K = 1, რადგან სისტემაში მოთხოვნილი სარგებლობის წლების ცალკე ველი ჯერ არ არსებობს.';
        } else {
            $notes[] = 'წლების კოეფიციენტი დათვლილია სისტემაში არსებული წლების მნიშვნელობით: ' . $yearsValue . '.';
        }

        if (trim((string) ($tyekafi->governingBody?->name ?? '')) === '') {
            $notes[] = 'მართვის ორგანო არ იყო შევსებული, ამიტომ გამოყენებულია სტანდარტული კოეფიციენტი.';
        }

        return $notes;
    }

    private function normalize(string $value): string
    {
        $value = trim($value);
        $value = preg_replace('/\s+/u', ' ', $value) ?: '';

        return mb_strtolower(str_replace(['’', '`'], "'", $value));
    }
}