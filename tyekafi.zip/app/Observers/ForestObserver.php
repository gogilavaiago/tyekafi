<?php

namespace App\Observers;

use App\Models\Forest;

class ForestObserver
{
    public function deleting(Forest $forest): void
    {
        if ($forest->isForceDeleting()) {
            return;
        }

        $forest->quarters()
            ->whereNull('deleted_at')
            ->chunkById(1000, function ($quarters) {
                foreach ($quarters as $quarter) {
                    $quarter->forceFill(['deleted_by_parent' => true])->saveQuietly();
                    $quarter->delete();
                }
            });
    }

    public function restoring(Forest $forest): void
    {
        $forest->quarters()
            ->onlyTrashed()
            ->where('deleted_by_parent', true)
            ->chunkById(1000, function ($quarters) {
                foreach ($quarters as $quarter) {
                    $quarter->restore();
                    $quarter->forceFill(['deleted_by_parent' => false])->saveQuietly();
                }
            });
    }
}