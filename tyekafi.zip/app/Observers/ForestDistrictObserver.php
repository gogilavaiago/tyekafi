<?php

namespace App\Observers;

use App\Models\ForestDistrict;

class ForestDistrictObserver
{
    public function deleting(ForestDistrict $district): void
    {
        if ($district->isForceDeleting()) {
            return;
        }

        $district->forests()
            ->whereNull('deleted_at')
            ->chunkById(1000, function ($forests) {
                foreach ($forests as $forest) {
                    $forest->forceFill(['deleted_by_parent' => true])->saveQuietly();
                    $forest->delete();
                }
            });
    }

    public function restoring(ForestDistrict $district): void
    {
        $district->forests()
            ->onlyTrashed()
            ->where('deleted_by_parent', true)
            ->chunkById(1000, function ($forests) {
                foreach ($forests as $forest) {
                    $forest->restore();
                    $forest->forceFill(['deleted_by_parent' => false])->saveQuietly();
                }
            });
    }
}