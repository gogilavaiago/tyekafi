<?php

namespace App\Observers;

use App\Models\GoverningBody;

class GoverningBodyObserver
{
    public function deleting(GoverningBody $gb): void
    {
        if ($gb->isForceDeleting()) {
            return;
        }

        $gb->regions()
            ->whereNull('deleted_at')
            ->chunkById(1000, function ($regions) {
                foreach ($regions as $region) {
                    $region->forceFill(['deleted_by_parent' => true])->saveQuietly();
                    $region->delete();
                }
            });
    }

    public function restoring(GoverningBody $gb): void
    {
        $gb->regions()
            ->onlyTrashed()
            ->where('deleted_by_parent', true)
            ->chunkById(1000, function ($regions) {
                foreach ($regions as $region) {
                    $region->restore();
                    $region->forceFill(['deleted_by_parent' => false])->saveQuietly();
                }
            });
    }
}