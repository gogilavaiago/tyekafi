<?php

namespace App\Observers;

use App\Models\Quarter;

class QuarterObserver
{
    public function deleting(Quarter $quarter): void
    {
        if ($quarter->isForceDeleting()) {
            return;
        }

        $quarter->liters()
            ->whereNull('deleted_at')
            ->chunkById(1000, function ($liters) {
                foreach ($liters as $liter) {
                    $liter->forceFill(['deleted_by_parent' => true])->saveQuietly();
                    $liter->delete();
                }
            });
    }

    public function restoring(Quarter $quarter): void
    {
        $quarter->liters()
            ->onlyTrashed()
            ->where('deleted_by_parent', true)
            ->chunkById(1000, function ($liters) {
                foreach ($liters as $liter) {
                    $liter->restore();
                    $liter->forceFill(['deleted_by_parent' => false])->saveQuietly();
                }
            });
    }
}