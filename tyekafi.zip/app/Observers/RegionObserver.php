<?php

namespace App\Observers;

use App\Models\Region;

class RegionObserver
{
    public function deleting(Region $region): void
    {
        if ($region->isForceDeleting()) {
            return;
        }

        $region->districts()
            ->whereNull('deleted_at')
            ->chunkById(1000, function ($districts) {
                foreach ($districts as $district) {
                    $district->forceFill(['deleted_by_parent' => true])->saveQuietly();
                    $district->delete();
                }
            });
    }

    public function restoring(Region $region): void
    {
        $region->districts()
            ->onlyTrashed()
            ->where('deleted_by_parent', true)
            ->chunkById(1000, function ($districts) {
                foreach ($districts as $district) {
                    $district->restore();
                    $district->forceFill(['deleted_by_parent' => false])->saveQuietly();
                }
            });
    }
}
