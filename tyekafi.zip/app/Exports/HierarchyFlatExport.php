<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class HierarchyFlatExport implements FromCollection, WithHeadings
{
    private array $rows;
    private array $headings;

    public function __construct(array $rows, array $headings)
    {
        $this->rows = $rows;
        $this->headings = $headings;
    }

    public function collection(): Collection
    {
        // rows must be array of numeric arrays already aligned with headings
        return collect($this->rows);
    }

    public function headings(): array
    {
        return $this->headings;
    }
}