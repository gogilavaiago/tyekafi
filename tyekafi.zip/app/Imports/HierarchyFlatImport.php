<?php

namespace App\Imports;

use Maatwebsite\Excel\Concerns\ToArray;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;

class HierarchyFlatImport implements ToArray, WithCalculatedFormulas
{
    /** @var array<int, array<int, mixed>> */
    public array $rows = [];

    public function array(array $array)
    {
        // $array = rows; each row is array of cells
        $this->rows = $array;
    }
}
