<?php

namespace App\Imports;

use Illuminate\Support\Arr;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Row;

class HierarchyChunkImport implements OnEachRow, WithChunkReading, WithStartRow
{
    private $onRow;

    public function __construct(callable $onRow)
    {
        $this->onRow = $onRow;
    }

    public function onRow(Row $row): void
    {
        $values = $row->toArray();
        $values = Arr::wrap($values);

        ($this->onRow)($values, $row->getIndex());
    }

    public function chunkSize(): int
    {
        return 1000;
    }

    public function startRow(): int
    {
        return 1;
    }
}