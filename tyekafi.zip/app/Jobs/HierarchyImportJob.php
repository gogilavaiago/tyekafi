<?php

namespace App\Jobs;

use App\Imports\HierarchyChunkImport;
use App\Models\Forest;
use App\Models\ForestDistrict;
use App\Models\GoverningBody;
use App\Models\HierarchyImportLog;
use App\Models\Liter;
use App\Models\Quarter;
use App\Models\Region;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class HierarchyImportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 1200;

    public function __construct(
        public string $token,
        public string $jobId,
        public int $logId,
        public string $storedPath,
        public string $ext = 'csv',
        public int $totalRows = 0,
    ) {
        $this->ext = strtolower($this->ext ?: 'csv');
    }

    public function handle(): void
    {
        $log = HierarchyImportLog::find($this->logId);

        try {
            if ($log) {
                $log->update(['status' => 'running']);
            }

            if (!Storage::disk('local')->exists($this->storedPath)) {
                throw new \RuntimeException('ფაილი ვერ მოიძებნა storage-ში: ' . $this->storedPath);
            }

            $created = $this->zeroCreated();
            $done = 0;
            $total = max($this->totalRows, (int) ($log?->rows_ready ?? 0), 1);

            $this->writeProgress('running', 'მუშავდება…', $done, $total, $created);

            $gbCache = [];
            $regionCache = [];
            $districtCache = [];
            $forestCache = [];
            $quarterCache = [];
            $literCache = [];
            $seenInFile = [];

            $process = function (array $row, int $rowNumber) use (
                &$done,
                $total,
                &$created,
                &$gbCache,
                &$regionCache,
                &$districtCache,
                &$forestCache,
                &$quarterCache,
                &$literCache,
                &$seenInFile,
                $log
            ) {
                $gbCode = trim((string) ($row[0] ?? ''));
                $gbName = trim((string) ($row[1] ?? ''));

                $regionCode = trim((string) ($row[2] ?? ''));
                $regionName = trim((string) ($row[3] ?? ''));

                $districtCode = trim((string) ($row[4] ?? ''));
                $districtName = trim((string) ($row[5] ?? ''));

                $forestCode = trim((string) ($row[6] ?? ''));
                $forestName = trim((string) ($row[7] ?? ''));

                $quarterCode = trim((string) ($row[8] ?? ''));
                $quarterName = trim((string) ($row[9] ?? ''));

                $literCode = trim((string) ($row[10] ?? ''));
                $literName = trim((string) ($row[11] ?? ''));

                if (
                    $gbCode === '' || $gbName === ''
                    || $regionCode === '' || $regionName === ''
                    || $districtCode === '' || $districtName === ''
                    || $forestCode === '' || $forestName === ''
                    || $quarterCode === '' || $quarterName === ''
                    || $literCode === '' || $literName === ''
                ) {
                    return;
                }

                $lower0 = mb_strtolower($gbCode);
                if ($rowNumber === 1 && (str_contains($lower0, 'governing') || str_contains($lower0, 'gb'))) {
                    return;
                }

                $key = implode('|', [
                    $gbCode,
                    $regionCode,
                    $districtCode,
                    $forestCode,
                    $quarterCode,
                    $literCode,
                ]);

                if (isset($seenInFile[$key])) {
                    return;
                }
                $seenInFile[$key] = true;

                DB::transaction(function () use (
                    $gbCode,
                    $gbName,
                    $regionCode,
                    $regionName,
                    $districtCode,
                    $districtName,
                    $forestCode,
                    $forestName,
                    $quarterCode,
                    $quarterName,
                    $literCode,
                    $literName,
                    &$created,
                    &$gbCache,
                    &$regionCache,
                    &$districtCache,
                    &$forestCache,
                    &$quarterCache,
                    &$literCache
                ) {
                    // GB
                    $gbId = $gbCache[$gbCode] ?? null;
                    if (!$gbId) {
                        $gb = GoverningBody::withTrashed()
                            ->where('code', $gbCode)
                            ->first();

                        if (!$gb) {
                            $gb = GoverningBody::create([
                                'code' => $gbCode,
                                'name' => $gbName,
                            ]);
                            $created['governing_bodies']++;
                        } elseif ($gb->trashed()) {
                            $gb->restore();
                            if ($gb->name !== $gbName) {
                                $gb->update(['name' => $gbName]);
                            }
                        } elseif ($gb->name !== $gbName) {
                            $gb->update(['name' => $gbName]);
                        }

                        $gbId = $gb->id;
                        $gbCache[$gbCode] = $gbId;
                    }

                    // Region
                    $regionKey = $gbId . '|' . $regionCode;
                    $regionId = $regionCache[$regionKey] ?? null;
                    if (!$regionId) {
                        $region = Region::withTrashed()
                            ->where('governing_body_id', $gbId)
                            ->where('code', $regionCode)
                            ->first();

                        if (!$region) {
                            $region = Region::create([
                                'governing_body_id' => $gbId,
                                'code' => $regionCode,
                                'name' => $regionName,
                            ]);
                            $created['regions']++;
                        } elseif ($region->trashed()) {
                            $region->restore();
                            if ($region->name !== $regionName) {
                                $region->update(['name' => $regionName]);
                            }
                        } elseif ($region->name !== $regionName) {
                            $region->update(['name' => $regionName]);
                        }

                        $regionId = $region->id;
                        $regionCache[$regionKey] = $regionId;
                    }

                    // District
                    $districtKey = $regionId . '|' . $districtCode;
                    $districtId = $districtCache[$districtKey] ?? null;
                    if (!$districtId) {
                        $district = ForestDistrict::withTrashed()
                            ->where('region_id', $regionId)
                            ->where('code', $districtCode)
                            ->first();

                        if (!$district) {
                            $district = ForestDistrict::create([
                                'governing_body_id' => $gbId,
                                'region_id' => $regionId,
                                'code' => $districtCode,
                                'name' => $districtName,
                            ]);
                            $created['districts']++;
                        } elseif ($district->trashed()) {
                            $district->restore();

                            $update = [];
                            if ((int) $district->governing_body_id !== (int) $gbId) {
                                $update['governing_body_id'] = $gbId;
                            }
                            if ((int) $district->region_id !== (int) $regionId) {
                                $update['region_id'] = $regionId;
                            }
                            if ($district->name !== $districtName) {
                                $update['name'] = $districtName;
                            }
                            if (!empty($update)) {
                                $district->update($update);
                            }
                        } else {
                            $update = [];
                            if ((int) $district->governing_body_id !== (int) $gbId) {
                                $update['governing_body_id'] = $gbId;
                            }
                            if ((int) $district->region_id !== (int) $regionId) {
                                $update['region_id'] = $regionId;
                            }
                            if ($district->name !== $districtName) {
                                $update['name'] = $districtName;
                            }
                            if (!empty($update)) {
                                $district->update($update);
                            }
                        }

                        $districtId = $district->id;
                        $districtCache[$districtKey] = $districtId;
                    }

                    // Forest
                    $forestKey = $districtId . '|' . $forestCode;
                    $forestId = $forestCache[$forestKey] ?? null;
                    if (!$forestId) {
                        $forest = Forest::withTrashed()
                            ->where('forest_district_id', $districtId)
                            ->where('code', $forestCode)
                            ->first();

                        if (!$forest) {
                            $forest = Forest::create([
                                'forest_district_id' => $districtId,
                                'code' => $forestCode,
                                'name' => $forestName,
                            ]);
                            $created['forests']++;
                        } elseif ($forest->trashed()) {
                            $forest->restore();
                            if ($forest->name !== $forestName) {
                                $forest->update(['name' => $forestName]);
                            }
                        } elseif ($forest->name !== $forestName) {
                            $forest->update(['name' => $forestName]);
                        }

                        $forestId = $forest->id;
                        $forestCache[$forestKey] = $forestId;
                    }

                    // Quarter
                    $quarterKey = $forestId . '|' . $quarterCode;
                    $quarterId = $quarterCache[$quarterKey] ?? null;
                    if (!$quarterId) {
                        $quarter = Quarter::withTrashed()
                            ->where('forest_id', $forestId)
                            ->where('code', $quarterCode)
                            ->first();

                        if (!$quarter) {
                            $quarter = Quarter::create([
                                'forest_id' => $forestId,
                                'code' => $quarterCode,
                                'name' => $quarterName,
                            ]);
                            $created['quarters']++;
                        } elseif ($quarter->trashed()) {
                            $quarter->restore();
                            if ($quarter->name !== $quarterName) {
                                $quarter->update(['name' => $quarterName]);
                            }
                        } elseif ($quarter->name !== $quarterName) {
                            $quarter->update(['name' => $quarterName]);
                        }

                        $quarterId = $quarter->id;
                        $quarterCache[$quarterKey] = $quarterId;
                    }

                    // Liter
                    $literKey = $quarterId . '|' . $literCode;
                    if (!isset($literCache[$literKey])) {
                        $liter = Liter::withTrashed()
                            ->where('quarter_id', $quarterId)
                            ->where('code', $literCode)
                            ->first();

                        if (!$liter) {
                            $liter = Liter::create([
                                'quarter_id' => $quarterId,
                                'code' => $literCode,
                                'name' => $literName,
                            ]);
                            $created['liters']++;
                        } elseif ($liter->trashed()) {
                            $liter->restore();
                            if ($liter->name !== $literName) {
                                $liter->update(['name' => $literName]);
                            }
                        } elseif ($liter->name !== $literName) {
                            $liter->update(['name' => $literName]);
                        }

                        $literCache[$literKey] = $liter->id;
                    }
                });

                $done++;

                if ($done % 500 === 0) {
                    $this->writeProgress('running', 'მუშავდება…', $done, $total, $created);

                    if ($log) {
                        $update = ['status' => 'running'];

                        if (Schema::hasColumn('hierarchy_import_logs', 'progress')) {
                            $update['progress'] = $done;
                        }

                        $log->update($update);
                    }
                }
            };

            if (in_array($this->ext, ['xlsx', 'xls'], true)) {
                $import = new HierarchyChunkImport(function (array $row, int $rowIndex) use ($process) {
                    $process($row, $rowIndex);
                });

                Excel::import($import, $this->storedPath, 'local');
            } else {
                $stream = Storage::disk('local')->readStream($this->storedPath);
                if (!$stream) {
                    throw new \RuntimeException('CSV stream ვერ გაიხსნა');
                }

                $firstLine = fgets($stream);
                if ($firstLine === false) {
                    fclose($stream);
                    throw new \RuntimeException('CSV ცარიელია');
                }

                $delims = [',', ';', "\t"];
                $delimiter = ',';
                $best = 0;

                foreach ($delims as $d) {
                    $c = count(str_getcsv($firstLine, $d));
                    if ($c > $best) {
                        $best = $c;
                        $delimiter = $d;
                    }
                }

                rewind($stream);

                $rowNumber = 0;
                while (($row = fgetcsv($stream, 0, $delimiter)) !== false) {
                    $rowNumber++;
                    $process($row, $rowNumber);
                }

                fclose($stream);
            }

            [$csvPath, $pdfPath] = $this->generateReports($created, $done);

            $this->writeProgress('done', 'დასრულდა ✅', $done, $total, $created);

            if ($log) {
                $update = [
                    'status' => 'done',
                    'finished_at' => now(),
                    'report_csv_path' => $csvPath,
                    'report_pdf_path' => $pdfPath,
                    'error_message' => null,
                ];

                if (Schema::hasColumn('hierarchy_import_logs', 'progress')) {
                    $update['progress'] = $done;
                }

                if (Schema::hasColumn('hierarchy_import_logs', 'stats_created')) {
                    $update['stats_created'] = $created;
                }

                $log->update($update);
            }
        } catch (\Throwable $e) {
            $this->writeProgress('error', $e->getMessage(), 0, max($this->totalRows, 1), $this->zeroCreated());

            if ($log) {
                $log->update([
                    'status' => 'error',
                    'finished_at' => now(),
                    'error_message' => $e->getMessage(),
                ]);
            }

            throw $e;
        } finally {
            if ($this->storedPath && Storage::disk('local')->exists($this->storedPath)) {
                Storage::disk('local')->delete($this->storedPath);
            }
        }
    }

    private function generateReports(array $created, int $done): array
    {
        $dir = 'reports';

        if (!Storage::disk('local')->exists($dir)) {
            Storage::disk('local')->makeDirectory($dir);
        }

        $csvPath = "{$dir}/hierarchy_import_{$this->jobId}_summary.csv";

        $out = fopen('php://temp', 'r+');
        fputcsv($out, ['job_id', $this->jobId]);
        fputcsv($out, ['token', $this->token]);
        fputcsv($out, ['done_rows', $done]);
        fputcsv($out, []);
        fputcsv($out, ['created_governing_bodies', $created['governing_bodies'] ?? 0]);
        fputcsv($out, ['created_regions', $created['regions'] ?? 0]);
        fputcsv($out, ['created_districts', $created['districts'] ?? 0]);
        fputcsv($out, ['created_forests', $created['forests'] ?? 0]);
        fputcsv($out, ['created_quarters', $created['quarters'] ?? 0]);
        fputcsv($out, ['created_liters', $created['liters'] ?? 0]);

        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);

        Storage::disk('local')->put($csvPath, $csv);

        $pdfPath = null;

        if (class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
            $html = '<!doctype html><html><head><meta charset="utf-8">'
                . '<style>
                    body { font-family: "DejaVu Sans", sans-serif; font-size: 12px; }
                    h2 { margin-bottom: 10px; }
                    ul { margin-top: 8px; }
                  </style>'
                . '</head><body>';

            $html .= '<h2>იმპორტის შეჯამება (Hierarchy Import Summary)</h2>';
            $html .= '<p><b>Job:</b> ' . e($this->jobId) . '</p>';
            $html .= '<p><b>Rows processed:</b> ' . e((string) $done) . '</p>';
            $html .= '<ul>';
            $html .= '<li>GB: ' . e((string) ($created['governing_bodies'] ?? 0)) . '</li>';
            $html .= '<li>Regions: ' . e((string) ($created['regions'] ?? 0)) . '</li>';
            $html .= '<li>Districts: ' . e((string) ($created['districts'] ?? 0)) . '</li>';
            $html .= '<li>Forests: ' . e((string) ($created['forests'] ?? 0)) . '</li>';
            $html .= '<li>Quarters: ' . e((string) ($created['quarters'] ?? 0)) . '</li>';
            $html .= '<li>Liters: ' . e((string) ($created['liters'] ?? 0)) . '</li>';
            $html .= '</ul>';
            $html .= '</body></html>';

            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadHTML($html)
                ->setOption('defaultFont', 'DejaVu Sans');

            $pdfPath = "{$dir}/hierarchy_import_{$this->jobId}_summary.pdf";
            Storage::disk('local')->put($pdfPath, $pdf->output());
        }

        return [$csvPath, $pdfPath];
    }

    private function zeroCreated(): array
    {
        return [
            'governing_bodies' => 0,
            'regions' => 0,
            'districts' => 0,
            'forests' => 0,
            'quarters' => 0,
            'liters' => 0,
        ];
    }

    private function writeProgress(string $status, string $message, int $done, int $total, array $created): void
    {
        $percent = $total > 0 ? (int) floor(($done / $total) * 100) : 0;

        Cache::put("hierarchy_import_progress:{$this->jobId}", [
            'status' => $status,
            'message' => $message,
            'done' => $done,
            'total' => $total,
            'percent' => $percent,
            'created' => $created,
        ], now()->addHours(2));
    }
}