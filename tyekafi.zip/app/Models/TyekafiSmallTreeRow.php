<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TyekafiSmallTreeRow extends Model
{
    protected $table = 'tyekafi_small_tree_rows';

    protected $fillable = [
        'tyekafi_id',
        'tree_species_id',
        'quantity',
        'row_order',
    ];

    public function tyekafi(): BelongsTo
    {
        return $this->belongsTo(Tyekafi::class);
    }

    public function species(): BelongsTo
    {
        return $this->belongsTo(TreeSpecies::class, 'tree_species_id');
    }
}
