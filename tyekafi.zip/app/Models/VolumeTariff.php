<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VolumeTariff extends Model
{
    protected $fillable = [
        'species',
        'rank',
        'dt_cm',
        'h_m',
        'liquid_m3',
        'crown_firewood_m3',
    ];

    protected $casts = [
        'rank' => 'integer',
        'dt_cm' => 'integer',
        'h_m' => 'float',
        'liquid_m3' => 'float',
        'crown_firewood_m3' => 'float',
    ];
}