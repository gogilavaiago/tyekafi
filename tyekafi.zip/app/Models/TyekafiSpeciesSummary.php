<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TyekafiSpeciesSummary extends Model
{
    protected $table = 'tyekafi_species_summaries';

    protected $fillable = [
        'tyekafi_id',
        'tree_species_id',
        'avg_diameter_cm',
        'applied_dt_cm',
        'height_m',
        'tree_rank_id',
        'rank_method',
        'manual_rank_num',
        'handwritten_sequence',
        'liquid_m3',
        'firewood_m3',
        'issued_m3',
    ];

    public function tyekafi(): BelongsTo
    {
        return $this->belongsTo(Tyekafi::class, 'tyekafi_id');
    }

    public function species(): BelongsTo
    {
        return $this->belongsTo(TreeSpecies::class, 'tree_species_id');
    }

    public function rank(): BelongsTo
    {
        return $this->belongsTo(TreeRank::class, 'tree_rank_id');
    }
}