<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class HierarchyImportLog extends Model
{
    protected $fillable = [
        'user_id',
        'job_id',
        'token',
        'filename',
        'status',

        'rows_total',
        'rows_ready',
        'rows_skipped',
        'rows_file_duplicates',

        'stats_create',
        'stats_exists',
        'stats_created',
        'time',

        'progress',
        'started_at',
        'finished_at',

        'report_csv_path',
        'report_pdf_path',
        'error_message',
    ];

    protected $casts = [
        'stats_create' => 'array',
        'stats_exists' => 'array',
        'stats_created' => 'array',
        'time' => 'array',

        'started_at' => 'datetime',
        'finished_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}