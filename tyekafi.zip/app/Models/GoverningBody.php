<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class GoverningBody extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'code',
        'name',
    ];

    public function regions(): HasMany
    {
        return $this->hasMany(Region::class, 'governing_body_id');
    }

    public function districts(): HasMany
    {
        return $this->hasMany(ForestDistrict::class, 'governing_body_id');
    }
}