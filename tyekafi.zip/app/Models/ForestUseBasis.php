<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ForestUseBasis extends Model
{
    protected $fillable = [
        'code',
        'title',
        'is_active',
        'sort_order',
    ];
}