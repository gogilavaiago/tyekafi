<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quarter extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'forest_id',
        'code',
        'name',
    ];

    protected $casts = [
        'deleted_by_parent' => 'boolean',
    ];

    public function forest(): BelongsTo
    {
        return $this->belongsTo(Forest::class, 'forest_id');
    }

    public function liters(): HasMany
    {
        return $this->hasMany(Liter::class, 'quarter_id');
    }
}