<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TariffTable extends Model
{
    protected $fillable = [
        'code',
        'name',
        'notes',
    ];

    public function values(): HasMany
    {
        return $this->hasMany(TariffValue::class, 'tariff_table_id');
    }

    public function speciesMappings(): HasMany
    {
        return $this->hasMany(TariffSpeciesMapping::class, 'tariff_table_id');
    }
}