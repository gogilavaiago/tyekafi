<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Tyekafi extends Model
{
    protected $fillable = [
        'project_id',
        'user_id',
        'name',
        'description',

        'governing_body_id',
        'region_id',
        'forest_district_id',
        'forest_id',
        'quarter_id',
        'liter_id',
        'manual_quarter',
        'manual_liters',

        'marking_start_date',
        'marking_end_date',
        'forest_use_basis',
        'forest_user_name',
        'forest_user_id_code',
        'forest_user_address',
        'area_ha',
        'cut_purpose',
        'cut_type',
        'cut_percent',
        'szd',
        'frequency_actual',
        'frequency_plan',
        'regen_count_actual',
        'regen_count_plan',
        'age_actual',
        'age_plan',
        'exposure_actual',
        'exposure_plan',
        'slope_actual',
        'slope_plan',
        'gps_x1',
        'gps_y1',
        'gps_x2',
        'gps_y2',
        'inventory_method',
        'sample_plot_type',
        'sample_plot_area',
        'multiplier_coeff',
    ];

    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function governingBody(): BelongsTo
    {
        return $this->belongsTo(GoverningBody::class, 'governing_body_id');
    }

    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class, 'region_id');
    }

    public function forestDistrict(): BelongsTo
    {
        return $this->belongsTo(ForestDistrict::class, 'forest_district_id');
    }

    public function forest(): BelongsTo
    {
        return $this->belongsTo(Forest::class, 'forest_id');
    }

    public function quarter(): BelongsTo
    {
        return $this->belongsTo(Quarter::class, 'quarter_id');
    }

    public function liters(): BelongsToMany
    {
        return $this->belongsToMany(Liter::class, 'tyekafi_liter', 'tyekafi_id', 'liter_id')
            ->withTimestamps();
    }

    public function treeRows(): HasMany
    {
        return $this->hasMany(TyekafiTreeRow::class, 'tyekafi_id');
    }

    public function smallTreeRows(): HasMany
    {
        return $this->hasMany(TyekafiSmallTreeRow::class, 'tyekafi_id');
    }

    public function speciesSummaries(): HasMany
    {
        return $this->hasMany(TyekafiSpeciesSummary::class, 'tyekafi_id');
    }

    public function getDisplayQuarterAttribute(): string
    {
        $manual = trim((string) ($this->manual_quarter ?? ''));
        if ($manual !== '') {
            return $manual;
        }

        return (string) ($this->quarter?->name ?? $this->quarter?->number ?? '—');
    }

    public function getDisplayLitersAttribute(): string
    {
        $manual = trim((string) ($this->manual_liters ?? ''));
        if ($manual !== '') {
            return $manual;
        }

        $fromRelation = $this->relationLoaded('liters')
            ? $this->liters?->pluck('name')->filter()->implode(', ')
            : $this->liters()->pluck('name')->filter()->implode(', ');

        return $fromRelation !== '' ? $fromRelation : '—';
    }

}
