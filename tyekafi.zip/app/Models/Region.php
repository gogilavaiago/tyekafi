<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Region extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'governing_body_id',
        'code',
        'name',
        'deleted_by_parent',
    ];

    protected $casts = [
        'deleted_by_parent' => 'boolean',
    ];

    public function governingBody(): BelongsTo
    {
        return $this->belongsTo(GoverningBody::class, 'governing_body_id');
    }

    public function districts(): HasMany
    {
        return $this->hasMany(ForestDistrict::class, 'region_id');
    }
}
