<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TariffSpeciesMapping extends Model
{
    protected $fillable = [
        'species_name',
        'tariff_table_id',
        'notes',
    ];

    public function table(): BelongsTo
    {
        return $this->belongsTo(TariffTable::class, 'tariff_table_id');
    }
}