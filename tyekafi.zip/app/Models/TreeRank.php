<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TreeRank extends Model
{
    protected $table = 'tree_ranks';

    protected $fillable = [
        'tree_species_id',
        'name',
        'rank_num',
        'h_min_m',
        'h_max_m',
    ];

    public function species(): BelongsTo
    {
        return $this->belongsTo(TreeSpecies::class, 'tree_species_id');
    }
}