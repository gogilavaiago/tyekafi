<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class ForestDistrict extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'governing_body_id',
        'region_id',
        'code',
        'name',
    ];

    protected $casts = [
        'deleted_by_parent' => 'boolean',
    ];

    public function governingBody(): BelongsTo
    {
        return $this->belongsTo(GoverningBody::class, 'governing_body_id');
    }

    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class, 'region_id');
    }

    public function forests(): HasMany
    {
        return $this->hasMany(Forest::class, 'forest_district_id');
    }
}