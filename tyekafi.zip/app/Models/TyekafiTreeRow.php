<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TyekafiTreeRow extends Model
{
    protected $table = 'tyekafi_tree_rows';

    protected $fillable = [
        'tyekafi_id',
        'tree_species_id',
        'tree_rank_id',
        'diameter_cm',
        'quality',
        'trees_count',
        'liquid_m3',
        'firewood_m3',
        'issued_m3',
        'row_order',
        'note',
    ];

    public function tyekafi(): BelongsTo
    {
        return $this->belongsTo(Tyekafi::class);
    }

    public function species(): BelongsTo
    {
        return $this->belongsTo(TreeSpecies::class, 'tree_species_id');
    }

    public function rank(): BelongsTo
    {
        return $this->belongsTo(TreeRank::class, 'tree_rank_id');
    }
}
