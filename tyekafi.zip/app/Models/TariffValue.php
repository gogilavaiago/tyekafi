<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TariffValue extends Model
{
    protected $fillable = [
     'tariff_table_id',
     'rank',
     'dt_cm',
     'h_min_m',
     'h_max_m',
     'liquid_m3',
     'crown_firewood_m3',
     'total_m3'
];

    protected $casts = [
        'rank' => 'integer',
        'dt_cm' => 'integer',
        'liquid_m3' => 'float',
        'crown_firewood_m3' => 'float',
    ];

    public function table(): BelongsTo
    {
        return $this->belongsTo(TariffTable::class, 'tariff_table_id');
    }
}