<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Forest extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'forest_district_id',
        'code',
        'name',
    ];

    protected $casts = [
        'deleted_by_parent' => 'boolean',
    ];

    public function district(): BelongsTo
    {
        return $this->belongsTo(ForestDistrict::class, 'forest_district_id');
    }

    public function quarters(): HasMany
    {
        return $this->hasMany(Quarter::class, 'forest_id');
    }
}