<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TreeSpecies extends Model
{
    protected $table = 'tree_species';

    protected $fillable = [
        'name',
        'short_name',
        'latin_name',
        'red_list',
    ];

    public function ranks(): HasMany
    {
        return $this->hasMany(TreeRank::class, 'tree_species_id');
    }
}