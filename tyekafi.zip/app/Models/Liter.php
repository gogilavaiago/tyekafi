<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Liter extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'quarter_id',
        'code',
        'name',
    ];

    protected $casts = [
        'deleted_by_parent' => 'boolean',
    ];

    public function quarter(): BelongsTo
    {
        return $this->belongsTo(Quarter::class, 'quarter_id');
    }
}