<?php

namespace App\DTO\Hierarchy;

class GoverningBodyData
{
    public function __construct(
        public ?string $code,
        public string $name,
    ) {}

    public static function fromRequest($request): self
    {
        $code = $request->input('code');
        $code = is_string($code) ? trim($code) : null;
        if ($code === '') {
            $code = null;
        }

        return new self(
            code: $code,
            name: (string) $request->input('name'),
        );
    }
}