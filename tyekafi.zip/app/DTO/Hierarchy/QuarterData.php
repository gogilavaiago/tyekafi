<?php

namespace App\DTO\Hierarchy;

class QuarterData
{
    public function __construct(
        public int $forestId,
        public ?string $code,
        public string $name,
    ) {}

    public static function fromRequest($request): self
    {
        $code = $request->input('code');
        $code = is_string($code) ? trim($code) : null;
        if ($code === '') {
            $code = null;
        }

        return new self(
            forestId: (int) $request->input('forest_id'),
            code: $code,
            name: (string) $request->input('name'),
        );
    }
}