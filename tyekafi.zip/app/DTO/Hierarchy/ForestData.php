<?php

namespace App\DTO\Hierarchy;

class ForestData
{
    public function __construct(
        public int $forestDistrictId,
        public ?string $code,
        public string $name,
    ) {}

    public static function fromRequest($request): self
    {
        $code = $request->input('code');
        $code = is_string($code) ? trim($code) : null;
        if ($code === '') {
            $code = null;
        }

        return new self(
            forestDistrictId: (int) $request->input('forest_district_id'),
            code: $code,
            name: (string) $request->input('name'),
        );
    }
}