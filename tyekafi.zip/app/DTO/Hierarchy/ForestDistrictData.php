<?php

namespace App\DTO\Hierarchy;

class ForestDistrictData
{
    public function __construct(
        public int $governingBodyId,
        public int $regionId,
        public ?string $code,
        public string $name,
    ) {}

    public static function fromRequest($request): self
    {
        $code = $request->input('code');
        $code = is_string($code) ? trim($code) : null;
        if ($code === '') {
            $code = null;
        }

        return new self(
            governingBodyId: (int) $request->input('governing_body_id'),
            regionId: (int) $request->input('region_id'),
            code: $code,
            name: (string) $request->input('name'),
        );
    }
}