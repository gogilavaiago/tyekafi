<?php

namespace App\DTO\Hierarchy;

class RegionData
{
    public function __construct(
        public int $governingBodyId,
        public ?string $code,
        public string $name,
    ) {}

    public static function fromRequest($request): self
    {
        $code = $request->input('code');
        $code = is_string($code) ? trim($code) : null;
        if ($code === '') {
            $code = null;
        }

        return new self(
            governingBodyId: (int) $request->input('governing_body_id'),
            code: $code,
            name: (string) $request->input('name'),
        );
    }
}
