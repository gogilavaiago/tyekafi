<?php

namespace App\DTO\Hierarchy;

class LiterData
{
    public function __construct(
        public int $quarterId,
        public ?string $code,
        public string $name,
    ) {}

    public static function fromRequest($request): self
    {
        $code = $request->input('code');
        $code = is_string($code) ? trim($code) : null;
        if ($code === '') {
            $code = null;
        }

        return new self(
            quarterId: (int) $request->input('quarter_id'),
            code: $code,
            name: (string) $request->input('name'),
        );
    }
}