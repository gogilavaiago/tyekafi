<?php

namespace App\DTO;

class UserData
{
    public function __construct(
        public string $name,
        public ?string $surname,
        public string $personalNumber,
        public ?string $position,
        public string $email,
        public ?string $password,
        public array $roles,
        public array $permissions,
        public $signatureFile,
        public bool $removeSignature = false,
    ) {}

    public static function fromRequest($request): self
    {
        return new self(
            name: $request->name,
            surname: $request->surname,
            personalNumber: $request->personal_number,
            position: $request->position,
            email: $request->email,
            password: $request->password ?? null,
            roles: $request->roles ?? [],
            permissions: $request->permissions ?? [],
            signatureFile: $request->file('signature'),
            removeSignature: (bool) ($request->remove_signature ?? false),
        );
    }
}