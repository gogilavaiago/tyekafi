<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class CleanupHierarchyFiles extends Command
{
    protected $signature = 'tyekafi:cleanup-hierarchy-files {--days=30}';
    protected $description = 'Cleanup old hierarchy import/preview/report files from storage';

    public function handle(): int
    {
        $days = (int)$this->option('days');
        if ($days < 1) $days = 30;

        $cutoff = now()->subDays($days)->timestamp;

        $disk = Storage::disk('local');
        $folders = ['imports', 'previews', 'reports'];

        $deleted = 0;

        foreach ($folders as $folder) {
            if (!$disk->exists($folder)) continue;

            foreach ($disk->allFiles($folder) as $path) {
                $full = storage_path('app/' . $path);
                if (!is_file($full)) continue;

                $mtime = @filemtime($full);
                if ($mtime !== false && $mtime < $cutoff) {
                    $disk->delete($path);
                    $deleted++;
                }
            }
        }

        $this->info("Deleted {$deleted} file(s) older than {$days} day(s).");
        return self::SUCCESS;
    }
}