<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class UpdateUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'surname' => ['nullable', 'string', 'max:255'],
            'personal_number' => ['required', 'digits:11'],
            'position' => ['nullable', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email,' . $this->user->id],
            'password' => ['nullable', 'confirmed', Password::defaults()],
            'roles' => ['required', 'array', 'min:1'],
            'roles.*' => ['string', 'exists:roles,name'],
            'permissions' => ['nullable', 'array'],
            'permissions.*' => ['string', 'exists:permissions,name'],
            'signature' => ['nullable', 'file', 'mimes:png', 'max:2048'],
            'remove_signature' => ['nullable', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'personal_number.required' => 'პირადი ნომერი სავალდებულოა.',
            'personal_number.digits' => 'პირადი ნომერი უნდა შედგებოდეს ზუსტად 11 ციფრისგან.',
        ];
    }
}