<?php

namespace App\Http\Requests\Admin\Hierarchy;

use Illuminate\Foundation\Http\FormRequest;

class UpdateLiterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'quarter_id' => ['required', 'integer', 'exists:quarters,id'],
            'code' => ['nullable', 'string', 'max:50'],
            'name' => ['required', 'string', 'max:255'],
        ];
    }
}