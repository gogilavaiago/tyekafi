<?php

namespace App\Http\Requests\Admin\Hierarchy;

use Illuminate\Foundation\Http\FormRequest;

class UpdateGoverningBodyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['nullable', 'string', 'max:50'],
            'name' => ['required', 'string', 'max:255'],
        ];
    }
}