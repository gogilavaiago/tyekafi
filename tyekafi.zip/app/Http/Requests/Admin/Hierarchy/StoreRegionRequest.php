<?php

namespace App\Http\Requests\Admin\Hierarchy;

use Illuminate\Foundation\Http\FormRequest;

class StoreRegionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'governing_body_id' => ['required', 'integer', 'exists:governing_bodies,id'],
            'code' => ['nullable', 'string', 'max:50'],
            'name' => ['required', 'string', 'max:255'],
        ];
    }
}
