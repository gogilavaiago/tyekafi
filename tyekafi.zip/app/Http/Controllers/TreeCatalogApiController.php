<?php

namespace App\Http\Controllers;

use App\Models\TreeRank;
use Illuminate\Http\Request;

class TreeCatalogApiController extends Controller
{
    public function ranks(Request $request)
    {
        $data = $request->validate([
            'tree_species_id' => ['required', 'integer', 'exists:tree_species,id'],
        ]);

        $ranks = TreeRank::query()
            ->where('tree_species_id', (int) $data['tree_species_id'])
            ->orderByRaw('COALESCE(rank_num, 999) asc')
            ->orderBy('name')
            ->get(['id', 'name', 'rank_num', 'h_min_m', 'h_max_m']);

        return response()->json($ranks);
    }

    public function rankLookup(Request $request)
    {
        $data = $request->validate([
            'tree_species_id' => ['required', 'integer', 'exists:tree_species,id'],
            'height_m' => ['required', 'numeric', 'min:0', 'max:200'],
        ]);

        $speciesId = (int) $data['tree_species_id'];
        $h = (float) $data['height_m'];

        $rank = TreeRank::query()
            ->where('tree_species_id', $speciesId)
            ->where(function ($q) use ($h) {
                $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $h);
            })
            ->where(function ($q) use ($h) {
                $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $h);
            })
            ->orderByRaw('COALESCE(h_min_m, -999) desc')
            ->orderByRaw('COALESCE(rank_num, 999) asc')
            ->first();

        if (!$rank) {
            return response()->json([
                'ok' => false,
                'message' => 'No rank match for this species/height. Fill h_min_m/h_max_m for ranks.',
            ], 404);
        }

        return response()->json([
            'ok' => true,
            'rank' => [
                'id' => $rank->id,
                'name' => $rank->name,
                'rank_num' => $rank->rank_num,
                'h_min_m' => $rank->h_min_m,
                'h_max_m' => $rank->h_max_m,
            ],
        ]);
    }
}