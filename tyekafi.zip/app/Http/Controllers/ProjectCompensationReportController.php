<?php

namespace App\Http\Controllers;

use App\Models\Project;
use App\Models\Tyekafi;
use App\Services\ProjectCompensationSummaryService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ProjectCompensationReportController extends Controller
{
    use AuthorizesRequests;

    private function ensureOwnProject(Project $project): void
    {
        abort_unless((int) $project->user_id === (int) auth()->id(), 403);
    }

    public function byGoverningBody(
        Project $project,
        Request $request,
        ProjectCompensationSummaryService $projectCompensationSummaryService
    ) {
        $this->authorize('perm.view');
        $this->ensureOwnProject($project);

        $summary = $this->buildSummary($project, $request, $projectCompensationSummaryService);

        $pdf = Pdf::loadView('reports.project_compensation_by_body', array_merge([
            'project' => $project,
            'generatedAt' => now()->format('d.m.Y H:i'),
        ], $summary))->setPaper('a4', 'portrait');

        $pdf->setOptions([
            'isRemoteEnabled' => false,
            'isPhpEnabled' => false,
            'isHtml5ParserEnabled' => true,
            'dpi' => 96,
            'defaultFont' => 'DejaVu Sans',
            'isFontSubsettingEnabled' => true,
        ]);

        return $pdf->stream('project_compensation_by_governing_body_' . $project->id . '.pdf');
    }

    public function exportByGoverningBody(
        Project $project,
        Request $request,
        ProjectCompensationSummaryService $projectCompensationSummaryService
    ) {
        $this->authorize('perm.view');
        $this->ensureOwnProject($project);

        $summary = $this->buildSummary($project, $request, $projectCompensationSummaryService);
        $spreadsheet = new Spreadsheet();
        $spreadsheet->removeSheetByIndex(0);

        $this->buildSummarySheet($spreadsheet, $project, $summary);

        foreach (($summary['governingBodyCompensations'] ?? []) as $body) {
            $this->buildBodySheet($spreadsheet, $project, $body, (string) ($summary['yearsRange'] ?? '0-5'));
        }

        $tempPath = storage_path('app/project_compensation_by_body_' . $project->id . '_' . now()->format('Ymd_His') . '.xlsx');
        $writer = new Xlsx($spreadsheet);
        $writer->save($tempPath);

        return response()
            ->download($tempPath, 'project_compensation_by_governing_body_' . $project->id . '.xlsx')
            ->deleteFileAfterSend(true);
    }

    private function buildSummary(
        Project $project,
        Request $request,
        ProjectCompensationSummaryService $projectCompensationSummaryService
    ): array {
        $tyekafis = Tyekafi::query()
            ->where('project_id', $project->id)
            ->with([
                'governingBody',
                'forestDistrict.region',
                'forest',
                'quarter',
                'liters',
                'treeRows.species',
                'smallTreeRows.species',
                'speciesSummaries.rank',
            ])
            ->orderBy('id')
            ->get();

        return $projectCompensationSummaryService->build(
            $project,
            $tyekafis,
            $request->string('years_range')->toString()
        );
    }

    private function buildSummarySheet(Spreadsheet $spreadsheet, Project $project, array $summary): void
    {
        $sheet = $spreadsheet->createSheet();
        $sheet->setTitle('Summary');
        $sheet->freezePane('A7');
        $sheet->getDefaultRowDimension()->setRowHeight(20);

        $sheet->mergeCells('A1:H1');
        $sheet->setCellValue('A1', 'კომპენსაციის რეპორტი — მართვის ორგანოების მიხედვით');
        $sheet->mergeCells('A2:H2');
        $sheet->setCellValue('A2', 'პროექტი: ' . (string) $project->name);
        $sheet->mergeCells('A3:H3');
        $sheet->setCellValue('A3', 'სარგებლობის ვადის ინტერვალი: ' . (string) ($summary['yearsRange'] ?? '0-5'));

        $headers = [
            'A6' => 'მართვის ორგანო',
            'B6' => 'ტყეკაფები',
            'C6' => 'სახეობები',
            'D6' => 'Red List სახეობები',
            'E6' => 'ფართობი (ჰა)',
            'F6' => 'ხემცენარეები (₾)',
            'G6' => 'ფართობი (₾)',
            'H6' => 'სულ (₾)',
        ];

        foreach ($headers as $cell => $value) {
            $sheet->setCellValue($cell, $value);
        }

        $row = 7;
        foreach (($summary['governingBodyCompensations'] ?? []) as $body) {
            $sheet->setCellValue("A{$row}", (string) ($body['name'] ?? '—'));
            $sheet->setCellValue("B{$row}", (int) ($body['tyekafi_count'] ?? 0));
            $sheet->setCellValue("C{$row}", count((array) ($body['species_rows'] ?? [])));
            $sheet->setCellValue("D{$row}", collect((array) ($body['species_rows'] ?? []))->where('is_red_list', true)->count());
            $sheet->setCellValue("E{$row}", round((float) ($body['area_ha'] ?? 0), 4));
            $sheet->setCellValue("F{$row}", round((float) ($body['wood_compensation'] ?? 0), 3));
            $sheet->setCellValue("G{$row}", round((float) ($body['area_compensation'] ?? 0), 3));
            $sheet->setCellValue("H{$row}", round((float) ($body['total_compensation'] ?? 0), 3));
            $row++;
        }

        $sheet->setCellValue("A{$row}", 'საერთო ჯამი');
        $sheet->setCellValue("B{$row}", count((array) ($summary['tyekafiCompensations'] ?? [])));
        $sheet->setCellValue("C{$row}", collect((array) ($summary['governingBodyCompensations'] ?? []))->sum(fn ($body) => count((array) ($body['species_rows'] ?? []))));
        $sheet->setCellValue("D{$row}", collect((array) ($summary['governingBodyCompensations'] ?? []))->sum(fn ($body) => collect((array) ($body['species_rows'] ?? []))->where('is_red_list', true)->count()));
        $sheet->setCellValue("E{$row}", round((float) collect((array) ($summary['governingBodyCompensations'] ?? []))->sum('area_ha'), 4));
        $sheet->setCellValue("F{$row}", round((float) ($summary['woodCompensation'] ?? 0), 3));
        $sheet->setCellValue("G{$row}", round((float) ($summary['areaCompensation'] ?? 0), 3));
        $sheet->setCellValue("H{$row}", round((float) ($summary['totalCompensation'] ?? 0), 3));

        $this->styleHeaderBlock($sheet, 'A1:H3');
        $this->styleTableHeader($sheet, 'A6:H6');
        $this->styleTableBody($sheet, "A7:H{$row}");
        $this->styleTotalRow($sheet, "A{$row}:H{$row}");
        $this->applyNumberFormats($sheet, 7, $row, ['E'], '0.0000');
        $this->applyNumberFormats($sheet, 7, $row, ['F', 'G', 'H'], '0.000');
        $this->autoSizeColumns($sheet, 'A', 'H');
    }

    private function buildBodySheet(Spreadsheet $spreadsheet, Project $project, array $body, string $yearsRange): void
    {
        $sheet = $spreadsheet->createSheet();
        $sheet->setTitle($this->makeSheetTitle((string) ($body['name'] ?? 'ორგანო')));
        $sheet->getDefaultRowDimension()->setRowHeight(20);
        $sheet->freezePane('A8');

        $sheet->mergeCells('A1:H1');
        $sheet->setCellValue('A1', (string) ($body['name'] ?? '—'));
        $sheet->mergeCells('A2:H2');
        $sheet->setCellValue('A2', 'პროექტი: ' . (string) $project->name);
        $sheet->mergeCells('A3:H3');
        $sheet->setCellValue('A3', 'სარგებლობის ვადის ინტერვალი: ' . $yearsRange);

        $sheet->setCellValue('A5', 'ტყეკაფები');
        $sheet->setCellValue('B5', (int) ($body['tyekafi_count'] ?? 0));
        $sheet->setCellValue('C5', 'სახეობები');
        $sheet->setCellValue('D5', count((array) ($body['species_rows'] ?? [])));
        $sheet->setCellValue('E5', 'Red List');
        $sheet->setCellValue('F5', collect((array) ($body['species_rows'] ?? []))->where('is_red_list', true)->count());
        $sheet->setCellValue('G5', 'სულ');
        $sheet->setCellValue('H5', round((float) ($body['total_compensation'] ?? 0), 3));

        $speciesHeaderRow = 7;
        $speciesHeaders = ['სახეობა', 'ლათინური სახეობა', 'Red List', 'მოცულობა (მ³)', 'ტარიფი', 'K ორგანო/სახეობა', 'K ვადა', 'კომპენსაცია (₾)'];
        foreach ($speciesHeaders as $index => $header) {
            $sheet->setCellValue(Coordinate::stringFromColumnIndex($index + 1) . $speciesHeaderRow, $header);
        }

        $row = $speciesHeaderRow + 1;
        foreach ((array) ($body['species_rows'] ?? []) as $species) {
            $sheet->setCellValue("A{$row}", (string) ($species['species_name'] ?? '—'));
            $sheet->setCellValue("B{$row}", (string) ($species['species_latin_name'] ?? ''));
            $sheet->setCellValue("C{$row}", !empty($species['is_red_list']) ? 'კი' : '');
            $sheet->setCellValue("D{$row}", round((float) ($species['volume'] ?? 0), 3));
            $sheet->setCellValue("E{$row}", round((float) ($species['base_rate'] ?? 0), 3));
            $sheet->setCellValue("F{$row}", round((float) ($species['body_multiplier'] ?? 0), 3));
            $sheet->setCellValue("G{$row}", round((float) ($species['year_multiplier'] ?? 1), 3));
            $sheet->setCellValue("H{$row}", round((float) ($species['compensation'] ?? 0), 3));
            $row++;
        }

        $speciesDataStart = $speciesHeaderRow + 1;
        $speciesDataEnd = max($speciesDataStart, $row - 1);

        $sheet->setCellValue("A{$row}", 'ხემცენარეების subtotal');
        $sheet->mergeCells("A{$row}:G{$row}");
        $sheet->setCellValue("H{$row}", round((float) ($body['wood_compensation'] ?? 0), 3));
        $row++;

        $sheet->setCellValue("A{$row}", 'Red List subtotal');
        $sheet->mergeCells("A{$row}:G{$row}");
        $sheet->setCellValue("H{$row}", round((float) collect((array) ($body['species_rows'] ?? []))->where('is_red_list', true)->sum('compensation'), 3));
        $redSubtotalRow = $row;
        $row += 2;

        $tyekafiHeaderRow = $row;
        $tyekafiHeaders = ['ID', 'ტყეკაფი', 'ტყითმოსარგებლე', 'ფართობი (ჰა)', 'ხემცენარეები (₾)', 'ფართობი (₾)', 'სულ (₾)', 'Red List (₾)'];
        foreach ($tyekafiHeaders as $index => $header) {
            $sheet->setCellValue(Coordinate::stringFromColumnIndex($index + 1) . $tyekafiHeaderRow, $header);
        }

        $row = $tyekafiHeaderRow + 1;
        foreach ((array) ($body['tyekafis'] ?? []) as $tyekafiRow) {
            $sheet->setCellValue("A{$row}", (int) ($tyekafiRow['tyekafi_id'] ?? 0));
            $sheet->setCellValue("B{$row}", (string) ($tyekafiRow['name'] ?? '—'));
            $sheet->setCellValue("C{$row}", (string) (($tyekafiRow['forest_user_name'] ?? '') !== '' ? $tyekafiRow['forest_user_name'] : '—'));
            $sheet->setCellValue("D{$row}", round((float) ($tyekafiRow['area_ha'] ?? 0), 4));
            $sheet->setCellValue("E{$row}", round((float) ($tyekafiRow['wood_compensation'] ?? 0), 3));
            $sheet->setCellValue("F{$row}", round((float) ($tyekafiRow['area_compensation'] ?? 0), 3));
            $sheet->setCellValue("G{$row}", round((float) ($tyekafiRow['total_compensation'] ?? 0), 3));
            $sheet->setCellValue("H{$row}", round((float) ($tyekafiRow['red_list_compensation'] ?? 0), 3));
            $row++;
        }

        $sheet->setCellValue("A{$row}", 'საერთო ჯამი');
        $sheet->mergeCells("A{$row}:F{$row}");
        $sheet->setCellValue("G{$row}", round((float) ($body['total_compensation'] ?? 0), 3));
        $sheet->setCellValue("H{$row}", round((float) collect((array) ($body['tyekafis'] ?? []))->sum('red_list_compensation'), 3));

        $this->styleHeaderBlock($sheet, 'A1:H3');
        $this->styleKeyValueBlock($sheet, 'A5:H5');
        $this->styleTableHeader($sheet, "A{$speciesHeaderRow}:H{$speciesHeaderRow}");
        $this->styleTableBody($sheet, "A{$speciesDataStart}:H{$speciesDataEnd}");
        $this->styleTotalRow($sheet, 'A' . ($speciesDataEnd + 1) . ':H' . ($speciesDataEnd + 1));
        $this->styleRedTotalRow($sheet, "A{$redSubtotalRow}:H{$redSubtotalRow}");
        $this->styleTableHeader($sheet, "A{$tyekafiHeaderRow}:H{$tyekafiHeaderRow}");
        $this->styleTableBody($sheet, 'A' . ($tyekafiHeaderRow + 1) . ":H{$row}");
        $this->styleTotalRow($sheet, "A{$row}:H{$row}");
        $this->applyNumberFormats($sheet, $speciesDataStart, $speciesDataEnd, ['D', 'E', 'F', 'G', 'H'], '0.000');
        $this->applyNumberFormats($sheet, $tyekafiHeaderRow + 1, $row, ['D'], '0.0000');
        $this->applyNumberFormats($sheet, $tyekafiHeaderRow + 1, $row, ['E', 'F', 'G', 'H'], '0.000');
        $this->autoSizeColumns($sheet, 'A', 'H');
    }

    private function styleHeaderBlock($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => ['bold' => true, 'size' => 12],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
            ],
        ]);
    }

    private function styleKeyValueBlock($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => ['bold' => true],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'F3F4F6'],
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '9CA3AF'],
                ],
            ],
        ]);
    }

    private function styleTableHeader($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => ['bold' => true],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'DDEFE0'],
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '374151'],
                ],
            ],
        ]);
    }

    private function styleTableBody($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'alignment' => [
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'D1D5DB'],
                ],
            ],
        ]);
    }

    private function styleTotalRow($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => ['bold' => true],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'ECFDF5'],
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '10B981'],
                ],
            ],
        ]);
    }

    private function styleRedTotalRow($sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => ['bold' => true],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'FEE2E2'],
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => 'EF4444'],
                ],
            ],
        ]);
    }

    private function applyNumberFormats($sheet, int $startRow, int $endRow, array $columns, string $format): void
    {
        if ($endRow < $startRow) {
            return;
        }

        foreach ($columns as $column) {
            $sheet->getStyle("{$column}{$startRow}:{$column}{$endRow}")
                ->getNumberFormat()
                ->setFormatCode($format);
        }
    }

    private function autoSizeColumns($sheet, string $from, string $to): void
    {
        $start = Coordinate::columnIndexFromString($from);
        $end = Coordinate::columnIndexFromString($to);

        for ($col = $start; $col <= $end; $col++) {
            $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($col))->setAutoSize(true);
        }
    }

    private function makeSheetTitle(string $value): string
    {
        $value = trim($value) !== '' ? trim($value) : 'ორგანო';
        $value = str_replace(['\\', '/', '?', '*', '[', ']', ':'], ' ', $value);
        $value = preg_replace('/\s+/u', ' ', $value) ?: 'ორგანო';
        $value = trim($value);

        return mb_substr($value !== '' ? $value : 'ორგანო', 0, 31);
    }
}