<?php

namespace App\Http\Controllers;

use App\Models\Project;
use App\Models\TariffSpeciesMapping;
use App\Models\TariffValue;
use App\Models\TreeSpecies;
use App\Models\Tyekafi;
use App\Services\CompensationCalculator;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class ProjectController extends Controller
{
    use AuthorizesRequests;

    public function index(Request $request)
    {
        $this->authorize('perm.view');

        $projects = Project::query()
            ->where('user_id', auth()->id())
            ->orderByDesc('id')
            ->paginate(15);

        return view('projects.index', compact('projects'));
    }

    public function create()
    {
        $this->authorize('perm.edit');

        return view('projects.create');
    }

    public function store(Request $request)
    {
        $this->authorize('perm.edit');

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $project = Project::create([
            'user_id' => auth()->id(),
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
        ]);

        return redirect()->route('projects.show', $project);
    }

    public function show(Project $project)
    {
        $this->authorize('perm.view');
        $this->ensureOwnProject($project);

        $tyekafis = Tyekafi::query()
            ->where('project_id', $project->id)
            ->with([
                'governingBody',
                'forestDistrict.region',
                'forest',
                'quarter',
                'liters',
                'treeRows',
                'smallTreeRows',
                'speciesSummaries.rank',
            ])
            ->orderByDesc('id')
            ->paginate(10);

        $totals = $this->buildProjectTotalsFromTyekafis($tyekafis->getCollection());

        $tyekafis->getCollection()->transform(function ($t) use ($totals) {
            $stats = $totals['tyekafi_stats'][$t->id] ?? [
                'total_volume' => 0.0,
                'quality_1_volume' => 0.0,
                'quality_2_volume' => 0.0,
                'small_volume' => 0.0,
                'species_totals' => [],
            ];

            $t->trees_total_volume = (float) ($stats['total_volume'] ?? 0);
            $t->trees_quality_1_volume = (float) ($stats['quality_1_volume'] ?? 0);
            $t->trees_quality_2_volume = (float) ($stats['quality_2_volume'] ?? 0);
            $t->trees_small_volume = (float) ($stats['small_volume'] ?? 0);
            $t->trees_species_totals = $stats['species_totals'] ?? [];

            return $t;
        });

        return view('projects.show', array_merge([
            'project' => $project,
            'tyekafis' => $tyekafis,
        ], $totals));
    }

    public function totals(Project $project)
    {
        $this->authorize('perm.view');
        $this->ensureOwnProject($project);

        $selectedYearsRange = trim((string) request('years_range', '0-5'));
        if (!in_array($selectedYearsRange, ['0-5', '6-15', '16-30', '31-49'], true)) {
            $selectedYearsRange = '0-5';
        }

        $tyekafis = Tyekafi::query()
            ->where('project_id', $project->id)
            ->with([
                'governingBody',
                'treeRows.species',
                'smallTreeRows.species',
                'speciesSummaries.rank',
            ])
            ->orderByDesc('id')
            ->get();

        $totals = $this->buildProjectTotalsFromTyekafis($tyekafis);
        $compensationSummary = app(\App\Services\ProjectCompensationSummaryService::class)->build(
            $project,
            $tyekafis,
            $selectedYearsRange
        );

        return view('projects.totals', array_merge([
            'project' => $project,
            'tyekafis' => $tyekafis,
            'yearsRange' => $selectedYearsRange,
        ], $totals, $compensationSummary));
    }

    private function ensureOwnProject(Project $project): void
    {
        if ((int) $project->user_id !== (int) auth()->id()) {
            abort(403);
        }
    }

    private function isRedListValue(mixed $value): bool
    {
        if (is_null($value)) {
            return false;
        }

        $normalized = mb_strtolower(trim((string) $value));
        if ($normalized === '') {
            return false;
        }

        return !in_array($normalized, ['0', 'false', 'no', 'არა', 'null', 'none'], true);
    }

    private function buildProjectTotalsFromTyekafis(Collection $tyekafis): array
    {
        $speciesIds = $tyekafis
            ->flatMap(function ($t) {
                $treeRows = $t->treeRows ?? collect();
                $smallRows = $t->smallTreeRows ?? collect();

                return $treeRows->pluck('tree_species_id')
                    ->merge($smallRows->pluck('tree_species_id'));
            })
            ->filter()
            ->map(fn ($v) => (int) $v)
            ->unique()
            ->values()
            ->all();

        $speciesMap = TreeSpecies::query()
            ->whereIn('id', $speciesIds)
            ->get(['id', 'name', 'red_list'])
            ->keyBy('id');

        $projectTotalArea = 0.0;
        $projectTotalVolume = 0.0;
        $projectTotalQuality1Volume = 0.0;
        $projectTotalQuality2Volume = 0.0;
        $projectTotalSmallVolume = 0.0;
        $projectSpeciesTotals = [];
        $projectRedListSpeciesTotals = [];
        $tyekafiStats = [];

        foreach ($tyekafis as $t) {
            $stats = $this->calculateTyekafiBottomBlockStats($t, $speciesMap);
            $tyekafiStats[$t->id] = $stats;

            $area = is_null($t->area_ha) ? 0.0 : (float) $t->area_ha;
            $projectTotalArea += $area;
            $projectTotalVolume += (float) ($stats['total_volume'] ?? 0);
            $projectTotalQuality1Volume += (float) ($stats['quality_1_volume'] ?? 0);
            $projectTotalQuality2Volume += (float) ($stats['quality_2_volume'] ?? 0);
            $projectTotalSmallVolume += (float) ($stats['small_volume'] ?? 0);

            foreach (($stats['species_totals'] ?? []) as $speciesName => $volumes) {
                if (!isset($projectSpeciesTotals[$speciesName])) {
                    $projectSpeciesTotals[$speciesName] = [
                        'quality_1' => 0.0,
                        'quality_2' => 0.0,
                        'small' => 0.0,
                        'total' => 0.0,
                    ];
                }

                $projectSpeciesTotals[$speciesName]['quality_1'] += (float) ($volumes['quality_1'] ?? 0);
                $projectSpeciesTotals[$speciesName]['quality_2'] += (float) ($volumes['quality_2'] ?? 0);
                $projectSpeciesTotals[$speciesName]['small'] += (float) ($volumes['small'] ?? 0);
                $projectSpeciesTotals[$speciesName]['total'] += (float) ($volumes['total'] ?? 0);
            }
        }

        ksort($projectSpeciesTotals, SORT_NATURAL);

        foreach ($speciesMap as $species) {
            $speciesName = (string) ($species->name ?? '');
            if ($speciesName === '' || !$this->isRedListValue($species->red_list ?? null)) {
                continue;
            }

            if (!isset($projectSpeciesTotals[$speciesName])) {
                continue;
            }

            $projectRedListSpeciesTotals[$speciesName] = [
                'red_list_label' => 'წითელი ნუსხა',
                'quality_1' => (float) ($projectSpeciesTotals[$speciesName]['quality_1'] ?? 0),
                'quality_2' => (float) ($projectSpeciesTotals[$speciesName]['quality_2'] ?? 0),
                'small' => (float) ($projectSpeciesTotals[$speciesName]['small'] ?? 0),
                'total' => (float) ($projectSpeciesTotals[$speciesName]['total'] ?? 0),
            ];
        }

        ksort($projectRedListSpeciesTotals, SORT_NATURAL);

        return [
            'projectTotalArea' => $projectTotalArea,
            'projectTotalVolume' => $projectTotalVolume,
            'projectTotalQuality1Volume' => $projectTotalQuality1Volume,
            'projectTotalQuality2Volume' => $projectTotalQuality2Volume,
            'projectTotalSmallVolume' => $projectTotalSmallVolume,
            'projectSpeciesTotals' => $projectSpeciesTotals,
            'projectRedListSpeciesTotals' => $projectRedListSpeciesTotals,
            'projectRedListTotalVolume' => collect($projectRedListSpeciesTotals)->sum('total'),
            'projectRedListQuality1Volume' => collect($projectRedListSpeciesTotals)->sum('quality_1'),
            'projectRedListQuality2Volume' => collect($projectRedListSpeciesTotals)->sum('quality_2'),
            'projectRedListSmallVolume' => collect($projectRedListSpeciesTotals)->sum('small'),
            'projectRedListSpeciesCount' => count($projectRedListSpeciesTotals),
            'tyekafi_stats' => $tyekafiStats,
        ];
    }

    private function calculateTyekafiBottomBlockStats(Tyekafi $tyekafi, Collection $speciesMap): array
    {
        $rows = $tyekafi->treeRows ?? collect();
        $smallRows = $tyekafi->smallTreeRows ?? collect();
        $summaries = ($tyekafi->speciesSummaries ?? collect())->keyBy('tree_species_id');

        $valid = $rows->filter(function ($r) {
            return !is_null($r->tree_species_id);
        });

        $validSmallRows = $smallRows->filter(function ($r) {
            return !is_null($r->tree_species_id);
        });

        if ($valid->count() === 0 && $validSmallRows->count() === 0) {
            return [
                'total_volume' => 0.0,
                'quality_1_volume' => 0.0,
                'quality_2_volume' => 0.0,
                'small_volume' => 0.0,
                'species_totals' => [],
            ];
        }

        $speciesNameById = $speciesMap
            ->mapWithKeys(fn ($s, $id) => [(int) $id => (string) $s->name])
            ->all();

        $grouped = $valid->groupBy(function ($r) {
            $sid = (int) $r->tree_species_id;
            $q = is_null($r->quality) ? '' : (string) $r->quality;
            $d = !is_null($r->diameter_cm) ? (int) round((float) $r->diameter_cm) : 0;
            return $sid . '|' . $q . '|' . $d;
        });

        $tariffTableIdBySpeciesName = [];

        $totalVolume = 0.0;
        $quality1Volume = 0.0;
        $quality2Volume = 0.0;
        $smallVolume = 0.0;
        $speciesTotals = [];

        foreach ($grouped as $items) {
            $first = $items->first();

            $speciesId = (int) $first->tree_species_id;
            $quality = is_null($first->quality) ? '' : (string) $first->quality;
            $diameter = !is_null($first->diameter_cm) ? (int) round((float) $first->diameter_cm) : 0;
            $speciesName = $speciesNameById[$speciesId] ?? '—';

            if (!isset($speciesTotals[$speciesName])) {
                $speciesTotals[$speciesName] = [
                    'quality_1' => 0.0,
                    'quality_2' => 0.0,
                    'small' => 0.0,
                    'total' => 0.0,
                ];
            }

            $count = (int) $items->sum(function ($r) {
                $c = (int) ($r->trees_count ?? 1);
                return $c > 0 ? $c : 1;
            });

            $sum = $summaries->get($speciesId);

            $rankMethod = $sum?->rank_method;
            $rankMethod = ($rankMethod === '' || is_null($rankMethod)) ? 'h' : (string) $rankMethod;
            if (!in_array($rankMethod, ['h', 'manual'], true)) {
                $rankMethod = 'h';
            }

            $height = $sum?->height_m;
            $height = ($height === '' || is_null($height)) ? null : (float) $height;

            $manualRankNum = null;
            if ($sum && $sum->relationLoaded('rank') && $sum->rank && !is_null($sum->rank->rank_num)) {
                $manualRankNum = (int) $sum->rank->rank_num;
            } elseif (!is_null($sum?->manual_rank_num) && is_numeric($sum->manual_rank_num)) {
                $manualRankNum = (int) $sum->manual_rank_num;
            }

            $tariffTableId = null;

            if ($speciesName && $speciesName !== '—') {
                if (array_key_exists($speciesName, $tariffTableIdBySpeciesName)) {
                    $tariffTableId = $tariffTableIdBySpeciesName[$speciesName];
                } else {
                    $mapping = TariffSpeciesMapping::query()
                        ->where('species_name', $speciesName)
                        ->first();

                    $tariffTableId = $mapping ? (int) $mapping->tariff_table_id : null;
                    $tariffTableIdBySpeciesName[$speciesName] = $tariffTableId;
                }
            }

            $canCalc =
                $tariffTableId
                && $diameter > 0
                && (
                    ($rankMethod === 'h' && !is_null($height) && $height > 0)
                    || ($rankMethod === 'manual' && !is_null($manualRankNum) && $manualRankNum > 0)
                );

            if (!$canCalc) {
                continue;
            }

            $nearestDt = TariffValue::query()
                ->where('tariff_table_id', $tariffTableId)
                ->select('dt_cm')
                ->distinct()
                ->orderByRaw('ABS(CAST(dt_cm AS SIGNED) - ?) asc', [$diameter])
                ->value('dt_cm');

            if (is_null($nearestDt)) {
                continue;
            }

            $tvQuery = TariffValue::query()
                ->where('tariff_table_id', $tariffTableId)
                ->where('dt_cm', (int) $nearestDt);

            if ($rankMethod === 'h') {
                $tvQuery = $tvQuery
                    ->where(function ($q) use ($height) {
                        $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $height);
                    })
                    ->where(function ($q) use ($height) {
                        $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $height);
                    })
                    ->orderByRaw('COALESCE(h_min_m, -999) desc');
            } else {
                $tvQuery = $tvQuery->where('rank', (int) $manualRankNum);
            }

            $tv = $tvQuery->first();

            if (!$tv) {
                continue;
            }

            $perTotal = is_null($tv->total_m3)
                ? ((float) ($tv->liquid_m3 ?? 0) + (float) ($tv->crown_firewood_m3 ?? 0))
                : (float) $tv->total_m3;

            $groupTotal = $perTotal * $count;

            $speciesTotals[$speciesName]['total'] += $groupTotal;
            $totalVolume += $groupTotal;

            if ($quality === '1') {
                $speciesTotals[$speciesName]['quality_1'] += $groupTotal;
                $quality1Volume += $groupTotal;
            } elseif ($quality === '2') {
                $speciesTotals[$speciesName]['quality_2'] += $groupTotal;
                $quality2Volume += $groupTotal;
            }
        }

        foreach ($validSmallRows as $smallRow) {
            $speciesId = (int) ($smallRow->tree_species_id ?? 0);
            if ($speciesId <= 0) {
                continue;
            }

            $speciesName = $speciesNameById[$speciesId] ?? '—';

            if (!isset($speciesTotals[$speciesName])) {
                $speciesTotals[$speciesName] = [
                    'quality_1' => 0.0,
                    'quality_2' => 0.0,
                    'small' => 0.0,
                    'total' => 0.0,
                ];
            }

            $qty = (int) ($smallRow->quantity ?? 0);
            if ($qty <= 0) {
                continue;
            }

            $rowSmallVolume = $qty * 0.001;

            $speciesTotals[$speciesName]['small'] += $rowSmallVolume;
            $speciesTotals[$speciesName]['total'] += $rowSmallVolume;
            $smallVolume += $rowSmallVolume;
            $totalVolume += $rowSmallVolume;
        }

        ksort($speciesTotals, SORT_NATURAL);

        return [
            'total_volume' => $totalVolume,
            'quality_1_volume' => $quality1Volume,
            'quality_2_volume' => $quality2Volume,
            'small_volume' => $smallVolume,
            'species_totals' => $speciesTotals,
        ];
    }

    public function edit(Project $project)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnProject($project);

        return view('projects.edit', compact('project'));
    }

    public function update(Project $project, Request $request)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnProject($project);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
        ]);

        $project->update($data);

        return redirect()->route('projects.show', $project);
    }

    public function destroy(Project $project)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnProject($project);

        $project->delete();

        return redirect()->route('projects.index');
    }
}
