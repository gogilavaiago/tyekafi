<?php

namespace App\Http\Controllers;

use App\Models\Project;
use App\Models\ForestUseBasis;
use App\Models\TariffSpeciesMapping;
use App\Models\TariffValue;
use App\Models\TreeSpecies;
use App\Models\Tyekafi;
use App\Models\TyekafiSpeciesSummary;
use App\Models\TyekafiSmallTreeRow;
use App\Models\TyekafiTreeRow;
use App\Services\CompensationCalculator;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Collection;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Pdf\Mpdf;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class TyekafiReportController extends Controller
{
    use AuthorizesRequests;

    private function resolveForestUseBasisTitle(?string $code): string
    {
        $code = trim((string) $code);

        if ($code === '') {
            return '—';
        }

        $title = ForestUseBasis::query()
            ->where('code', $code)
            ->value('title');

        return $title ?: $code;
    }

    private function ensureOwnProject(Project $project): void
    {
        abort_unless((int) $project->user_id === (int) auth()->id(), 403);
    }

    private function ensureOwnTyekafi(Project $project, Tyekafi $tyekafi): void
    {
        $this->ensureOwnProject($project);

        abort_unless((int) $tyekafi->project_id === (int) $project->id, 404);
        abort_unless((int) $tyekafi->user_id === (int) auth()->id(), 403);
    }


    public function reportN1(Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.view');
        $this->ensureOwnTyekafi($project, $tyekafi);

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', '300');
        set_time_limit(300);

        $data = $this->preparePdfRenderData($project, $tyekafi);
        $viewData = array_merge($data, $this->buildN1PdfData($data));

        $pdf = Pdf::loadView('reports.tyekafi_n1', $viewData)
            ->setPaper('a4', 'portrait');

        $pdf->setOptions([
            'isRemoteEnabled' => false,
            'isPhpEnabled' => false,
            'isHtml5ParserEnabled' => false,
            'dpi' => 72,
            'defaultFont' => 'DejaVu Sans',
            'isFontSubsettingEnabled' => true,
        ]);

        return $pdf->stream('დანართი_N1_ტყეკაფი_' . $tyekafi->id . '.pdf');
    }

    public function reportN11(Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.view');
        $this->ensureOwnTyekafi($project, $tyekafi);

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', '300');
        set_time_limit(300);

        $data = $this->preparePdfRenderData($project, $tyekafi);
        $viewData = array_merge($data, $this->buildN11PdfData($data));

        $pdf = Pdf::loadView('reports.tyekafi_n11', $viewData)
            ->setPaper('a4', 'portrait');

        $pdf->setOptions([
            'isRemoteEnabled' => false,
            'isPhpEnabled' => false,
            'isHtml5ParserEnabled' => false,
            'dpi' => 72,
            'defaultFont' => 'DejaVu Sans',
            'isFontSubsettingEnabled' => true,
        ]);

        return $pdf->stream('დანართი_N11_ტყეკაფი_' . $tyekafi->id . '.pdf');
    }

    public function reportCompensation(Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.view');
        $this->ensureOwnTyekafi($project, $tyekafi);

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', '300');
        set_time_limit(300);

        $data = $this->preparePdfRenderData($project, $tyekafi);
        $calculator = app(CompensationCalculator::class);
        $selectedYearsRange = trim((string) request('years_range', ''));
        if (!in_array($selectedYearsRange, ['0-5', '6-15', '16-30', '31-49'], true)) {
            $selectedYearsRange = '';
        }

        $compensation = $calculator->calculateForTyekafi(
            $data['tyekafi'],
            $data['reportRows'] ?? [],
            $data['smallDiameterRows'] ?? [],
            $selectedYearsRange
        );

        $viewData = array_merge($data, [
            'compensation' => $compensation,
            'selectedYearsRange' => $selectedYearsRange,
        ]);

        $pdf = Pdf::loadView('reports.compensation', $viewData)
            ->setPaper('a4', 'portrait');

        $pdf->setOptions([
            'isRemoteEnabled' => false,
            'isPhpEnabled' => false,
            'isHtml5ParserEnabled' => false,
            'dpi' => 96,
            'defaultFont' => 'DejaVu Sans',
            'isFontSubsettingEnabled' => true,
        ]);

        return $pdf->stream('კომპენსაცია_ტყეკაფი_' . $tyekafi->id . '.pdf');
    }


    public function reportProjectCompensationByBody(Project $project)
    {
        $this->authorize('perm.view');
        $this->ensureOwnProject($project);

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', '300');
        set_time_limit(300);

        $selectedYearsRange = trim((string) request('years_range', ''));
        if (!in_array($selectedYearsRange, ['0-5', '6-15', '16-30', '31-49'], true)) {
            $selectedYearsRange = '0-5';
        }

        $calculator = app(CompensationCalculator::class);

        $tyekafis = Tyekafi::query()
            ->where('project_id', $project->id)
            ->with([
                'governingBody',
                'region',
                'forestDistrict.region',
                'forest',
                'quarter',
                'liters',
                'user',
            ])
            ->orderBy('governing_body_id')
            ->orderBy('id')
            ->get();

        $groupedBodies = [];
        $grandTotals = [
            'tyekafi_count' => 0,
            'area_ha' => 0.0,
            'wood_compensation' => 0.0,
            'area_compensation' => 0.0,
            'total_compensation' => 0.0,
            'species_volume' => 0.0,
        ];

        foreach ($tyekafis as $tyekafi) {
            $data = $this->preparePdfRenderData($project, $tyekafi);
            $compensation = $calculator->calculateForTyekafi(
                $data['tyekafi'],
                $data['reportRows'] ?? [],
                $data['smallDiameterRows'] ?? [],
                $selectedYearsRange
            );

            $bodyName = trim((string) ($tyekafi->governingBody?->name ?? ''));
            if (!$this->shouldIncludeBodyInCompensationReport($bodyName)) {
                continue;
            }

            if ($bodyName === '') {
                $bodyName = 'არ არის მითითებული';
            }

            if (!isset($groupedBodies[$bodyName])) {
                $groupedBodies[$bodyName] = [
                    'body_name' => $bodyName,
                    'tyekafi_count' => 0,
                    'area_ha' => 0.0,
                    'wood_compensation' => 0.0,
                    'area_compensation' => 0.0,
                    'total_compensation' => 0.0,
                    'species_volume' => 0.0,
                    'species_rows' => [],
                    'tyekafis' => [],
                ];
            }

            $groupedBodies[$bodyName]['tyekafi_count']++;
            $groupedBodies[$bodyName]['area_ha'] += (float) ($tyekafi->area_ha ?? 0);
            $groupedBodies[$bodyName]['wood_compensation'] += (float) ($compensation['wood_compensation'] ?? 0);
            $groupedBodies[$bodyName]['area_compensation'] += (float) ($compensation['area_compensation'] ?? 0);
            $groupedBodies[$bodyName]['total_compensation'] += (float) ($compensation['total_compensation'] ?? 0);

            $groupedBodies[$bodyName]['tyekafis'][] = [
                'id' => $tyekafi->id,
                'area_ha' => (float) ($tyekafi->area_ha ?? 0),
                'wood_compensation' => (float) ($compensation['wood_compensation'] ?? 0),
                'area_compensation' => (float) ($compensation['area_compensation'] ?? 0),
                'total_compensation' => (float) ($compensation['total_compensation'] ?? 0),
                'region_name' => $tyekafi->region?->name ?? $tyekafi->forestDistrict?->region?->name ?? '—',
                'district_name' => $tyekafi->forestDistrict?->name ?? '—',
                'forest_name' => $tyekafi->forest?->name ?? '—',
                'quarter_name' => $tyekafi->quarter?->name ?? '—',
            ];

            foreach (($compensation['species_rows'] ?? []) as $speciesRow) {
                $speciesKey = trim((string) ($speciesRow['species_name'] ?? '')) . '|' . (((bool) ($speciesRow['is_red_list'] ?? false)) ? '1' : '0');
                if (!isset($groupedBodies[$bodyName]['species_rows'][$speciesKey])) {
                    $groupedBodies[$bodyName]['species_rows'][$speciesKey] = [
                        'species_name' => (string) ($speciesRow['species_name'] ?? ''),
                        'species_latin_name' => (string) ($speciesRow['species_latin_name'] ?? ''),
                        'is_red_list' => (bool) ($speciesRow['is_red_list'] ?? false),
                        'money_group' => (int) ($speciesRow['money_group'] ?? 0),
                        'base_rate' => (float) ($speciesRow['base_rate'] ?? 0),
                        'body_multiplier' => (float) ($speciesRow['body_multiplier'] ?? 0),
                        'volume' => 0.0,
                        'compensation' => 0.0,
                    ];
                }

                $groupedBodies[$bodyName]['species_rows'][$speciesKey]['volume'] += (float) ($speciesRow['volume'] ?? 0);
                $groupedBodies[$bodyName]['species_rows'][$speciesKey]['compensation'] += (float) ($speciesRow['compensation'] ?? 0);
                $groupedBodies[$bodyName]['species_volume'] += (float) ($speciesRow['volume'] ?? 0);
            }

            $grandTotals['tyekafi_count']++;
            $grandTotals['area_ha'] += (float) ($tyekafi->area_ha ?? 0);
            $grandTotals['wood_compensation'] += (float) ($compensation['wood_compensation'] ?? 0);
            $grandTotals['area_compensation'] += (float) ($compensation['area_compensation'] ?? 0);
            $grandTotals['total_compensation'] += (float) ($compensation['total_compensation'] ?? 0);
            $grandTotals['species_volume'] += collect($compensation['species_rows'] ?? [])->sum('volume');
        }

        ksort($groupedBodies, SORT_NATURAL);

        foreach ($groupedBodies as &$bodyGroup) {
            uasort($bodyGroup['species_rows'], function (array $a, array $b) {
                return strnatcasecmp((string) ($a['species_name'] ?? ''), (string) ($b['species_name'] ?? ''));
            });

            foreach (['wood_compensation', 'area_compensation', 'total_compensation', 'species_volume'] as $field) {
                $bodyGroup[$field] = round((float) $bodyGroup[$field], 3);
            }
            $bodyGroup['area_ha'] = round((float) ($bodyGroup['area_ha'] ?? 0), 4);

            foreach ($bodyGroup['species_rows'] as &$speciesRow) {
                $speciesRow['volume'] = round((float) $speciesRow['volume'], 3);
                $speciesRow['compensation'] = round((float) $speciesRow['compensation'], 3);
            }
            unset($speciesRow);
        }
        unset($bodyGroup);

        foreach (['wood_compensation', 'area_compensation', 'total_compensation', 'species_volume'] as $field) {
            $grandTotals[$field] = round((float) $grandTotals[$field], 3);
        }
        $grandTotals['area_ha'] = round((float) ($grandTotals['area_ha'] ?? 0), 4);

        $pdf = Pdf::loadView('reports.project_compensation_by_body', [
            'project' => $project,
            'groupedBodies' => $groupedBodies,
            'grandTotals' => $grandTotals,
            'selectedYearsRange' => $selectedYearsRange,
            'reportDate' => now()->format('d.m.Y'),
        ])->setPaper('a4', 'portrait');

        $pdf->setOptions([
            'isRemoteEnabled' => false,
            'isPhpEnabled' => false,
            'isHtml5ParserEnabled' => false,
            'dpi' => 96,
            'defaultFont' => 'DejaVu Sans',
            'isFontSubsettingEnabled' => true,
        ]);

        return $pdf->stream('კომპენსაცია_მართვის_ორგანოების_მიხედვით_პროექტი_' . $project->id . '.pdf');
    }


    private function shouldIncludeBodyInCompensationReport(?string $bodyName): bool
    {
        $bodyName = trim((string) $bodyName);
        if ($bodyName === '') {
            return false;
        }

        $allowedBodies = array_map(
            static fn ($value) => trim((string) $value),
            (array) config('compensation.eligible_governing_bodies_for_compensation_reports', [])
        );

        return in_array($bodyName, array_filter($allowedBodies), true);
    }

    private function preparePdfRenderData(Project $project, Tyekafi $tyekafi): array
    {
        $tyekafi->loadMissing([
            'project',
            'region',
            'forestDistrict.region',
            'forest',
            'quarter',
            'liters',
            'user',
            'governingBody',
            'user',
        ]);

        $data = $this->prepareReportData($project, $tyekafi);

        return array_merge($data, [
            'pdf_common' => $this->buildPdfCommonData($tyekafi),
        ]);
    }

    private function buildPdfCommonData(Tyekafi $tyekafi): array
    {
        $markerPosition = trim((string) ($tyekafi->user?->position ?? ''));
        $markerFullName = trim(collect([
            $tyekafi->user?->name,
            $tyekafi->user?->surname,
        ])->filter(fn ($v) => trim((string) $v) !== '')->implode(' '));

        $markerDisplay = trim(implode("\n", array_values(array_filter([
            $markerPosition,
            $markerFullName,
        ]))));
        if ($markerDisplay === '') {
            $markerDisplay = '—';
        }

        $logoBase64 = null;
        foreach ([
            public_path('images/logo.png'),
            public_path('images/company-logo.png'),
            public_path('img/logo.png'),
            public_path('logo.png'),
        ] as $logoFile) {
            if (file_exists($logoFile)) {
                $logoBase64 = $this->fileToDataUri($logoFile);
                break;
            }
        }

        $signatureBase64 = null;
        $signatureRelativePath = trim((string) ($tyekafi->user?->signature_path ?? ''));
        if ($signatureRelativePath !== '') {
            $signatureFile = storage_path('app/public/' . ltrim($signatureRelativePath, '/'));
            if (file_exists($signatureFile)) {
                $signatureBase64 = $this->fileToDataUri($signatureFile);
            }
        }

        return [
            'marker_display' => $markerDisplay,
            'forest_use_basis_title' => $this->resolveForestUseBasisTitle($tyekafi->forest_use_basis),
            'logo_base64' => $logoBase64,
            'signature_base64' => $signatureBase64,
            'company_display_name' => "საქართველოს\nსატყეო სერვისები",
            'note_text' => 'შენიშვნა: შეშა ვარჯიდან იანგარიშება ფოთლოვნებისათვის ხის ღეროს მოცულობის (ქერქით) 10%, ხოლო წიწვოვნებისათვის ხის ღეროს მოცულობის (ქერქით) 5%, გარდა თხმელისა, აკაციისა და წყავის ჯიშის ხეებისა. შენიშვნის გრაფაში მიეთითება ფაუტი, გადატეხილი და ზეხმელი ხე.',
        ];
    }

    private function fileToDataUri(string $path): ?string
    {
        if (!file_exists($path)) {
            return null;
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $mime = match ($ext) {
            'png' => 'image/png',
            'jpg', 'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            default => 'application/octet-stream',
        };

        return 'data:' . $mime . ';base64,' . base64_encode((string) file_get_contents($path));
    }

    private function buildN1PdfData(array $data): array
    {
        /** @var Tyekafi $tyekafi */
        $tyekafi = $data['tyekafi'];
        $reportRows = array_values($data['reportRows'] ?? []);
        $smallDiameterRows = array_values($data['smallDiameterRows'] ?? []);
        $totals = $data['totals'] ?? [];
        $common = $data['pdf_common'] ?? [];

        $summaryQuery = TyekafiSpeciesSummary::query()
            ->with(['species:id,name', 'rank:id,name,rank_num'])
            ->where('tyekafi_id', $tyekafi->id)
            ->orderBy('tree_species_id')
            ->get();

        $heightRankRows = $summaryQuery
            ->map(function ($item) {
                $speciesName = trim((string) ($item->species?->name ?? ''));

                $rankValue = '';
                if ($item->relationLoaded('rank') && $item->rank) {
                    $rankValue = trim((string) ($item->rank->name ?: $item->rank->rank_num));
                }

                if ($rankValue === '') {
                    foreach (['manual_rank_num', 'manual_rank', 'rank_actual', 'height_rank', 'rank', 'rank_num'] as $field) {
                        $value = $item->{$field} ?? null;
                        if (!is_null($value) && trim((string) $value) !== '') {
                            $rankValue = trim((string) $value);
                            break;
                        }
                    }
                }

                return [
                    'species' => $speciesName,
                    'rank' => $rankValue,
                ];
            })
            ->filter(fn ($row) => $row['species'] !== '' || $row['rank'] !== '')
            ->unique(fn ($row) => $row['species'] . '|' . $row['rank'])
            ->values()
            ->all();

        if (empty($heightRankRows)) {
            $fallbackSpecies = trim((string) ($tyekafi->dominant_species ?? ''));
            $fallbackRank = trim((string) ($tyekafi->height_rank ?? ''));
            if ($fallbackSpecies !== '' || $fallbackRank !== '') {
                $heightRankRows = [[
                    'species' => $fallbackSpecies,
                    'rank' => $fallbackRank,
                ]];
            }
        }

        $sectionOneGroupedForSummary = [];
        foreach ($reportRows as $row) {
            $speciesName = (string) ($row['species_name'] ?? '—');
            if (!isset($sectionOneGroupedForSummary[$speciesName])) {
                $sectionOneGroupedForSummary[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'q1_count' => 0,
                    'q1_liquid' => 0.0,
                    'q1_firewood' => 0.0,
                    'q2_count' => 0,
                    'q2_liquid' => 0.0,
                    'q2_firewood' => 0.0,
                    'all_total' => 0.0,
                    'note' => '',
                ];
            }

            $sectionOneGroupedForSummary[$speciesName]['q1_count'] += (int) ($row['q1_count'] ?? 0);
            $sectionOneGroupedForSummary[$speciesName]['q1_liquid'] += (float) ($row['q1_liquid'] ?? 0);
            $sectionOneGroupedForSummary[$speciesName]['q1_firewood'] += (float) ($row['q1_firewood'] ?? 0);
            $sectionOneGroupedForSummary[$speciesName]['q2_count'] += (int) ($row['q2_count'] ?? 0);
            $sectionOneGroupedForSummary[$speciesName]['q2_liquid'] += (float) ($row['q2_liquid'] ?? 0);
            $sectionOneGroupedForSummary[$speciesName]['q2_firewood'] += (float) ($row['q2_firewood'] ?? 0);
            $sectionOneGroupedForSummary[$speciesName]['all_total'] += (float) ($row['all_total'] ?? 0);

            $noteParts = preg_split('/\R+/', (string) ($row['note'] ?? '')) ?: [];
            $noteParts = array_values(array_filter(array_map('trim', $noteParts), fn ($v) => $v === 'წითელი ნუსხა'));
            if ($noteParts) {
                $existing = preg_split('/\R+/', (string) ($sectionOneGroupedForSummary[$speciesName]['note'] ?? '')) ?: [];
                $sectionOneGroupedForSummary[$speciesName]['note'] = implode("\n", array_values(array_unique(array_merge($existing, $noteParts))));
            }
        }
        ksort($sectionOneGroupedForSummary, SORT_NATURAL);

        $smallBySpecies = [];
        $smallCountTotal = 0;
        $smallVolumeTotal = 0.0;
        foreach ($smallDiameterRows as $row) {
            $speciesName = (string) ($row['species_name'] ?? '—');
            if (!isset($smallBySpecies[$speciesName])) {
                $smallBySpecies[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'count' => 0,
                    'volume' => 0.0,
                ];
            }
            $smallBySpecies[$speciesName]['count'] += (int) ($row['count'] ?? 0);
            $smallBySpecies[$speciesName]['volume'] += (float) ($row['volume'] ?? 0);
            $smallCountTotal += (int) ($row['count'] ?? 0);
            $smallVolumeTotal += (float) ($row['volume'] ?? 0);
        }

        $combined = [];
        foreach ($sectionOneGroupedForSummary as $speciesName => $row) {
            $combined[$speciesName] = [
                'species_name' => $speciesName,
                'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                'q1_count' => (int) ($row['q1_count'] ?? 0),
                'q1_total' => (float) (($row['q1_liquid'] ?? 0) + ($row['q1_firewood'] ?? 0)),
                'q2_count' => (int) ($row['q2_count'] ?? 0),
                'q2_total' => (float) (($row['q2_liquid'] ?? 0) + ($row['q2_firewood'] ?? 0)),
                'small_count' => 0,
                'small_volume' => 0.0,
                'all_total' => (float) ($row['all_total'] ?? 0),
                'note' => trim((string) ($row['note'] ?? '')),
            ];
        }

        foreach ($smallBySpecies as $speciesName => $row) {
            if (!isset($combined[$speciesName])) {
                $combined[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'q1_count' => 0,
                    'q1_total' => 0.0,
                    'q2_count' => 0,
                    'q2_total' => 0.0,
                    'small_count' => 0,
                    'small_volume' => 0.0,
                    'all_total' => 0.0,
                    'note' => '',
                ];
            }
            if ($combined[$speciesName]['species_latin_name'] === '' && trim((string) ($row['species_latin_name'] ?? '')) !== '') {
                $combined[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
            }
            $combined[$speciesName]['small_count'] += (int) ($row['count'] ?? 0);
            $combined[$speciesName]['small_volume'] += (float) ($row['volume'] ?? 0);
        }
        ksort($combined, SORT_NATURAL);

        $sectionThreeRows = array_values(array_map(function ($row) {
            $row['grand_total'] = (float) ($row['all_total'] ?? 0) + (float) ($row['small_volume'] ?? 0);
            return $row;
        }, $combined));

        $compositionRows = $this->calculateCompositionRows($sectionOneGroupedForSummary, $smallDiameterRows);

        $detailRows = [];
        foreach (array_values($reportRows) as $index => $row) {
            $detailRows[] = array_merge($row, ['row_no' => $index + 1]);
        }

        return [
            'pdf_n1' => [
                'detail_chunks' => $this->chunkRowsForPdf($detailRows, 42),
                'height_rank_rows' => $heightRankRows,
                'composition_rows' => $compositionRows,
                'section_three_rows' => $sectionThreeRows,
                'small_rows' => array_values($smallBySpecies),
                'small_count_total' => $smallCountTotal,
                'small_volume_total' => $this->formatNumber($smallVolumeTotal, 3),
                'marker_display' => $common['marker_display'] ?? '—',
                'signature_base64' => $common['signature_base64'] ?? null,
                'note_text' => $common['note_text'] ?? '',
                'forest_use_basis_title' => $common['forest_use_basis_title'] ?? '—',
            ],
        ];
    }

    private function buildN11PdfData(array $data): array
    {
        $tyekafi = $data['tyekafi'];
        $reportRows = array_values($data['reportRows'] ?? []);
        $smallDiameterRows = array_values($data['smallDiameterRows'] ?? []);
        $speciesSummaryRows = array_values($data['speciesSummaryRows'] ?? []);

        $summaryFromBlock1 = $this->groupReportRowsBySpecies($reportRows);
        $heightRankSummaries = TyekafiSpeciesSummary::query()
            ->with(['species:id,name,latin_name', 'rank:id,name,rank_num'])
            ->where('tyekafi_id', $tyekafi->id)
            ->orderBy('tree_species_id')
            ->get();

        $compositionBaseRows = $this->calculateCompositionRows($summaryFromBlock1, $smallDiameterRows);
        $compositionRowsWithRanks = $this->buildCompositionSpeciesRows($heightRankSummaries, $smallDiameterRows, $compositionBaseRows);
        $qualityGroups = [];
        $qualityTotals = [
            'q1_count' => 0,
            'q1_liquid' => 0.0,
            'q1_firewood' => 0.0,
            'q2_count' => 0,
            'q2_liquid' => 0.0,
            'q2_firewood' => 0.0,
            'all_total' => 0.0,
        ];

        foreach ($reportRows as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? ''));
            if ($speciesName === '') {
                continue;
            }
            $diameter = (string) ($row['diameter_cm'] ?? '—');
            if (!isset($qualityGroups[$speciesName])) {
                $qualityGroups[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'rows' => [],
                    'q1_count' => 0,
                    'q1_liquid' => 0.0,
                    'q1_firewood' => 0.0,
                    'q2_count' => 0,
                    'q2_liquid' => 0.0,
                    'q2_firewood' => 0.0,
                    'all_total' => 0.0,
                    'note' => '',
                ];
            }
            if (!isset($qualityGroups[$speciesName]['rows'][$diameter])) {
                $qualityGroups[$speciesName]['rows'][$diameter] = [
                    'diameter_cm' => $diameter,
                    'q1_count' => 0,
                    'q1_liquid' => 0.0,
                    'q1_firewood' => 0.0,
                    'q2_count' => 0,
                    'q2_liquid' => 0.0,
                    'q2_firewood' => 0.0,
                    'all_total' => 0.0,
                    'note' => '',
                ];
            }
            foreach (['q1_count', 'q2_count'] as $k) {
                $value = (int) ($row[$k] ?? 0);
                $qualityGroups[$speciesName]['rows'][$diameter][$k] += $value;
                $qualityGroups[$speciesName][$k] += $value;
                $qualityTotals[$k] += $value;
            }
            foreach (['q1_liquid', 'q1_firewood', 'q2_liquid', 'q2_firewood', 'all_total'] as $k) {
                $value = (float) ($row[$k] ?? 0);
                $qualityGroups[$speciesName]['rows'][$diameter][$k] += $value;
                $qualityGroups[$speciesName][$k] += $value;
                $qualityTotals[$k] += $value;
            }
            $note = $this->extractRedListNote($row['note'] ?? '');
            if ($note !== '') {
                $qualityGroups[$speciesName]['rows'][$diameter]['note'] = $note;
                $qualityGroups[$speciesName]['note'] = $note;
            }
        }
        ksort($qualityGroups, SORT_NATURAL);

        $qualityFlatRows = [];
        foreach ($qualityGroups as $group) {
            ksort($group['rows'], SORT_NATURAL);
            foreach ($group['rows'] as $item) {
                $qualityFlatRows[] = [
                    'type' => 'detail',
                    'species_name' => $group['species_name'],
                    'species_latin_name' => $group['species_latin_name'],
                    'diameter_cm' => $item['diameter_cm'],
                    'q1_count' => $item['q1_count'],
                    'q1_liquid' => $item['q1_liquid'],
                    'q1_firewood' => $item['q1_firewood'],
                    'q2_count' => $item['q2_count'],
                    'q2_liquid' => $item['q2_liquid'],
                    'q2_firewood' => $item['q2_firewood'],
                    'all_total' => $item['all_total'],
                    'note' => $item['note'],
                ];
            }
            $qualityFlatRows[] = [
                'type' => 'species_total',
                'species_name' => $group['species_name'],
                'species_latin_name' => $group['species_latin_name'],
                'q1_count' => $group['q1_count'],
                'q1_liquid' => $group['q1_liquid'],
                'q1_firewood' => $group['q1_firewood'],
                'q2_count' => $group['q2_count'],
                'q2_liquid' => $group['q2_liquid'],
                'q2_firewood' => $group['q2_firewood'],
                'all_total' => $group['all_total'],
                'note' => $group['note'],
            ];
        }

        $smallTotals = ['count' => 0, 'volume' => 0.0];
        foreach ($smallDiameterRows as $smallRow) {
            $smallTotals['count'] += (int) ($smallRow['count'] ?? 0);
            $smallTotals['volume'] += (float) ($smallRow['volume'] ?? 0);
        }

        $summaryCombined = [];
        foreach ($speciesSummaryRows as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? '—'));
            $summaryCombined[$speciesName] = [
                'species_name' => $speciesName,
                'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                'note' => $this->extractRedListNote($row['note'] ?? ''),
                'all_count' => (int) ($row['all_count'] ?? 0),
                'q1_total' => (float) ($row['q1_total'] ?? 0),
                'q2_total' => (float) ($row['q2_total'] ?? 0),
                'small_count' => 0,
                'small_volume' => 0.0,
            ];
        }
        foreach ($smallDiameterRows as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? '—'));
            if (!isset($summaryCombined[$speciesName])) {
                $summaryCombined[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'note' => '',
                    'all_count' => 0,
                    'q1_total' => 0.0,
                    'q2_total' => 0.0,
                    'small_count' => 0,
                    'small_volume' => 0.0,
                ];
            }
            if (($summaryCombined[$speciesName]['species_latin_name'] ?? '') === '' && trim((string) ($row['species_latin_name'] ?? '')) !== '') {
                $summaryCombined[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
            }
            $summaryCombined[$speciesName]['small_count'] += (int) ($row['count'] ?? 0);
            $summaryCombined[$speciesName]['small_volume'] += (float) ($row['volume'] ?? 0);
        }
        ksort($summaryCombined, SORT_NATURAL);

        return [
            'pdf_n11' => [
                'quality_chunks' => $this->chunkRowsForPdf($qualityFlatRows, 38),
                'quality_totals' => $qualityTotals,
                'small_totals' => [
                    'count' => $smallTotals['count'],
                    'volume' => $this->formatNumber($smallTotals['volume'], 3),
                ],
                'summary_rows' => array_values($summaryCombined),
                'composition_rows' => array_map(function ($row) {
                    return [
                        'unit' => $row['composition_unit'] ?? '+',
                        'species' => $row['species_name'] ?? '—',
                        'species_latin_name' => $row['species_latin_name'] ?? '',
                        'rank' => $row['rank'] ?? '—',
                    ];
                }, $compositionRowsWithRanks),
            ],
        ];
    }

    private function chunkRowsForPdf(array $rows, int $size): array
    {
        if ($size < 1) {
            $size = 25;
        }
        if (empty($rows)) {
            return [[]];
        }
        return array_values(array_chunk($rows, $size));
    }

    private function extractRedListNote(mixed $note): string
    {
        $parts = preg_split('/\R+/', trim((string) $note)) ?: [];
        foreach ($parts as $part) {
            if (trim((string) $part) === 'წითელი ნუსხა') {
                return 'წითელი ნუსხა';
            }
        }
        return '';
    }

    public function exportExcel(Project $project, Tyekafi $tyekafi)
{
    $this->authorize('perm.view');
    $this->ensureOwnTyekafi($project, $tyekafi);

    $data = $this->prepareReportData($project, $tyekafi);

    $spreadsheet = new Spreadsheet();
    $spreadsheet->getDefaultStyle()->getFont()->setName('Sylfaen')->setSize(10);

    $sheetN1 = $spreadsheet->getActiveSheet();
    $sheetN1->setTitle('დანართი N1');
    $this->buildN1Sheet($sheetN1, $data);
    $sheetN1->getPageSetup()->setOrientation(PageSetup::ORIENTATION_PORTRAIT);
    $sheetN1->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);

    $sheetN11 = $spreadsheet->createSheet();
    $sheetN11->setTitle('დანართი N11');
    $this->buildN11Sheet($sheetN11, $data);
    $sheetN11->getPageSetup()->setOrientation(PageSetup::ORIENTATION_PORTRAIT);
    $sheetN11->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);

    $spreadsheet->setActiveSheetIndex(0);

    $tempDir = storage_path('app');
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0777, true);
    }

    $tempFile = tempnam($tempDir, 'tyekafi_xlsx_');
    if ($tempFile === false) {
        throw new \RuntimeException('Temporary file could not be created.');
    }

    $xlsxFile = $tempFile . '.xlsx';

    if (file_exists($xlsxFile)) {
        @unlink($xlsxFile);
    }

    @rename($tempFile, $xlsxFile);

    $writer = new Xlsx($spreadsheet);
    $writer->save($xlsxFile);

    if (!file_exists($xlsxFile)) {
        throw new \RuntimeException('Excel file was not created.');
    }

    return response()->download(
        $xlsxFile,
        'danartebi_tyekafi_' . $tyekafi->id . '.xlsx'
    )->deleteFileAfterSend(true);
}


private function buildExportSpreadsheet(Project $project, Tyekafi $tyekafi): Spreadsheet
{
    $data = $this->prepareReportData($project, $tyekafi);

    $spreadsheet = new Spreadsheet();
    $spreadsheet->getDefaultStyle()->getFont()->setName('Sylfaen')->setSize(10);

    $sheetN1 = $spreadsheet->getActiveSheet();
    $sheetN1->setTitle('დანართი N1');
    $this->buildN1Sheet($sheetN1, $data);
    $sheetN1->getPageSetup()->setOrientation(PageSetup::ORIENTATION_PORTRAIT);
    $sheetN1->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);

    $sheetN11 = $spreadsheet->createSheet();
    $sheetN11->setTitle('დანართი N11');
    $this->buildN11Sheet($sheetN11, $data);
    $sheetN11->getPageSetup()->setOrientation(PageSetup::ORIENTATION_PORTRAIT);
    $sheetN11->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);

    $spreadsheet->setActiveSheetIndex(0);

    return $spreadsheet;
}

private function buildSingleSheetSpreadsheet(Project $project, Tyekafi $tyekafi, string $sheetType): Spreadsheet
{
    $data = $this->prepareReportData($project, $tyekafi);

    $spreadsheet = new Spreadsheet();
    $spreadsheet->getDefaultStyle()->getFont()->setName('Sylfaen')->setSize(10);

    $sheet = $spreadsheet->getActiveSheet();

    if ($sheetType === 'n11') {
        $sheet->setTitle('დანართი N11');
        $this->buildN11Sheet($sheet, $data);
    } else {
        $sheet->setTitle('დანართი N1');
        $this->buildN1Sheet($sheet, $data);
    }

    $sheet->getPageSetup()->setOrientation(PageSetup::ORIENTATION_PORTRAIT);
    $sheet->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);

    $spreadsheet->setActiveSheetIndex(0);

    return $spreadsheet;
}

private function downloadSpreadsheetAsPdf(Spreadsheet $spreadsheet, string $filename)
{
    $tempDir = storage_path('app');
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0777, true);
    }

    $tempFile = tempnam($tempDir, 'tyekafi_pdf_');
    if ($tempFile === false) {
        throw new \RuntimeException('Temporary PDF file could not be created.');
    }

    $pdfFile = $tempFile . '.pdf';

    if (file_exists($pdfFile)) {
        @unlink($pdfFile);
    }

    @rename($tempFile, $pdfFile);

    $writer = new Mpdf($spreadsheet);
    $writer->save($pdfFile);

    if (!file_exists($pdfFile)) {
        throw new \RuntimeException('PDF file was not created.');
    }

    return response()->download($pdfFile, $filename)->deleteFileAfterSend(true);
}

public function exportPdf(Project $project, Tyekafi $tyekafi)
{
    $this->authorize('perm.view');
    $this->ensureOwnTyekafi($project, $tyekafi);

    $spreadsheet = $this->buildExportSpreadsheet($project, $tyekafi);

    return $this->downloadSpreadsheetAsPdf(
        $spreadsheet,
        'danartebi_tyekafi_' . $tyekafi->id . '.pdf'
    );
}

public function exportPdfN1(Project $project, Tyekafi $tyekafi)
{
    $this->authorize('perm.view');
    $this->ensureOwnTyekafi($project, $tyekafi);

    $spreadsheet = $this->buildSingleSheetSpreadsheet($project, $tyekafi, 'n1');

    return $this->downloadSpreadsheetAsPdf(
        $spreadsheet,
        'danarti_N1_tyekafi_' . $tyekafi->id . '.pdf'
    );
}

public function exportPdfN11(Project $project, Tyekafi $tyekafi)
{
    $this->authorize('perm.view');
    $this->ensureOwnTyekafi($project, $tyekafi);

    $spreadsheet = $this->buildSingleSheetSpreadsheet($project, $tyekafi, 'n11');

    return $this->downloadSpreadsheetAsPdf(
        $spreadsheet,
        'danarti_N11_tyekafi_' . $tyekafi->id . '.pdf'
    );
}


    private function prepareReportData(Project $project, Tyekafi $tyekafi): array
    {
        $tyekafi->load([
            'governingBody',
            'region',
            'forestDistrict',
            'forest',
            'quarter',
            'liters',
            'user',
        ]);

        $species = TreeSpecies::query()
            ->orderBy('name')
            ->get(['id', 'name', 'latin_name', 'red_list']);

        $rows = TyekafiTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->with('species:id,name,latin_name,red_list')
            ->orderBy('row_order')
            ->orderBy('id')
            ->get();

        $summaries = TyekafiSpeciesSummary::with(['species:id,name', 'rank:id,name,rank_num'])
            ->where('tyekafi_id', $tyekafi->id)
            ->get()
            ->keyBy('tree_species_id');

        $report = $this->buildReportData($rows, $summaries, $species);

        return [
            'project' => $project,
            'tyekafi' => $tyekafi,
            'reportRows' => $report['rows'],
            'speciesSummaryRows' => $report['species_summary_rows'],
            'totals' => $report['totals'],
            'smallDiameterRows' => $this->buildSmallDiameterRowsFromSmallTreeBlock($tyekafi),
            'reportDate' => now()->format('d.m.Y'),
        ];
    }

    private function buildN1Sheet(Worksheet $sheet, array $data): void
    {
        /** @var Tyekafi $tyekafi */
        $tyekafi = $data['tyekafi'];
        $reportRows = $data['reportRows'];
        $totals = $data['totals'];
        $reportDate = $data['reportDate'];

        $summaryFromBlock1 = $this->groupReportRowsBySpecies($reportRows);
        $smallDiameterRows = $data['smallDiameterRows'] ?? [];
        $smallDiameterTotals = $this->sumSmallDiameterRows($smallDiameterRows);

        $sheet->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $sheet->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);
        $sheet->getPageSetup()->setFitToWidth(1);
        $sheet->getPageSetup()->setFitToHeight(0);

        $sheet->getPageMargins()->setTop(0.3);
        $sheet->getPageMargins()->setBottom(0.3);
        $sheet->getPageMargins()->setLeft(0.2);
        $sheet->getPageMargins()->setRight(0.2);

        $widths = [
            'A' => 5,
            'B' => 15,
            'C' => 12,
            'D' => 12,
            'E' => 12,
            'F' => 15,
            'G' => 15,
            'H' => 15,
            'I' => 9,
            'J' => 15,
            'K' => 10,
        ];

        foreach ($widths as $col => $width) {
            $sheet->getColumnDimension($col)->setWidth($width);
        }

        $this->applyN1CustomHeader($sheet);

        $startDate = $this->valueFromCandidates($tyekafi, [
            'marking_start_date',
            'marking_started_at',
            'start_date',
            'started_at',
        ]);

        $endDate = $this->valueFromCandidates($tyekafi, [
            'marking_end_date',
            'marking_finished_at',
            'end_date',
            'finished_at',
        ]);

        $leftLabelRange = fn (int $row) => "A{$row}:C{$row}";
        $leftValueRange = fn (int $row) => "D{$row}:F{$row}";
        $rightLabelRange = fn (int $row) => "G{$row}:H{$row}";
        $rightValueRange = fn (int $row) => "I{$row}:K{$row}";

        $row = 4;

        $startLine = '1. ტყეკაფის მონიშვნის დაწყების თარიღი: ' . $this->formatDateValue($startDate);
        $sheet->mergeCells("A{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", $startLine);
        $sheet->getStyle("A{$row}:K{$row}")->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 10,
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_NONE],
            ],
        ]);
        $this->applyAdaptiveFontSizeForRange($sheet, "A{$row}:K{$row}", $startLine, 10, 88, 9, 110, 8);
        $sheet->getRowDimension($row)->setRowHeight(
            $this->calculateWrappedTextRowHeight($startLine, 88, 18, 13)
        );
        $row++;

        $endLine = '2. ტყეკაფის მონიშვნის დამთავრების თარიღი: ' . $this->formatDateValue($endDate);
        $sheet->mergeCells("A{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", $endLine);
        $sheet->getStyle("A{$row}:K{$row}")->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 10,
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_NONE],
            ],
        ]);
        $this->applyAdaptiveFontSizeForRange($sheet, "A{$row}:K{$row}", $endLine, 10, 88, 9, 110, 8);
        $sheet->getRowDimension($row)->setRowHeight(
            $this->calculateWrappedTextRowHeight($endLine, 88, 18, 13)
        );
        $row++;

        $sheet->mergeCells("A{$row}:C{$row}");
        $sheet->mergeCells("D{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", '3. ტყითსარგებლობის საფუძველი:');
        $sheet->setCellValue("D{$row}", $this->resolveForestUseBasisTitle($tyekafi->forest_use_basis));
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, ["A{$row}:C{$row}"], ["D{$row}:K{$row}"]);
        $this->applyAdaptiveFontSizeForRange($sheet, "D{$row}:K{$row}", (string) $sheet->getCell("D{$row}")->getValue(), 10, 72, 9, 95, 8);
        $sheet->getRowDimension($row)->setRowHeight(
            $this->calculateWrappedTextRowHeight((string) $sheet->getCell("D{$row}")->getValue(), 72, 18, 13)
        );
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '4. ტყითმოსარგებლე:');
        $sheet->setCellValue("D{$row}", $tyekafi->forest_user_name ?: '—');
        $sheet->setCellValue("G{$row}", '5. ს/ნ:');
        $sheet->setCellValue("I{$row}", $tyekafi->forest_user_id_code ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $sheet->getStyle("A{$row}:C{$row}")->getFont()->setSize(9);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '6. მართვის ორგანო:');
        $sheet->setCellValue("D{$row}", $tyekafi->governingBody?->name ?: '—');
        $sheet->setCellValue("G{$row}", '7. რეგიონი:');
        $sheet->setCellValue("I{$row}", $tyekafi->forestDistrict?->region?->name ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '8. სატყეო უბანი:');
        $sheet->setCellValue("D{$row}", $tyekafi->forestDistrict?->name ?: '—');
        $sheet->setCellValue("G{$row}", '9. სატყეო:');
        $sheet->setCellValue("I{$row}", $tyekafi->forest?->name ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '10. კვარტალი №:');
        $sheet->setCellValue("D{$row}", $tyekafi->display_quarter);
        $sheet->setCellValue("G{$row}", '11. ლიტერი №:');
        $sheet->setCellValue("I{$row}", $tyekafi->display_liters);
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '12. ფართობი (ჰა):');
        $sheet->setCellValue("D{$row}", number_format((float) ($tyekafi->area_ha ?? 0), 4, '.', ''));
        $sheet->setCellValue("G{$row}", '13. სიხშირე:');
        $sheet->setCellValue("I{$row}", $tyekafi->frequency_actual ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '14. ჭრის სახე:');
        $sheet->setCellValue("D{$row}", $this->valueFromCandidates($tyekafi, ['cut_type', 'cut_purpose']) ?: '—');
        $sheet->setCellValue("G{$row}", '15. ჭრის %:');
        $sheet->setCellValue("I{$row}", $tyekafi->cut_percent ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '16. დაქანება:');
        $sheet->setCellValue("D{$row}", $tyekafi->slope_actual ?: '—');
        $sheet->setCellValue("G{$row}", '17. ხნოვანება:');
        $sheet->setCellValue("I{$row}", $tyekafi->age_actual ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $sheet->mergeCells($leftLabelRange($row));
        $sheet->mergeCells($leftValueRange($row));
        $sheet->mergeCells($rightLabelRange($row));
        $sheet->mergeCells($rightValueRange($row));
        $sheet->setCellValue("A{$row}", '18. მოზარდ-აღმონაცენი:');
        $sheet->setCellValue("D{$row}", $this->valueFromCandidates($tyekafi, [
            'regen_count_actual',
            'young_growth_actual',
            'regeneration_actual',
            'undergrowth_actual',
            'young_growth_count_actual',
            'regeneration_count_actual',
            'undergrowth_count_actual',
            'young_growth',
            'regeneration',
            'undergrowth',
        ]) ?: '—');
        $sheet->setCellValue("G{$row}", '19. ს.ზ.დ.:');
        $sheet->setCellValue("I{$row}", $this->valueFromCandidates($tyekafi, ['szd', 'altitude_actual', 'altitude_m', 'height_above_sea_level_m', 'elevation_m']) ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [$leftLabelRange($row), $rightLabelRange($row)], [$leftValueRange($row), $rightValueRange($row)]);
        $this->applyAdaptiveFontSizeForRange($sheet, $leftValueRange($row), (string) $sheet->getCell("D{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyAdaptiveFontSizeForRange($sheet, $rightValueRange($row), (string) $sheet->getCell("I{$row}")->getFormattedValue(), 10, 24, 9, 34, 8);
        $this->applyN1AdaptiveMetaRowHeight($sheet, $row);
        $row++;

        $heightRankSummaries = TyekafiSpeciesSummary::query()
            ->with(['species:id,name,latin_name', 'rank:id,name,rank_num'])
            ->where('tyekafi_id', $tyekafi->id)
            ->orderBy('tree_species_id')
            ->get();

        $compositionRows = $this->calculateCompositionRows($summaryFromBlock1, []);
        $n1SpeciesRows = $this->buildCompositionSpeciesRows($heightRankSummaries, $smallDiameterRows, $compositionRows);

        $sheet->mergeCells('A15:K15');
        $sheet->setCellValue('A15', '20. კორომის შემადგენლიბა');
        $this->applySectionHeaderStyle($sheet, 'A15:K15');
        $sheet->getStyle('A15:K15')->getFont()->setSize(10);
        $sheet->getStyle('A15:K15')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle('A15:K15')->getFill()->setFillType(Fill::FILL_NONE);
        $sheet->getRowDimension(15)->setRowHeight(20);

        $sheet->mergeCells('A16:C16');
        $sheet->mergeCells('D16:G16');
        $sheet->mergeCells('H16:K16');
        $sheet->setCellValue('A16', 'ერთეული');
        $sheet->setCellValue('D16', 'სახეობა (ჯიში)');
        $sheet->setCellValue('H16', 'თანრიგი');
        $this->applyTableHeaderStyle($sheet, 'A16:K16');
        $sheet->getStyle('A16:K16')->getFont()->setSize(11);
        $sheet->getStyle('A16:K16')->getFill()->setFillType(Fill::FILL_NONE);
        $sheet->getStyle('A16:K16')->getBorders()->getOutline()->setBorderStyle(Border::BORDER_MEDIUM);
        $sheet->getRowDimension(16)->setRowHeight(22);

        $speciesStartRow = 17;
        if (empty($n1SpeciesRows)) {
            $sheet->mergeCells("A{$speciesStartRow}:C{$speciesStartRow}");
            $sheet->mergeCells("D{$speciesStartRow}:G{$speciesStartRow}");
            $sheet->mergeCells("H{$speciesStartRow}:K{$speciesStartRow}");
            $sheet->setCellValue("A{$speciesStartRow}", '—');
            $sheet->setCellValue("D{$speciesStartRow}", '—');
            $sheet->setCellValue("H{$speciesStartRow}", '—');
            $this->applyBodyRowStyle($sheet, "A{$speciesStartRow}:K{$speciesStartRow}");
            $sheet->getStyle("A{$speciesStartRow}:K{$speciesStartRow}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle("A{$speciesStartRow}:K{$speciesStartRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
            $sheet->getRowDimension($speciesStartRow)->setRowHeight(24);
            $lastSpeciesRow = $speciesStartRow;
        } else {
            $currentSpeciesRow = $speciesStartRow;
            foreach ($n1SpeciesRows as $speciesRow) {
                $sheet->mergeCells("A{$currentSpeciesRow}:C{$currentSpeciesRow}");
                $sheet->mergeCells("D{$currentSpeciesRow}:G{$currentSpeciesRow}");
                $sheet->mergeCells("H{$currentSpeciesRow}:K{$currentSpeciesRow}");

                $sheet->setCellValue("A{$currentSpeciesRow}", (string) ($speciesRow['composition_unit'] ?? '+'));
                $sheet->getCell("D{$currentSpeciesRow}")->setValue(
                    $this->makeSpeciesRichText(
                        (string) ($speciesRow['species_name'] ?? ''),
                        (string) ($speciesRow['species_latin_name'] ?? ''),
                        8
                    )
                );
                $sheet->setCellValue("H{$currentSpeciesRow}", (string) ($speciesRow['rank'] ?? '—'));

                $this->applyBodyRowStyle($sheet, "A{$currentSpeciesRow}:K{$currentSpeciesRow}");
                $sheet->getStyle("A{$currentSpeciesRow}:K{$currentSpeciesRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("A{$currentSpeciesRow}:C{$currentSpeciesRow}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("D{$currentSpeciesRow}:G{$currentSpeciesRow}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("H{$currentSpeciesRow}:K{$currentSpeciesRow}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("D{$currentSpeciesRow}:G{$currentSpeciesRow}")->getAlignment()->setWrapText(true);
                $sheet->getStyle("A{$currentSpeciesRow}:K{$currentSpeciesRow}")->getBorders()->getOutline()->setBorderStyle(Border::BORDER_MEDIUM);
                $sheet->getRowDimension($currentSpeciesRow)->setRowHeight(24);

                $currentSpeciesRow++;
            }
            $lastSpeciesRow = $currentSpeciesRow - 1;
        }

        $blankRow = $lastSpeciesRow + 1;
        $sheet->getRowDimension($blankRow)->setRowHeight(12);

        $gpsStart = $blankRow + 1;

$sheet->mergeCells("A{$gpsStart}:C" . ($gpsStart + 1));
$sheet->mergeCells("E{$gpsStart}:G{$gpsStart}");
$sheet->mergeCells("E" . ($gpsStart + 1) . ":G" . ($gpsStart + 1));
$sheet->mergeCells("I{$gpsStart}:K{$gpsStart}");
$sheet->mergeCells("I" . ($gpsStart + 1) . ":K" . ($gpsStart + 1));

$sheet->setCellValue("A{$gpsStart}", '21. GPS კოორდინატები:');
$sheet->getStyle("A{$gpsStart}:C" . ($gpsStart + 1))->getFont()->setBold(true);

$sheet->setCellValue("D{$gpsStart}", 'X1');
$sheet->setCellValue("D" . ($gpsStart + 1), 'Y1');

$sheet->setCellValue("E{$gpsStart}", $tyekafi->gps_x1 ?: '—');
$sheet->setCellValue("E" . ($gpsStart + 1), $tyekafi->gps_y1 ?: '—');

$sheet->setCellValue("H{$gpsStart}", 'X2');
$sheet->setCellValue("H" . ($gpsStart + 1), 'Y2');

$sheet->setCellValue("I{$gpsStart}", $tyekafi->gps_x2 ?: '—');
$sheet->setCellValue("I" . ($gpsStart + 1), $tyekafi->gps_y2 ?: '—');

$this->applyMetaRowStyle($sheet, "A{$gpsStart}:K" . ($gpsStart + 1));

$sheet->getStyle("A{$gpsStart}:C" . ($gpsStart + 1))->getAlignment()
    ->setHorizontal(Alignment::HORIZONTAL_CENTER)
    ->setVertical(Alignment::VERTICAL_CENTER);

$sheet->getStyle("D{$gpsStart}:D" . ($gpsStart + 1))->getAlignment()
    ->setHorizontal(Alignment::HORIZONTAL_CENTER);

$sheet->getStyle("H{$gpsStart}:H" . ($gpsStart + 1))->getAlignment()
    ->setHorizontal(Alignment::HORIZONTAL_CENTER);

$sheet->getStyle("E{$gpsStart}:G" . ($gpsStart + 1))->getAlignment()
    ->setHorizontal(Alignment::HORIZONTAL_LEFT);

$sheet->getStyle("I{$gpsStart}:K" . ($gpsStart + 1))->getAlignment()
    ->setHorizontal(Alignment::HORIZONTAL_LEFT);

$sheet->getStyle("A{$gpsStart}:K" . ($gpsStart + 1))
    ->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

$sheet->getStyle("A{$gpsStart}:K" . ($gpsStart + 1))
    ->getBorders()->getOutline()->setBorderStyle(Border::BORDER_MEDIUM);

$sheet->getRowDimension($gpsStart)->setRowHeight(15);
$sheet->getRowDimension($gpsStart + 1)->setRowHeight(15);

        $row = $gpsStart + 3;

        $headerTop = $row;
        $headerMid = $row + 1;
        $headerBottom = $row + 2;

        $sheet->mergeCells("A{$headerTop}:A{$headerBottom}");
        $sheet->mergeCells("B{$headerTop}:B{$headerBottom}");
        $sheet->mergeCells("C{$headerTop}:D{$headerTop}");
        $sheet->mergeCells("E{$headerTop}:I{$headerTop}");
        $sheet->mergeCells("J{$headerTop}:J{$headerBottom}");
        $sheet->mergeCells("K{$headerTop}:K{$headerBottom}");

        $sheet->mergeCells("C{$headerMid}:C{$headerBottom}");
        $sheet->mergeCells("D{$headerMid}:D{$headerBottom}");
        $sheet->mergeCells("E{$headerMid}:E{$headerBottom}");
        $sheet->mergeCells("F{$headerMid}:F{$headerBottom}");
        $sheet->mergeCells("G{$headerMid}:I{$headerMid}");

        $sheet->setCellValue("A{$headerTop}", 'ხის №');
        $sheet->setCellValue("B{$headerTop}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("C{$headerTop}", 'ხის ხარისხი და დიამეტრი');
        $sheet->setCellValue("E{$headerTop}", 'გასაცემი მერქნის მოცულობა');
        $sheet->setCellValue("J{$headerTop}", 'შენიშვნა');
        $sheet->setCellValue("K{$headerTop}", 'გაცემა');
        $sheet->setCellValue("C{$headerMid}", 'I ხარისხის');
        $sheet->setCellValue("D{$headerMid}", 'II ხარისხის');
        $sheet->setCellValue("E{$headerMid}", 'საქმისი მერქანი (ლიკვიდი)');
        $sheet->setCellValue("F{$headerMid}", 'შეშა ვარჯიდან');
        $sheet->setCellValue("G{$headerMid}", 'ხარისხის მიხედვით');
        $sheet->setCellValue("G{$headerBottom}", 'I ხარისხის');
        $sheet->setCellValue("H{$headerBottom}", 'II ხარისხის');
        $sheet->setCellValue("I{$headerBottom}", 'სულ ჯამი');

        $this->applyTableHeaderStyle($sheet, "A{$headerTop}:K{$headerBottom}");
        $sheet->getRowDimension($headerTop)->setRowHeight(31.5);
        $sheet->getRowDimension($headerMid)->setRowHeight(27.95);
        $sheet->getRowDimension($headerBottom)->setRowHeight(27.95);

        $row += 3;

        foreach ($reportRows as $i => $item) {
            $dtQ1 = ($item['q1_count'] ?? 0) > 0 ? $item['diameter_cm'] : '';
            $dtQ2 = ($item['q2_count'] ?? 0) > 0 ? $item['diameter_cm'] : '';

            $liquidTotal = (float) ($item['q1_liquid'] ?? 0) + (float) ($item['q2_liquid'] ?? 0);
            $firewoodTotal = (float) ($item['q1_firewood'] ?? 0) + (float) ($item['q2_firewood'] ?? 0);

            $sheet->fromArray([
                $i + 1,
                '',
                $dtQ1,
                $dtQ2,
                $this->formatNumber($liquidTotal, 3),
                $this->formatNumber($firewoodTotal, 3),
                $this->formatNumber($item['q1_total'], 3),
                $this->formatNumber($item['q2_total'], 3),
                $this->formatNumber($item['all_total'], 3),
                trim((string) ($item['note'] ?? '')),
                '',
            ], null, "A{$row}");

            $sheet->getCell("B{$row}")->setValue(
                $this->makeSpeciesRichText(
                    (string) ($item['species_name'] ?? ''),
                    (string) ($item['species_latin_name'] ?? ''),
                    8
                )
            );

            $this->applyBodyRowStyle($sheet, "A{$row}:K{$row}");
            $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle("A{$row}:A{$row}")->getFont()->setSize(8);
            $sheet->getStyle("B{$row}:B{$row}")->getFont()->setSize(8);
            $sheet->getStyle("B{$row}:B{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
            $sheet->getStyle("B{$row}:B{$row}")->getAlignment()->setWrapText(true);
            $sheet->getStyle("J{$row}:J{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
            $sheet->getRowDimension($row)->setRowHeight(-1);

            $row++;
        }

        $sheet->fromArray([
            '',
            'სულ ჯამში',
            '',
            '',
            $this->formatNumber($totals['all_liquid'], 3),
            $this->formatNumber($totals['all_firewood'], 3),
            $this->formatNumber($totals['q1_total'], 3),
            $this->formatNumber($totals['q2_total'], 3),
            $this->formatNumber($totals['all_total'], 3),
            '',
            '',
        ], null, "A{$row}");
       $this->applyTotalRowStyle($sheet, "A{$row}:K{$row}");

// 🔥 დაამატე ეს
$sheet->getStyle("A{$row}:K{$row}")->getFont()->setBold(true);

$sheet->getStyle("A{$row}:K{$row}")->getAlignment()
    ->setHorizontal(Alignment::HORIZONTAL_CENTER)
    ->setVertical(Alignment::VERTICAL_CENTER);
        $row += 2;

        $sheet->mergeCells("A{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", 'გარდა ამისა ტერიტორიაზე აღრიცხული 8 სმ_მდე ტაქსაციური დიამეტრის ხე-მცენარეები');
        $this->applySectionHeaderStyle($sheet, "A{$row}:K{$row}");
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $row++;

        $sheet->fromArray(['№', '', '', '', '', '', '', '', '', '', ''], null, "A{$row}");
        $sheet->mergeCells("B{$row}:F{$row}");
        $sheet->mergeCells("G{$row}:H{$row}");
        $sheet->mergeCells("I{$row}:K{$row}");
        $sheet->setCellValue("B{$row}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("G{$row}", 'რაოდენობა');
        $sheet->setCellValue("I{$row}", 'მოცულობა');
        $this->applyTableHeaderStyle($sheet, "A{$row}:K{$row}");
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $row++;

        foreach ($smallDiameterRows as $i => $item) {
            $sheet->fromArray([
                $i + 1,
                '',
                '',
                '',
                '',
                '',
                $item['count'] ?? 0,
                '',
                $this->formatNumber((float) ($item['volume'] ?? 0), 3),
                '',
                '',
            ], null, "A{$row}");
            $sheet->mergeCells("B{$row}:F{$row}");
            $sheet->mergeCells("G{$row}:H{$row}");
            $sheet->mergeCells("I{$row}:K{$row}");

            $speciesName = (string) ($item['species_name'] ?? '');
            $speciesLatinName = (string) ($item['species_latin_name'] ?? '');

            $sheet->getCell("B{$row}")->setValue(
                $this->makeSpeciesRichText(
                    $speciesName,
                    $speciesLatinName,
                    8
                )
            );
            $this->applyBodyRowStyle($sheet, "A{$row}:K{$row}");
            $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
            $sheet->getStyle("B{$row}:F{$row}")->getAlignment()->setWrapText(true);
            $sheet->getRowDimension($row)->setRowHeight(
                $this->calculateMergedRowHeight($speciesName, $speciesLatinName, 24)
            );
            $row++;
        }

        $sheet->fromArray([
            '',
            'სულ ჯამში',
            '',
            '',
            '',
            '',
            $smallDiameterTotals['count'],
            '',
            $this->formatNumber($smallDiameterTotals['volume'], 3),
            '',
            '',
        ], null, "A{$row}");
        $sheet->mergeCells("B{$row}:F{$row}");
        $sheet->mergeCells("G{$row}:H{$row}");
        $sheet->mergeCells("I{$row}:K{$row}");
        $this->applyTotalRowStyle($sheet, "A{$row}:K{$row}");
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $row += 2;

        $sheet->mergeCells("A{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", 'ჯამური მონაცემები');
        $this->applySectionHeaderStyle($sheet, "A{$row}:K{$row}");
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getRowDimension($row)->setRowHeight(20);
        $row++;

        $sheet->mergeCells("A{$row}:B{$row}");
        $sheet->mergeCells("H{$row}:I{$row}");
        $sheet->mergeCells("J{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("C{$row}", 'ხეთა რაოდენობა');
        $sheet->setCellValue("D{$row}", 'I ხარისხი');
        $sheet->setCellValue("E{$row}", 'II ხარისხი');
        $sheet->setCellValue("F{$row}", '8 სმ-მდე რაოდენობა');
        $sheet->setCellValue("G{$row}", '8 სმ-მდე მოცულობა');
        $sheet->setCellValue("H{$row}", 'სულ ჯამი');
        $sheet->setCellValue("J{$row}", 'შენიშვნა');
        $this->applyTableHeaderStyle($sheet, "A{$row}:K{$row}");
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getRowDimension($row)->setRowHeight(30);
        $row++;

        $summaryCombined = [];
        foreach ($summaryFromBlock1 as $item) {
            $speciesName = $item['species_name'];

            $summaryCombined[$speciesName] = [
                'species_name' => $speciesName,
                'species_latin_name' => trim((string) ($item['species_latin_name'] ?? '')),
                'note' => $this->extractRedListNote($item['note'] ?? ''),
                'all_count' => (int) ($item['all_count'] ?? 0),
                'q1_total' => (float) ($item['q1_total'] ?? 0),
                'q2_total' => (float) ($item['q2_total'] ?? 0),
                'small_count' => 0,
                'small_volume' => 0.0,
            ];
        }

        foreach ($smallDiameterRows as $smallItem) {
            $speciesName = $smallItem['species_name'] ?? '—';

            if (!isset($summaryCombined[$speciesName])) {
                $summaryCombined[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($smallItem['species_latin_name'] ?? '')),
                    'note' => '',
                    'all_count' => 0,
                    'q1_total' => 0.0,
                    'q2_total' => 0.0,
                    'small_count' => 0,
                    'small_volume' => 0.0,
                ];
            } elseif (trim((string) ($summaryCombined[$speciesName]['species_latin_name'] ?? '')) === '') {
                $summaryCombined[$speciesName]['species_latin_name'] = trim((string) ($smallItem['species_latin_name'] ?? ''));
            }

            if ($this->extractRedListNote(($smallItem['is_red_list'] ?? false) ? 'წითელი ნუსხა' : '') !== '') {
                $summaryCombined[$speciesName]['note'] = 'წითელი ნუსხა';
            }

            $summaryCombined[$speciesName]['small_count'] += (int) ($smallItem['count'] ?? 0);
            $summaryCombined[$speciesName]['small_volume'] += (float) ($smallItem['volume'] ?? 0);
        }

        ksort($summaryCombined, SORT_NATURAL);

        foreach ($summaryCombined as $item) {
            $grandTotal = (float) $item['q1_total'] + (float) $item['q2_total'] + (float) $item['small_volume'];

            $sheet->mergeCells("A{$row}:B{$row}");
            $sheet->mergeCells("H{$row}:I{$row}");
            $sheet->mergeCells("J{$row}:K{$row}");

            $speciesName = (string) ($item['species_name'] ?? '');
            $speciesLatinName = (string) ($item['species_latin_name'] ?? '');

            $sheet->setCellValue("A{$row}", '');
            $sheet->setCellValue("C{$row}", ((int) ($item['all_count'] ?? 0)) !== 0 ? $item['all_count'] : '');
            $sheet->setCellValue("D{$row}", ((float) ($item['q1_total'] ?? 0)) != 0.0 ? $this->formatNumber((float) $item['q1_total'], 3) : '');
            $sheet->setCellValue("E{$row}", ((float) ($item['q2_total'] ?? 0)) != 0.0 ? $this->formatNumber((float) $item['q2_total'], 3) : '');
            $sheet->setCellValue("F{$row}", ((int) ($item['small_count'] ?? 0)) !== 0 ? $item['small_count'] : '');
            $sheet->setCellValue("G{$row}", ((float) ($item['small_volume'] ?? 0)) != 0.0 ? $this->formatNumber((float) $item['small_volume'], 3) : '');
            $sheet->setCellValue("H{$row}", $grandTotal != 0.0 ? $this->formatNumber($grandTotal, 3) : '');
            $sheet->setCellValue("J{$row}", $item['note'] ?? '');

            $sheet->getCell("A{$row}")->setValue(
                $this->makeSpeciesRichText($speciesName, $speciesLatinName, 8)
            );

            $this->applyBodyRowStyle($sheet, "A{$row}:K{$row}");
            $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
            $sheet->getStyle("A{$row}:B{$row}")->getFont()->setSize(8)->setBold(true);
            $sheet->getStyle("A{$row}:B{$row}")->getAlignment()->setWrapText(true);
            $sheet->getStyle("J{$row}:K{$row}")->getAlignment()->setWrapText(true);
            $sheet->getStyle("C{$row}:I{$row}")->getFont()->setBold(true);
            $sheet->getStyle("J{$row}:K{$row}")->getFont()->setBold(true);
            $sheet->getRowDimension($row)->setRowHeight(
                $this->calculateMergedRowHeight($speciesName, $speciesLatinName, 24)
            );

            $row++;
        }

        $sheet->mergeCells("A{$row}:B{$row}");
        $sheet->mergeCells("H{$row}:I{$row}");
        $sheet->mergeCells("J{$row}:K{$row}");

        $sheet->setCellValue("A{$row}", 'სულ ჯამში');
        $sheet->setCellValue("C{$row}", ((int) ($totals['all_count'] ?? 0)) !== 0 ? $totals['all_count'] : '');
        $sheet->setCellValue("D{$row}", ((float) ($totals['q1_total'] ?? 0)) != 0.0 ? $this->formatNumber((float) $totals['q1_total'], 3) : '');
        $sheet->setCellValue("E{$row}", ((float) ($totals['q2_total'] ?? 0)) != 0.0 ? $this->formatNumber((float) $totals['q2_total'], 3) : '');
        $sheet->setCellValue("F{$row}", array_sum(array_column($smallDiameterRows, 'count')) !== 0 ? array_sum(array_column($smallDiameterRows, 'count')) : '');
        $sheet->setCellValue("G{$row}", array_sum(array_column($smallDiameterRows, 'volume')) != 0.0 ? $this->formatNumber(array_sum(array_column($smallDiameterRows, 'volume')), 3) : '');
        $sheet->setCellValue("H{$row}", ($totals['all_total'] + array_sum(array_column($smallDiameterRows, 'volume'))) != 0.0 ? $this->formatNumber($totals['all_total'] + array_sum(array_column($smallDiameterRows, 'volume')), 3) : '');
        $sheet->setCellValue("J{$row}", '');

        $this->applyTotalRowStyle($sheet, "A{$row}:K{$row}");
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("A{$row}:K{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getStyle("A{$row}:B{$row}")->getAlignment()->setWrapText(true);
        $sheet->getStyle("J{$row}:K{$row}")->getAlignment()->setWrapText(true);
        $sheet->getStyle("A{$row}:K{$row}")->getFont()->setBold(true);
        $row += 2;

        $sheet->mergeCells("A{$row}:C{$row}");
        $sheet->mergeCells("D{$row}:F{$row}");
        $sheet->mergeCells("G{$row}:H{$row}");
        $sheet->mergeCells("I{$row}:K{$row}");

        $markerDisplay = $this->buildMarkerDisplay($tyekafi);

        $sheet->setCellValue("A{$row}", 'ტყეკაფის მომნიშნავი:');
        $sheet->setCellValue("D{$row}", $markerDisplay);
        $sheet->setCellValue("G{$row}", 'უწყისის შედგენის თარიღი:');
        $sheet->setCellValue("I{$row}", $reportDate);
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [
            "A{$row}:C{$row}",
            "G{$row}:H{$row}",
        ], [
            "D{$row}:F{$row}",
            "I{$row}:K{$row}",
        ]);
        $sheet->getStyle("D{$row}:F{$row}")->getAlignment()->setWrapText(true);
        $sheet->getStyle("D{$row}:F{$row}")->getAlignment()->setVertical(Alignment::VERTICAL_TOP);
        $sheet->getRowDimension($row)->setRowHeight(
            $this->calculateWrappedTextRowHeight($markerDisplay, 22, 32, 16)
        );
        $row++;

        $sheet->mergeCells("A{$row}:C{$row}");
        $sheet->mergeCells("D{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", 'ხელმოწერა:');
        $this->applyMetaRowStyle($sheet, "A{$row}:K{$row}");
        $this->applyLabelValueRowStyles($sheet, [
            "A{$row}:C{$row}",
        ], [
            "D{$row}:K{$row}",
        ]);

        $signaturePath = $this->resolveSignatureImagePath($tyekafi);
        if ($signaturePath) {
            $this->placeSignatureDrawing($sheet, "D{$row}", $signaturePath, 80, 14, 4);
            $sheet->getRowDimension($row)->setRowHeight(34);
        } else {
            $sheet->setCellValue("D{$row}", '__________________________');
        }

        $row += 2;

        $noteText = 'შენიშვნა: შეშა ვარჯიდან იანგარიშება ფოთლოვნებისათვის ხის ღეროს მოცულობის (ქერქით) 10%, ხოლო წიწვოვნებისათვის ხის ღეროს მოცულობის (ქერქით) 5%, გარდა თხმელისა, აკაციისა და წყავის ჯიშის ხეებისა. შენიშვნის გრაფაში მიეთითება ფაუტი, გადატეხილი და ზეხმელი ხე.';

        $sheet->mergeCells("A{$row}:K{$row}");
        $sheet->setCellValue("A{$row}", $noteText);
        $this->applyNoteStyle($sheet, "A{$row}:K{$row}");
        $sheet->getRowDimension($row)->setRowHeight(
            $this->calculateWrappedTextRowHeight($noteText, 88, 48, 15)
        );

        $sheet->freezePane('A25');
    }

    private function buildN11Sheet(Worksheet $sheet, array $data): void
    {
        /** @var Tyekafi $tyekafi */
        $tyekafi = $data['tyekafi'];
        $reportRows = $data['reportRows'] ?? [];
        $smallDiameterRows = $data['smallDiameterRows'] ?? [];
        $totals = $data['totals'];
        $reportDate = $data['reportDate'];

        $qualityGroups = $this->aggregateN11RowsBySpeciesAndDiameter($reportRows);
        $summaryRows = $qualityGroups['groups'] ?? [];
        $summaryFromBlock1 = $this->groupReportRowsBySpecies($reportRows);
        $smallDiameterTotals = $this->sumSmallDiameterRows($smallDiameterRows);
        $markerDisplay = $this->buildMarkerDisplay($tyekafi);

        $heightRankSummaries = TyekafiSpeciesSummary::query()
            ->with(['species:id,name,latin_name', 'rank:id,name,rank_num'])
            ->where('tyekafi_id', $tyekafi->id)
            ->orderBy('tree_species_id')
            ->get();

        $compositionRows = $this->calculateCompositionRows($summaryFromBlock1, []);
        $n11CompositionSpeciesRows = $this->buildCompositionSpeciesRows($heightRankSummaries, $smallDiameterRows, $compositionRows);

        $sheet->getPageSetup()->setOrientation(PageSetup::ORIENTATION_PORTRAIT);
        $sheet->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);
        $sheet->getPageSetup()->setFitToWidth(1);
        $sheet->getPageSetup()->setFitToHeight(0);
        $sheet->getPageMargins()->setTop(0.25);
        $sheet->getPageMargins()->setBottom(0.25);
        $sheet->getPageMargins()->setLeft(0.2);
        $sheet->getPageMargins()->setRight(0.2);

        $widths = [
            'A' => 4.43,
            'B' => 9.00,
            'C' => 13.00,
            'D' => 12.86,
            'E' => 15.00,
            'F' => 15.00,
            'G' => 12.14,
            'H' => 15.00,
            'I' => 15.00,
            'J' => 12.14,
            'K' => 15.00,
            'L' => 15.00,
            'M' => 15.00,
        ];
        foreach ($widths as $col => $width) {
            $sheet->getColumnDimension($col)->setWidth($width);
        }

        $this->applyN11CustomHeader($sheet, $tyekafi->id);

        $r = 4;

        /* 1 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '1. ტყითსარგებლობის საფუძველი:');
        $sheet->setCellValue("E{$r}", $this->resolveForestUseBasisTitle($tyekafi->forest_use_basis));
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}"], ["E{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(
            $this->calculateWrappedTextRowHeight((string) $this->resolveForestUseBasisTitle($tyekafi->forest_use_basis), 52, 20, 13)
        );
        $r++;

        /* 2 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:H{$r}");
        $sheet->mergeCells("I{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '2. ტყითმოსარგებლე:');
        $sheet->setCellValue("E{$r}", $tyekafi->forest_user_name ?: '—');
        $sheet->setCellValue("I{$r}", 'ს/ნ');
        $sheet->setCellValue("K{$r}", $tyekafi->forest_user_id_code ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "I{$r}:J{$r}"], ["E{$r}:H{$r}", "K{$r}:M{$r}"]);
        $sheet->getStyle("I{$r}:J{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 3 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '3. ტყითმოსარგებლის მისამართი:');
        $sheet->setCellValue("E{$r}", $tyekafi->forest_user_address ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}"], ["E{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(
            $this->calculateWrappedTextRowHeight((string) ($tyekafi->forest_user_address ?: '—'), 52, 20, 13)
        );
        $r++;

        /* 4 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '4. მართვის ორგანო:');
        $sheet->setCellValue("E{$r}", $tyekafi->governingBody?->name ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}"], ["E{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 5 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '5. რეგიონი:');
        $sheet->setCellValue("E{$r}", $tyekafi->region?->name ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}"], ["E{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 6-7 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:I{$r}");
        $sheet->mergeCells("J{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '6. სატყეო უბანი:');
        $sheet->setCellValue("E{$r}", $tyekafi->forestDistrict?->name ?: '—');
        $sheet->setCellValue("H{$r}", '7. სატყეო:');
        $sheet->setCellValue("J{$r}", $tyekafi->forest?->name ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:I{$r}"], ["E{$r}:G{$r}", "J{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 8-9 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:I{$r}");
        $sheet->mergeCells("J{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '8. კვარტალი №:');
        $sheet->setCellValue("E{$r}", $tyekafi->display_quarter);
        $sheet->setCellValue("H{$r}", '9. ლიტერი(ები) №:');
        $sheet->setCellValue("J{$r}", $tyekafi->display_liters);
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:I{$r}"], ["E{$r}:G{$r}", "J{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 10-11 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:I{$r}");
        $sheet->mergeCells("J{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '10. ტყეკაფის ფართობი (ჰა):');
        $sheet->setCellValue(
            "E{$r}",
            number_format((float)($tyekafi->area_ha ?? 0), 4, '.', '')
        );
        $sheet->setCellValue("H{$r}", '11. ჭრის მიზანი:');
        $sheet->setCellValue("J{$r}", $tyekafi->cut_purpose ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:I{$r}"], ["E{$r}:G{$r}", "J{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 12-13 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '12. ჭრის სახე:');
        $sheet->setCellValue("E{$r}", $tyekafi->cut_type ?: '—');
        $sheet->setCellValue("H{$r}", '13. ტყეკაფის მონიშვნის წარდგენის თარიღი:');
        $sheet->setCellValue("K{$r}", '');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:J{$r}"], ["E{$r}:G{$r}", "K{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(24);
        $r++;

        /* 14-15 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '14. ტყეკაფის მომნიშნავი:');
        $sheet->setCellValue("E{$r}", $markerDisplay);
        $sheet->setCellValue("H{$r}", '15. ხეთა რაოდენობა:');
        $sheet->setCellValue("K{$r}", (($totals['all_count'] ?? 0) ? ($totals['all_count'] . ' ძირი') : '—'));
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:J{$r}"], ["E{$r}:G{$r}", "K{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(max(20, $this->calculateWrappedTextRowHeight($markerDisplay, 16, 22, 12)));
        $r++;

        /* 16-17 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '16. სიხშირე:');
        $sheet->setCellValue("E{$r}", $tyekafi->frequency_actual ?: '—');
        $sheet->setCellValue("H{$r}", '17. ხნოვანება:');
        $sheet->setCellValue("K{$r}", $tyekafi->age_actual ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:J{$r}"], ["E{$r}:G{$r}", "K{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 18-19 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '18. მოზარდ-აღმონაცენი:');
        $sheet->setCellValue("E{$r}", $tyekafi->regen_count_actual ?: '—');
        $sheet->setCellValue("H{$r}", '19. ს.ზ.დ.:');
        $sheet->setCellValue("K{$r}", $tyekafi->szd ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:J{$r}"], ["E{$r}:G{$r}", "K{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 20-21 */
        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:G{$r}");
        $sheet->mergeCells("H{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '20. დაქანება:');
        $sheet->setCellValue("E{$r}", $tyekafi->slope_actual ?: '—');
        $sheet->setCellValue("H{$r}", '21. ექსპოზიცია:');
        $sheet->setCellValue("K{$r}", $tyekafi->exposure_actual ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "H{$r}:J{$r}"], ["E{$r}:G{$r}", "K{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        /* 22 */
        $sheet->mergeCells("A{$r}:F{$r}");
        $sheet->mergeCells("G{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '22. ტყეკაფის დახურვის (ათვისების დასრულების) თარიღი:');
        $sheet->setCellValue("G{$r}", '');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:F{$r}"], ["G{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(24);
        $r++;

        /* 24 */
        $sheet->mergeCells("A{$r}:F{$r}");
        $sheet->mergeCells("G{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '23.  ტყეკაფის გაუქმების თარიღი:');
        $sheet->setCellValue("G{$r}", '');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:F{$r}"], ["G{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        $sheet->mergeCells("A{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", '24. კორომის შემადგენლობა');
        $this->applySectionHeaderStyle($sheet, "A{$r}:M{$r}");
        $sheet->getStyle("A{$r}:M{$r}")->getFont()->setSize(10);
        $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("A{$r}:M{$r}")->getFill()->setFillType(Fill::FILL_NONE);
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        $sheet->mergeCells("A{$r}:C{$r}");
        $sheet->mergeCells("D{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'ერთეული');
        $sheet->setCellValue("D{$r}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("K{$r}", 'თანრიგი');
        $this->applyTableHeaderStyle($sheet, "A{$r}:M{$r}");
        $sheet->getStyle("A{$r}:M{$r}")->getFont()->setSize(11);
        $sheet->getStyle("A{$r}:M{$r}")->getFill()->setFillType(Fill::FILL_NONE);
        $sheet->getStyle("A{$r}:M{$r}")->getBorders()->getOutline()->setBorderStyle(Border::BORDER_MEDIUM);
        $sheet->getRowDimension($r)->setRowHeight(22);
        $r++;

        if (empty($n11CompositionSpeciesRows)) {
            $sheet->mergeCells("A{$r}:C{$r}");
            $sheet->mergeCells("D{$r}:J{$r}");
            $sheet->mergeCells("K{$r}:M{$r}");
            $sheet->setCellValue("A{$r}", '—');
            $sheet->setCellValue("D{$r}", '—');
            $sheet->setCellValue("K{$r}", '—');
            $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
            $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
            $sheet->getRowDimension($r)->setRowHeight(24);
            $r++;
        } else {
            foreach ($n11CompositionSpeciesRows as $speciesRow) {
                $sheet->mergeCells("A{$r}:C{$r}");
                $sheet->mergeCells("D{$r}:J{$r}");
                $sheet->mergeCells("K{$r}:M{$r}");

                $sheet->setCellValue("A{$r}", (string) ($speciesRow['composition_unit'] ?? '+'));
                $sheet->getCell("D{$r}")->setValue(
                    $this->makeSpeciesRichText(
                        (string) ($speciesRow['species_name'] ?? ''),
                        (string) ($speciesRow['species_latin_name'] ?? ''),
                        8,
                        7
                    )
                );
                $sheet->setCellValue("K{$r}", (string) ($speciesRow['rank'] ?? '—'));

                $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
                $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("A{$r}:C{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("D{$r}:J{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("D{$r}:J{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("D{$r}:J{$r}")->getAlignment()->setWrapText(true);
                $sheet->getStyle("K{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("A{$r}:M{$r}")->getBorders()->getOutline()->setBorderStyle(Border::BORDER_MEDIUM);
                $sheet->getRowDimension($r)->setRowHeight(24);
                $r++;
            }
        }

        $sheet->getRowDimension($r)->setRowHeight(12);
        $r++;

        /* 25 GPS */
        $sheet->mergeCells("A{$r}:D" . ($r + 1));
        $sheet->setCellValue("A{$r}", '25. GPS კოორდინატები:');
        $sheet->getStyle("A{$r}:D" . ($r + 1))->getFont()->setBold(true);
        $sheet->mergeCells("E{$r}:F{$r}");
        $sheet->mergeCells("G{$r}:H{$r}");
        $sheet->mergeCells("I{$r}:J{$r}");
        $sheet->mergeCells("K{$r}:M{$r}");
        $sheet->setCellValue("E{$r}", 'X1');
        $sheet->setCellValue("G{$r}", 'X2');
        $sheet->setCellValue("I{$r}", 'Y1');
        $sheet->setCellValue("K{$r}", 'Y2');
        $sheet->mergeCells("E" . ($r + 1) . ':F' . ($r + 1));
        $sheet->mergeCells("G" . ($r + 1) . ':H' . ($r + 1));
        $sheet->mergeCells("I" . ($r + 1) . ':J' . ($r + 1));
        $sheet->mergeCells("K" . ($r + 1) . ':M' . ($r + 1));
        $sheet->setCellValue("E" . ($r + 1), $tyekafi->gps_x1 ?: '—');
        $sheet->setCellValue("G" . ($r + 1), $tyekafi->gps_x2 ?: '—');
        $sheet->setCellValue("I" . ($r + 1), $tyekafi->gps_y1 ?: '—');
        $sheet->setCellValue("K" . ($r + 1), $tyekafi->gps_y2 ?: '—');
        $this->applyMetaRowStyle($sheet, "A{$r}:M" . ($r + 1));
        $this->applyLabelValueRowStyles(
            $sheet,
            ["A{$r}:D" . ($r + 1), "E{$r}:F{$r}", "G{$r}:H{$r}", "I{$r}:J{$r}", "K{$r}:M{$r}"],
            ["E" . ($r + 1) . ':F' . ($r + 1), "G" . ($r + 1) . ':H' . ($r + 1), "I" . ($r + 1) . ':J' . ($r + 1), "K" . ($r + 1) . ':M' . ($r + 1)]
        );
        $sheet->getStyle("E{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("E" . ($r + 1) . ':M' . ($r + 1))->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getRowDimension($r)->setRowHeight(18);
        $sheet->getRowDimension($r + 1)->setRowHeight(20);
        $r += 3;
        $sheet->mergeCells("A{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'ხის ხარისხის მიხედვით');
        $this->applyN11BlockHeaderStyle($sheet, "A{$r}:M{$r}");
        $r++;

        $tableHeaderTop = $r;
        $tableHeaderBottom = $r + 2;
        $sheet->mergeCells("A{$tableHeaderTop}:A{$tableHeaderBottom}");
        $sheet->mergeCells("B{$tableHeaderTop}:C{$tableHeaderBottom}");
        $sheet->mergeCells("D{$tableHeaderTop}:D{$tableHeaderBottom}");
        $sheet->mergeCells("E{$tableHeaderTop}:G{$tableHeaderTop}");
        $sheet->mergeCells("H{$tableHeaderTop}:J{$tableHeaderTop}");
        $sheet->mergeCells("K{$tableHeaderTop}:K{$tableHeaderBottom}");
        $sheet->mergeCells("L{$tableHeaderTop}:M{$tableHeaderBottom}");
        $sheet->mergeCells("E" . ($tableHeaderTop + 1) . ':G' . ($tableHeaderTop + 1));
        $sheet->mergeCells("H" . ($tableHeaderTop + 1) . ':J' . ($tableHeaderTop + 1));

        $sheet->setCellValue("A{$tableHeaderTop}", '№');
        $sheet->setCellValue("B{$tableHeaderTop}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("D{$tableHeaderTop}", 'დიამეტრი');
        $sheet->setCellValue("E{$tableHeaderTop}", 'I ხარისხი');
        $sheet->setCellValue("H{$tableHeaderTop}", 'II ხარისხი');
        $sheet->setCellValue("K{$tableHeaderTop}", 'გასაცემი მერქანი სულ');
        $sheet->setCellValue("L{$tableHeaderTop}", 'შენიშვნა');
        $sheet->setCellValue("E" . ($tableHeaderTop + 1), 'ხის ხარისხის მიხედვით');
        $sheet->setCellValue("H" . ($tableHeaderTop + 1), 'ხის ხარისხის მიხედვით');
        foreach (['E' => 'ხეთა რაოდენობა', 'F' => 'ლიკვიდური მერქანი', 'G' => 'შეშა ვარჯიდან', 'H' => 'ხეთა რაოდენობა', 'I' => 'ლიკვიდური მერქანი', 'J' => 'შეშა ვარჯიდან'] as $col => $label) {
            $sheet->setCellValue($col . $tableHeaderBottom, $label);
        }
        $this->applyN11TableHeaderStyle($sheet, "A{$tableHeaderTop}:M{$tableHeaderBottom}");
        $sheet->getRowDimension($tableHeaderTop)->setRowHeight(18);
        $sheet->getRowDimension($tableHeaderTop + 1)->setRowHeight(18);
        $sheet->getRowDimension($tableHeaderBottom)->setRowHeight(28);

        $r = $tableHeaderBottom + 1;
        $index = 1;
        if (empty($qualityGroups['groups'])) {
            $sheet->mergeCells("A{$r}:M{$r}");
            $sheet->setCellValue("A{$r}", 'მონაცემები არ არის');
            $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
            $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $r++;
        } else {
            foreach ($qualityGroups['groups'] as $group) {
                foreach ($group['rows'] as $item) {
                    $sheet->mergeCells("B{$r}:C{$r}");
                    $sheet->mergeCells("L{$r}:M{$r}");
                    $sheet->setCellValue("A{$r}", $index++);
                    $sheet->getCell("B{$r}")->setValue(
                        $this->makeSpeciesRichText(
                            (string) ($group['species_name'] ?? ''),
                            (string) ($group['species_latin_name'] ?? ''),
                            8,
                            7
                        )
                    );
                    $sheet->setCellValue("D{$r}", $item['diameter_cm'] ?: '—');
                    $sheet->setCellValue("E{$r}", $item['q1_count'] ?: '');
                    $sheet->setCellValue("F{$r}", $this->formatNumber($item['q1_liquid'] ?? 0));
                    $sheet->setCellValue("G{$r}", $this->formatNumber($item['q1_firewood'] ?? 0));
                    $sheet->setCellValue("H{$r}", $item['q2_count'] ?: '');
                    $sheet->setCellValue("I{$r}", $this->formatNumber($item['q2_liquid'] ?? 0));
                    $sheet->setCellValue("J{$r}", $this->formatNumber($item['q2_firewood'] ?? 0));
                    $sheet->setCellValue("K{$r}", $this->formatNumber($item['all_total'] ?? 0));
                    $note = trim((string) ($item['note'] ?? ''));
                    $sheet->setCellValue("L{$r}", str_contains($note, 'წითელი ნუსხა') ? 'წითელი ნუსხა' : '');
                    $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
                    $sheet->getStyle("A{$r}:A{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle("B{$r}:C{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
                    $sheet->getStyle("B{$r}:C{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                    $sheet->getStyle("B{$r}:C{$r}")->getAlignment()->setWrapText(true);
                    $sheet->getStyle("D{$r}:K{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getRowDimension($r)->setRowHeight(
                        $this->calculateMergedRowHeight(
                            (string) ($group['species_name'] ?? ''),
                            (string) ($group['species_latin_name'] ?? ''),
                            24
                        )
                    );
                    $r++;
                }

                $sheet->mergeCells("A{$r}:C{$r}");
                $sheet->mergeCells("L{$r}:M{$r}");
                $sheet->getCell("A{$r}")->setValue(
                    $this->makeSpeciesRichText(
                        'სულ - "' . $group['species_name'] . '"',
                        (string) ($group['species_latin_name'] ?? ''),
                        8,
                        7
                    )
                );
                $sheet->setCellValue("E{$r}", $group['q1_count'] ?: '');
                $sheet->setCellValue("F{$r}", $this->formatNumber($group['q1_liquid'] ?? 0));
                $sheet->setCellValue("G{$r}", $this->formatNumber($group['q1_firewood'] ?? 0));
                $sheet->setCellValue("H{$r}", $group['q2_count'] ?: '');
                $sheet->setCellValue("I{$r}", $this->formatNumber($group['q2_liquid'] ?? 0));
                $sheet->setCellValue("J{$r}", $this->formatNumber($group['q2_firewood'] ?? 0));
                $sheet->setCellValue("K{$r}", $this->formatNumber($group['all_total'] ?? 0));
                $note = trim((string) ($group['note'] ?? ''));
                $sheet->setCellValue("L{$r}", str_contains($note, 'წითელი ნუსხა') ? 'წითელი ნუსხა' : '');
                $this->applyTotalRowStyle($sheet, "A{$r}:M{$r}");
                $sheet->getStyle("A{$r}:M{$r}")->getFont()->setBold(true);
                $sheet->getStyle("A{$r}:C{$r}")->getAlignment()->setWrapText(true);
                $sheet->getStyle("A{$r}:C{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("K{$r}:K{$r}")->getFont()->setBold(true);
                $sheet->getStyle("D{$r}:K{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getRowDimension($r)->setRowHeight(
                    max(
                        $this->calculateMergedRowHeight(
                            'სულ - "' . (string) ($group['species_name'] ?? '') . '"',
                            (string) ($group['species_latin_name'] ?? ''),
                            24
                        ),
                        $this->calculateWrappedTextRowHeight((string) ($group['note'] ?? ''), 18, 18, 12)
                    )
                );
                $r++;
            }
        }

        $sheet->mergeCells("A{$r}:C{$r}");
        $sheet->mergeCells("L{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'სულ ჯამში');
        $sheet->setCellValue("E{$r}", $qualityGroups['totals']['q1_count'] ?: '');
        $sheet->setCellValue("F{$r}", $this->formatNumber($qualityGroups['totals']['q1_liquid'] ?? 0));
        $sheet->setCellValue("G{$r}", $this->formatNumber($qualityGroups['totals']['q1_firewood'] ?? 0));
        $sheet->setCellValue("H{$r}", $qualityGroups['totals']['q2_count'] ?: '');
        $sheet->setCellValue("I{$r}", $this->formatNumber($qualityGroups['totals']['q2_liquid'] ?? 0));
        $sheet->setCellValue("J{$r}", $this->formatNumber($qualityGroups['totals']['q2_firewood'] ?? 0));
        $sheet->setCellValue("K{$r}", $this->formatNumber($qualityGroups['totals']['all_total'] ?? 0));
        $this->applyTotalRowStyle($sheet, "A{$r}:M{$r}");
        $sheet->getStyle("A{$r}:M{$r}")->getFont()->setBold(true);
        $sheet->getStyle("D{$r}:K{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $r += 2;

        $sheet->mergeCells("A{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'გარდა ამისა ტერიტორიაზე აღრიცხული 8 სმ_მდე ტაქსაციური დიამეტრის ხე-მცენარეები');
        $this->applyN11BlockHeaderStyle($sheet, "A{$r}:M{$r}");
        $sheet->getRowDimension($r)->setRowHeight(20);
        $r++;

        $smallHeader = $r;
        $sheet->mergeCells("A{$smallHeader}:A" . ($smallHeader + 1));
        $sheet->mergeCells("B{$smallHeader}:F" . ($smallHeader + 1));
        $sheet->mergeCells("G{$smallHeader}:I" . ($smallHeader + 1));
        $sheet->mergeCells("J{$smallHeader}:M" . ($smallHeader + 1));
        $sheet->setCellValue("A{$smallHeader}", '№');
        $sheet->setCellValue("B{$smallHeader}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("G{$smallHeader}", 'ხეთა რაოდენობა');
        $sheet->setCellValue("J{$smallHeader}", 'მოცულობა');
        $this->applyN11TableHeaderStyle($sheet, "A{$smallHeader}:M" . ($smallHeader + 1));
        $sheet->getRowDimension($smallHeader)->setRowHeight(18);
        $sheet->getRowDimension($smallHeader + 1)->setRowHeight(18);
        $r = $smallHeader + 2;

        if (empty($smallDiameterRows)) {
            $sheet->mergeCells("A{$r}:M{$r}");
            $sheet->setCellValue("A{$r}", 'მონაცემები არ არის');
            $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
            $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $r++;
        } else {
            foreach ($smallDiameterRows as $i => $item) {
                $sheet->mergeCells("B{$r}:F{$r}");
                $sheet->mergeCells("G{$r}:I{$r}");
                $sheet->mergeCells("J{$r}:M{$r}");
                $sheet->setCellValue("A{$r}", $i + 1);
                $sheet->getCell("B{$r}")->setValue(
                    $this->makeSpeciesRichText(
                        (string) ($item['species_name'] ?? ''),
                        (string) ($item['species_latin_name'] ?? ''),
                        8,
                        7
                    )
                );
                $sheet->setCellValue("G{$r}", (int) ($item['count'] ?? 0));
                $sheet->setCellValue("J{$r}", $this->formatNumber($item['volume'] ?? 0));
                $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
                $sheet->getStyle("A{$r}:A{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("B{$r}:F{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
                $sheet->getStyle("B{$r}:F{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("B{$r}:F{$r}")->getAlignment()->setWrapText(true);
                $sheet->getStyle("G{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getRowDimension($r)->setRowHeight(
                    $this->calculateMergedRowHeight(
                        (string) ($item['species_name'] ?? ''),
                        (string) ($item['species_latin_name'] ?? ''),
                        24
                    )
                );
                $r++;
            }
        }

        $sheet->mergeCells("A{$r}:F{$r}");
        $sheet->mergeCells("G{$r}:I{$r}");
        $sheet->mergeCells("J{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'სულ ჯამში');
        $sheet->setCellValue("G{$r}", $smallDiameterTotals['count'] ?: '');
        $sheet->setCellValue("J{$r}", $this->formatNumber($smallDiameterTotals['volume'] ?? 0));
        $this->applyTotalRowStyle($sheet, "A{$r}:M{$r}");
        $sheet->getStyle("A{$r}:M{$r}")->getFont()->setBold(true);
        $sheet->getStyle("J{$r}:M{$r}")->getFont()->setBold(true);
        $sheet->getStyle("G{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $r += 2;

        $sheet->mergeCells("A{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'ჯამური მონაცემები');
        $this->applyN11BlockHeaderStyle($sheet, "A{$r}:M{$r}");
        $r++;

        $sumHeadTop = $r;
        $sumHeadBottom = $r + 1;
        $sheet->mergeCells("A{$sumHeadTop}:A{$sumHeadBottom}");
        $sheet->mergeCells("B{$sumHeadTop}:D{$sumHeadBottom}");
        $sheet->mergeCells("E{$sumHeadTop}:G{$sumHeadTop}");
        $sheet->mergeCells("H{$sumHeadTop}:J{$sumHeadTop}");
        $sheet->mergeCells("K{$sumHeadTop}:L{$sumHeadTop}");
        $sheet->mergeCells("M{$sumHeadTop}:M{$sumHeadBottom}");

        $sheet->setCellValue("A{$sumHeadTop}", 'N');
        $sheet->setCellValue("B{$sumHeadTop}", 'სახეობა (ჯიში)');
        $sheet->setCellValue("E{$sumHeadTop}", 'I ხარისხი');
        $sheet->setCellValue("H{$sumHeadTop}", 'II ხარისხი');
        $sheet->setCellValue("K{$sumHeadTop}", '8 სმ_ზე ნაკლები დიამეტრის მქონე');
        $sheet->setCellValue("M{$sumHeadTop}", 'სულ ჯამში');

        $sheet->setCellValue("E{$sumHeadBottom}", 'ხეთა რაოდენობა');
        $sheet->setCellValue("F{$sumHeadBottom}", 'ლიკვიდი');
        $sheet->setCellValue("G{$sumHeadBottom}", 'შეშა ვარჯიდან');
        $sheet->setCellValue("H{$sumHeadBottom}", 'ხეთა რაოდენობა');
        $sheet->setCellValue("I{$sumHeadBottom}", 'ლიკვიდი');
        $sheet->setCellValue("J{$sumHeadBottom}", 'შეშა ვარჯიდან');
        $sheet->setCellValue("K{$sumHeadBottom}", 'რაოდენობა');
        $sheet->setCellValue("L{$sumHeadBottom}", 'მოცულობა');

        $this->applyN11TableHeaderStyle($sheet, "A{$sumHeadTop}:M{$sumHeadBottom}");
        $sheet->getStyle("A{$sumHeadTop}:M{$sumHeadBottom}")->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
        $sheet->getStyle("A{$sumHeadTop}:M{$sumHeadBottom}")->getFill()->getStartColor()->setRGB('E2EFDA');
        $sheet->getRowDimension($sumHeadTop)->setRowHeight(36);
        $sheet->getRowDimension($sumHeadBottom)->setRowHeight(48);
        $r = $sumHeadBottom + 1;

        $smallBySpecies = [];
        foreach ($smallDiameterRows as $item) {
            $name = trim((string) ($item['species_name'] ?? ''));
            if ($name === '') {
                continue;
            }
            if (!isset($smallBySpecies[$name])) {
                $smallBySpecies[$name] = ['count' => 0, 'volume' => 0.0];
            }
            $smallBySpecies[$name]['count'] += (int) ($item['count'] ?? 0);
            $smallBySpecies[$name]['volume'] += (float) ($item['volume'] ?? 0);
        }

        if (empty($summaryRows) && empty($smallBySpecies)) {
            $sheet->mergeCells("A{$r}:M{$r}");
            $sheet->setCellValue("A{$r}", 'მონაცემები არ არის');
            $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
            $sheet->getStyle("A{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $r++;
        } else {
            $combinedNames = array_values(array_unique(array_merge(array_column($summaryRows, 'species_name'), array_keys($smallBySpecies))));
            natcasesort($combinedNames);
            $combinedNames = array_values($combinedNames);
            foreach ($combinedNames as $i => $speciesName) {
                $rowData = null;
                foreach ($summaryRows as $candidate) {
                    if (($candidate['species_name'] ?? '') === $speciesName) {
                        $rowData = $candidate;
                        break;
                    }
                }
                $smallData = $smallBySpecies[$speciesName] ?? ['count' => 0, 'volume' => 0.0];

                $sheet->mergeCells("B{$r}:D{$r}");
                $sheet->setCellValue("A{$r}", $i + 1);
                $sheet->getCell("B{$r}")->setValue(
                    $this->makeSpeciesRichText(
                        (string) $speciesName,
                        (string) ($rowData['species_latin_name'] ?? ''),
                        8,
                        7
                    )
                );
                $sheet->setCellValue("E{$r}", ((int) ($rowData['q1_count'] ?? 0)) !== 0 ? $rowData['q1_count'] : '');
                $sheet->setCellValue("F{$r}", ((float) ($rowData['q1_liquid'] ?? 0)) != 0.0 ? $this->formatNumber($rowData['q1_liquid'] ?? 0, 3) : '');
                $sheet->setCellValue("G{$r}", ((float) ($rowData['q1_firewood'] ?? 0)) != 0.0 ? $this->formatNumber($rowData['q1_firewood'] ?? 0, 3) : '');
                $sheet->setCellValue("H{$r}", ((int) ($rowData['q2_count'] ?? 0)) !== 0 ? $rowData['q2_count'] : '');
                $sheet->setCellValue("I{$r}", ((float) ($rowData['q2_liquid'] ?? 0)) != 0.0 ? $this->formatNumber($rowData['q2_liquid'] ?? 0, 3) : '');
                $sheet->setCellValue("J{$r}", ((float) ($rowData['q2_firewood'] ?? 0)) != 0.0 ? $this->formatNumber($rowData['q2_firewood'] ?? 0, 3) : '');
                $sheet->setCellValue("K{$r}", $smallData['count'] ?: '');
                $sheet->setCellValue("L{$r}", ((float) ($smallData['volume'] ?? 0)) != 0.0 ? $this->formatNumber($smallData['volume'] ?? 0, 3) : '');
                $sheet->setCellValue(
                    "M{$r}",
                    $this->buildN11SummaryTotalText([
                        'q1_total' => ((float) ($rowData['q1_liquid'] ?? 0)) + ((float) ($rowData['q1_firewood'] ?? 0)),
                        'q2_total' => ((float) ($rowData['q2_liquid'] ?? 0)) + ((float) ($rowData['q2_firewood'] ?? 0)),
                        'small_total' => (float) ($smallData['volume'] ?? 0),
                    ])
                );
                $this->applyBodyRowStyle($sheet, "A{$r}:M{$r}");
                $sheet->getStyle("A{$r}:A{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("B{$r}:D{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
                $sheet->getStyle("B{$r}:D{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("B{$r}:D{$r}")->getAlignment()->setWrapText(true);
                $sheet->getStyle("E{$r}:L{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("M{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle("M{$r}:M{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $sheet->getStyle("M{$r}:M{$r}")->getAlignment()->setWrapText(true);
                $sheet->getRowDimension($r)->setRowHeight(max(
                    $this->calculateMergedRowHeight(
                        (string) $speciesName,
                        (string) ($rowData['species_latin_name'] ?? ''),
                        24
                    ),
                    $this->calculateWrappedTextRowHeight(
                        $this->buildN11SummaryTotalText([
                            'q1_total' => ((float) ($rowData['q1_liquid'] ?? 0)) + ((float) ($rowData['q1_firewood'] ?? 0)),
                            'q2_total' => ((float) ($rowData['q2_liquid'] ?? 0)) + ((float) ($rowData['q2_firewood'] ?? 0)),
                            'small_total' => (float) ($smallData['volume'] ?? 0),
                        ]),
                        18,
                        22,
                        12
                    )
                ));
                $r++;
            }
        }

        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->setCellValue("A{$r}", 'სულ ჯამში');
        $sheet->setCellValue("E{$r}", ((int) ($totals['q1_count'] ?? 0)) !== 0 ? $totals['q1_count'] : '');
        $sheet->setCellValue("F{$r}", ((float) ($totals['q1_liquid'] ?? 0)) != 0.0 ? $this->formatNumber($totals['q1_liquid'] ?? 0, 3) : '');
        $sheet->setCellValue("G{$r}", ((float) ($totals['q1_firewood'] ?? 0)) != 0.0 ? $this->formatNumber($totals['q1_firewood'] ?? 0, 3) : '');
        $sheet->setCellValue("H{$r}", ((int) ($totals['q2_count'] ?? 0)) !== 0 ? $totals['q2_count'] : '');
        $sheet->setCellValue("I{$r}", ((float) ($totals['q2_liquid'] ?? 0)) != 0.0 ? $this->formatNumber($totals['q2_liquid'] ?? 0, 3) : '');
        $sheet->setCellValue("J{$r}", ((float) ($totals['q2_firewood'] ?? 0)) != 0.0 ? $this->formatNumber($totals['q2_firewood'] ?? 0, 3) : '');
        $sheet->setCellValue("K{$r}", $smallDiameterTotals['count'] ?: '');
        $sheet->setCellValue("L{$r}", ((float) ($smallDiameterTotals['volume'] ?? 0)) != 0.0 ? $this->formatNumber($smallDiameterTotals['volume'] ?? 0, 3) : '');
        $sheet->setCellValue(
            "M{$r}",
            $this->buildN11SummaryTotalText([
                'q1_total' => ((float) ($totals['q1_liquid'] ?? 0)) + ((float) ($totals['q1_firewood'] ?? 0)),
                'q2_total' => ((float) ($totals['q2_liquid'] ?? 0)) + ((float) ($totals['q2_firewood'] ?? 0)),
                'small_total' => (float) ($smallDiameterTotals['volume'] ?? 0),
            ])
        );
        $this->applyTotalRowStyle($sheet, "A{$r}:M{$r}");
        $sheet->getStyle("A{$r}:M{$r}")->getFont()->setBold(true);
        $sheet->getStyle("L{$r}:L{$r}")->getFont()->setBold(true);
        $sheet->getStyle("E{$r}:L{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("M{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle("M{$r}:M{$r}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getStyle("M{$r}:M{$r}")->getAlignment()->setWrapText(true);
        $sheet->getRowDimension($r)->setRowHeight(
            $this->calculateWrappedTextRowHeight(
                $this->buildN11SummaryTotalText([
                    'q1_total' => ((float) ($totals['q1_liquid'] ?? 0)) + ((float) ($totals['q1_firewood'] ?? 0)),
                    'q2_total' => ((float) ($totals['q2_liquid'] ?? 0)) + ((float) ($totals['q2_firewood'] ?? 0)),
                    'small_total' => (float) ($smallDiameterTotals['volume'] ?? 0),
                ]),
                18,
                22,
                12
            )
        );
        $r += 2;

        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'ტყეკაფის პასპორტის გამცემი უფლებამოსილი პირი:');
        $sheet->setCellValue("E{$r}", '');
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}"], ["E{$r}:M{$r}"]);
        $sheet->getRowDimension($r)->setRowHeight(30);
        $r++;

        $sheet->mergeCells("A{$r}:D{$r}");
        $sheet->mergeCells("E{$r}:I{$r}");
        $sheet->mergeCells("J{$r}:K{$r}");
        $sheet->mergeCells("L{$r}:M{$r}");
        $sheet->setCellValue("A{$r}", 'ხელმოწერა:');
        $sheet->setCellValue("J{$r}", 'აქტის შედგენის თარიღი:');
        $sheet->setCellValue("L{$r}", $reportDate);
        $this->applyMetaRowStyle($sheet, "A{$r}:M{$r}");
        $this->applyLabelValueRowStyles($sheet, ["A{$r}:D{$r}", "J{$r}:K{$r}"], ["E{$r}:I{$r}", "L{$r}:M{$r}"]);
        $sheet->getStyle("L{$r}:M{$r}")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $sheet->getRowDimension($r)->setRowHeight(42);

        $sheet->getStyle('A1:M' . $r)->getFont()->setName('Sylfaen')->setSize(9);
        $this->applyN11ManualRowHeights($sheet, $r);
        $sheet->getRowDimension($sumHeadTop)->setRowHeight(36);
        $sheet->getRowDimension($sumHeadBottom)->setRowHeight(48);
        $sheet->getRowDimension($r)->setRowHeight(42);

        // Keep N11 header rows exactly as requested
        $sheet->getRowDimension(1)->setRowHeight(15);
        $sheet->getRowDimension(2)->setRowHeight(30);
        $sheet->getRowDimension(3)->setRowHeight(20);
        $sheet->getStyle('A1:M1')->getFont()->setSize(9);
        $sheet->getStyle('A2:M2')->getFont()->setSize(16);
        $sheet->getStyle('A3:M3')->getFont()->setSize(9);

        $sheet->freezePane('A' . ($tableHeaderBottom + 1));
        $sheet->getPageSetup()->setPrintArea('A1:M' . $r);
        $sheet->getSheetView()->setZoomScale(90);
    }


    private function applyN1AdaptiveMetaRowHeight(Worksheet $sheet, int $row): void
    {
        $sheet->getRowDimension($row)->setRowHeight(
            $this->calculateN1MetaRowHeight($sheet, $row)
        );
    }

    private function calculateN1MetaRowHeight(Worksheet $sheet, int $row): float
    {
        $segments = [
            ['text' => (string) $sheet->getCell("A{$row}")->getFormattedValue(), 'chars' => 22, 'base' => 24, 'line' => 15],
            ['text' => (string) $sheet->getCell("D{$row}")->getFormattedValue(), 'chars' => 24, 'base' => 24, 'line' => 15],
            ['text' => (string) $sheet->getCell("G{$row}")->getFormattedValue(), 'chars' => 16, 'base' => 24, 'line' => 15],
            ['text' => (string) $sheet->getCell("I{$row}")->getFormattedValue(), 'chars' => 24, 'base' => 24, 'line' => 15],
        ];

        $height = 24.0;
        foreach ($segments as $segment) {
            $height = max(
                $height,
                $this->calculateWrappedTextRowHeight(
                    (string) $segment['text'],
                    (int) $segment['chars'],
                    (float) $segment['base'],
                    (float) $segment['line']
                )
            );
        }

        return $height;
    }

    private function applyN11ManualRowHeights(Worksheet $sheet, int $lastRow): void
    {
        $minimumHeights = [
            1 => 15.00,
            2 => 30.00,
            3 => 20.00,
            4 => 18.00,
            5 => 20.10,
            6 => 18.00,
            7 => 18.00,
            8 => 18.00,
            9 => 26.10,
            10 => 38.10,
            11 => 26.10,
            12 => 26.10,
            13 => 18.00,
            14 => 18.00,
            15 => 18.00,
            16 => 18.00,
            17 => 26.10,
            18 => 18.00,
            19 => 18.00,
            20 => 20.10,
        ];

        foreach ($minimumHeights as $row => $height) {
            if ($row <= $lastRow) {
                $sheet->getRowDimension($row)->setRowHeight($height);
            }
        }

        for ($row = 21; $row <= $lastRow; $row++) {
            $sheet->getRowDimension($row)->setRowHeight(18);
        }

        $this->autoFitRowsByMergedContent($sheet, 1, $lastRow, 'A', 'M', 18, 9);

        foreach ($minimumHeights as $row => $height) {
            if ($row > $lastRow) {
                continue;
            }

            $currentHeight = $sheet->getRowDimension($row)->getRowHeight();
            if (!is_numeric($currentHeight) || (float) $currentHeight < $height) {
                $sheet->getRowDimension($row)->setRowHeight($height);
            }
        }

        for ($row = 21; $row <= $lastRow; $row++) {
            $currentHeight = $sheet->getRowDimension($row)->getRowHeight();
            if (!is_numeric($currentHeight) || (float) $currentHeight < 18) {
                $sheet->getRowDimension($row)->setRowHeight(18);
            }
        }
    }

    private function aggregateN11RowsBySpeciesAndDiameter(array $reportRows): array
    {
        $grouped = [];
        $totals = [
            'q1_count' => 0,
            'q1_liquid' => 0.0,
            'q1_firewood' => 0.0,
            'q2_count' => 0,
            'q2_liquid' => 0.0,
            'q2_firewood' => 0.0,
            'all_total' => 0.0,
        ];

        foreach ($reportRows as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? ''));
            if ($speciesName === '') {
                continue;
            }

            $diameter = (int) round((float) ($row['diameter_cm'] ?? 0));
            $diameterKey = (string) $diameter;

            if (!isset($grouped[$speciesName])) {
                $grouped[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'rows' => [],
                    'q1_count' => 0,
                    'q1_liquid' => 0.0,
                    'q1_firewood' => 0.0,
                    'q2_count' => 0,
                    'q2_liquid' => 0.0,
                    'q2_firewood' => 0.0,
                    'all_total' => 0.0,
                    '_notes' => [],
                ];
            } elseif (
                trim((string) ($grouped[$speciesName]['species_latin_name'] ?? '')) === ''
                && trim((string) ($row['species_latin_name'] ?? '')) !== ''
            ) {
                $grouped[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
            }

            if (!isset($grouped[$speciesName]['rows'][$diameterKey])) {
                $grouped[$speciesName]['rows'][$diameterKey] = [
                    'diameter_cm' => $diameter,
                    'q1_count' => 0,
                    'q1_liquid' => 0.0,
                    'q1_firewood' => 0.0,
                    'q2_count' => 0,
                    'q2_liquid' => 0.0,
                    'q2_firewood' => 0.0,
                    'all_total' => 0.0,
                    '_notes' => [],
                ];
            }

            foreach (['q1_count', 'q2_count'] as $key) {
                $value = (int) ($row[$key] ?? 0);
                $grouped[$speciesName]['rows'][$diameterKey][$key] += $value;
                $grouped[$speciesName][$key] += $value;
                $totals[$key] += $value;
            }

            foreach (['q1_liquid', 'q1_firewood', 'q2_liquid', 'q2_firewood', 'all_total'] as $key) {
                $value = (float) ($row[$key] ?? 0);
                $grouped[$speciesName]['rows'][$diameterKey][$key] += $value;
                $grouped[$speciesName][$key] += $value;
                $totals[$key] += $value;
            }

            $incoming = trim((string) ($row['note'] ?? ''));
            if ($incoming !== '') {
                $parts = array_values(array_filter(array_map('trim', preg_split('/\R+/', $incoming) ?: [])));
                $grouped[$speciesName]['rows'][$diameterKey]['_notes'] = array_values(array_unique(array_merge(
                    $grouped[$speciesName]['rows'][$diameterKey]['_notes'],
                    $parts
                )));
                $grouped[$speciesName]['_notes'] = array_values(array_unique(array_merge(
                    $grouped[$speciesName]['_notes'],
                    $parts
                )));
            }
        }

        ksort($grouped, SORT_NATURAL);

        foreach ($grouped as &$group) {
            uasort($group['rows'], fn ($a, $b) => ((int) $a['diameter_cm']) <=> ((int) $b['diameter_cm']));

            foreach ($group['rows'] as &$item) {
                foreach (['q1_liquid', 'q1_firewood', 'q2_liquid', 'q2_firewood', 'all_total'] as $key) {
                    $item[$key] = round((float) $item[$key], 3);
                }
                $item['note'] = implode("
", $item['_notes']);
                unset($item['_notes']);
            }
            unset($item);

            foreach (['q1_liquid', 'q1_firewood', 'q2_liquid', 'q2_firewood', 'all_total'] as $key) {
                $group[$key] = round((float) $group[$key], 3);
            }

            $group['note'] = implode("
", $group['_notes']);
            unset($group['_notes']);
            $group['rows'] = array_values($group['rows']);
        }
        unset($group);

        foreach (['q1_liquid', 'q1_firewood', 'q2_liquid', 'q2_firewood', 'all_total'] as $key) {
            $totals[$key] = round((float) $totals[$key], 3);
        }

        return [
            'groups' => array_values($grouped),
            'totals' => $totals,
        ];
    }

    private function buildN11SummaryTotalText(array $totals): string
    {
        $q1Total = (float) ($totals['q1_total'] ?? 0);
        $q2Total = (float) ($totals['q2_total'] ?? 0);
        $smallTotal = (float) ($totals['small_total'] ?? 0);
        $grandTotal = $q1Total + $q2Total + $smallTotal;

        return $this->formatNumber($grandTotal, 3);
    }

    private function applyN11BlockHeaderStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2EFDA'],
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
                'outline' => ['borderStyle' => Border::BORDER_MEDIUM],
            ],
        ]);
    }

    private function applyN11TableHeaderStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 9,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2EFDA'],
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
                'outline' => ['borderStyle' => Border::BORDER_MEDIUM],
            ],
        ]);
    }

    private function applySectionTitleStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 11,
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
                'outline' => ['borderStyle' => Border::BORDER_MEDIUM],
            ],
        ]);
    }

    private function applyMetaRowStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
            ],
        ]);
    }

    private function applyTableHeaderStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2EFDA'],
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
            ],
        ]);
    }

    private function applyBodyRowStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
            ],
        ]);
    }

    private function applyTotalRowStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'bold' => false,
                'size' => 10,
            ],
            'alignment' => [
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E2EFDA']
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
            ],
        ]);
    }

    private function applyNoteStyle(Worksheet $sheet, string $range): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'italic' => true,
                'size' => 9,
            ],
            'alignment' => [
                'vertical' => Alignment::VERTICAL_TOP,
                'wrapText' => true,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_THIN],
            ],
        ]);
    }

    private function makeSpeciesRichText(
        string $speciesName,
        string $latinName = '',
        int $fontSize = 8,
        ?int $latinFontSize = null
    ): RichText
    {
        $richText = new RichText();

        $speciesName = trim($speciesName);
        $latinName = trim($latinName);
        $latinFontSize = $latinFontSize ?? $fontSize;

        $mainRun = $richText->createTextRun($speciesName !== '' ? $speciesName : '—');
        $mainRun->getFont()
            ->setName('Sylfaen')
            ->setSize($fontSize)
            ->setItalic(false);

        if ($latinName !== '') {
            $latinRun = $richText->createTextRun("\n" . $latinName);
            $latinRun->getFont()
                ->setName('Sylfaen')
                ->setSize($latinFontSize)
                ->setItalic(true);
        }

        return $richText;
    }

    private function resolveSpeciesSummaryRankValue(object $item): string
    {
        if (method_exists($item, 'relationLoaded') && $item->relationLoaded('rank') && $item->rank) {
            $rankNum = $item->rank->rank_num ?? null;
            if (!is_null($rankNum) && trim((string) $rankNum) !== '') {
                return trim((string) $rankNum);
            }

            $rankName = trim((string) ($item->rank->name ?? ''));
            if ($rankName !== '') {
                return $rankName;
            }
        }

        foreach (['manual_rank_num', 'rank_actual', 'height_rank', 'rank', 'rank_num'] as $field) {
            $value = $item->{$field} ?? null;
            if (!is_null($value) && trim((string) $value) !== '') {
                return trim((string) $value);
            }
        }

        return '';
    }

    private function extractNumericRankValue(mixed $value): int
    {
        $value = trim((string) $value);
        if ($value === '') {
            return 0;
        }

        if (preg_match('/\d+/', $value, $matches) === 1) {
            return (int) $matches[0];
        }

        $romanMap = [
            'I' => 1,
            'II' => 2,
            'III' => 3,
            'IV' => 4,
            'V' => 5,
            'VI' => 6,
            'VII' => 7,
            'VIII' => 8,
            'IX' => 9,
            'X' => 10,
        ];

        $normalized = strtoupper(preg_replace('/[^IVX]/i', '', $value));

        return $romanMap[$normalized] ?? 0;
    }

    private function toRomanNumeral(mixed $value): string
    {
        $number = $this->extractNumericRankValue($value);
        if ($number <= 0) {
            return trim((string) $value);
        }

        $map = [
            10 => 'X',
            9 => 'IX',
            8 => 'VIII',
            7 => 'VII',
            6 => 'VI',
            5 => 'V',
            4 => 'IV',
            3 => 'III',
            2 => 'II',
            1 => 'I',
        ];

        $result = '';
        foreach ($map as $arabic => $roman) {
            while ($number >= $arabic) {
                $result .= $roman;
                $number -= $arabic;
            }
        }

        return $result !== '' ? $result : trim((string) $value);
    }

    private function calculateMergedRowHeight(string $mainText = '', string $latinText = '', float $baseHeight = 24): float
    {
        $mainText = trim($mainText);
        $latinText = trim($latinText);

        $mainLines = $mainText !== '' ? max(1, substr_count($mainText, "\n") + 1) : 1;
        $latinLines = $latinText !== '' ? max(1, substr_count($latinText, "\n") + 1) : 0;

        $totalLines = $mainLines + $latinLines;

        $height = ($totalLines * 18) + 8;

        if ($latinText !== '') {
            $height += 4;
        }

        return max($baseHeight, $height);
    }

    private function groupReportRowsBySpecies(array $reportRows): array
    {
        $grouped = [];

        foreach ($reportRows as $row) {
            $speciesName = $row['species_name'];

            if (!isset($grouped[$speciesName])) {
                $grouped[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                    'note' => trim((string) ($row['note'] ?? '')),
                    'q1_count' => 0,
                    'q1_total' => 0.0,
                    'q2_count' => 0,
                    'q2_total' => 0.0,
                    'all_count' => 0,
                    'all_total' => 0.0,
                ];
            }

            $incomingNote = trim((string) ($row['note'] ?? ''));
            if ($incomingNote !== '') {
                $existingNote = trim((string) ($grouped[$speciesName]['note'] ?? ''));
                $existingParts = preg_split('/\R+/', $existingNote ?: '') ?: [];
                $incomingParts = preg_split('/\R+/', $incomingNote) ?: [];
                $grouped[$speciesName]['note'] = implode("\n", array_values(array_unique(array_filter(array_map('trim', array_merge($existingParts, $incomingParts))))));
            }

            $grouped[$speciesName]['q1_count'] += (int) ($row['q1_count'] ?? 0);
            $grouped[$speciesName]['q1_total'] += (float) ($row['q1_total'] ?? 0);
            $grouped[$speciesName]['q2_count'] += (int) ($row['q2_count'] ?? 0);
            $grouped[$speciesName]['q2_total'] += (float) ($row['q2_total'] ?? 0);
            $grouped[$speciesName]['all_count'] += (int) ($row['all_count'] ?? 0);
            $grouped[$speciesName]['all_total'] += (float) ($row['all_total'] ?? 0);
        }

        ksort($grouped, SORT_NATURAL);

        return array_values($grouped);
    }

    private function buildSmallDiameterRowsFromSmallTreeBlock(Tyekafi $tyekafi): array
    {
        $rows = TyekafiSmallTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->with('species:id,name,latin_name,red_list')
            ->orderBy('row_order')
            ->orderBy('id')
            ->get();

        $grouped = [];

        foreach ($rows as $row) {
            $speciesName = $row->species?->name ?: '—';
            $speciesLatinName = trim((string) ($row->species?->latin_name ?? ''));
            $quantity = (int) ($row->quantity ?? 0);
            $volume = $this->formatNumber($quantity * 0.001, 3);

            if (!isset($grouped[$speciesName])) {
                $grouped[$speciesName] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => $speciesLatinName,
                    'count' => 0,
                    'volume' => 0.0,
                    'is_red_list' => false,
                ];
            }

            if (
                trim((string) ($grouped[$speciesName]['species_latin_name'] ?? '')) === ''
                && $speciesLatinName !== ''
            ) {
                $grouped[$speciesName]['species_latin_name'] = $speciesLatinName;
            }

            $grouped[$speciesName]['count'] += $quantity;
            $grouped[$speciesName]['volume'] += $volume;
            $grouped[$speciesName]['is_red_list'] = $grouped[$speciesName]['is_red_list']
                || (trim((string) ($row->species?->red_list ?? '')) !== '');
        }

        foreach ($grouped as &$item) {
            $item['volume'] = round((float) $item['volume'], 3);
        }
        unset($item);

        return array_values($grouped);
    }

    private function sumSmallDiameterRows(array $rows): array
    {
        $totalCount = 0;
        $totalVolume = 0.0;

        foreach ($rows as $row) {
            $totalCount += (int) ($row['count'] ?? 0);
            $totalVolume += (float) ($row['volume'] ?? 0);
        }

        return [
            'count' => $totalCount,
            'volume' => $this->formatNumber($totalVolume, 3),
        ];
    }

    private function valueFromCandidates(object $source, array $keys, mixed $default = '—'): mixed
    {
        foreach ($keys as $key) {
            $value = data_get($source, $key);

            if ($value !== null && $value !== '') {
                return $value;
            }
        }

        return $default;
    }

    private function formatDateValue(mixed $value): string
    {
        if (empty($value) || $value === '—') {
            return '—';
        }

        try {
            return \Carbon\Carbon::parse($value)->format('d.m.Y');
        } catch (\Throwable $e) {
            return (string) $value;
        }
    }

    private function formatNumber(mixed $value, int $decimals = 3): string
    {
        if ($value === null || $value === '') {
            return '';
        }

        $number = (float) $value;
        $threshold = 1 / (10 ** max(0, $decimals));

        if (abs($number) < $threshold) {
            return '';
        }

        return number_format($number, $decimals, '.', '');
    }

    private function buildReportData(Collection $rows, Collection $summaries, Collection $species): array
    {
        $speciesById = $species->keyBy('id');

        $speciesNameById = $speciesById->map(fn ($s) => (string) $s->name)->all();
        $speciesLatinNameById = $speciesById->map(fn ($s) => trim((string) ($s->latin_name ?? '')))->all();
        $speciesRedListById = $speciesById->map(function ($s) {
            return trim((string) ($s->red_list ?? '')) !== '';
        })->all();

        $valid = $rows->filter(function ($r) {
            return !is_null($r->tree_species_id)
                && !is_null($r->diameter_cm)
                && (float) $r->diameter_cm > 0;
        });

        $reportRows = [];
        $speciesSummaryRows = [];

        $totals = [
            'q1_count' => 0,
            'q1_liquid' => 0.0,
            'q1_firewood' => 0.0,
            'q1_total' => 0.0,
            'q2_count' => 0,
            'q2_liquid' => 0.0,
            'q2_firewood' => 0.0,
            'q2_total' => 0.0,
            'all_count' => 0,
            'all_liquid' => 0.0,
            'all_firewood' => 0.0,
            'all_total' => 0.0,
        ];

        foreach ($valid as $sourceRow) {
            $speciesId = (int) $sourceRow->tree_species_id;
            $speciesName = $speciesNameById[$speciesId] ?? '—';
            $speciesLatinName = $speciesLatinNameById[$speciesId] ?? '';
            $diameter = (int) round((float) $sourceRow->diameter_cm);

            $manualNote = trim((string) ($sourceRow->note ?? ''));
            $isRedList = (bool) ($speciesRedListById[$speciesId] ?? false);

            $noteLines = [];
            if ($isRedList) {
                $noteLines[] = 'წითელი ნუსხა';
            }
            if ($manualNote !== '') {
                $noteLines[] = $manualNote;
            }

            $note = implode("\n", array_values(array_unique($noteLines)));

            $sum = $summaries->get($speciesId);

            $rankMethod = $sum?->rank_method;
            $rankMethod = ($rankMethod === '' || is_null($rankMethod)) ? 'h' : (string) $rankMethod;
            if (!in_array($rankMethod, ['h', 'manual'], true)) {
                $rankMethod = 'h';
            }

            $height = $sum?->height_m;
            $height = ($height === '' || is_null($height)) ? null : (float) $height;

            $manualRankNum = null;
            if ($sum && $sum->relationLoaded('rank') && $sum->rank && !is_null($sum->rank->rank_num)) {
                $manualRankNum = (int) $sum->rank->rank_num;
            } elseif (!is_null($sum?->manual_rank_num) && is_numeric($sum->manual_rank_num)) {
                $manualRankNum = (int) $sum->manual_rank_num;
            }

            $perLiquid = 0.0;
            $perFirewood = 0.0;
            $perTotal = 0.0;

            $tariffTableId = null;
            if ($speciesName && $speciesName !== '—') {
                $mapping = TariffSpeciesMapping::query()
                    ->where('species_name', $speciesName)
                    ->first();

                $tariffTableId = $mapping ? (int) $mapping->tariff_table_id : null;
            }

            $canCalc =
                $tariffTableId
                && $diameter > 0
                && (
                    ($rankMethod === 'h' && !is_null($height) && $height > 0)
                    || ($rankMethod === 'manual' && !is_null($manualRankNum) && $manualRankNum > 0)
                );

            if ($canCalc) {
                $nearestDt = TariffValue::query()
                    ->where('tariff_table_id', $tariffTableId)
                    ->select('dt_cm')
                    ->distinct()
                    ->orderByRaw('ABS(CAST(dt_cm AS SIGNED) - ?) asc', [$diameter])
                    ->value('dt_cm');

                if (!is_null($nearestDt)) {
                    $tvQuery = TariffValue::query()
                        ->where('tariff_table_id', $tariffTableId)
                        ->where('dt_cm', (int) $nearestDt);

                    if ($rankMethod === 'h') {
                        $tvQuery = $tvQuery
                            ->where(function ($q) use ($height) {
                                $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $height);
                            })
                            ->where(function ($q) use ($height) {
                                $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $height);
                            })
                            ->orderByRaw('COALESCE(h_min_m, -999) desc');
                    } else {
                        $tvQuery = $tvQuery->where('rank', (int) $manualRankNum);
                    }

                    $tv = $tvQuery->first();

                    if ($tv) {
                        $perLiquid = (float) ($tv->liquid_m3 ?? 0);
                        $perFirewood = (float) ($tv->crown_firewood_m3 ?? 0);
                        $perTotal = is_null($tv->total_m3)
                            ? ($perLiquid + $perFirewood)
                            : (float) $tv->total_m3;
                    }
                }
            }

            $quality = is_null($sourceRow->quality) || $sourceRow->quality === ''
                ? null
                : (string) $sourceRow->quality;

            $count = (int) ($sourceRow->trees_count ?? 1);
            if ($count < 1) {
                $count = 1;
            }

            for ($i = 0; $i < $count; $i++) {
                $q1Count = $quality === '1' ? 1 : 0;
                $q2Count = $quality === '2' ? 1 : 0;

                $q1Liquid = $quality === '1' ? $perLiquid : 0.0;
                $q1Firewood = $quality === '1' ? $perFirewood : 0.0;
                $q1Total = $quality === '1' ? $perTotal : 0.0;

                $q2Liquid = $quality === '2' ? $perLiquid : 0.0;
                $q2Firewood = $quality === '2' ? $perFirewood : 0.0;
                $q2Total = $quality === '2' ? $perTotal : 0.0;

                $allCount = $q1Count + $q2Count;
                $allLiquid = $q1Liquid + $q2Liquid;
                $allFirewood = $q1Firewood + $q2Firewood;
                $allTotal = $q1Total + $q2Total;

                $reportRows[] = [
                    'species_name' => $speciesName,
                    'species_latin_name' => $speciesLatinName,
                    'diameter_cm' => $diameter,
                    'q1_count' => $q1Count,
                    'q1_liquid' => $q1Liquid,
                    'q1_firewood' => $q1Firewood,
                    'q1_total' => $q1Total,
                    'q2_count' => $q2Count,
                    'q2_liquid' => $q2Liquid,
                    'q2_firewood' => $q2Firewood,
                    'q2_total' => $q2Total,
                    'all_count' => $allCount,
                    'all_liquid' => $allLiquid,
                    'all_firewood' => $allFirewood,
                    'all_total' => $allTotal,
                    'note' => $note,
                ];

                if (!isset($speciesSummaryRows[$speciesName])) {
                    $speciesSummaryRows[$speciesName] = [
                        'species_name' => $speciesName,
                        'species_latin_name' => $speciesLatinName,
                        'note' => $note,
                        'q1_count' => 0,
                        'q1_total' => 0.0,
                        'q2_count' => 0,
                        'q2_total' => 0.0,
                        'all_count' => 0,
                        'all_total' => 0.0,
                    ];
                }

                if ($note !== '') {
                    $existingNote = trim((string) ($speciesSummaryRows[$speciesName]['note'] ?? ''));
                    $noteParts = preg_split('/\R+/', $existingNote ?: '') ?: [];
                    $newParts = preg_split('/\R+/', $note) ?: [];
                    $mergedNoteParts = array_values(array_unique(array_filter(array_map('trim', array_merge($noteParts, $newParts)))));
                    $speciesSummaryRows[$speciesName]['note'] = implode("\n", $mergedNoteParts);
                }

                $speciesSummaryRows[$speciesName]['q1_count'] += $q1Count;
                $speciesSummaryRows[$speciesName]['q1_total'] += $q1Total;
                $speciesSummaryRows[$speciesName]['q2_count'] += $q2Count;
                $speciesSummaryRows[$speciesName]['q2_total'] += $q2Total;
                $speciesSummaryRows[$speciesName]['all_count'] += $allCount;
                $speciesSummaryRows[$speciesName]['all_total'] += $allTotal;

                $totals['q1_count'] += $q1Count;
                $totals['q1_liquid'] += $q1Liquid;
                $totals['q1_firewood'] += $q1Firewood;
                $totals['q1_total'] += $q1Total;

                $totals['q2_count'] += $q2Count;
                $totals['q2_liquid'] += $q2Liquid;
                $totals['q2_firewood'] += $q2Firewood;
                $totals['q2_total'] += $q2Total;

                $totals['all_count'] += $allCount;
                $totals['all_liquid'] += $allLiquid;
                $totals['all_firewood'] += $allFirewood;
                $totals['all_total'] += $allTotal;
            }
        }

        ksort($speciesSummaryRows, SORT_NATURAL);

        return [
            'rows' => array_values($reportRows),
            'species_summary_rows' => array_values($speciesSummaryRows),
            'totals' => $totals,
        ];
    }

    private function autoFitRowsByMergedContent(
        Worksheet $sheet,
        int $startRow,
        int $endRow,
        string $startColumn = 'A',
        string $endColumn = 'M',
        float $minHeight = 18,
        float $fontSize = 9
    ): void {
        $startColIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($startColumn);
        $endColIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($endColumn);
        $mergedRanges = $sheet->getMergeCells();

        for ($row = $startRow; $row <= $endRow; $row++) {
            $maxHeight = $sheet->getRowDimension($row)->getRowHeight();
            if (!is_numeric($maxHeight) || (float) $maxHeight <= 0) {
                $maxHeight = $minHeight;
            }

            $processed = [];

            foreach ($mergedRanges as $range) {
                $bounds = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::rangeBoundaries($range);
                $minCol = (int) $bounds[0][0];
                $minRow = (int) $bounds[0][1];
                $maxCol = (int) $bounds[1][0];
                $maxRow = (int) $bounds[1][1];

                if ($row < $minRow || $row > $maxRow) {
                    continue;
                }

                if ($minCol > $endColIndex || $maxCol < $startColIndex) {
                    continue;
                }

                $topLeft = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($minCol) . $minRow;
                if (isset($processed[$topLeft])) {
                    continue;
                }
                $processed[$topLeft] = true;

                $value = trim((string) $sheet->getCell($topLeft)->getFormattedValue());
                if ($value === '') {
                    continue;
                }

                $width = 0.0;
                for ($col = max($startColIndex, $minCol); $col <= min($endColIndex, $maxCol); $col++) {
                    $letter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($col);
                    $colWidth = $sheet->getColumnDimension($letter)->getWidth();
                    $width += is_numeric($colWidth) ? (float) $colWidth : 8.43;
                }

                $charsPerLine = (int) max(8, floor($width * 1.1));
                $rowsSpanned = max(1, $maxRow - $minRow + 1);
                $estimated = $this->calculateWrappedTextRowHeight($value, $charsPerLine, $minHeight, max(11, $fontSize + 3));

                if ($rowsSpanned > 1) {
                    $estimated = max($minHeight, $estimated / $rowsSpanned);
                }

                $maxHeight = max($maxHeight, $estimated);
            }

            for ($col = $startColIndex; $col <= $endColIndex; $col++) {
                $letter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($col);
                $coord = $letter . $row;
                if (isset($processed[$coord])) {
                    continue;
                }

                $value = trim((string) $sheet->getCell($coord)->getFormattedValue());
                if ($value === '') {
                    continue;
                }

                $colWidth = $sheet->getColumnDimension($letter)->getWidth();
                $width = is_numeric($colWidth) ? (float) $colWidth : 8.43;
                $charsPerLine = (int) max(6, floor($width * 1.1));
                $estimated = $this->calculateWrappedTextRowHeight($value, $charsPerLine, $minHeight, max(11, $fontSize + 3));
                $maxHeight = max($maxHeight, $estimated);
            }

            $sheet->getRowDimension($row)->setRowHeight($maxHeight);
        }
    }

    private function calculateWrappedTextRowHeight(?string $text, int $charsPerLine = 30, float $baseHeight = 18, float $lineHeight = 15): float
    {
        $text = trim((string) $text);

        if ($text === '') {
            return $baseHeight;
        }

        $lines = preg_split('/\R/u', $text) ?: [];
        $visualLineCount = 0;

        foreach ($lines as $line) {
            $line = (string) $line;
            $length = function_exists('mb_strlen') ? mb_strlen($line) : strlen($line);

            if ($length === 0) {
                $visualLineCount++;
                continue;
            }

            $visualLineCount += (int) max(1, ceil($length / max(1, $charsPerLine)));
        }

        return max($baseHeight, $visualLineCount * $lineHeight + 2);
    }

    private function applyAdaptiveFontSizeForRange(
        Worksheet $sheet,
        string $range,
        ?string $text,
        int $defaultSize = 10,
        int $mediumThreshold = 24,
        int $mediumSize = 9,
        int $smallThreshold = 34,
        int $smallSize = 8
    ): void {
        $text = trim((string) $text);
        $length = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
        $size = $defaultSize;

        if ($length > $smallThreshold) {
            $size = $smallSize;
        } elseif ($length > $mediumThreshold) {
            $size = $mediumSize;
        }

        $sheet->getStyle($range)->getFont()->setSize($size);
    }

    private function applyN1CustomHeader(Worksheet $sheet): void
    {
        foreach (["A1:E3", "F1:J3", "K1:K3", "C1:I1", "J1:K1"] as $range) {
            if ($sheet->getMergeCells() && array_key_exists($range, $sheet->getMergeCells())) {
                $sheet->unmergeCells($range);
            }
        }

        $sheet->mergeCells('C1:I1');
        $sheet->mergeCells('J1:K1');

        foreach (range('A', 'K') as $column) {
            $sheet->setCellValue($column . '1', null);
            $sheet->setCellValue($column . '2', null);
            $sheet->setCellValue($column . '3', null);
        }

        $sheet->setCellValue('C1', 'ტყეკაფის აღრიცხვის უწყისი');
        $sheet->getStyle('C1:I1')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 16,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
        ]);

        $sheet->setCellValue('J1', 'დანართი №1');
        $sheet->getStyle('J1:K1')->applyFromArray([
            'font' => [
                'bold' => false,
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_RIGHT,
                'vertical' => Alignment::VERTICAL_TOP,
                'wrapText' => true,
            ],
        ]);

        $sheet->getRowDimension(1)->setRowHeight(24);
        $sheet->getRowDimension(2)->setRowHeight(0);
        $sheet->getRowDimension(3)->setRowHeight(0);
        $sheet->getRowDimension(2)->setVisible(false);
        $sheet->getRowDimension(3)->setVisible(false);
    }

    private function applyN11CustomHeader(Worksheet $sheet, int|string $tyekafiId): void
    {
        $sheet->mergeCells('A1:D3');
        $sheet->mergeCells('E2:J2');
        $sheet->mergeCells('F3:I3');
        $sheet->mergeCells('K1:M1');

        $sheet->setCellValue('E2', 'ტყეკაფის პასპორტი');
        $sheet->getStyle('E2:J2')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 16,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
        ]);

        $sheet->setCellValue('F3', 'ტყეკაფი №');
        $sheet->getStyle('F3:I3')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 9,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
            ],
        ]);

        $sheet->setCellValue('K1', 'დანართი № 11');
        $sheet->getStyle('K1:M1')->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_RIGHT,
                'vertical' => Alignment::VERTICAL_TOP,
                'wrapText' => true,
            ],
        ]);

        $sheet->getRowDimension(1)->setRowHeight(15);
        $sheet->getRowDimension(2)->setRowHeight(30);
        $sheet->getRowDimension(3)->setRowHeight(20);

        $sheet->getStyle('A1:M1')->getFont()->setSize(9);
        $sheet->getStyle('A2:M2')->getFont()->setSize(16);
        $sheet->getStyle('A3:M3')->getFont()->setSize(9);
    }

    private function applyBrandHeader(
        Worksheet $sheet,
        int $startRow,
        string $annexTitle,
        string $mainTitle,
        string $brandStartCol = 'A',
        string $brandEndCol = 'D',
        string $titleStartCol = 'E',
        string $titleEndCol = 'H',
        string $annexStartCol = 'I',
        ?string $annexEndCol = 'K'
    ): void {
        $brandRange = "{$brandStartCol}{$startRow}:{$brandEndCol}" . ($startRow + 2);
        $titleRange = "{$titleStartCol}{$startRow}:{$titleEndCol}" . ($startRow + 2);
        $annexRange = "{$annexStartCol}{$startRow}:" . ($annexEndCol ?: $annexStartCol) . "{$startRow}";

        $sheet->mergeCells($brandRange);
        $sheet->mergeCells($titleRange);
        $sheet->mergeCells($annexRange);

        $logoPath = $this->resolveReportLogoPath();
        if ($logoPath) {
            $drawing = new Drawing();
            $drawing->setName('Company Logo');
            $drawing->setDescription('Company Logo');
            $drawing->setPath($logoPath);
            $drawing->setHeight(54);
            $drawing->setCoordinates($brandStartCol . $startRow);
            $drawing->setOffsetX(8);
            $drawing->setOffsetY(4);
            $drawing->setWorksheet($sheet);
        }

        $companyDisplayName = "საქართველოს\nსატყეო სერვისები";
        $brandTextColumn = $this->nextColumn($brandStartCol, 1);

        $sheet->setCellValue($brandTextColumn . $startRow, $companyDisplayName);
        $sheet->getStyle($brandRange)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 12,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_RIGHT,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
        ]);

        $sheet->setCellValue($titleStartCol . $startRow, $mainTitle);
        $sheet->getStyle($titleRange)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 16,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true,
            ],
        ]);

        $sheet->setCellValue($annexStartCol . $startRow, $annexTitle);
        $sheet->getStyle($annexRange)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 11,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_RIGHT,
                'vertical' => Alignment::VERTICAL_TOP,
                'wrapText' => true,
            ],
        ]);

        $sheet->getRowDimension($startRow)->setRowHeight(20);
        $sheet->getRowDimension($startRow + 1)->setRowHeight(28);
        $sheet->getRowDimension($startRow + 2)->setRowHeight(20);
    }

    private function resolveReportLogoPath(): ?string
    {
        foreach ([
            public_path('images/logo.png'),
            public_path('images/company-logo.png'),
            public_path('img/logo.png'),
            public_path('logo.png'),
        ] as $logoPath) {
            if (is_file($logoPath)) {
                return $logoPath;
            }
        }

        return null;
    }

    private function nextColumn(string $column, int $steps = 1): string
    {
        $index = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($column);

        return \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($index + max(0, $steps));
    }


    private function buildCompositionSpeciesRows($heightRankSummaries, array $smallDiameterRows, array $compositionRows): array
    {
        $compositionUnitBySpecies = [];
        foreach ($compositionRows as $compositionRow) {
            $speciesKey = trim((string) ($compositionRow['species'] ?? ''));
            if ($speciesKey === '') {
                continue;
            }

            $compositionUnitBySpecies[$speciesKey] = (string) ($compositionRow['unit'] ?? '+');
        }

        $rowsBySpecies = [];

        foreach ($heightRankSummaries as $item) {
            $speciesName = trim((string) ($item->species?->name ?? ''));
            if ($speciesName === '') {
                continue;
            }

            $latinName = trim((string) ($item->species?->latin_name ?? ''));
            $rankValue = $this->resolveSpeciesSummaryRankValue($item);
            $romanRank = $rankValue !== '' ? $this->toRomanNumeral($rankValue) : '—';
            $rankSort = $rankValue !== '' ? $this->extractNumericRankValue($rankValue) : 9999;

            $rowsBySpecies[$speciesName] = [
                'composition_unit' => $compositionUnitBySpecies[$speciesName] ?? '+',
                'species_name' => $speciesName,
                'species_latin_name' => $latinName,
                'rank' => $romanRank,
                'rank_sort' => $rankSort,
            ];
        }

        $rows = array_values($rowsBySpecies);
        usort($rows, function (array $a, array $b): int {
            $aUnit = $a['composition_unit'] === '+' ? 0 : (int) $a['composition_unit'];
            $bUnit = $b['composition_unit'] === '+' ? 0 : (int) $b['composition_unit'];

            if ($aUnit !== $bUnit) {
                return $bUnit <=> $aUnit;
            }

            if (($a['rank_sort'] ?? 9999) !== ($b['rank_sort'] ?? 9999)) {
                return ($a['rank_sort'] ?? 9999) <=> ($b['rank_sort'] ?? 9999);
            }

            return strnatcasecmp((string) ($a['species_name'] ?? ''), (string) ($b['species_name'] ?? ''));
        });

        return $rows;
    }

    private function calculateCompositionRows(array $summaryFromBlock1, array $smallDiameterRows = []): array
    {
        $combined = [];

        foreach ($summaryFromBlock1 as $row) {
            $speciesName = trim((string) ($row['species_name'] ?? ''));
            if ($speciesName === '') {
                continue;
            }

            if (!isset($combined[$speciesName])) {
                $combined[$speciesName] = [
                    'volume' => 0.0,
                    'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                ];
            }

            $combined[$speciesName]['volume'] += (float) ($row['all_total'] ?? 0);

            if (
                trim((string) ($combined[$speciesName]['species_latin_name'] ?? '')) === ''
                && trim((string) ($row['species_latin_name'] ?? '')) !== ''
            ) {
                $combined[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
            }
        }

        $combined = array_filter($combined, fn ($item) => (float) ($item['volume'] ?? 0) > 0);

        $rows = [];
        $includedSpecies = [];

        if (!empty($combined)) {
            uasort($combined, fn ($a, $b) => ((float) ($b['volume'] ?? 0)) <=> ((float) ($a['volume'] ?? 0)));

            $totalVolume = array_sum(array_map(fn ($item) => (float) ($item['volume'] ?? 0), $combined));
            if ($totalVolume > 0) {
                $allocations = [];
                $floorSum = 0;

                foreach ($combined as $speciesName => $itemData) {
                    $volume = (float) ($itemData['volume'] ?? 0);
                    $latinName = trim((string) ($itemData['species_latin_name'] ?? ''));

                    $raw = ($volume / $totalVolume) * 10;
                    $floor = (int) floor($raw);

                    $allocations[$speciesName] = [
                        'species' => $speciesName,
                        'species_latin_name' => $latinName,
                        'volume' => round($volume, 3),
                        'raw' => $raw,
                        'unit' => $floor,
                        'remainder' => $raw - $floor,
                    ];

                    $floorSum += $floor;
                }

                $remaining = max(0, 10 - $floorSum);

                if ($remaining > 0) {
                    uasort($allocations, function (array $a, array $b) {
                        $remainderCompare = $b['remainder'] <=> $a['remainder'];
                        if ($remainderCompare !== 0) {
                            return $remainderCompare;
                        }

                        $volumeCompare = $b['volume'] <=> $a['volume'];
                        if ($volumeCompare !== 0) {
                            return $volumeCompare;
                        }

                        return strnatcasecmp($a['species'], $b['species']);
                    });

                    foreach ($allocations as &$item) {
                        if ($remaining <= 0) {
                            break;
                        }

                        $item['unit']++;
                        $remaining--;
                    }
                    unset($item);
                }

                uasort($allocations, function (array $a, array $b) {
                    $unitCompare = $b['unit'] <=> $a['unit'];
                    if ($unitCompare !== 0) {
                        return $unitCompare;
                    }

                    $rawCompare = $b['raw'] <=> $a['raw'];
                    if ($rawCompare !== 0) {
                        return $rawCompare;
                    }

                    return strnatcasecmp($a['species'], $b['species']);
                });

                foreach ($allocations as $item) {
                    if ($item['unit'] > 0) {
                        $rows[] = [
                            'unit' => $item['unit'],
                            'species' => $item['species'],
                            'species_latin_name' => $item['species_latin_name'] ?? '',
                        ];
                        $includedSpecies[$item['species']] = true;
                        continue;
                    }

                    if ($item['raw'] > 0) {
                        $rows[] = [
                            'unit' => '+',
                            'species' => $item['species'],
                            'species_latin_name' => $item['species_latin_name'] ?? '',
                        ];
                        $includedSpecies[$item['species']] = true;
                    }
                }
            }
        }

        return array_slice($rows, 0, 10);
    }

    private function buildMarkerDisplay(Tyekafi $tyekafi): string
    {
        $user = $tyekafi->relationLoaded('user') ? $tyekafi->user : $tyekafi->user()->first();

        if (! $user) {
            return '—';
        }

        $position = trim((string) ($user->position ?? ''));
        $fullName = trim(implode(' ', array_filter([
            $user->name ?? null,
            $user->surname ?? null,
        ])));

        if ($position !== '' && $fullName !== '') {
            return $position . "\n" . $fullName;
        }

        if ($position !== '') {
            return $position;
        }

        return $fullName !== '' ? $fullName : '—';
    }

    private function resolveSignatureImagePath(Tyekafi $tyekafi): ?string
    {
        $user = $tyekafi->relationLoaded('user') ? $tyekafi->user : $tyekafi->user()->first();

        $signatureRelativePath = trim((string) ($user?->signature_path ?? ''));
        if ($signatureRelativePath === '') {
            return null;
        }

        $signatureFile = storage_path('app/public/' . ltrim($signatureRelativePath, '/'));

        return is_file($signatureFile) ? $signatureFile : null;
    }

    private function placeSignatureDrawing(
        Worksheet $sheet,
        string $coordinates,
        string $path,
        int $height = 80,
        int $offsetX = 10,
        int $offsetY = 4
    ): void {
        if (!is_file($path)) {
            return;
        }

        $drawing = new Drawing();
        $drawing->setName('Signature');
        $drawing->setDescription('Signature');
        $drawing->setPath($path);
        $drawing->setCoordinates($coordinates);
        $drawing->setOffsetX($offsetX);
        $drawing->setOffsetY($offsetY);
        $drawing->setResizeProportional(true);
        $drawing->setHeight($height);
        $drawing->setWorksheet($sheet);
    }

    private function applyLabelValueRowStyles(Worksheet $sheet, array $labelRanges, array $valueRanges): void
    {
        foreach ($labelRanges as $range) {
            $sheet->getStyle($range)->applyFromArray([
                'font' => [
                    'bold' => true,
                    'size' => 10,
                    'name' => 'Sylfaen',
                ],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_LEFT,
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'wrapText' => true,
                ],
            ]);
        }

        foreach ($valueRanges as $range) {
            $sheet->getStyle($range)->applyFromArray([
                'font' => [
                    'bold' => false,
                    'size' => 10,
                    'name' => 'Sylfaen',
                ],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_LEFT,
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'wrapText' => true,
                ],
            ]);
        }
    }

    private function applyPlainLabelValueRowStyles(Worksheet $sheet, string $labelRange, string $valueRange): void
    {
        $sheet->getStyle($labelRange)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_NONE],
            ],
        ]);

        $sheet->getStyle($valueRange)->applyFromArray([
            'font' => [
                'bold' => false,
                'size' => 10,
                'name' => 'Sylfaen',
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => Border::BORDER_NONE],
            ],
        ]);
    }

    private function applySectionHeaderStyle(Worksheet $sheet, string $range): void
    {
        $this->applySectionTitleStyle($sheet, $range);
    }

    private function applyTitleStyle(Worksheet $sheet, string $range, int $fontSize = 14): void
    {
        $sheet->getStyle($range)->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => $fontSize,
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
            ],
        ]);
    }
}