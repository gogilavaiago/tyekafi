<?php

namespace App\Http\Controllers;

use App\Models\TariffSpeciesMapping;
use App\Models\TariffValue;
use App\Models\TreeRank;
use App\Models\TreeSpecies;
use Illuminate\Http\Request;

class TariffApiController extends Controller
{
    public function lookup(Request $request)
    {
        $data = $request->validate([
            'tree_species_id' => ['required', 'integer', 'exists:tree_species,id'],
            'tree_rank_id'    => ['required', 'integer', 'exists:tree_ranks,id'],
            'diameter_cm'     => ['required', 'integer', 'min:8', 'max:300'],
        ]);

        $species = TreeSpecies::query()->findOrFail($data['tree_species_id']);
        $rank    = TreeRank::query()->findOrFail($data['tree_rank_id']);

        // rank number must be numeric (1..9).
        // If your ranks are Roman numerals or text, tell me and I’ll adjust.
        $rankNum = (int) preg_replace('/\D+/', '', (string)$rank->name);
        if ($rankNum <= 0) {
            return response()->json([
                'ok' => false,
                'message' => 'Rank value is not numeric. TreeRank.name must contain a number (1..9).',
            ], 422);
        }

        // mapping is name-based (species_name == TreeSpecies.name)
        $map = TariffSpeciesMapping::query()
            ->where('species_name', $species->name)
            ->first();

        if (!$map) {
            return response()->json([
                'ok' => false,
                'message' => 'No tariff mapping for this species_name: ' . $species->name,
            ], 404);
        }

        $tableId = (int) $map->tariff_table_id;
        $dt      = (int) $data['diameter_cm'];

        // Exact DT
        $exact = TariffValue::query()
            ->where('tariff_table_id', $tableId)
            ->where('rank', $rankNum)
            ->where('dt_cm', $dt)
            ->first();

        if ($exact) {
            $liq = (float) $exact->liquid_m3;
            $crw = (float) $exact->crown_firewood_m3;

            return response()->json([
                'ok' => true,
                'mode' => 'exact',
                'dt_cm' => $dt,
                'liquid_m3' => $liq,
                'crown_firewood_m3' => $crw,
                'total_m3' => $liq + $crw,
            ]);
        }

        // Interpolate nearest DT
        $lower = TariffValue::query()
            ->where('tariff_table_id', $tableId)
            ->where('rank', $rankNum)
            ->where('dt_cm', '<', $dt)
            ->orderByDesc('dt_cm')
            ->first();

        $upper = TariffValue::query()
            ->where('tariff_table_id', $tableId)
            ->where('rank', $rankNum)
            ->where('dt_cm', '>', $dt)
            ->orderBy('dt_cm')
            ->first();

        if (!$lower && !$upper) {
            return response()->json([
                'ok' => false,
                'message' => 'No tariff values found for this table/rank.',
            ], 404);
        }

        if (!$lower) $lower = $upper;
        if (!$upper) $upper = $lower;

        if ((int)$lower->dt_cm === (int)$upper->dt_cm) {
            $liq = (float) $lower->liquid_m3;
            $crw = (float) $lower->crown_firewood_m3;

            return response()->json([
                'ok' => true,
                'mode' => 'nearest',
                'dt_cm' => $dt,
                'liquid_m3' => $liq,
                'crown_firewood_m3' => $crw,
                'total_m3' => $liq + $crw,
                'source' => ['dt_cm' => (int)$lower->dt_cm],
            ]);
        }

        $x0 = (int) $lower->dt_cm;
        $x1 = (int) $upper->dt_cm;
        $t  = ($dt - $x0) / ($x1 - $x0);

        $lerp = fn(float $a, float $b) => $a + ($b - $a) * $t;

        $liq = $lerp((float)$lower->liquid_m3, (float)$upper->liquid_m3);
        $crw = $lerp((float)$lower->crown_firewood_m3, (float)$upper->crown_firewood_m3);

        return response()->json([
            'ok' => true,
            'mode' => 'interpolated',
            'dt_cm' => $dt,
            'liquid_m3' => $liq,
            'crown_firewood_m3' => $crw,
            'total_m3' => $liq + $crw,
            'source' => ['lower_dt_cm' => $x0, 'upper_dt_cm' => $x1],
        ]);
    }
}