<?php

namespace App\Http\Controllers;

use App\Models\Forest;
use App\Models\ForestDistrict;
use App\Models\Liter;
use App\Models\Quarter;
use App\Models\Region;
use Illuminate\Http\Request;

class HierarchyApiController extends Controller
{
    public function regions(Request $request)
    {
        $request->validate([
            'governing_body_id' => ['required', 'integer'],
        ]);

        return Region::query()
            ->where('governing_body_id', $request->integer('governing_body_id'))
            ->orderBy('name')
            ->get(['id', 'name']);
    }

    public function districts(Request $request)
    {
        $request->validate([
            'region_id' => ['required', 'integer'],
        ]);

        return ForestDistrict::query()
            ->where('region_id', $request->integer('region_id'))
            ->orderBy('name')
            ->get(['id', 'name']);
    }

    public function forests(Request $request)
    {
        $request->validate([
            'forest_district_id' => ['required', 'integer'],
        ]);

        return Forest::query()
            ->where('forest_district_id', $request->integer('forest_district_id'))
            ->orderBy('name')
            ->get(['id', 'name']);
    }

    public function quarters(Request $request)
    {
        $request->validate([
            'forest_id' => ['required', 'integer'],
        ]);

        return Quarter::query()
            ->where('forest_id', $request->integer('forest_id'))
            ->orderBy('name')
            ->get(['id', 'name']);
    }

    public function liters(Request $request)
    {
        $request->validate([
            'quarter_id' => ['required', 'integer'],
        ]);

        return Liter::query()
            ->where('quarter_id', $request->integer('quarter_id'))
            ->orderBy('name')
            ->get(['id', 'name']);
    }
}
