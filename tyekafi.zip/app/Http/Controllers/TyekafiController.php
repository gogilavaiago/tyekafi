<?php

namespace App\Http\Controllers;

use App\Models\Forest;
use App\Models\ForestDistrict;
use App\Models\ForestUseBasis;
use App\Models\GoverningBody;
use App\Models\Liter;
use App\Models\Project;
use App\Models\Quarter;
use App\Models\Region;
use App\Models\TariffSpeciesMapping;
use App\Models\TariffValue;
use App\Models\TreeRank;
use App\Models\TreeSpecies;
use App\Models\Tyekafi;
use App\Models\TyekafiSpeciesSummary;
use App\Models\TyekafiSmallTreeRow;
use App\Models\TyekafiTreeRow;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\IOFactory;

class TyekafiController extends Controller
{
    use AuthorizesRequests;

    private function ensureOwnProject(Project $project): void
    {
        abort_unless($project->user_id === auth()->id(), 403);
    }

    private function ensureOwnTyekafi(Project $project, Tyekafi $tyekafi): void
    {
        $this->ensureOwnProject($project);
        abort_unless($tyekafi->project_id === $project->id, 404);
        abort_unless($tyekafi->user_id === auth()->id(), 403);
    }

    /**
     * Pick nearest value from candidates by absolute difference.
     * Tie-breaker: choose the larger candidate.
     *
     * @param float $value
     * @param array<int|float|string|null> $candidates
     */
    private function nearestFromCandidates(float $value, array $candidates): ?int
    {
        $vals = collect($candidates)
            ->map(function ($v) {
                if ($v === '' || is_null($v)) return null;
                if (!is_numeric($v)) return null;
                $n = (int) round((float) $v);
                return $n > 0 ? $n : null;
            })
            ->filter()
            ->unique()
            ->values()
            ->all();

        if (count($vals) === 0) return null;

        $best = null;
        $bestDiff = null;

        foreach ($vals as $cand) {
            $diff = abs($cand - $value);

            if ($bestDiff === null || $diff < $bestDiff) {
                $best = $cand;
                $bestDiff = $diff;
                continue;
            }

            if ($diff === $bestDiff && $cand > $best) {
                $best = $cand;
            }
        }

        return $best;
    }

    /**
     * Bottom-block breakdown grouped by (species_id, diameter_cm).
     *
     * @return array<int, array<string,mixed>>
     */
    private function buildTreeVolumeBreakdown(Collection $rows, Collection $summaries, Collection $species): array
    {
        $valid = $rows->filter(function ($r) {
            return !is_null($r->tree_species_id) && !is_null($r->diameter_cm) && (float) $r->diameter_cm > 0;
        });

        if ($valid->count() === 0) return [];

        $speciesNameById = $species->keyBy('id')->map(fn ($s) => (string) $s->name)->all();

        $grouped = $valid->groupBy(function ($r) {
            $sid = (int) $r->tree_species_id;
            $d = (int) round((float) $r->diameter_cm);
            return $sid . '|' . $d;
        });

        $tariffTableIdBySpeciesName = [];
        $out = [];

        foreach ($grouped as $items) {
            $first = $items->first();

            $speciesId = (int) $first->tree_species_id;
            $diameter = (int) round((float) $first->diameter_cm);

            $count = (int) $items->sum(function ($r) {
                $c = (int) ($r->trees_count ?? 1);
                return $c > 0 ? $c : 1;
            });

            $qVals = $items->map(function ($r) {
                $q = $r->quality;
                $q = is_null($q) ? '' : (string) $q;
                return in_array($q, ['1', '2'], true) ? $q : '';
            })->filter()->unique()->values()->all();

            $qualityDisplay = '—';
            if (count($qVals) === 1) $qualityDisplay = $qVals[0];
            elseif (count($qVals) > 1) $qualityDisplay = 'mix';

            $speciesName = $speciesNameById[$speciesId] ?? '—';
            $sum = $summaries->get($speciesId);

            $rankMethod = $sum?->rank_method;
            $rankMethod = ($rankMethod === '' || is_null($rankMethod)) ? 'h' : (string) $rankMethod;
            if (!in_array($rankMethod, ['h', 'manual'], true)) $rankMethod = 'h';

            $height = $sum?->height_m;
            $height = ($height === '' || is_null($height)) ? null : (float) $height;

            $manualRankNum = null;
            if ($sum && $sum->relationLoaded('rank') && $sum->rank && !is_null($sum->rank->rank_num)) {
                $manualRankNum = (int) $sum->rank->rank_num;
            } elseif (!is_null($sum?->manual_rank_num) && is_numeric($sum->manual_rank_num)) {
                $manualRankNum = (int) $sum->manual_rank_num;
            }

            $tariffTableId = null;
            $appliedDt = null;

            $perLiquid = null;
            $perFirewood = null;
            $perTotal = null;

            $groupLiquid = null;
            $groupFirewood = null;
            $groupTotal = null;

            if ($speciesName && $speciesName !== '—') {
                if (array_key_exists($speciesName, $tariffTableIdBySpeciesName)) {
                    $tariffTableId = $tariffTableIdBySpeciesName[$speciesName];
                } else {
                    $mapping = TariffSpeciesMapping::query()
                        ->where('species_name', $speciesName)
                        ->first();
                    $tariffTableId = $mapping ? (int) $mapping->tariff_table_id : null;
                    $tariffTableIdBySpeciesName[$speciesName] = $tariffTableId;
                }
            }

            $canCalc =
                $tariffTableId
                && $diameter > 0
                && (
                    ($rankMethod === 'h' && !is_null($height) && $height > 0)
                    || ($rankMethod === 'manual' && !is_null($manualRankNum) && $manualRankNum > 0)
                );

            if ($canCalc) {
                $nearestDt = TariffValue::query()
                    ->where('tariff_table_id', $tariffTableId)
                    ->select('dt_cm')
                    ->distinct()
                    ->orderByRaw('ABS(CAST(dt_cm AS SIGNED) - ?) asc', [$diameter])
                    ->value('dt_cm');

                if (!is_null($nearestDt)) {
                    $appliedDt = (int) $nearestDt;

                    $tvQuery = TariffValue::query()
                        ->where('tariff_table_id', $tariffTableId)
                        ->where('dt_cm', (int) $nearestDt);

                    if ($rankMethod === 'h') {
                        $tvQuery = $tvQuery
                            ->where(function ($q) use ($height) {
                                $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $height);
                            })
                            ->where(function ($q) use ($height) {
                                $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $height);
                            })
                            ->orderByRaw('COALESCE(h_min_m, -999) desc');
                    } else {
                        $tvQuery = $tvQuery->where('rank', (int) $manualRankNum);
                    }

                    $tv = $tvQuery->first();

                    if ($tv) {
                        $perLiquid = is_null($tv->liquid_m3) ? null : (float) $tv->liquid_m3;
                        $perFirewood = is_null($tv->crown_firewood_m3) ? null : (float) $tv->crown_firewood_m3;

                        $perTotal = $tv->total_m3;
                        $perTotal = is_null($perTotal)
                            ? ((float) ($tv->liquid_m3 ?? 0) + (float) ($tv->crown_firewood_m3 ?? 0))
                            : (float) $perTotal;

                        $groupLiquid = is_null($perLiquid) ? null : $perLiquid * $count;
                        $groupFirewood = is_null($perFirewood) ? null : $perFirewood * $count;
                        $groupTotal = is_null($perTotal) ? null : $perTotal * $count;
                    }
                }
            }

            $out[] = [
                'species_id' => $speciesId,
                'species_name' => $speciesName,
                'diameter_cm' => $diameter,
                'count' => $count,
                'height_m' => $height,
                'quality_display' => $qualityDisplay,
                'applied_dt_cm' => $appliedDt,
                'per_liquid_m3' => $perLiquid,
                'per_firewood_m3' => $perFirewood,
                'per_total_m3' => $perTotal,
                'sum_liquid_m3' => $groupLiquid,
                'sum_firewood_m3' => $groupFirewood,
                'sum_total_m3' => $groupTotal,
            ];
        }

        usort($out, function ($a, $b) {
            if ($a['species_name'] !== $b['species_name']) return strcmp($a['species_name'], $b['species_name']);
            return $a['diameter_cm'] <=> $b['diameter_cm'];
        });

        return $out;
    }

    private function normalizeImportHeader(?string $value): string
    {
        $value = mb_strtolower(trim((string) $value), 'UTF-8');
        $value = str_replace(["\r", "\n", "\t"], ' ', $value);
        $value = preg_replace('/\s+/u', ' ', $value);

        $map = [
            'species' => 'species',
            'species name' => 'species',
            'species_name' => 'species',
            'tree species' => 'species',
            'სახეობა' => 'species',
            'ჯიში' => 'species',

            'quality' => 'quality',
            'class' => 'quality',
            'ხარისხი' => 'quality',

            'diameter' => 'diameter_cm',
            'diameter cm' => 'diameter_cm',
            'diameter_cm' => 'diameter_cm',
            'dt' => 'diameter_cm',
            'dbh' => 'diameter_cm',
            'დიამეტრი' => 'diameter_cm',
            'დიამეტრი სმ' => 'diameter_cm',

            'count' => 'trees_count',
            'qty' => 'trees_count',
            'quantity' => 'trees_count',
            'trees count' => 'trees_count',
            'trees_count' => 'trees_count',
            'number of trees' => 'trees_count',
            'რაოდენობა' => 'trees_count',
            'ხეების რაოდენობა' => 'trees_count',
            'ხეების_რაოდენობა' => 'trees_count',
            'ცალი' => 'trees_count',

            'note' => 'note',
            'notes' => 'note',
            'remark' => 'note',
            'remarks' => 'note',
            'comment' => 'note',
            'comments' => 'note',
            'შენიშვნა' => 'note',
            'შენიშვნები' => 'note',
            'კომენტარი' => 'note',
        ];

        return $map[$value] ?? $value;
    }

    private function importCellNumber(mixed $value): ?float
    {
        if (is_null($value)) return null;
        if (is_numeric($value)) return (float) $value;

        $value = trim((string) $value);
        if ($value === '') return null;

        $value = str_replace([' ', ','], ['', '.'], $value);
        return is_numeric($value) ? (float) $value : null;
    }


    private function countNestedInputLeaves(mixed $value): int
    {
        if (!is_array($value)) {
            return 1;
        }

        $count = 0;
        foreach ($value as $item) {
            $count += $this->countNestedInputLeaves($item);
        }

        return $count;
    }

    /**
     * Heuristic guard against truncated POST bodies caused by PHP max_input_vars.
     *
     * When the form is truncated, request('rows') contains only the first slice,
     * but the current code would delete all existing rows and re-save only that slice.
     */
    private function detectTruncatedTreeForm(Request $request, Tyekafi $tyekafi, array $rowsPayload, array $smallRowsPayload): array
    {
        $existingTreeRowsCount = TyekafiTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->count();

        $existingSmallRowsCount = TyekafiSmallTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->count();

        $incomingTreeRowsCount = count($rowsPayload);
        $incomingSmallRowsCount = count($smallRowsPayload);

        $maxInputVars = (int) ini_get('max_input_vars');
        $estimatedLeafInputs =
            $this->countNestedInputLeaves($request->input('rows', []))
            + $this->countNestedInputLeaves($request->input('small_rows', []))
            + $this->countNestedInputLeaves($request->input('summaries', []))
            + $this->countNestedInputLeaves($request->input('analysis_species_ids', []));

        $treeRowsLookTruncated =
            $existingTreeRowsCount >= 300
            && $incomingTreeRowsCount > 0
            && (
                $incomingTreeRowsCount <= (int) floor($existingTreeRowsCount * 0.35)
                || ($existingTreeRowsCount - $incomingTreeRowsCount) >= 200
            );

        $smallRowsLookTruncated =
            $existingSmallRowsCount >= 100
            && $incomingSmallRowsCount > 0
            && (
                $incomingSmallRowsCount <= (int) floor($existingSmallRowsCount * 0.35)
                || ($existingSmallRowsCount - $incomingSmallRowsCount) >= 100
            );

        $leafInputsLookNearLimit = $maxInputVars > 0 && $estimatedLeafInputs >= (int) floor($maxInputVars * 0.9);

        $message = null;
        if ($treeRowsLookTruncated || $smallRowsLookTruncated) {
            $message = 'ფორმის ნაწილი სავარაუდოდ მოიჭრა და დეტალური მწკრივების წაშლის რისკი არსებობდა.';

            if ($treeRowsLookTruncated) {
                $message .= ' ხეების სტრიქონები: ბაზაში იყო ' . $existingTreeRowsCount . ', request-ით მოვიდა მხოლოდ ' . $incomingTreeRowsCount . '.';
            }

            if ($smallRowsLookTruncated) {
                $message .= ' მცირე დიამეტრის სტრიქონები: ბაზაში იყო ' . $existingSmallRowsCount . ', request-ით მოვიდა მხოლოდ ' . $incomingSmallRowsCount . '.';
            }

            if ($maxInputVars > 0) {
                $message .= ' PHP max_input_vars=' . $maxInputVars . '.';
                if ($leafInputsLookNearLimit) {
                    $message .= ' მოთხოვნა მიუახლოვდა ამ ლიმიტს.';
                }
            }

            $message .= ' დეტალური სტრიქონები უცვლელად დარჩა, მაგრამ სახეობების შეჯამება და მოცულობები ხელახლა გადაითვალა არსებულ მონაცემებზე დაყრდნობით.';
        }

        return [
            'is_truncated' => $treeRowsLookTruncated || $smallRowsLookTruncated,
            'tree_rows_truncated' => $treeRowsLookTruncated,
            'small_rows_truncated' => $smallRowsLookTruncated,
            'existing_tree_rows_count' => $existingTreeRowsCount,
            'existing_small_rows_count' => $existingSmallRowsCount,
            'incoming_tree_rows_count' => $incomingTreeRowsCount,
            'incoming_small_rows_count' => $incomingSmallRowsCount,
            'message' => $message,
        ];
    }

    public function importTreeRows(Request $request, Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnTyekafi($project, $tyekafi);

        $data = $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx,xls,csv'],
        ]);

        $spreadsheet = IOFactory::load($data['file']->getRealPath());
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray(null, true, true, true);

        if (count($rows) < 2) {
            return back()->withErrors(['file' => 'ფაილში მონაცემები ვერ მოიძებნა.']);
        }

        $headerRow = array_shift($rows);
        $headers = [];
        foreach ($headerRow as $column => $label) {
            $headers[$column] = $this->normalizeImportHeader($label);
        }

        if (!in_array('species', $headers, true) || !in_array('diameter_cm', $headers, true)) {
            return back()->withErrors([
                'file' => 'ფაილს უნდა ჰქონდეს მინიმუმ ეს სვეტები: სახეობა და დიამეტრი. დამატებით შეიძლება: ხარისხი, რაოდენობა, შენიშვნა.',
            ]);
        }

        $speciesMap = TreeSpecies::query()
            ->get(['id', 'name'])
            ->mapWithKeys(function ($s) {
                return [mb_strtolower(trim((string) $s->name), 'UTF-8') => ['id' => (int) $s->id, 'name' => (string) $s->name]];
            });

        $prepared = [];
        $errors = [];
        $importedSpeciesIds = [];
        $excelRowNumber = 1;

        foreach ($rows as $sheetRow) {
            $excelRowNumber++;

            $payload = [
                'species' => null,
                'quality' => null,
                'diameter_cm' => null,
                'trees_count' => 1,
                'note' => null,
            ];

            foreach ($sheetRow as $column => $value) {
                $field = $headers[$column] ?? null;
                if (!$field) continue;
                $payload[$field] = $value;
            }

            $speciesRaw = trim((string) ($payload['species'] ?? ''));
            $diameterRaw = $payload['diameter_cm'] ?? null;
            $qualityRaw = trim((string) ($payload['quality'] ?? ''));
            $countRaw = $payload['trees_count'] ?? null;
            $noteRaw = trim((string) ($payload['note'] ?? ''));

            if (
                $speciesRaw === ''
                && (is_null($diameterRaw) || trim((string) $diameterRaw) === '')
                && $qualityRaw === ''
                && (is_null($countRaw) || trim((string) $countRaw) === '')
                && $noteRaw === ''
            ) {
                continue;
            }

            $speciesKey = mb_strtolower($speciesRaw, 'UTF-8');
            $species = $speciesMap->get($speciesKey);
            if (!$species) {
                $errors[] = "სტრიქონი {$excelRowNumber}: სახეობა ვერ მოიძებნა — {$speciesRaw}";
                continue;
            }

            $diameter = $this->importCellNumber($diameterRaw);
            if (is_null($diameter) || $diameter <= 0) {
                $errors[] = "სტრიქონი {$excelRowNumber}: დიამეტრი არასწორია.";
                continue;
            }

            $quality = $qualityRaw === '' ? null : $qualityRaw;
            if (!is_null($quality) && !in_array($quality, ['1', '2'], true)) {
                $errors[] = "სტრიქონი {$excelRowNumber}: ხარისხი უნდა იყოს 1 ან 2.";
                continue;
            }

            $count = $this->importCellNumber($countRaw);
            $count = is_null($count) ? 1 : (int) round($count);
            if ($count < 1) {
                $errors[] = "სტრიქონი {$excelRowNumber}: რაოდენობა უნდა იყოს მინიმუმ 1.";
                continue;
            }

            $prepared[] = [
                'tyekafi_id' => $tyekafi->id,
                'tree_species_id' => $species['id'],
                'diameter_cm' => $diameter,
                'quality' => $quality,
                'trees_count' => $count,
                'note' => $noteRaw !== '' ? $noteRaw : null,
                'row_order' => count($prepared) + 1,
                'created_at' => now(),
                'updated_at' => now(),
            ];

            $importedSpeciesIds[] = (int) $species['id'];
        }

        if (count($prepared) === 0) {
            return back()->withErrors(['file' => 'იმპორტისთვის ვალიდური სტრიქონები ვერ მოიძებნა.'])->with('import_errors', $errors);
        }

        DB::transaction(function () use ($tyekafi, $prepared, $importedSpeciesIds) {
            DB::table('tyekafi_tree_rows')
                ->where('tyekafi_id', $tyekafi->id)
                ->delete();

            foreach (array_chunk($prepared, 500) as $chunk) {
                DB::table('tyekafi_tree_rows')->insert($chunk);
            }

            $importedSpeciesIds = collect($importedSpeciesIds)->unique()->values()->all();
            TyekafiSpeciesSummary::query()
                ->where('tyekafi_id', $tyekafi->id)
                ->whereNotIn('tree_species_id', $importedSpeciesIds)
                ->delete();
        });

        $message = 'Excel-იდან ხეების ცხრილი წარმატებით დაიმპორტდა. სტრიქონები: ' . count($prepared);
        if (count($errors) > 0) {
            $message .= '. გამოტოვებული ჩანაწერები: ' . count($errors);
        }

        return redirect(route('projects.tyekafis.show', [$project, $tyekafi]) . '#trees')
            ->with('status', $message)
            ->with('import_errors', $errors);
    }

    public function index(Project $project)
    {
        $this->authorize('perm.view');
        $this->ensureOwnProject($project);

        $tyekafis = Tyekafi::query()
            ->where('project_id', $project->id)
            ->where('user_id', auth()->id())
            ->orderByDesc('id')
            ->paginate(15);

        return view('tyekafis.index', compact('project', 'tyekafis'));
    }

    public function create(Project $project)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnProject($project);

        $governingBodies = GoverningBody::query()->orderBy('name')->get(['id', 'name']);
        $regions = Region::query()->orderBy('name')->get(['id', 'name', 'governing_body_id']);
        $districts = ForestDistrict::query()->orderBy('name')->get(['id', 'name', 'region_id']);
        $forests = Forest::query()->orderBy('name')->get(['id', 'name', 'forest_district_id']);
        $quarters = Quarter::query()->orderBy('name')->get(['id', 'name', 'forest_id']);
        $liters = Liter::query()
            ->with(['quarter:id,name'])
            ->orderBy('name')
            ->get(['id', 'name', 'quarter_id']);

        return view('tyekafis.create', compact(
            'project',
            'governingBodies',
            'regions',
            'districts',
            'forests',
            'quarters',
            'liters'
        ));
    }

    public function store(Request $request, Project $project)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnProject($project);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'governing_body_id' => ['nullable', 'exists:governing_bodies,id'],
            'region_id' => ['nullable', 'exists:regions,id'],
            'district_id' => ['nullable', 'exists:forest_districts,id'],
            'forest_id' => ['nullable', 'exists:forests,id'],
            'quarter_id' => ['nullable', 'exists:quarters,id'],
            'manual_quarter' => ['nullable', 'string', 'max:255'],
            'liter_ids' => ['nullable', 'array'],
            'liter_ids.*' => ['integer', 'exists:liters,id'],
            'manual_liters' => ['nullable', 'string', 'max:500'],
            'area_ha' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'volume' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
        ]);

        $tyekafi = Tyekafi::create([
            'project_id' => $project->id,
            'user_id' => auth()->id(),
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'governing_body_id' => $data['governing_body_id'] ?? null,
            'region_id' => $data['region_id'] ?? null,
            'forest_district_id' => $data['district_id'] ?? null,
            'forest_id' => $data['forest_id'] ?? null,
            'quarter_id' => $data['quarter_id'] ?? null,
            'manual_quarter' => $data['manual_quarter'] ?? null,
            'manual_liters' => $data['manual_liters'] ?? null,
            'area_ha' => array_key_exists('area_ha', $data) && $data['area_ha'] !== null ? number_format((float) $data['area_ha'], 4, '.', '') : null,
            'volume' => $data['volume'] ?? null,
        ]);

        $literIds = $data['liter_ids'] ?? [];
        if (method_exists($tyekafi, 'liters')) {
            $tyekafi->liters()->sync($literIds);
        }

        if (property_exists($tyekafi, 'liter_id') || array_key_exists('liter_id', $tyekafi->getAttributes())) {
            $tyekafi->liter_id = count($literIds) ? (int) $literIds[0] : null;
            $tyekafi->save();
        }

        return redirect()
            ->route('projects.tyekafis.show', [$project, $tyekafi])
            ->with('status', 'ტყეკაფი შეიქმნა');
    }

    public function show(Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.view');
        $this->ensureOwnTyekafi($project, $tyekafi);

        $governingBodies = GoverningBody::query()->orderBy('name')->get(['id', 'name']);
        $regions = Region::query()->orderBy('name')->get(['id', 'name', 'governing_body_id']);
        $districts = ForestDistrict::query()->orderBy('name')->get(['id', 'name', 'region_id']);
        $forests = Forest::query()->orderBy('name')->get(['id', 'name', 'forest_district_id']);
        $quarters = Quarter::query()->orderBy('name')->get(['id', 'name', 'forest_id']);
        $liters = Liter::query()
            ->with(['quarter:id,name'])
            ->orderBy('name')
            ->get(['id', 'name', 'quarter_id']);

        $species = TreeSpecies::query()->orderBy('name')->get(['id', 'name', 'red_list']);

        $rows = TyekafiTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->orderBy('row_order')
            ->orderBy('id')
            ->get();

        if ($rows->count() === 0) {
            $rows = collect([new TyekafiTreeRow(['row_order' => 1])]);
        }

        $smallRows = TyekafiSmallTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->orderBy('row_order')
            ->orderBy('id')
            ->get();

        if ($smallRows->count() === 0) {
            $smallRows = collect([new TyekafiSmallTreeRow(['row_order' => 1])]);
        }

        $summaries = TyekafiSpeciesSummary::with(['species:id,name', 'rank:id,name,rank_num'])
            ->where('tyekafi_id', $tyekafi->id)
            ->get()
            ->keyBy('tree_species_id');

        $computedAvgBySpecies = $rows
            ->filter(function ($row) {
                return !is_null($row->tree_species_id)
                    && !is_null($row->diameter_cm)
                    && (float) $row->diameter_cm > 0;
            })
            ->groupBy(fn ($row) => (int) $row->tree_species_id)
            ->map(function ($group, $speciesId) use ($summaries) {
                $existing = $summaries->get((int) $speciesId);
                if ($existing && !is_null($existing->avg_diameter_cm) && (float) $existing->avg_diameter_cm > 0) {
                    return (float) $existing->avg_diameter_cm;
                }

                $totalWeighted = 0.0;
                $totalCount = 0;
                $diametersPresent = [];

                foreach ($group as $row) {
                    $count = (int) ($row->trees_count ?? 1);
                    if ($count < 1) {
                        $count = 1;
                    }

                    $diameter = (float) ($row->diameter_cm ?? 0);
                    if ($diameter <= 0) {
                        continue;
                    }

                    $diametersPresent[] = (int) round($diameter);
                    $totalWeighted += $diameter * $count;
                    $totalCount += $count;
                }

                if ($totalCount < 1) {
                    return null;
                }

                $rawAvg = $totalWeighted / $totalCount;
                if ($rawAvg <= 0) {
                    return null;
                }

                return $this->nearestFromCandidates($rawAvg, $diametersPresent);
            });

        foreach ($computedAvgBySpecies as $speciesId => $avgDiameter) {
            $speciesId = (int) $speciesId;
            if (!isset($summaries[$speciesId])) {
                $summary = new TyekafiSpeciesSummary([
                    'tyekafi_id' => $tyekafi->id,
                    'tree_species_id' => $speciesId,
                    'avg_diameter_cm' => $avgDiameter,
                    'rank_method' => 'h',
                ]);

                $summaries->put($speciesId, $summary);
                continue;
            }

            $existing = $summaries->get($speciesId);
            if ((is_null($existing->avg_diameter_cm) || (float) $existing->avg_diameter_cm <= 0) && !is_null($avgDiameter)) {
                $existing->avg_diameter_cm = $avgDiameter;
            }

            if (!$existing->rank_method) {
                $existing->rank_method = 'h';
            }
        }

        $analysisSpeciesIds = $summaries->keys()
            ->map(fn ($v) => (int) $v)
            ->merge($rows->pluck('tree_species_id')->filter()->map(fn ($v) => (int) $v))
            ->unique()
            ->values()
            ->all();

        $rankMethod = old('rank_method');
        if (!$rankMethod) {
            $rankMethod = ($summaries->first()?->rank_method) ?: 'h';
        }
        if (!in_array($rankMethod, ['h', 'manual'], true)) $rankMethod = 'h';

        $rankOptionsBySpecies = [];
        $diameterOptionsBySpecies = [];

        foreach ($species as $sp) {
            $sid = (int) $sp->id;
            $spName = (string) $sp->name;

            $mapping = TariffSpeciesMapping::query()->where('species_name', $spName)->first();
            if (!$mapping) {
                $rankOptionsBySpecies[$sid] = [];
                $diameterOptionsBySpecies[$sid] = [];
                continue;
            }

            $tariffTableId = (int) $mapping->tariff_table_id;

            $ranks = TariffValue::query()
                ->where('tariff_table_id', $tariffTableId)
                ->select('rank')
                ->distinct()
                ->orderBy('rank')
                ->pluck('rank')
                ->map(fn ($r) => (int) $r)
                ->filter(fn ($r) => $r > 0)
                ->values()
                ->all();

            $diameters = TariffValue::query()
                ->where('tariff_table_id', $tariffTableId)
                ->select('dt_cm')
                ->distinct()
                ->orderByRaw('CAST(dt_cm AS SIGNED) asc')
                ->pluck('dt_cm')
                ->map(fn ($d) => (int) $d)
                ->filter(fn ($d) => $d > 0)
                ->values()
                ->all();

            $rankOptionsBySpecies[$sid] = $ranks;
            $diameterOptionsBySpecies[$sid] = $diameters;
        }

        $selectedLiterIds = method_exists($tyekafi, 'liters')
            ? $tyekafi->liters()->pluck('liters.id')->toArray()
            : [];

        $forestUseBases = ForestUseBasis::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('title')
            ->get(['code', 'title']);

        $cutPercentOptions = [];
        for ($i = 5; $i <= 100; $i += 5) $cutPercentOptions[] = $i . '%';

        $ageOptions = [];
        for ($i = 10; $i <= 70; $i += 5) $ageOptions[] = (string) $i;
        for ($i = 80; $i <= 300; $i += 10) $ageOptions[] = (string) $i;

        $frequencyOptions = [];
        for ($i = 1; $i <= 10; $i++) $frequencyOptions[] = number_format($i / 10, 1);

        $options = [
            'cut_purpose' => [
                'სოციალური დანიშნულების ტყეკაფი',
                'განსაკუთრებული დანიშნულებით ტყით სპეციალური სარგებლობა',
                'მოვტყის მოვლა',
            ],
            'cut_type' => [
                'პირწმინდა',
                'ნებით-ამორჩევითი',
                'სანიტარული ჭრა',
                'ერთეული ხეების ჭრა',
                'გავლითი',
                'განათებითი',
                'გამოხშირვითი',
                'გაწმენდითი',
                'ჩახერგილობის გაწმენდა',
                'ჯგუფურ-ამორჩევითი',
                'თანდათანობითი',
            ],
            'cut_percent' => $cutPercentOptions,
            'frequency' => $frequencyOptions,
            'szd' => [
                '0-250', '251-500', '501-750', '751-1000', '1001-1250', '1251-1500',
                '1501-1750', '1751-2000', '2001-2250', '2251-2500', '2501-2750', '2751-3000'
            ],
            'inventory_method' => ['ძირობრივი', 'სანიმუშო ფართობები'],
            'sample_plot_type' => ['წრიული', 'მართკუთხა', 'ლენტისებური'],
            'age' => $ageOptions,
            'exposure' => ['ჩ', 'ჩდ', 'დ', 'სდ', 'ს', 'სა', 'ა', 'ჩა'],
            'slope' => ['0-10°', '11-20°', '21-30°', '31-35°+', '36° და მეტი'],
        ];

        $treeVolumeRows = $this->buildTreeVolumeBreakdown($rows, $summaries, $species);

        return view('tyekafis.show', compact(
            'project',
            'tyekafi',
            'governingBodies',
            'regions',
            'districts',
            'forests',
            'quarters',
            'liters',
            'species',
            'rows',
            'summaries',
            'analysisSpeciesIds',
            'options',
            'selectedLiterIds',
            'forestUseBases',
            'treeVolumeRows',
            'rankOptionsBySpecies',
            'diameterOptionsBySpecies',
            'rankMethod',
            'smallRows'
        ));
    }

    public function updateFormIn(Request $request, Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnTyekafi($project, $tyekafi);

        $data = $request->validate([
            'governing_body_id' => ['nullable', 'exists:governing_bodies,id'],
            'region_id' => ['nullable', 'exists:regions,id'],
            'forest_district_id' => ['nullable', 'exists:forest_districts,id'],
            'forest_id' => ['nullable', 'exists:forests,id'],
            'quarter_id' => ['nullable', 'exists:quarters,id'],
            'manual_quarter' => ['nullable', 'string', 'max:255'],
            'liter_ids' => ['nullable', 'array'],
            'liter_ids.*' => ['integer', 'exists:liters,id'],
            'manual_liters' => ['nullable', 'string', 'max:500'],
            'marking_start_date' => ['nullable', 'date'],
            'marking_end_date' => ['nullable', 'date'],
            'forest_use_basis' => ['nullable', 'string', 'max:255', 'exists:forest_use_bases,code'],
            'forest_user_name' => ['nullable', 'string', 'max:255'],
            'forest_user_id_code' => ['nullable', 'string', 'max:255'],
            'forest_user_address' => ['nullable', 'string', 'max:500'],
            'area_ha' => ['nullable', 'numeric', 'min:0', 'max:999999'],
            'cut_purpose' => ['nullable', 'string', 'max:255'],
            'cut_type' => ['nullable', 'string', 'max:255'],
            'cut_percent' => ['nullable', 'string', 'max:255'],
            'szd' => ['nullable', 'string', 'max:255'],
            'frequency_actual' => ['nullable', 'numeric', 'min:0', 'max:999'],
            'frequency_plan' => ['nullable', 'numeric', 'min:0', 'max:999'],
            'regen_count_actual' => ['nullable', 'string', 'max:255'],
            'regen_count_plan' => ['nullable', 'string', 'max:255'],
            'age_actual' => ['nullable', 'string', 'max:255'],
            'age_plan' => ['nullable', 'string', 'max:255'],
            'exposure_actual' => ['nullable', 'string', 'max:255'],
            'exposure_plan' => ['nullable', 'string', 'max:255'],
            'slope_actual' => ['nullable', 'string', 'max:255'],
            'slope_plan' => ['nullable', 'string', 'max:255'],
            'gps_x1' => ['nullable', 'regex:/^\d{6}$/'],
            'gps_y1' => ['nullable', 'regex:/^\d{7}$/'],
            'gps_x2' => ['nullable', 'regex:/^\d{6}$/'],
            'gps_y2' => ['nullable', 'regex:/^\d{7}$/'],
            'inventory_method' => ['nullable', 'string', 'max:255'],
            'sample_plot_type' => ['nullable', 'string', 'max:255'],
            'sample_plot_area' => ['nullable', 'numeric', 'min:0', 'max:999999'],
            'multiplier_coeff' => ['nullable', 'numeric', 'min:0', 'max:999999'],
        ]);

        $tyekafi->update([
            'governing_body_id' => $data['governing_body_id'] ?? null,
            'region_id' => $data['region_id'] ?? null,
            'forest_district_id' => $data['forest_district_id'] ?? null,
            'forest_id' => $data['forest_id'] ?? null,
            'quarter_id' => $data['quarter_id'] ?? null,
            'manual_quarter' => $data['manual_quarter'] ?? null,
            'manual_liters' => $data['manual_liters'] ?? null,
            'marking_start_date' => $data['marking_start_date'] ?? null,
            'marking_end_date' => $data['marking_end_date'] ?? null,
            'forest_use_basis' => $data['forest_use_basis'] ?? null,
            'forest_user_name' => $data['forest_user_name'] ?? null,
            'forest_user_id_code' => $data['forest_user_id_code'] ?? null,
            'forest_user_address' => $data['forest_user_address'] ?? null,
            'area_ha' => array_key_exists('area_ha', $data) && $data['area_ha'] !== null ? number_format((float) $data['area_ha'], 4, '.', '') : null,
            'cut_purpose' => $data['cut_purpose'] ?? null,
            'cut_type' => $data['cut_type'] ?? null,
            'cut_percent' => $data['cut_percent'] ?? null,
            'szd' => $data['szd'] ?? null,
            'frequency_actual' => $data['frequency_actual'] ?? null,
            'frequency_plan' => $data['frequency_plan'] ?? null,
            'regen_count_actual' => $data['regen_count_actual'] ?? null,
            'regen_count_plan' => $data['regen_count_plan'] ?? null,
            'age_actual' => $data['age_actual'] ?? null,
            'age_plan' => $data['age_plan'] ?? null,
            'exposure_actual' => $data['exposure_actual'] ?? null,
            'exposure_plan' => $data['exposure_plan'] ?? null,
            'slope_actual' => $data['slope_actual'] ?? null,
            'slope_plan' => $data['slope_plan'] ?? null,
            'gps_x1' => $data['gps_x1'] ?? null,
            'gps_y1' => $data['gps_y1'] ?? null,
            'gps_x2' => $data['gps_x2'] ?? null,
            'gps_y2' => $data['gps_y2'] ?? null,
            'inventory_method' => $data['inventory_method'] ?? null,
            'sample_plot_type' => $data['sample_plot_type'] ?? null,
            'sample_plot_area' => $data['sample_plot_area'] ?? null,
            'multiplier_coeff' => $data['multiplier_coeff'] ?? null,
        ]);

        $literIds = $data['liter_ids'] ?? [];
        if (method_exists($tyekafi, 'liters')) {
            $tyekafi->liters()->sync($literIds);
        }

        if (property_exists($tyekafi, 'liter_id') || array_key_exists('liter_id', $tyekafi->getAttributes())) {
            $tyekafi->liter_id = count($literIds) ? (int) $literIds[0] : null;
            $tyekafi->save();
        }

        return back()->with('status', 'FORM_IN შენახულია');
    }

    public function updateTreeRows(Request $request, Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnTyekafi($project, $tyekafi);

        $data = $request->validate([
            'rank_method' => ['nullable', 'string', 'in:h,manual'],

            'analysis_species_ids' => ['nullable', 'array'],
            'analysis_species_ids.*' => ['integer', 'exists:tree_species,id'],

            'rows' => ['nullable', 'array'],
            'rows.*.tree_species_id' => ['nullable', 'integer', 'exists:tree_species,id'],
            'rows.*.diameter_cm' => ['nullable', 'numeric', 'min:0'],
            'rows.*.quality' => ['nullable', 'in:1,2'],
            'rows.*.trees_count' => ['nullable', 'integer', 'min:1'],
            'rows.*.note' => ['nullable', 'string', 'max:2000'],

            'small_rows' => ['nullable', 'array'],
            'small_rows.*.tree_species_id' => ['nullable', 'integer', 'exists:tree_species,id'],
            'small_rows.*.quantity' => ['nullable', 'integer', 'min:1'],

            'summaries' => ['nullable', 'array'],
            'summaries.*.height_m' => ['nullable', 'numeric', 'min:0', 'max:200'],
            'summaries.*.manual_rank_num' => ['nullable', 'integer', 'min:1', 'max:50'],
            'summaries.*.handwritten_sequence' => ['nullable', 'string', 'max:255'],
        ], [
            'rows.*.quality.in' => 'ხარისხი უნდა იყოს 1 ან 2.',
            'small_rows.*.quantity.min' => 'რაოდენობა უნდა იყოს მინიმუმ 1.',
        ]);

        $rankMethod = $data['rank_method'] ?? 'h';
        if ($rankMethod === '' || is_null($rankMethod)) $rankMethod = 'h';
        if (!in_array($rankMethod, ['h', 'manual'], true)) $rankMethod = 'h';

        $hasManualRankSelection = collect($data['summaries'] ?? [])->contains(function ($summary) {
            $value = $summary['manual_rank_num'] ?? null;
            return !is_null($value) && $value !== '' && (int) $value > 0;
        });

        $hasHeightSelection = collect($data['summaries'] ?? [])->contains(function ($summary) {
            $value = $summary['height_m'] ?? null;
            return !is_null($value) && $value !== '' && (float) $value > 0;
        });

        if ($hasManualRankSelection && !$hasHeightSelection) {
            $rankMethod = 'manual';
        }

        $analysisIds = collect($data['analysis_species_ids'] ?? [])
            ->filter()
            ->map(fn ($v) => (int) $v)
            ->filter(fn ($v) => $v > 0)
            ->unique()
            ->values()
            ->all();

        $rowsPayload = is_array($data['rows'] ?? null) ? $data['rows'] : [];
        $smallRowsPayload = is_array($data['small_rows'] ?? null) ? $data['small_rows'] : [];

        $truncation = $this->detectTruncatedTreeForm($request, $tyekafi, $rowsPayload, $smallRowsPayload);
        $preserveExistingTreeRows = (bool) ($truncation['tree_rows_truncated'] ?? false);
        $preserveExistingSmallRows = (bool) ($truncation['small_rows_truncated'] ?? false);

        $treeRowsToInsert = [];
        $smallRowsToInsert = [];

        $order = 1;
        foreach ($rowsPayload as $r) {
            $sid = isset($r['tree_species_id']) ? (int) $r['tree_species_id'] : null;

            if (count($analysisIds) > 0 && $sid && !in_array($sid, $analysisIds, true)) {
                $sid = null;
            }

            $diameter = $r['diameter_cm'] ?? null;
            $diameter = ($diameter === '' || is_null($diameter)) ? null : (float) $diameter;

            $quality = $r['quality'] ?? null;
            if ($quality === '') $quality = null;

            $treesCount = $r['trees_count'] ?? 1;
            $treesCount = ($treesCount === '' || is_null($treesCount)) ? 1 : max((int) $treesCount, 1);

            $hasAnyValue = ($sid && $sid > 0) || !is_null($diameter) || !is_null($quality) || !is_null($treesCount);
            if (!$hasAnyValue || (!$sid && is_null($diameter))) {
                continue;
            }

            $treeRowsToInsert[] = [
                'tyekafi_id' => $tyekafi->id,
                'tree_species_id' => $sid ?: null,
                'diameter_cm' => $diameter,
                'quality' => $quality,
                'trees_count' => $treesCount,
                'note' => isset($r['note']) ? trim((string) $r['note']) : null,
                'row_order' => $order++,
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }

        $smallOrder = 1;
        foreach ($smallRowsPayload as $r) {
            $sid = isset($r['tree_species_id']) ? (int) $r['tree_species_id'] : null;
            $quantity = $r['quantity'] ?? null;

            $hasAnyValue = ($sid && $sid > 0) || ($quantity !== null && $quantity !== '');
            if (!$hasAnyValue) {
                continue;
            }

            $smallRowsToInsert[] = [
                'tyekafi_id' => $tyekafi->id,
                'tree_species_id' => $sid ?: null,
                'quantity' => ($quantity === '' || is_null($quantity)) ? null : (int) $quantity,
                'row_order' => $smallOrder++,
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }

        DB::transaction(function () use ($tyekafi, $treeRowsToInsert, $smallRowsToInsert, $preserveExistingTreeRows, $preserveExistingSmallRows) {
            if (!$preserveExistingTreeRows) {
                TyekafiTreeRow::where('tyekafi_id', $tyekafi->id)->delete();

                foreach (array_chunk($treeRowsToInsert, 500) as $chunk) {
                    DB::table('tyekafi_tree_rows')->insert($chunk);
                }
            }

            if (!$preserveExistingSmallRows) {
                TyekafiSmallTreeRow::where('tyekafi_id', $tyekafi->id)->delete();

                foreach (array_chunk($smallRowsToInsert, 500) as $chunk) {
                    DB::table('tyekafi_small_tree_rows')->insert($chunk);
                }
            }
        });

        $effectiveTreeRows = TyekafiTreeRow::query()
            ->where('tyekafi_id', $tyekafi->id)
            ->whereNotNull('tree_species_id')
            ->whereNotNull('diameter_cm')
            ->get();

        $grouped = $effectiveTreeRows->groupBy('tree_species_id');

        $speciesIdsInRows = $grouped->keys()->map(fn ($x) => (int) $x)->values()->all();

        $selectedSpeciesIds = collect($analysisIds)
            ->merge($speciesIdsInRows)
            ->unique()
            ->values()
            ->all();

        if (count($selectedSpeciesIds) === 0) {
            TyekafiSpeciesSummary::where('tyekafi_id', $tyekafi->id)->delete();
            return back()->with('status', 'ხეების ცხრილი შენახულია');
        }

        TyekafiSpeciesSummary::where('tyekafi_id', $tyekafi->id)
            ->whereNotIn('tree_species_id', $selectedSpeciesIds)
            ->delete();

        $speciesNameById = TreeSpecies::query()
            ->whereIn('id', $selectedSpeciesIds)
            ->pluck('name', 'id')
            ->mapWithKeys(fn ($name, $id) => [(int) $id => (string) $name])
            ->all();

        foreach ($selectedSpeciesIds as $speciesId) {
            $speciesId = (int) $speciesId;
            $rowsGroup = $grouped->get($speciesId, collect());

            $totalWeighted = 0.0;
            $totalCount = 0;
            $diametersPresent = [];

            foreach ($rowsGroup as $row) {
                $count = (int) ($row->trees_count ?? 1);
                if ($count < 1) $count = 1;

                $d = (float) ($row->diameter_cm ?? 0);
                if ($d <= 0) continue;

                $dInt = (int) round($d);
                if ($dInt > 0) $diametersPresent[] = $dInt;

                $totalWeighted += $d * $count;
                $totalCount += $count;
            }

            $rawAvg = $totalCount > 0 ? ($totalWeighted / $totalCount) : null;

            $avgD = (!is_null($rawAvg) && $rawAvg > 0)
                ? $this->nearestFromCandidates($rawAvg, $diametersPresent)
                : null;

            $height = $data['summaries'][$speciesId]['height_m'] ?? null;
            if ($height === '') $height = null;
            if (!is_null($height)) $height = (float) $height;

            $handwrittenSeq = $data['summaries'][$speciesId]['handwritten_sequence'] ?? null;
            if (is_string($handwrittenSeq)) {
                $handwrittenSeq = trim($handwrittenSeq);
                if ($handwrittenSeq === '') $handwrittenSeq = null;
            } else {
                $handwrittenSeq = null;
            }

            $manualRankNum = $data['summaries'][$speciesId]['manual_rank_num'] ?? null;
            if ($manualRankNum === '') $manualRankNum = null;
            if (!is_null($manualRankNum)) $manualRankNum = (int) $manualRankNum;

            if ($rankMethod === 'h') {
                $manualRankNum = null;
            }

            $treeRankId = null;
            $liquid = null;
            $firewood = null;
            $total = null;
            $appliedDt = null;

            $canCalc =
                !is_null($avgD) && $avgD > 0
                && (
                    ($rankMethod === 'h' && !is_null($height) && $height > 0)
                    || ($rankMethod === 'manual' && !is_null($manualRankNum) && $manualRankNum > 0)
                );

            if ($canCalc) {
                $speciesName = $speciesNameById[$speciesId] ?? null;

                if ($speciesName) {
                    $mapping = TariffSpeciesMapping::query()
                        ->where('species_name', $speciesName)
                        ->first();

                    if ($mapping) {
                        $tariffTableId = (int) $mapping->tariff_table_id;

                        $nearestDt = TariffValue::query()
                            ->where('tariff_table_id', $tariffTableId)
                            ->select('dt_cm')
                            ->distinct()
                            ->orderByRaw('ABS(CAST(dt_cm AS SIGNED) - ?) asc', [(int) round($avgD)])
                            ->value('dt_cm');

                        if (!is_null($nearestDt)) {
                            $appliedDt = (int) $nearestDt;

                            $tvQuery = TariffValue::query()
                                ->where('tariff_table_id', $tariffTableId)
                                ->where('dt_cm', (int) $nearestDt);

                            if ($rankMethod === 'h') {
                                $tvQuery = $tvQuery
                                    ->where(function ($q) use ($height) {
                                        $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $height);
                                    })
                                    ->where(function ($q) use ($height) {
                                        $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $height);
                                    })
                                    ->orderByRaw('COALESCE(h_min_m, -999) desc');
                            } else {
                                $tvQuery = $tvQuery->where('rank', (int) $manualRankNum);
                            }

                            $tv = $tvQuery->first();

                            if ($tv) {
                                $rankNum = (int) $tv->rank;

                                $rank = TreeRank::query()->firstOrCreate(
                                    ['tree_species_id' => $speciesId, 'rank_num' => $rankNum],
                                    ['name' => (string) $rankNum]
                                );

                                if (!$rank->name) {
                                    $rank->name = (string) $rankNum;
                                    $rank->save();
                                }

                                $treeRankId = $rank->id;
                                $liquid = $tv->liquid_m3;
                                $firewood = $tv->crown_firewood_m3;
                                $total = $tv->total_m3 ?? ((float) $tv->liquid_m3 + (float) $tv->crown_firewood_m3);
                            }
                        }
                    }
                }
            }

            TyekafiSpeciesSummary::updateOrCreate(
                [
                    'tyekafi_id' => $tyekafi->id,
                    'tree_species_id' => $speciesId,
                ],
                [
                    'avg_diameter_cm' => $avgD,
                    'height_m' => $height,
                    'rank_method' => $rankMethod,
                    'manual_rank_num' => $manualRankNum,
                    'tree_rank_id' => $treeRankId,
                    'liquid_m3' => $liquid,
                    'firewood_m3' => $firewood,
                    'issued_m3' => $total,
                    'handwritten_sequence' => $handwrittenSeq,
                    'applied_dt_cm' => $appliedDt,
                ]
            );
        }

        $statusMessage = 'ხეების ცხრილი შენახულია';
        if (!empty($truncation['message'])) {
            $statusMessage .= ' გაფრთხილება: ' . $truncation['message'];
        }

        return back()->with('status', $statusMessage);
    }

    public function destroy(Project $project, Tyekafi $tyekafi)
    {
        $this->authorize('perm.edit');
        $this->ensureOwnTyekafi($project, $tyekafi);

        $tyekafi->delete();

        return redirect()
            ->route('projects.tyekafis.index', $project)
            ->with('status', 'ტყეკაფი წაიშალა');
    }
}