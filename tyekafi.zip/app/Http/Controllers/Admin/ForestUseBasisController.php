<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ForestUseBasis;
use Illuminate\Http\Request;

class ForestUseBasisController extends Controller
{
    public function index()
    {
        $items = ForestUseBasis::query()
            ->orderBy('sort_order')
            ->orderBy('title')
            ->paginate(20);

        return view('admin.forest_use_bases.index', compact('items'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:120', 'unique:forest_use_bases,code'],
            'title' => ['required', 'string', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $data['is_active'] = (bool)($data['is_active'] ?? false);
        $data['sort_order'] = (int)($data['sort_order'] ?? 0);

        ForestUseBasis::create($data);

        return redirect()->route('admin.forest-use-bases.index')->with('status', 'დაემატა');
    }

    public function update(Request $request, ForestUseBasis $forestUseBasis)
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:120', 'unique:forest_use_bases,code,' . $forestUseBasis->id],
            'title' => ['required', 'string', 'max:255'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $data['is_active'] = (bool)($data['is_active'] ?? false);
        $data['sort_order'] = (int)($data['sort_order'] ?? 0);

        $forestUseBasis->update($data);

        return redirect()->route('admin.forest-use-bases.index')->with('status', 'განახლდა');
    }

    public function destroy(ForestUseBasis $forestUseBasis)
    {
        // ✅ არ ვშლით, უბრალოდ ვთიშავთ
        $forestUseBasis->update(['is_active' => false]);

        return redirect()->route('admin.forest-use-bases.index')->with('status', 'გამოირთო');
    }
}