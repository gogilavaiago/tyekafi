<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreUserRequest;
use App\Http\Requests\Admin\UpdateUserRequest;
use App\DTO\UserData;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use App\Services\UserService;

class UserController extends Controller
{
    public function __construct(private UserService $service)
    {
    }

    public function index()
    {
        $users = User::query()
            ->with(['roles', 'permissions'])
            ->orderBy('id', 'desc')
            ->paginate(20);

        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        $roles = Role::query()->orderBy('name')->get();
        $permissions = Permission::query()->orderBy('id')->get();

        return view('admin.users.create', compact('roles', 'permissions'));
    }

    public function store(StoreUserRequest $request)
    {
        $this->service->create(UserData::fromRequest($request));

        return redirect()
            ->route('admin.users.index')
            ->with('status', 'მომხმარებელი დაემატა');
    }

    public function edit(User $user)
    {
        $roles = Role::query()->orderBy('name')->get();
        $permissions = Permission::query()->orderBy('id')->get();
        $user->load(['roles', 'permissions']);

        return view('admin.users.edit', compact('user', 'roles', 'permissions'));
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $this->service->update($user, UserData::fromRequest($request));

        return redirect()
            ->route('admin.users.index')
            ->with('status', 'მომხმარებელი განახლდა');
    }

    public function destroy(User $user)
    {
        if (auth()->id() === $user->id) {
            return back()->with('status', 'საკუთარი ანგარიშის წაშლა არ შეიძლება');
        }

        $user->delete();

        return redirect()
            ->route('admin.users.index')
            ->with('status', 'მომხმარებელი წაიშალა');
    }
}