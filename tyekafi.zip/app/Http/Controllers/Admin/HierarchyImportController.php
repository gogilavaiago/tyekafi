<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Imports\HierarchyPreviewChunkImport;
use App\Jobs\HierarchyImportJob;
use App\Models\Forest;
use App\Models\ForestDistrict;
use App\Models\GoverningBody;
use App\Models\HierarchyImportLog;
use App\Models\Liter;
use App\Models\Quarter;
use App\Models\Region;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;

class HierarchyImportController extends Controller
{
    public function showForm()
    {
        Gate::authorize('perm.hierarchy.import');

        $logs = HierarchyImportLog::query()
            ->with('user')
            ->orderByDesc('id')
            ->limit(20)
            ->get();

        return view('admin.hierarchy.import', [
            'preview' => null,
            'logs' => $logs,
        ]);
    }

    public function showLog(HierarchyImportLog $log)
    {
        Gate::authorize('perm.hierarchy.import');
        $log->load('user');

        return view('admin.hierarchy.import-log-show', [
            'log' => $log,
        ]);
    }

    public function preview(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'file' => ['required', 'file', 'max:20480'],
        ]);

        $file = $data['file'];
        $ext = strtolower($file->getClientOriginalExtension());
        if ($ext === '') {
            $ext = 'csv';
        }

        $token = (string) Str::uuid();

        $storedPath = $file->storeAs('imports', "hierarchy_{$token}.{$ext}", 'local');

        if (!Storage::disk('local')->exists($storedPath)) {
            throw new \RuntimeException("შენახული ფაილი ვერ მოიძებნა: {$storedPath}");
        }

        $preview = $this->buildPreviewWithDbCompare($storedPath, $ext);
        $previewReportPaths = $this->writePreviewReports($token, $preview);

        Cache::put($this->cacheKey($token), [
            'token' => $token,
            'stored_path' => $storedPath,
            'original_name' => $file->getClientOriginalName(),
            'ext' => $ext,
            'preview' => $preview,
            'preview_reports' => $previewReportPaths,
        ], now()->addHours(6));

        $logs = HierarchyImportLog::query()
            ->with('user')
            ->orderByDesc('id')
            ->limit(20)
            ->get();

        return view('admin.hierarchy.import', [
            'preview' => array_merge(['token' => $token], $preview),
            'logs' => $logs,
        ]);
    }

    public function confirm(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'token' => ['required', 'string'],
        ]);

        $token = $data['token'];
        $payload = Cache::get($this->cacheKey($token));

        if (!$payload || empty($payload['stored_path'])) {
            return redirect()->route('admin.hierarchy.import.form')
                ->withErrors(['file' => 'Preview სესია ვერ მოიძებნა ან ვადა გაუვიდა. თავიდან ატვირთე ფაილი.']);
        }

        if (!Storage::disk('local')->exists($payload['stored_path'])) {
            return redirect()->route('admin.hierarchy.import.form')
                ->withErrors(['file' => 'ფაილი ვერ მოიძებნა storage-ში. თავიდან ატვირთე ფაილი.']);
        }

        $jobId = (string) Str::uuid();
        $stats = $payload['preview']['stats'] ?? [];

        $log = HierarchyImportLog::query()->create([
            'user_id' => auth()->id(),
            'job_id' => $jobId,
            'token' => $token,
            'filename' => $payload['original_name'] ?? null,
            'status' => 'queued',

            'rows_total' => (int)($stats['rows_total'] ?? 0),
            'rows_ready' => (int)($stats['rows_ready'] ?? 0),
            'rows_skipped' => (int)($stats['rows_skipped'] ?? 0),
            'rows_file_duplicates' => (int)($stats['rows_file_duplicates'] ?? 0),

            'stats_create' => $stats['create'] ?? null,
            'stats_exists' => $stats['exists'] ?? null,
            'time' => $payload['preview']['time'] ?? null,
            'started_at' => now(),
        ]);

        dispatch(new HierarchyImportJob(
            token: $token,
            jobId: $jobId,
            logId: (int) $log->id,
            storedPath: $payload['stored_path'],
            ext: $payload['ext'] ?? 'csv',
            totalRows: (int)($stats['rows_ready'] ?? ($stats['rows_total'] ?? 0)),
        ));

        return redirect()->route('admin.hierarchy.import.progress', [
            'job' => $jobId,
            'token' => $token,
        ]);
    }

    public function progress(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'job' => ['required', 'string'],
            'token' => ['required', 'string'],
        ]);

        return view('admin.hierarchy.import-progress', [
            'jobId' => $data['job'],
            'token' => $data['token'],
        ]);
    }

    public function status(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'job' => ['required', 'string'],
        ]);

        $payload = Cache::get($this->progressKey($data['job']));
        if (!$payload) {
            return response()->json(['status' => 'unknown', 'message' => 'Progress ვერ მოიძებნა']);
        }

        return response()->json($payload);
    }

    public function downloadReportCsv(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'token' => ['required', 'string'],
            'type' => ['required', 'in:skipped,file_duplicates'],
        ]);

        $payload = Cache::get($this->cacheKey($data['token']));
        if (!$payload) {
            abort(404, 'Preview ვერ მოიძებნა ან ვადა გაუვიდა.');
        }

        $paths = $payload['preview_reports'] ?? [];
        $path = $data['type'] === 'skipped'
            ? ($paths['skipped_csv'] ?? null)
            : ($paths['duplicates_csv'] ?? null);

        if ($path && Storage::disk('local')->exists($path)) {
            return Storage::disk('local')->download($path);
        }

        $rows = $payload['preview'][$data['type']] ?? [];
        $filename = $data['type'] === 'skipped'
            ? 'hierarchy_skipped_preview.csv'
            : 'hierarchy_duplicates_preview.csv';

        $out = fopen('php://temp', 'r+');
        fputcsv($out, [
            'row',
            'reason',
            'first_row',
            'gb_code',
            'gb_name',
            'region_code',
            'region_name',
            'district_code',
            'district_name',
            'forest_code',
            'forest_name',
            'quarter_code',
            'quarter_name',
            'liter_code',
            'liter_name',
        ]);

        foreach ($rows as $r) {
            $d = $r['data'] ?? [];
            fputcsv($out, [
                $r['row'] ?? '',
                $r['reason'] ?? '',
                $r['first_row'] ?? '',
                $d[0] ?? '',
                $d[1] ?? '',
                $d[2] ?? '',
                $d[3] ?? '',
                $d[4] ?? '',
                $d[5] ?? '',
                $d[6] ?? '',
                $d[7] ?? '',
                $d[8] ?? '',
                $d[9] ?? '',
                $d[10] ?? '',
                $d[11] ?? '',
            ]);
        }

        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);

        return response($csv, 200, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }

    public function downloadReportPdf(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'token' => ['required', 'string'],
            'type' => ['required', 'in:skipped,file_duplicates'],
        ]);

        $payload = Cache::get($this->cacheKey($data['token']));
        if (!$payload) {
            abort(404, 'Preview ვერ მოიძებნა ან ვადა გაუვიდა.');
        }

        $paths = $payload['preview_reports'] ?? [];
        $path = $data['type'] === 'skipped'
            ? ($paths['skipped_pdf'] ?? null)
            : ($paths['duplicates_pdf'] ?? null);

        if ($path && Storage::disk('local')->exists($path)) {
            return Storage::disk('local')->download($path);
        }

        $rows = $payload['preview'][$data['type']] ?? [];
        $title = $data['type'] === 'skipped'
            ? 'გამოტოვებული სტრიქონები (Preview)'
            : 'დუბლიკატები (Preview)';

        $html = $this->buildPdfHtml($title, $rows);

        if (class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadHTML($html)
                ->setOption('defaultFont', 'DejaVu Sans');

            $filename = $data['type'] === 'skipped'
                ? 'hierarchy_skipped_preview.pdf'
                : 'hierarchy_duplicates_preview.pdf';

            return $pdf->download($filename);
        }

        return response($html, 200, ['Content-Type' => 'text/html; charset=UTF-8']);
    }

    public function downloadFinalSummaryCsv(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'log_id' => ['required', 'integer'],
        ]);

        $log = HierarchyImportLog::query()->findOrFail($data['log_id']);

        if (!$log->report_csv_path || !Storage::disk('local')->exists($log->report_csv_path)) {
            abort(404, 'Final CSV report ვერ მოიძებნა.');
        }

        return Storage::disk('local')->download($log->report_csv_path);
    }

    public function downloadFinalSummaryPdf(Request $request)
    {
        Gate::authorize('perm.hierarchy.import');

        $data = $request->validate([
            'log_id' => ['required', 'integer'],
        ]);

        $log = HierarchyImportLog::query()->findOrFail($data['log_id']);

        if (!$log->report_pdf_path || !Storage::disk('local')->exists($log->report_pdf_path)) {
            abort(404, 'Final PDF report ვერ მოიძებნა.');
        }

        return Storage::disk('local')->download($log->report_pdf_path);
    }

    private function cacheKey(string $token): string
    {
        return "hierarchy_import_preview:{$token}";
    }

    private function progressKey(string $jobId): string
    {
        return "hierarchy_import_progress:{$jobId}";
    }

    private function writePreviewReports(string $token, array $preview): array
    {
        $dir = 'previews';

        if (!Storage::disk('local')->exists($dir)) {
            Storage::disk('local')->makeDirectory($dir);
        }

        $skipped = $preview['skipped'] ?? [];
        $dups = $preview['file_duplicates'] ?? [];

        $skippedCsvPath = "{$dir}/{$token}_skipped.csv";
        $dupCsvPath = "{$dir}/{$token}_duplicates.csv";

        Storage::disk('local')->put($skippedCsvPath, $this->rowsToCsv($skipped));
        Storage::disk('local')->put($dupCsvPath, $this->rowsToCsv($dups));

        $skippedPdfPath = null;
        $dupPdfPath = null;

        if (class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
            $skippedHtml = $this->buildPdfHtml('გამოტოვებული სტრიქონები (Preview)', $skipped);
            $dupHtml = $this->buildPdfHtml('დუბლიკატები (Preview)', $dups);

            $skippedPdfPath = "{$dir}/{$token}_skipped.pdf";
            $dupPdfPath = "{$dir}/{$token}_duplicates.pdf";

            $skippedPdf = \Barryvdh\DomPDF\Facade\Pdf::loadHTML($skippedHtml)->setOption('defaultFont', 'DejaVu Sans');
            $dupPdf = \Barryvdh\DomPDF\Facade\Pdf::loadHTML($dupHtml)->setOption('defaultFont', 'DejaVu Sans');

            Storage::disk('local')->put($skippedPdfPath, $skippedPdf->output());
            Storage::disk('local')->put($dupPdfPath, $dupPdf->output());
        }

        return [
            'skipped_csv' => $skippedCsvPath,
            'duplicates_csv' => $dupCsvPath,
            'skipped_pdf' => $skippedPdfPath,
            'duplicates_pdf' => $dupPdfPath,
        ];
    }

    private function rowsToCsv(array $rows): string
    {
        $out = fopen('php://temp', 'r+');

        fputcsv($out, [
            'row',
            'reason',
            'first_row',
            'gb_code',
            'gb_name',
            'region_code',
            'region_name',
            'district_code',
            'district_name',
            'forest_code',
            'forest_name',
            'quarter_code',
            'quarter_name',
            'liter_code',
            'liter_name',
        ]);

        foreach ($rows as $r) {
            $d = $r['data'] ?? [];
            fputcsv($out, [
                $r['row'] ?? '',
                $r['reason'] ?? '',
                $r['first_row'] ?? '',
                $d[0] ?? '',
                $d[1] ?? '',
                $d[2] ?? '',
                $d[3] ?? '',
                $d[4] ?? '',
                $d[5] ?? '',
                $d[6] ?? '',
                $d[7] ?? '',
                $d[8] ?? '',
                $d[9] ?? '',
                $d[10] ?? '',
                $d[11] ?? '',
            ]);
        }

        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);

        return (string) $csv;
    }

    private function buildPdfHtml(string $title, array $rows): string
    {
        $html = '<!doctype html><html><head>'
            . '<meta charset="utf-8">'
            . '<style>
                body { font-family: "DejaVu Sans", sans-serif; font-size: 11px; }
                h2 { margin-bottom: 12px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #333; padding: 6px; vertical-align: top; }
                th { background: #f2f2f2; }
              </style>'
            . '</head><body>';

        $html .= '<h2>' . e($title) . '</h2>';
        $html .= '<table>';
        $html .= '<tr>
                    <th>Row</th>
                    <th>Reason</th>
                    <th>First row</th>
                    <th>GB</th>
                    <th>Region</th>
                    <th>District</th>
                    <th>Forest</th>
                    <th>Quarter</th>
                    <th>Liter</th>
                  </tr>';

        foreach ($rows as $r) {
            $d = $r['data'] ?? [];
            $html .= '<tr>';
            $html .= '<td>' . e($r['row'] ?? '') . '</td>';
            $html .= '<td>' . e($r['reason'] ?? '') . '</td>';
            $html .= '<td>' . e($r['first_row'] ?? '') . '</td>';
            $html .= '<td>' . e(($d[0] ?? '') . ' ' . ($d[1] ?? '')) . '</td>';
            $html .= '<td>' . e(($d[2] ?? '') . ' ' . ($d[3] ?? '')) . '</td>';
            $html .= '<td>' . e(($d[4] ?? '') . ' ' . ($d[5] ?? '')) . '</td>';
            $html .= '<td>' . e(($d[6] ?? '') . ' ' . ($d[7] ?? '')) . '</td>';
            $html .= '<td>' . e(($d[8] ?? '') . ' ' . ($d[9] ?? '')) . '</td>';
            $html .= '<td>' . e(($d[10] ?? '') . ' ' . ($d[11] ?? '')) . '</td>';
            $html .= '</tr>';
        }

        $html .= '</table></body></html>';

        return $html;
    }

    private function buildPreviewWithDbCompare(string $storedPath, string $ext): array
    {
        $t0 = microtime(true);

        $rowsTotal = 0;
        $rowsReady = 0;
        $rowsSkipped = 0;
        $rowsDups = 0;

        $skipped = [];
        $dups = [];
        $sample = [];

        $seen = [];

        $gbCodes = [];
        $regionCodesByGb = [];
        $districtCodesByGbRegion = [];
        $forestCodesByGbRegionDistrict = [];
        $quarterCodesByGbRegionDistrictForest = [];
        $literCodesByGbRegionDistrictForestQuarter = [];

        foreach ($this->iterateRowsFromStored($storedPath, $ext) as $rowNumber => $row) {
            $rowsTotal++;

            $gbCode = trim((string) ($row[0] ?? ''));
            $gbName = trim((string) ($row[1] ?? ''));

            $regionCode = trim((string) ($row[2] ?? ''));
            $regionName = trim((string) ($row[3] ?? ''));

            $districtCode = trim((string) ($row[4] ?? ''));
            $districtName = trim((string) ($row[5] ?? ''));

            $forestCode = trim((string) ($row[6] ?? ''));
            $forestName = trim((string) ($row[7] ?? ''));

            $quarterCode = trim((string) ($row[8] ?? ''));
            $quarterName = trim((string) ($row[9] ?? ''));

            $literCode = trim((string) ($row[10] ?? ''));
            $literName = trim((string) ($row[11] ?? ''));

            if (
                $gbCode === '' && $gbName === ''
                && $regionCode === '' && $regionName === ''
                && $districtCode === '' && $districtName === ''
                && $forestCode === '' && $forestName === ''
                && $quarterCode === '' && $quarterName === ''
                && $literCode === '' && $literName === ''
            ) {
                continue;
            }

            $lower0 = mb_strtolower($gbCode);
            if ($rowNumber === 1 && (str_contains($lower0, 'governing') || str_contains($lower0, 'gb'))) {
                continue;
            }

            $required = [
                $gbCode, $gbName,
                $regionCode, $regionName,
                $districtCode, $districtName,
                $forestCode, $forestName,
                $quarterCode, $quarterName,
                $literCode, $literName,
            ];

            $hasEmpty = false;
            foreach ($required as $x) {
                if ($x === '') {
                    $hasEmpty = true;
                    break;
                }
            }

            if ($hasEmpty) {
                $rowsSkipped++;
                if (count($skipped) < 200) {
                    $skipped[] = [
                        'row' => $rowNumber,
                        'reason' => 'ცარიელი ველები',
                        'data' => $required,
                    ];
                }
                continue;
            }

            $key = implode('|', [$gbCode, $regionCode, $districtCode, $forestCode, $quarterCode, $literCode]);

            if (isset($seen[$key])) {
                $rowsDups++;
                if (count($dups) < 200) {
                    $dups[] = [
                        'row' => $rowNumber,
                        'first_row' => $seen[$key],
                        'reason' => 'დუბლიკატი ფაილში',
                        'data' => $required,
                    ];
                }
                continue;
            }

            $seen[$key] = $rowNumber;
            $rowsReady++;

            if (count($sample) < 50) {
                $sample[] = [
                    'row' => $rowNumber,
                    'gb_code' => $gbCode,
                    'gb_name' => $gbName,
                    'region_code' => $regionCode,
                    'region_name' => $regionName,
                    'district_code' => $districtCode,
                    'district_name' => $districtName,
                    'forest_code' => $forestCode,
                    'forest_name' => $forestName,
                    'quarter_code' => $quarterCode,
                    'quarter_name' => $quarterName,
                    'liter_code' => $literCode,
                    'liter_name' => $literName,
                ];
            }

            $gbCodes[$gbCode] = true;
            $regionCodesByGb[$gbCode][$regionCode] = true;

            $gbRegion = $gbCode . '|' . $regionCode;
            $districtCodesByGbRegion[$gbRegion][$districtCode] = true;

            $gbRegionDistrict = $gbCode . '|' . $regionCode . '|' . $districtCode;
            $forestCodesByGbRegionDistrict[$gbRegionDistrict][$forestCode] = true;

            $gbRegionDistrictForest = $gbRegionDistrict . '|' . $forestCode;
            $quarterCodesByGbRegionDistrictForest[$gbRegionDistrictForest][$quarterCode] = true;

            $gbRegionDistrictForestQuarter = $gbRegionDistrictForest . '|' . $quarterCode;
            $literCodesByGbRegionDistrictForestQuarter[$gbRegionDistrictForestQuarter][$literCode] = true;
        }

        $gbCodeList = array_keys($gbCodes);

        $gbMap = GoverningBody::query()
            ->withTrashed()
            ->whereIn('code', $gbCodeList)
            ->get()
            ->keyBy('code');

        $gbIds = $gbMap->pluck('id')->all();

        $regionCodeSet = [];
        foreach ($regionCodesByGb as $codes) {
            foreach (array_keys($codes) as $c) {
                $regionCodeSet[$c] = true;
            }
        }
        $regionCodeList = array_keys($regionCodeSet);

        $regions = Region::query()
            ->withTrashed()
            ->whereIn('governing_body_id', $gbIds ?: [0])
            ->whereIn('code', $regionCodeList ?: ['__none__'])
            ->get();

        $regionMap = [];
        foreach ($regions as $region) {
            $regionMap[$region->governing_body_id . '|' . $region->code] = $region;
        }

        $regionIds = $regions->pluck('id')->all();

        $districtCodeSet = [];
        foreach ($districtCodesByGbRegion as $codes) {
            foreach (array_keys($codes) as $c) {
                $districtCodeSet[$c] = true;
            }
        }
        $districtCodeList = array_keys($districtCodeSet);

        $districts = ForestDistrict::query()
            ->withTrashed()
            ->whereIn('region_id', $regionIds ?: [0])
            ->whereIn('code', $districtCodeList ?: ['__none__'])
            ->get();

        $districtMap = [];
        foreach ($districts as $district) {
            $districtMap[$district->region_id . '|' . $district->code] = $district;
        }

        $districtIds = $districts->pluck('id')->all();

        $forestCodeSet = [];
        foreach ($forestCodesByGbRegionDistrict as $codes) {
            foreach (array_keys($codes) as $c) {
                $forestCodeSet[$c] = true;
            }
        }
        $forestCodeList = array_keys($forestCodeSet);

        $forests = Forest::query()
            ->withTrashed()
            ->whereIn('forest_district_id', $districtIds ?: [0])
            ->whereIn('code', $forestCodeList ?: ['__none__'])
            ->get();

        $forestMap = [];
        foreach ($forests as $forest) {
            $forestMap[$forest->forest_district_id . '|' . $forest->code] = $forest;
        }

        $forestIds = $forests->pluck('id')->all();

        $quarterCodeSet = [];
        foreach ($quarterCodesByGbRegionDistrictForest as $codes) {
            foreach (array_keys($codes) as $c) {
                $quarterCodeSet[$c] = true;
            }
        }
        $quarterCodeList = array_keys($quarterCodeSet);

        $quarters = Quarter::query()
            ->withTrashed()
            ->whereIn('forest_id', $forestIds ?: [0])
            ->whereIn('code', $quarterCodeList ?: ['__none__'])
            ->get();

        $quarterMap = [];
        foreach ($quarters as $quarter) {
            $quarterMap[$quarter->forest_id . '|' . $quarter->code] = $quarter;
        }

        $quarterIds = $quarters->pluck('id')->all();

        $literCodeSet = [];
        foreach ($literCodesByGbRegionDistrictForestQuarter as $codes) {
            foreach (array_keys($codes) as $c) {
                $literCodeSet[$c] = true;
            }
        }
        $literCodeList = array_keys($literCodeSet);

        $liters = Liter::query()
            ->withTrashed()
            ->whereIn('quarter_id', $quarterIds ?: [0])
            ->whereIn('code', $literCodeList ?: ['__none__'])
            ->get();

        $literMap = [];
        foreach ($liters as $liter) {
            $literMap[$liter->quarter_id . '|' . $liter->code] = $liter;
        }

        $create = [
            'governing_bodies' => 0,
            'regions' => 0,
            'districts' => 0,
            'forests' => 0,
            'quarters' => 0,
            'liters' => 0,
        ];

        $exists = [
            'governing_bodies' => 0,
            'regions' => 0,
            'districts' => 0,
            'forests' => 0,
            'quarters' => 0,
            'liters' => 0,
        ];

        foreach ($this->iterateRowsFromStored($storedPath, $ext) as $rowNumber => $row) {
            $gbCode = trim((string) ($row[0] ?? ''));
            $gbName = trim((string) ($row[1] ?? ''));

            $regionCode = trim((string) ($row[2] ?? ''));
            $regionName = trim((string) ($row[3] ?? ''));

            $districtCode = trim((string) ($row[4] ?? ''));
            $districtName = trim((string) ($row[5] ?? ''));

            $forestCode = trim((string) ($row[6] ?? ''));
            $forestName = trim((string) ($row[7] ?? ''));

            $quarterCode = trim((string) ($row[8] ?? ''));
            $quarterName = trim((string) ($row[9] ?? ''));

            $literCode = trim((string) ($row[10] ?? ''));
            $literName = trim((string) ($row[11] ?? ''));

            $lower0 = mb_strtolower($gbCode);
            if ($rowNumber === 1 && (str_contains($lower0, 'governing') || str_contains($lower0, 'gb'))) {
                continue;
            }

            $required = [
                $gbCode, $gbName,
                $regionCode, $regionName,
                $districtCode, $districtName,
                $forestCode, $forestName,
                $quarterCode, $quarterName,
                $literCode, $literName,
            ];

            foreach ($required as $x) {
                if ($x === '') {
                    continue 2;
                }
            }

            $key = implode('|', [$gbCode, $regionCode, $districtCode, $forestCode, $quarterCode, $literCode]);
            if (!isset($seen[$key])) {
                continue;
            }

            $gb = $gbMap[$gbCode] ?? null;
            if (!$gb) {
                $create['governing_bodies']++;
                $create['regions']++;
                $create['districts']++;
                $create['forests']++;
                $create['quarters']++;
                $create['liters']++;
                continue;
            }
            $exists['governing_bodies']++;

            $region = $regionMap[$gb->id . '|' . $regionCode] ?? null;
            if (!$region) {
                $create['regions']++;
                $create['districts']++;
                $create['forests']++;
                $create['quarters']++;
                $create['liters']++;
                continue;
            }
            $exists['regions']++;

            $district = $districtMap[$region->id . '|' . $districtCode] ?? null;
            if (!$district) {
                $create['districts']++;
                $create['forests']++;
                $create['quarters']++;
                $create['liters']++;
                continue;
            }
            $exists['districts']++;

            $forest = $forestMap[$district->id . '|' . $forestCode] ?? null;
            if (!$forest) {
                $create['forests']++;
                $create['quarters']++;
                $create['liters']++;
                continue;
            }
            $exists['forests']++;

            $quarter = $quarterMap[$forest->id . '|' . $quarterCode] ?? null;
            if (!$quarter) {
                $create['quarters']++;
                $create['liters']++;
                continue;
            }
            $exists['quarters']++;

            $liter = $literMap[$quarter->id . '|' . $literCode] ?? null;
            if (!$liter) {
                $create['liters']++;
                continue;
            }
            $exists['liters']++;
        }

        $previewSeconds = max(0.0001, microtime(true) - $t0);
        $perRowMs = $rowsReady > 0 ? (($previewSeconds * 1000.0) / $rowsReady) : 0.0;

        return [
            'stats' => [
                'rows_total' => $rowsTotal,
                'rows_ready' => $rowsReady,
                'rows_skipped' => $rowsSkipped,
                'rows_file_duplicates' => $rowsDups,
                'create' => $create,
                'exists' => $exists,
            ],
            'time' => [
                'preview_seconds' => round($previewSeconds, 3),
                'per_row_ms' => round($perRowMs, 3),
                'estimated_import_seconds' => round(($rowsReady * $perRowMs / 1000.0) * 2.0, 2),
            ],
            'skipped' => $skipped,
            'file_duplicates' => $dups,
            'sample' => $sample,
        ];
    }

    private function iterateRowsFromStored(string $storedPath, string $ext): \Generator
    {
        $ext = strtolower($ext);

        if (in_array($ext, ['xlsx', 'xls'], true) && class_exists(\Maatwebsite\Excel\Facades\Excel::class)) {
            $rows = [];

            $collector = new HierarchyPreviewChunkImport(function (array $row, int $rowIndex) use (&$rows) {
                $rows[] = [$rowIndex, $row];
            });

            Excel::import($collector, $storedPath, 'local');

            foreach ($rows as [$idx, $r]) {
                yield $idx => $r;
            }

            return;
        }

        $stream = Storage::disk('local')->readStream($storedPath);
        if (!$stream) {
            return;
        }

        $firstLine = fgets($stream);
        if ($firstLine === false) {
            fclose($stream);
            return;
        }

        $delims = [',', ';', "\t"];
        $delimiter = ',';
        $best = 0;

        foreach ($delims as $d) {
            $c = count(str_getcsv($firstLine, $d));
            if ($c > $best) {
                $best = $c;
                $delimiter = $d;
            }
        }

        rewind($stream);

        $rowNumber = 0;
        while (($row = fgetcsv($stream, 0, $delimiter)) !== false) {
            $rowNumber++;
            yield $rowNumber => $row;
        }

        fclose($stream);
    }
}