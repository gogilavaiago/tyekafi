<?php

namespace App\Http\Controllers\Admin;

use App\Exports\HierarchyFlatExport;
use App\Http\Controllers\Controller;
use App\Models\Liter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\StreamedResponse;

class HierarchyExportController extends Controller
{
    public function showForm()
    {
        Gate::authorize('perm.hierarchy.export');

        return view('admin.hierarchy.export');
    }

    public function exportCsv(Request $request): StreamedResponse
    {
        Gate::authorize('perm.hierarchy.export');

        [$headings, $filters] = $this->prepareExport($request);

        $filename = 'hierarchy_export_' . now()->format('Ymd_His') . '.csv';

        return response()->streamDownload(function () use ($headings, $filters) {

            $out = fopen('php://output', 'w');
            fputcsv($out, $headings);

            $this->streamRows($filters, function ($row) use ($out) {
                fputcsv($out, $row);
            });

            fclose($out);

        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function exportXlsx(Request $request)
    {
        Gate::authorize('perm.hierarchy.export');

        [$headings, $filters] = $this->prepareExport($request);

        $rows = [];

        $this->streamRows($filters, function ($row) use (&$rows) {
            $rows[] = $row;
        });

        return (new HierarchyFlatExport($rows, $headings))
            ->download('hierarchy_export_' . now()->format('Ymd_His') . '.xlsx');
    }

    private function prepareExport(Request $request): array
    {
        $includeCodes = $request->boolean('include_codes');
        $includeFullChain = $request->boolean('include_full_chain');
        $includeDeleted = $request->boolean('include_deleted');

        $headings = [];

        if ($includeFullChain) {
            $headings[] = 'full_code_chain';
        }

        if ($includeCodes) {
            $headings = array_merge($headings, [
                'gb_code', 'district_code', 'forest_code', 'quarter_code', 'liter_code',
            ]);
        }

        $headings = array_merge($headings, [
            'governing_body', 'district', 'forest', 'quarter', 'liter',
        ]);

        $filters = [
            'include_codes' => $includeCodes,
            'include_full_chain' => $includeFullChain,
            'include_deleted' => $includeDeleted,
        ];

        return [$headings, $filters];
    }

    private function streamRows(array $filters, callable $callback): void
    {
        $query = Liter::query();

        if ($filters['include_deleted']) {
            $query->withTrashed();
        }

        $query->with([
            'quarter.forest.district.governingBody'
        ]);

        $query->orderBy('id')->chunkById(1000, function ($chunk) use ($filters, $callback) {

            foreach ($chunk as $liter) {

                $quarter = $liter->quarter;
                $forest = $quarter?->forest;
                $district = $forest?->district;
                $gb = $district?->governingBody;

                $gbCode = $gb?->code ?? '';
                $dCode  = $district?->code ?? '';
                $fCode  = $forest?->code ?? '';
                $qCode  = $quarter?->code ?? '';
                $lCode  = $liter?->code ?? '';

                $row = [];

                if ($filters['include_full_chain']) {
                    $row[] = implode('-', [$gbCode, $dCode, $fCode, $qCode, $lCode]);
                }

                if ($filters['include_codes']) {
                    $row[] = $gbCode;
                    $row[] = $dCode;
                    $row[] = $fCode;
                    $row[] = $qCode;
                    $row[] = $lCode;
                }

                $row[] = $gb?->name ?? '';
                $row[] = $district?->name ?? '';
                $row[] = $forest?->name ?? '';
                $row[] = $quarter?->name ?? '';
                $row[] = $liter?->name ?? '';

                $callback($row);
            }

        });
    }
}