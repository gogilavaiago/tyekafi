<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TariffSpeciesMapping;
use App\Models\TariffTable;
use App\Models\TariffValue;
use App\Services\VolumeTariffImporter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class VolumeTariffController extends Controller
{
    public function index()
    {
        $tablesCount = TariffTable::query()->count();
        $valuesCount = TariffValue::query()->count();
        $mapsCount   = TariffSpeciesMapping::query()->count();

        $latest = TariffValue::query()->latest('updated_at')->first()
            ?? TariffTable::query()->latest('updated_at')->first()
            ?? TariffSpeciesMapping::query()->latest('updated_at')->first();

        return view('admin.volume_tariffs.index', [
            'tablesCount' => $tablesCount,
            'valuesCount' => $valuesCount,
            'mapsCount' => $mapsCount,
            'latestUpdatedAt' => $latest?->updated_at,
        ]);
    }

    public function upload(Request $request, VolumeTariffImporter $importer)
    {
        $validated = $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx'],
        ]);

        $file = $validated['file'];

        $dir = 'volume_tariffs';
        $name = 'latest.xlsx';
        $path = $file->storeAs($dir, $name);

        if (!$path) {
            throw ValidationException::withMessages(['file' => 'ფაილის შენახვა ვერ მოხერხდა.']);
        }

        $absolutePath = Storage::path($path);

        $result = $importer->import($absolutePath, true);

        $msg = "განახლდა წარმატებით. "
            . "Tables ახალი/განახლებული: {$result['tables_inserted']}/{$result['tables_updated']}. "
            . "Values ახალი/განახლებული: {$result['values_inserted']}/{$result['values_updated']}. "
            . "Mappings ახალი/განახლებული: {$result['mappings_inserted']}/{$result['mappings_updated']}. "
            . "გამოტოვებული: {$result['skipped']}";

        return redirect()
            ->route('admin.volume-tariffs.index')
            ->with('status', $msg);
    }
}