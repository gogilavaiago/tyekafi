<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TariffSpeciesMapping;
use App\Models\TariffTable;
use App\Models\TreeSpecies;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TreeCatalogController extends Controller
{
    public function index()
    {
        $species = TreeSpecies::query()
            ->leftJoin('tariff_species_mappings', 'tariff_species_mappings.species_name', '=', 'tree_species.name')
            ->leftJoin('tariff_tables', 'tariff_tables.id', '=', 'tariff_species_mappings.tariff_table_id')
            ->select([
                'tree_species.id',
                'tree_species.name',
                'tree_species.short_name',
                'tree_species.latin_name',
                'tree_species.red_list',
                'tariff_tables.code as tariff_table_code',
                'tariff_tables.name as tariff_table_name',
            ])
            ->orderBy('tree_species.name')
            ->get();

        $tariffTables = TariffTable::query()
            ->orderBy('code')
            ->get(['id', 'code', 'name']);

        return view('admin.users.tree_catalog.index', compact('species', 'tariffTables'));
    }

    public function storeSpecies(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:tree_species,name'],
            'short_name' => ['nullable', 'string', 'max:255'],
            'latin_name' => ['nullable', 'string', 'max:255'],
            'tariff_table_id' => ['required', 'integer', 'exists:tariff_tables,id'],
        ], [
            'name.required' => 'სახეობის დასახელება სავალდებულოა.',
            'name.unique' => 'ასეთი სახეობა უკვე არსებობს.',
            'short_name.max' => 'შემოკლებული სახელი მაქსიმუმ 255 სიმბოლო უნდა იყოს.',
            'latin_name.max' => 'ლათინური დასახელება მაქსიმუმ 255 სიმბოლო უნდა იყოს.',
            'tariff_table_id.required' => 'დასათვლელი ცხრილის არჩევა სავალდებულოა.',
            'tariff_table_id.exists' => 'არჩეული ტარიფის ცხრილი ვერ მოიძებნა.',
        ]);

        DB::transaction(function () use ($data) {
            $species = TreeSpecies::create([
                'name' => trim($data['name']),
                'short_name' => isset($data['short_name']) && trim((string) $data['short_name']) !== ''
                    ? trim($data['short_name'])
                    : null,
                'latin_name' => isset($data['latin_name']) && trim((string) $data['latin_name']) !== ''
                    ? trim($data['latin_name'])
                    : null,
                'red_list' => null,
            ]);

            TariffSpeciesMapping::updateOrCreate(
                ['species_name' => $species->name],
                [
                    'tariff_table_id' => (int) $data['tariff_table_id'],
                    'notes' => null,
                ]
            );
        });

        return redirect()
            ->route('admin.tree-catalog.index')
            ->with('status', 'სახეობა და დასათვლელი ცხრილი წარმატებით დაემატა.');
    }

    public function destroySpecies(TreeSpecies $treeSpecies)
    {
        $usedInTreeRows = DB::table('tyekafi_tree_rows')
            ->where('tree_species_id', $treeSpecies->id)
            ->exists();

        $usedInSmallRows = DB::table('tyekafi_small_tree_rows')
            ->where('tree_species_id', $treeSpecies->id)
            ->exists();

        $usedInSummaries = DB::table('tyekafi_species_summaries')
            ->where('tree_species_id', $treeSpecies->id)
            ->exists();

        if ($usedInTreeRows || $usedInSmallRows || $usedInSummaries) {
            return redirect()
                ->route('admin.tree-catalog.index')
                ->withErrors([
                    'species_delete' => 'ეს სახეობა უკვე გამოყენებულია სისტემაში და წაშლა დაუშვებელია.',
                ]);
        }

        DB::transaction(function () use ($treeSpecies) {
            TariffSpeciesMapping::query()
                ->where('species_name', $treeSpecies->name)
                ->delete();

            $treeSpecies->delete();
        });

        return redirect()
            ->route('admin.tree-catalog.index')
            ->with('status', 'სახეობა წაიშალა.');
    }
}