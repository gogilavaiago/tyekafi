<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Hierarchy\StoreForestDistrictRequest;
use App\Http\Requests\Admin\Hierarchy\StoreForestRequest;
use App\Http\Requests\Admin\Hierarchy\StoreGoverningBodyRequest;
use App\Http\Requests\Admin\Hierarchy\StoreLiterRequest;
use App\Http\Requests\Admin\Hierarchy\StoreRegionRequest;
use App\Http\Requests\Admin\Hierarchy\StoreQuarterRequest;
use App\Http\Requests\Admin\Hierarchy\UpdateForestDistrictRequest;
use App\Http\Requests\Admin\Hierarchy\UpdateForestRequest;
use App\Http\Requests\Admin\Hierarchy\UpdateGoverningBodyRequest;
use App\Http\Requests\Admin\Hierarchy\UpdateLiterRequest;
use App\Http\Requests\Admin\Hierarchy\UpdateRegionRequest;
use App\Http\Requests\Admin\Hierarchy\UpdateQuarterRequest;
use App\Models\Forest;
use App\Models\ForestDistrict;
use App\Models\GoverningBody;
use App\Models\Liter;
use App\Models\Quarter;
use App\Models\Region;
use App\Services\Hierarchy\ForestDistrictService;
use App\Services\Hierarchy\ForestService;
use App\Services\Hierarchy\GoverningBodyService;
use App\Services\Hierarchy\LiterService;
use App\Services\Hierarchy\QuarterService;
use App\Services\Hierarchy\RegionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class HierarchyController extends Controller
{
    public function __construct(
        private GoverningBodyService $gbService,
        private RegionService $regionService,
        private ForestDistrictService $districtService,
        private ForestService $forestService,
        private QuarterService $quarterService,
        private LiterService $literService
    ) {
    }

    public function index(Request $request)
    {
        Gate::authorize('perm.hierarchy.view');

        $status = $request->query('status', 'active');
        if (!in_array($status, ['active', 'deleted', 'all'], true)) {
            $status = 'active';
        }

        $gbQuery = GoverningBody::query()->orderBy('name');
        $this->applyTrashScope($gbQuery, $status);
        $governingBodies = $gbQuery->get();

        $rQuery = Region::query()
            ->with(['governingBody' => fn($q) => $q->withTrashed()])
            ->orderBy('name');
        $this->applyTrashScope($rQuery, $status);
        $regions = $rQuery->get();

        $dQuery = ForestDistrict::query()
            ->with(['governingBody' => fn($q) => $q->withTrashed(), 'region' => fn($q) => $q->withTrashed()])
            ->orderBy('name');
        $this->applyTrashScope($dQuery, $status);
        $districts = $dQuery->get();

        $fQuery = Forest::query()
            ->with([
                'district' => fn($q) => $q->withTrashed()->with([
                    'governingBody' => fn($qq) => $qq->withTrashed(),
                    'region' => fn($qq) => $qq->withTrashed(),
                ]),
            ])
            ->orderBy('name');
        $this->applyTrashScope($fQuery, $status);
        $forests = $fQuery->get();

        $qQuery = Quarter::query()
            ->with([
                'forest' => fn($q) => $q->withTrashed()->with([
                    'district' => fn($qq) => $qq->withTrashed()->with([
                        'governingBody' => fn($qqq) => $qqq->withTrashed(),
                        'region' => fn($qqq) => $qqq->withTrashed(),
                    ]),
                ]),
            ])
            ->orderBy('name');
        $this->applyTrashScope($qQuery, $status);
        $quarters = $qQuery->get();

        $lQuery = Liter::query()
            ->with([
                'quarter' => fn($q) => $q->withTrashed()->with([
                    'forest' => fn($qq) => $qq->withTrashed()->with([
                        'district' => fn($qqq) => $qqq->withTrashed()->with([
                            'governingBody' => fn($qqqq) => $qqqq->withTrashed(),
                            'region' => fn($qqqq) => $qqqq->withTrashed(),
                        ]),
                    ]),
                ]),
            ])
            ->orderBy('name');
        $this->applyTrashScope($lQuery, $status);
        $liters = $lQuery->get();

        $notDeleted = fn($model) => !(method_exists($model, 'trashed') ? $model->trashed() : !is_null($model->deleted_at));

        $activeGoverningBodyOptions = $governingBodies
            ->filter($notDeleted)
            ->map(fn($gb) => ['value' => $gb->id, 'label' => trim(($gb->name ?? '—') . ' (' . ($gb->code ?? '—') . ')')])
            ->values()
            ->all();

        $activeRegionOptions = $regions
            ->filter(function ($region) use ($notDeleted) {
                return $notDeleted($region) && $region->governingBody && $notDeleted($region->governingBody);
            })
            ->map(fn($region) => ['value' => $region->id, 'label' => ($region->governingBody?->name ?? '—') . ' → ' . $region->name . ' (' . ($region->code ?? '—') . ')'])
            ->values()
            ->all();

        $activeDistrictOptions = $districts
            ->filter(function ($district) use ($notDeleted) {
                return $notDeleted($district)
                    && $district->governingBody && $notDeleted($district->governingBody)
                    && $district->region && $notDeleted($district->region);
            })
            ->map(fn($district) => ['value' => $district->id, 'label' => ($district->governingBody?->name ?? '—') . ' → ' . ($district->region?->name ?? '—') . ' → ' . $district->name . ' (' . ($district->code ?? '—') . ')'])
            ->values()
            ->all();

        $activeForestOptions = $forests
            ->filter(function ($forest) use ($notDeleted) {
                return $notDeleted($forest)
                    && $forest->district && $notDeleted($forest->district)
                    && $forest->district->governingBody && $notDeleted($forest->district->governingBody);
            })
            ->map(fn($forest) => ['value' => $forest->id, 'label' => ($forest->district?->governingBody?->name ?? '—') . ' → ' . ($forest->district?->name ?? '—') . ' → ' . $forest->name])
            ->values()
            ->all();

        $activeQuarterOptions = $quarters
            ->filter(function ($quarter) use ($notDeleted) {
                return $notDeleted($quarter)
                    && $quarter->forest && $notDeleted($quarter->forest)
                    && $quarter->forest->district && $notDeleted($quarter->forest->district)
                    && $quarter->forest->district->governingBody && $notDeleted($quarter->forest->district->governingBody);
            })
            ->map(fn($quarter) => ['value' => $quarter->id, 'label' => ($quarter->forest?->district?->governingBody?->name ?? '—') . ' → ' . ($quarter->forest?->district?->name ?? '—') . ' → ' . ($quarter->forest?->name ?? '—') . ' → ' . $quarter->name])
            ->values()
            ->all();

        return view('admin.hierarchy.index', compact(
            'governingBodies',
            'regions',
            'districts',
            'forests',
            'quarters',
            'liters',
            'status',
            'activeGoverningBodyOptions',
            'activeRegionOptions',
            'activeDistrictOptions',
            'activeForestOptions',
            'activeQuarterOptions'
        ));
    }

    private function applyTrashScope($query, string $status): void
    {
        if ($status === 'all') {
            $query->withTrashed();
        } elseif ($status === 'deleted') {
            $query->onlyTrashed();
        }
    }

    public function storeGoverningBody(StoreGoverningBodyRequest $request)
    {
        Gate::authorize('perm.hierarchy.manage');
        $this->gbService->create(\App\DTO\Hierarchy\GoverningBodyData::fromRequest($request));
        return back()->with('success', 'მართვის ორგანო დაემატა');
    }
    public function updateGoverningBody(UpdateGoverningBodyRequest $request, GoverningBody $governingBody) { Gate::authorize('perm.hierarchy.manage'); $this->gbService->update($governingBody, \App\DTO\Hierarchy\GoverningBodyData::fromRequest($request)); return back()->with('success', 'მართვის ორგანო განახლდა'); }
    public function destroyGoverningBody(GoverningBody $governingBody) { Gate::authorize('perm.hierarchy.manage'); $this->gbService->softDelete($governingBody); return back()->with('success', 'მართვის ორგანო წაიშალა (soft)'); }
    public function restoreGoverningBody($governingBody) { Gate::authorize('perm.hierarchy.manage'); $this->gbService->restore((int) $governingBody); return back()->with('success', 'მართვის ორგანო აღდგა'); }
    public function storeRegion(StoreRegionRequest $request) { Gate::authorize('perm.hierarchy.manage'); $this->regionService->create(\App\DTO\Hierarchy\RegionData::fromRequest($request)); return back()->with('success', 'რეგიონი დაემატა'); }
    public function updateRegion(UpdateRegionRequest $request, Region $region) { Gate::authorize('perm.hierarchy.manage'); $this->regionService->update($region, \App\DTO\Hierarchy\RegionData::fromRequest($request)); return back()->with('success', 'რეგიონი განახლდა'); }
    public function destroyRegion(Region $region) { Gate::authorize('perm.hierarchy.manage'); $this->regionService->softDelete($region); return back()->with('success', 'რეგიონი წაიშალა (soft)'); }
    public function restoreRegion($region) { Gate::authorize('perm.hierarchy.manage'); $this->regionService->restore((int) $region); return back()->with('success', 'რეგიონი აღდგა'); }
    public function storeDistrict(StoreForestDistrictRequest $request) { Gate::authorize('perm.hierarchy.manage'); $this->districtService->create(\App\DTO\Hierarchy\ForestDistrictData::fromRequest($request)); return back()->with('success', 'სატყეო უბანი დაემატა'); }
    public function updateDistrict(UpdateForestDistrictRequest $request, ForestDistrict $forestDistrict) { Gate::authorize('perm.hierarchy.manage'); $this->districtService->update($forestDistrict, \App\DTO\Hierarchy\ForestDistrictData::fromRequest($request)); return back()->with('success', 'სატყეო უბანი განახლდა'); }
    public function destroyDistrict(ForestDistrict $forestDistrict) { Gate::authorize('perm.hierarchy.manage'); $this->districtService->softDelete($forestDistrict); return back()->with('success', 'სატყეო უბანი წაიშალა (soft)'); }
    public function restoreDistrict($forestDistrict) { Gate::authorize('perm.hierarchy.manage'); $this->districtService->restore((int) $forestDistrict); return back()->with('success', 'სატყეო უბანი აღდგა'); }
    public function storeForest(StoreForestRequest $request) { Gate::authorize('perm.hierarchy.manage'); $this->forestService->create(\App\DTO\Hierarchy\ForestData::fromRequest($request)); return back()->with('success', 'სატყეო დაემატა'); }
    public function updateForest(UpdateForestRequest $request, Forest $forest) { Gate::authorize('perm.hierarchy.manage'); $this->forestService->update($forest, \App\DTO\Hierarchy\ForestData::fromRequest($request)); return back()->with('success', 'სატყეო განახლდა'); }
    public function destroyForest(Forest $forest) { Gate::authorize('perm.hierarchy.manage'); $this->forestService->softDelete($forest); return back()->with('success', 'სატყეო წაიშალა (soft)'); }
    public function restoreForest($forest) { Gate::authorize('perm.hierarchy.manage'); $this->forestService->restore((int) $forest); return back()->with('success', 'სატყეო აღდგა'); }
    public function storeQuarter(StoreQuarterRequest $request) { Gate::authorize('perm.hierarchy.manage'); $this->quarterService->create(\App\DTO\Hierarchy\QuarterData::fromRequest($request)); return back()->with('success', 'კვარტალი დაემატა'); }
    public function updateQuarter(UpdateQuarterRequest $request, Quarter $quarter) { Gate::authorize('perm.hierarchy.manage'); $this->quarterService->update($quarter, \App\DTO\Hierarchy\QuarterData::fromRequest($request)); return back()->with('success', 'კვარტალი განახლდა'); }
    public function destroyQuarter(Quarter $quarter) { Gate::authorize('perm.hierarchy.manage'); $this->quarterService->softDelete($quarter); return back()->with('success', 'კვარტალი წაიშალა (soft)'); }
    public function restoreQuarter($quarter) { Gate::authorize('perm.hierarchy.manage'); $this->quarterService->restore((int) $quarter); return back()->with('success', 'კვარტალი აღდგა'); }
    public function storeLiter(StoreLiterRequest $request) { Gate::authorize('perm.hierarchy.manage'); $this->literService->create(\App\DTO\Hierarchy\LiterData::fromRequest($request)); return back()->with('success', 'ლიტერი დაემატა'); }
    public function updateLiter(UpdateLiterRequest $request, Liter $liter) { Gate::authorize('perm.hierarchy.manage'); $this->literService->update($liter, \App\DTO\Hierarchy\LiterData::fromRequest($request)); return back()->with('success', 'ლიტერი განახლდა'); }
    public function destroyLiter(Liter $liter) { Gate::authorize('perm.hierarchy.manage'); $this->literService->softDelete($liter); return back()->with('success', 'ლიტერი წაიშალა (soft)'); }
    public function restoreLiter($liter) { Gate::authorize('perm.hierarchy.manage'); $this->literService->restore((int) $liter); return back()->with('success', 'ლიტერი აღდგა'); }
}
