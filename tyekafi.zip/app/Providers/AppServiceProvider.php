<?php

namespace App\Providers;

use App\Models\Forest;
use App\Models\ForestDistrict;
use App\Models\GoverningBody;
use App\Models\Quarter;
use App\Models\Region;
use App\Observers\ForestDistrictObserver;
use App\Observers\ForestObserver;
use App\Observers\GoverningBodyObserver;
use App\Observers\QuarterObserver;
use App\Observers\RegionObserver;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // ✅ Register hierarchy observers (cascade soft delete + restore)
        GoverningBody::observe(GoverningBodyObserver::class);
        Region::observe(RegionObserver::class);
        ForestDistrict::observe(ForestDistrictObserver::class);
        Forest::observe(ForestObserver::class);
        Quarter::observe(QuarterObserver::class);

        // Admin gate
        Gate::define('admin', fn ($user) => $user && $user->hasRole('admin'));

        // Permission gates (არსებული)
        Gate::define('perm.view', fn ($user) => $user && $user->hasPermission('view'));
        Gate::define('perm.edit', fn ($user) => $user && $user->hasPermission('edit'));
        Gate::define('perm.import_export', fn ($user) => $user && $user->hasPermission('import_export'));
        Gate::define('perm.report_export', fn ($user) => $user && $user->hasPermission('report_export'));

        // ✅ Hierarchy permissions

        // view = ვისაც მაინც აქვს hierarchy-სთან კავშირი (manage/import/export) შეუძლია hierarchy index ნახოს
        Gate::define('perm.hierarchy.view', function ($user) {
            return $user && (
                $user->hasPermission('hierarchy_manage')
                || $user->hasPermission('hierarchy_import')
                || $user->hasPermission('hierarchy_export')
            );
        });

        // manage = CRUD + delete/restore
        Gate::define('perm.hierarchy.manage', fn ($user) => $user && $user->hasPermission('hierarchy_manage'));

        // import/export
        Gate::define('perm.hierarchy.import', fn ($user) => $user && $user->hasPermission('hierarchy_import'));
        Gate::define('perm.hierarchy.export', fn ($user) => $user && $user->hasPermission('hierarchy_export'));
    }
}