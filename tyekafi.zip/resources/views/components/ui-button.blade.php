@props([
    'href' => null,
    'type' => 'button',     // submit-საც მივცემთ მხარდაჭერას
    'variant' => 'open',    // open | add | edit | delete | dark | light
    'size' => 'md',         // sm | md
    'icon' => null,         // string: +, ✎, 🗑, ↗, etc
])

@php
    // ---------- Sizes ----------
    $sizes = [
        'sm' => 'px-3 py-1 text-sm',
        'md' => 'px-4 py-2 text-sm',
    ];
    $sizeClasses = $sizes[$size] ?? $sizes['md'];

    // ---------- Variants ----------
    // შენი მოთხოვნა: მწვანე/add, ნარინჯისფერი/edit, წითელი/delete, ნაცრისფერი/open
    $variants = [
        'open' => 'bg-gray-200 hover:bg-gray-300 text-gray-900',
        'add' => 'bg-green-600 hover:bg-green-700 text-white',
        'edit' => 'bg-orange-500 hover:bg-orange-600 text-white',
        'delete' => 'bg-red-600 hover:bg-red-700 text-white',
        'light' => 'bg-gray-100 hover:bg-gray-200 text-gray-800',
        'dark' => 'bg-gray-900 hover:bg-gray-800 text-white',
        'primary' => 'bg-green-600 hover:bg-green-700 text-white', // უკან compatibility
        'danger' => 'bg-red-600 hover:bg-red-700 text-white',      // უკან compatibility
    ];
    $variantClasses = $variants[$variant] ?? $variants['open'];

    // ---------- Base ----------
    $base = 'inline-flex items-center gap-2 rounded-md font-medium shadow-sm transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400';

    // Icons spacing (ერთნაირი)
    $iconWrap = 'inline-flex items-center justify-center w-4 h-4 leading-none';
@endphp

@if ($href)
    <a href="{{ $href }}" {{ $attributes->merge(['class' => "$base $sizeClasses $variantClasses"]) }}>
        @if($icon)
            <span class="{{ $iconWrap }}" aria-hidden="true">{{ $icon }}</span>
        @endif
        <span>{{ $slot }}</span>
    </a>
@else
    <button type="{{ $type }}" {{ $attributes->merge(['class' => "$base $sizeClasses $variantClasses"]) }}>
        @if($icon)
            <span class="{{ $iconWrap }}" aria-hidden="true">{{ $icon }}</span>
        @endif
        <span>{{ $slot }}</span>
    </button>
@endif
