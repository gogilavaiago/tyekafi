@props(['size' => 'md'])

@php
    $sizes = [
        'sm' => 'px-3 py-1 text-sm',
        'md' => 'px-4 py-2 text-sm',
        'lg' => 'px-5 py-2.5 text-base',
    ];

    $classes = 'inline-flex items-center justify-center gap-2 font-medium rounded border cursor-not-allowed opacity-70 bg-gray-300 text-gray-800 border-gray-400 whitespace-nowrap '
        .($sizes[$size] ?? $sizes['md']);
@endphp

<span {{ $attributes->merge(['class' => $classes]) }}>
    <span>{{ $slot }}</span>
</span>
