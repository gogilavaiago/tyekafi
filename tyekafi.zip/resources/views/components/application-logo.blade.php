<img
    src="{{ asset('images/logo.png') }}"
    {{ $attributes->merge(['class' => 'block h-16 w-auto']) }}
/>