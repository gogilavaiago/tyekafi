@php
    // აქტიური Project route parameter-იდან
    $routeProject = request()->route('project');
    $activeProject = null;

    if ($routeProject instanceof \App\Models\Project) {
        $activeProject = $routeProject;
    } elseif (!empty($routeProject) && is_numeric($routeProject)) {
        $activeProject = \App\Models\Project::query()->find((int) $routeProject);
    }
@endphp

<nav x-data="{ open: false }" class="bg-white border-b border-gray-200">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-6 lg:px-8">
        <div class="flex justify-between h-16">

            <!-- Left side -->
            <div class="flex items-center space-x-10">

                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}" class="flex items-center gap-2">
                        <x-application-logo class="block h-16 w-auto text-gray-800" />
                        <span class="font-semibold text-gray-800 leading-tight">
                        <span class="block text-lg"  >საქართველოს</span>
                        <span class="block text-lg">სატყეო სერვისები</span>
                        </span>
                    </a>
                </div>

                <!-- Navigation Links -->
                <div class="hidden sm:flex items-center space-x-8">
                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                        მთავარი
                    </x-nav-link>

                    <x-nav-link :href="route('projects.index')" :active="request()->routeIs('projects.*')">
                        პროექტები
                    </x-nav-link>

                    {{-- აქტიური პროექტის ჩიპი --}}
                    @if($activeProject)
                        <a href="{{ route('projects.show', $activeProject) }}"
                           class="inline-flex items-center gap-2 px-3 py-1 rounded-full border bg-gray-50 text-gray-700 hover:bg-gray-100 transition text-sm">
                            <span class="text-gray-500">აქტიური პროექტი:</span>
                            <span class="font-semibold text-gray-900">{{ $activeProject->name }}</span>
                        </a>
                    @endif

                    @can('admin')
                        <x-nav-link :href="route('admin.users.index')" :active="request()->routeIs('admin.*')">
                            ადმინისტრირება
                        </x-nav-link>
                    @endcan
                </div>
            </div>

            <!-- Right side -->
            <div class="hidden sm:flex sm:items-center sm:space-x-6">
                <x-dropdown align="right" width="48">
                    <x-slot name="trigger">
                        <button
                            class="flex items-center gap-2 px-3 py-2 border border-transparent text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-100 focus:outline-none transition">
                            <span>{{ Auth::user()->name }}</span>

                            <svg class="h-4 w-4 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none"
                                 viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link :href="route('profile.edit')">
                            პროფილი
                        </x-dropdown-link>

                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <x-dropdown-link :href="route('logout')"
                                             onclick="event.preventDefault(); this.closest('form').submit();">
                                გასვლა
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </div>

            <!-- Hamburger -->
            <div class="-mr-2 flex items-center sm:hidden">
                <button @click="open = ! open"
                        class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none transition">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{ 'hidden': open, 'inline-flex': ! open }"
                              class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M4 6h16M4 12h16M4 18h16"/>
                        <path :class="{ 'hidden': ! open, 'inline-flex': open }"
                              class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>

        </div>
    </div>

    <!-- Responsive Navigation Menu -->
    <div :class="{ 'block': open, 'hidden': ! open }" class="hidden sm:hidden border-t">
        <div class="pt-4 pb-3 space-y-2 px-4">
            <x-responsive-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                მთავარი
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('projects.index')" :active="request()->routeIs('projects.*')">
                პროექტები
            </x-responsive-nav-link>

            {{-- Mobile: აქტიური პროექტის ჩიპი --}}
            @if($activeProject)
                <a href="{{ route('projects.show', $activeProject) }}"
                   class="block px-4 py-2 rounded-md border bg-gray-50 text-gray-700">
                    <div class="text-xs text-gray-500">აქტიური პროექტი</div>
                    <div class="font-semibold text-gray-900">{{ $activeProject->name }}</div>
                </a>
            @endif

            @can('admin')
                <x-responsive-nav-link :href="route('admin.users.index')" :active="request()->routeIs('admin.*')">
                    ადმინისტრირება
                </x-responsive-nav-link>
            @endcan
        </div>

        <div class="pt-4 pb-3 border-t border-gray-200 px-4">
            <div class="text-sm font-medium text-gray-800">{{ Auth::user()->name }}</div>
            <div class="text-sm text-gray-500">{{ Auth::user()->email }}</div>

            <div class="mt-3 space-y-1">
                <x-responsive-nav-link :href="route('profile.edit')">
                    პროფილი
                </x-responsive-nav-link>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <x-responsive-nav-link :href="route('logout')"
                                           onclick="event.preventDefault(); this.closest('form').submit();">
                        გასვლა
                    </x-responsive-nav-link>
                </form>
            </div>
        </div>
    </div>
</nav>
