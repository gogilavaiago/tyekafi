{{-- resources/views/tyekafis/create.blade.php --}}

@php
    // plain arrays JS-სთვის
    $GB = collect($governingBodies ?? [])->map(fn($x) => [
        'id' => (int) $x->id,
        'name' => (string) $x->name,
    ])->values()->all();

    $REG = collect($regions ?? [])->map(fn($x) => [
        'id' => (int) $x->id,
        'name' => (string) $x->name,
        'governing_body_id' => (int) $x->governing_body_id,
    ])->values()->all();

    // controller-იდან შეიძლება მოვიდეს districts ან forestDistricts
    $districtSource = $districts ?? $forestDistricts ?? [];

    $DIST = collect($districtSource)->map(fn($x) => [
        'id' => (int) $x->id,
        'name' => (string) $x->name,
        'region_id' => (int) ($x->region_id ?? 0),
    ])->values()->all();

    $FOR = collect($forests ?? [])->map(fn($x) => [
        'id' => (int) $x->id,
        'name' => (string) $x->name,
        'forest_district_id' => (int) $x->forest_district_id,
    ])->values()->all();

    $Q = collect($quarters ?? [])->map(fn($x) => [
        'id' => (int) $x->id,
        'name' => (string) $x->name,
        'forest_id' => (int) $x->forest_id,
    ])->values()->all();

    // liters with quarter relation
    $L = collect($liters ?? [])->map(function ($x) {
        return [
            'id' => (int) $x->id,
            'name' => (string) ($x->name ?? ('Liter #' . $x->id)),
            'quarter_id' => (int) ($x->quarter_id ?? optional($x->quarter)->id ?? 0),
            'quarter_name' => (string) (optional($x->quarter)->name ?? (isset($x->quarter_id) ? ('Quarter #' . $x->quarter_id) : '—')),
        ];
    })->values()->all();

    $oldSelected = array_map('intval', old('liter_ids', []));
@endphp

<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Tyekafi შექმნა — პროექტი: {{ $project->name }}
            </h2>

            <x-ui-button :href="route('projects.show', $project)" variant="open" icon="↗">
                უკან პროექტზე
            </x-ui-button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-8 text-gray-900"
                     x-data="tyCreate({
                        governingBodies: @js($GB),
                        regions: @js($REG),
                        districts: @js($DIST),
                        forests: @js($FOR),
                        quarters: @js($Q),
                        liters: @js($L),
                        oldSelected: @js($oldSelected),
                        oldGb: @js(old('governing_body_id')),
                        oldRegion: @js(old('region_id')),
                        oldDistrict: @js(old('district_id')),
                        oldForest: @js(old('forest_id')),
                        oldQuarter: @js(old('quarter_id')),
                     })"
                     x-init="init()"
                >

                    {{-- Errors --}}
                    @if ($errors->any())
                        <div class="mb-6 rounded border border-red-200 bg-red-50 p-4 text-red-700">
                            <div class="font-semibold mb-2">შეცდომაა:</div>
                            <ul class="list-disc pl-5 space-y-1">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('projects.tyekafis.store', $project) }}">
                        @csrf

                        {{-- Name --}}
                        <div class="mb-4">
                            <label class="block mb-1 font-medium text-gray-700">
                                Tyekafi-ს სახელი <span class="text-red-600">*</span>
                            </label>
                            <input name="name" value="{{ old('name') }}" class="w-full border rounded p-2" required>
                        </div>

                        {{-- Description --}}
                        <div class="mb-6">
                            <label class="block mb-1 font-medium text-gray-700">აღწერა</label>
                            <textarea name="description" class="w-full border rounded p-2" rows="4">{{ old('description') }}</textarea>
                        </div>

                        {{-- Dependent dropdowns --}}
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">

                            <div>
                                <label class="block mb-1 font-medium text-gray-700">მართვის ორგანო</label>
                                <select name="governing_body_id"
                                        class="w-full border rounded p-2"
                                        x-model.number="selectedGb"
                                        @change="onGbChange()">
                                    <option value="">— აირჩიე —</option>
                                    <template x-for="gb in governingBodies" :key="gb.id">
                                        <option :value="gb.id" x-text="gb.name"></option>
                                    </template>
                                </select>
                            </div>

                            <div>
                                <label class="block mb-1 font-medium text-gray-700">რეგიონი</label>
                                <select name="region_id"
                                        class="w-full border rounded p-2"
                                        x-model.number="selectedRegion"
                                        :disabled="!selectedGb"
                                        @change="onRegionChange()">
                                    <option value="">— აირჩიე —</option>
                                    <template x-for="r in filteredRegions" :key="r.id">
                                        <option :value="r.id" x-text="r.name"></option>
                                    </template>
                                </select>
                                <div class="text-xs text-gray-500 mt-1" x-show="!selectedGb">ჯერ აირჩიე მართვის ორგანო</div>
                            </div>

                            <div>
                                <label class="block mb-1 font-medium text-gray-700">სატყეო უბანი</label>
                                <select name="district_id"
                                        class="w-full border rounded p-2"
                                        x-model.number="selectedDistrict"
                                        :disabled="!selectedRegion"
                                        @change="onDistrictChange()">
                                    <option value="">— აირჩიე —</option>
                                    <template x-for="d in filteredDistricts" :key="d.id">
                                        <option :value="d.id" x-text="d.name"></option>
                                    </template>
                                </select>
                                <div class="text-xs text-gray-500 mt-1" x-show="selectedGb && !selectedRegion">ჯერ აირჩიე რეგიონი</div>
                            </div>

                            <div>
                                <label class="block mb-1 font-medium text-gray-700">სატყეო</label>
                                <select name="forest_id"
                                        class="w-full border rounded p-2"
                                        x-model.number="selectedForest"
                                        :disabled="!selectedDistrict"
                                        @change="onForestChange()">
                                    <option value="">— აირჩიე —</option>
                                    <template x-for="f in filteredForests" :key="f.id">
                                        <option :value="f.id" x-text="f.name"></option>
                                    </template>
                                </select>
                                <div class="text-xs text-gray-500 mt-1" x-show="selectedRegion && !selectedDistrict">ჯერ აირჩიე უბანი</div>
                            </div>

                            <div>
                                <label class="block mb-1 font-medium text-gray-700">კვარტალი (ხელით)</label>
                                <input type="text" name="manual_quarter" value="{{ old('manual_quarter') }}" class="w-full border rounded p-2" placeholder="მაგ: 12">
                                <div class="text-xs text-gray-500 mt-1">ეს ველი ივსება ხელით და რეპორტებში პრიორიტეტი აქვს.</div>
                            </div>

                        </div>

                        {{-- Liters --}}
                        <div class="mb-6">
                            <label class="block font-medium text-gray-700 mb-2">ლიტერი / ლიტერები (ხელით)</label>
                            <input type="text" name="manual_liters" value="{{ old('manual_liters') }}" class="w-full border rounded p-2" placeholder="მაგ: 3, 3ა, 4ბ">
                            <div class="text-xs text-gray-500 mt-1">ეს ველი ივსება ხელით და რეპორტებში პრიორიტეტი აქვს.</div>
                        </div>

                        {{-- Area / Volume --}}
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div>
                                <label class="block mb-1 font-medium text-gray-700">ფართობი</label>
                                <input 
                                    type="text"
                                    name="area_ha" 
                                    value="{{ old('area_ha') }}" 
                                    class="w-full border rounded p-2"
                                    inputmode="decimal"
                                    placeholder="მაგ: 2.6200"
                                >
                            </div>
                            <div>
                                <label class="block mb-1 font-medium text-gray-700">მოცულობა</label>
                                <input name="volume" value="{{ old('volume') }}" class="w-full border rounded p-2">
                            </div>
                        </div>

                        {{-- Buttons --}}
                        <div class="flex items-center gap-2">
                            <x-ui-button type="submit" variant="add" icon="+">
                                დამატება
                            </x-ui-button>

                            <x-ui-button :href="route('projects.show', $project)" variant="open">
                                გაუქმება
                            </x-ui-button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</x-app-layout>

<script>
    function tyCreate(payload) {
        return {
            governingBodies: payload.governingBodies || [],
            regions: payload.regions || [],
            districts: payload.districts || [],
            forests: payload.forests || [],
            quarters: payload.quarters || [],
            liters: payload.liters || [],

            selectedGb: payload.oldGb ? parseInt(payload.oldGb) : null,
            selectedRegion: payload.oldRegion ? parseInt(payload.oldRegion) : null,
            selectedDistrict: payload.oldDistrict ? parseInt(payload.oldDistrict) : null,
            selectedForest: payload.oldForest ? parseInt(payload.oldForest) : null,
            selectedQuarter: payload.oldQuarter ? parseInt(payload.oldQuarter) : null,

            search: '',
            selected: Array.isArray(payload.oldSelected) ? payload.oldSelected.map(x => parseInt(x)) : [],

            filteredRegions: [],
            filteredDistricts: [],
            filteredForests: [],
            filteredQuarters: [],

            init() {
                this.rebuildRegions();
                this.rebuildDistricts();
                this.rebuildForests();
                this.rebuildQuarters();

                if (this.selectedGb && !this.filteredRegions.some(x => x.id === this.selectedRegion)) {
                    this.selectedRegion = null;
                }

                this.rebuildDistricts();

                if (this.selectedRegion && !this.filteredDistricts.some(x => x.id === this.selectedDistrict)) {
                    this.selectedDistrict = null;
                }

                this.rebuildForests();

                if (this.selectedDistrict && !this.filteredForests.some(x => x.id === this.selectedForest)) {
                    this.selectedForest = null;
                }

                this.rebuildQuarters();

                if (this.selectedForest && !this.filteredQuarters.some(x => x.id === this.selectedQuarter)) {
                    this.selectedQuarter = null;
                }
            },

            onGbChange() {
                this.selectedRegion = null;
                this.selectedDistrict = null;
                this.selectedForest = null;
                this.selectedQuarter = null;
                this.search = '';
                this.selected = [];

                this.rebuildRegions();
                this.rebuildDistricts();
                this.rebuildForests();
                this.rebuildQuarters();
            },

            onRegionChange() {
                this.selectedDistrict = null;
                this.selectedForest = null;
                this.selectedQuarter = null;
                this.search = '';
                this.selected = [];

                this.rebuildDistricts();
                this.rebuildForests();
                this.rebuildQuarters();
            },

            onDistrictChange() {
                this.selectedForest = null;
                this.selectedQuarter = null;
                this.search = '';
                this.selected = [];

                this.rebuildForests();
                this.rebuildQuarters();
            },

            onForestChange() {
                this.selectedQuarter = null;
                this.search = '';
                this.selected = [];

                this.rebuildQuarters();
            },

            onQuarterChange() {
                this.selected = [];
            },

            rebuildRegions() {
                if (!this.selectedGb) {
                    this.filteredRegions = [];
                    return;
                }

                this.filteredRegions = this.regions.filter(r =>
                    parseInt(r.governing_body_id) === parseInt(this.selectedGb)
                );
            },

            rebuildDistricts() {
                if (!this.selectedRegion) {
                    this.filteredDistricts = [];
                    return;
                }

                this.filteredDistricts = this.districts.filter(d =>
                    parseInt(d.region_id) === parseInt(this.selectedRegion)
                );
            },

            rebuildForests() {
                if (!this.selectedDistrict) {
                    this.filteredForests = [];
                    return;
                }

                this.filteredForests = this.forests.filter(f =>
                    parseInt(f.forest_district_id) === parseInt(this.selectedDistrict)
                );
            },

            rebuildQuarters() {
                if (!this.selectedForest) {
                    this.filteredQuarters = [];
                    return;
                }

                this.filteredQuarters = this.quarters.filter(q =>
                    parseInt(q.forest_id) === parseInt(this.selectedForest)
                );
            },

            norm(s) {
                return (s || '').toString().toLowerCase().trim();
            },

            selectedQuarterName() {
                const q = this.quarters.find(x => parseInt(x.id) === parseInt(this.selectedQuarter));
                return q ? q.name : '—';
            },

            litersForSelectedQuarter() {
                if (!this.selectedQuarter) return [];
                return this.liters.filter(l => parseInt(l.quarter_id) === parseInt(this.selectedQuarter));
            },

            visibleLiters() {
                const all = this.litersForSelectedQuarter();
                if (!this.search) return all;

                const q = this.norm(this.search);
                return all.filter(it =>
                    this.norm(it.name).includes(q) || String(it.id).includes(q)
                );
            },

            isChecked(id) {
                id = parseInt(id);
                return this.selected.includes(id);
            },

            toggle(id) {
                id = parseInt(id);

                if (this.selected.includes(id)) {
                    this.selected = this.selected.filter(x => x !== id);
                } else {
                    this.selected = [...this.selected, id];
                }
            },

            visibleIds() {
                return this.visibleLiters().map(x => parseInt(x.id));
            },

            allVisibleSelected() {
                const ids = this.visibleIds();
                if (ids.length === 0) return false;
                return ids.every(id => this.selected.includes(id));
            },

            toggleAllVisible() {
                if (!this.selectedQuarter) return;

                const ids = this.visibleIds();
                if (ids.length === 0) return;

                const allSelected = ids.every(id => this.selected.includes(id));

                if (allSelected) {
                    this.selected = this.selected.filter(id => !ids.includes(id));
                } else {
                    const set = new Set(this.selected);
                    ids.forEach(id => set.add(id));
                    this.selected = Array.from(set);
                }
            },

            groupIdsCurrent() {
                return this.visibleIds();
            },

            groupAllSelectedCurrent() {
                const ids = this.groupIdsCurrent();
                if (ids.length === 0) return false;
                return ids.every(id => this.selected.includes(id));
            },

            toggleGroupCurrent() {
                this.toggleAllVisible();
            }
        }
    }
</script>