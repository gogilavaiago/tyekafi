{{-- resources/views/tyekafis/partials/trees_visual.blade.php --}}
<div id="tabTrees" class="space-y-6 hidden">
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900 space-y-8">

            <div class="flex items-center justify-between">
                <div>
                    <div class="text-lg font-semibold">სახეობის დამატება</div>
                    <div class="text-sm text-gray-500">
                        ზედა ბლოკში ირჩევ სახეობებს → ქვემოთ ჩანაწერებში გამოჩნდება მხოლოდ არჩეული სახეობები.
                    </div>
                </div>

            </div>

            @can('perm.edit')
                <div class="border rounded-lg bg-amber-50 p-4">
                    <div>
                        <div class="font-semibold">Excel-იდან იმპორტი</div>
                        <div class="text-sm text-gray-600 mt-1">
                            სვეტები: <span class="font-medium">სახეობა</span>, <span class="font-medium">დიამეტრი</span>
                            და სურვილისამებრ <span class="font-medium">ხარისხი</span>, <span class="font-medium">რაოდენობა</span>, <span class="font-medium">შენიშვნა</span>.
                        </div>
                    </div>

                    <form method="POST"
                          action="{{ route('projects.tyekafis.importTreeRows', [$project, $tyekafi]) }}"
                          enctype="multipart/form-data"
                          class="mt-4 space-y-3">
                        @csrf

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">აირჩიე Excel ფაილი</label>
                            <input type="file"
                                   name="file"
                                   accept=".xlsx,.xls,.csv"
                                   required
                                   class="block w-full text-sm border rounded p-2 bg-white">
                        </div>

                        <div>
                            <button type="submit"
                                    class="inline-flex items-center px-4 py-2 rounded font-medium border"
                                    style="background:#2563eb;color:#ffffff;border-color:#1d4ed8;min-width:190px;justify-content:center;"
                                    onmouseover="this.style.background='#1d4ed8'"
                                    onmouseout="this.style.background='#2563eb'">
                                ატვირთვა / იმპორტი
                            </button>
                        </div>
                    </form>

                    @if($errors->has('file'))
                        <div class="mt-3 text-sm text-red-700">{{ $errors->first('file') }}</div>
                    @endif

                    @if(session('import_errors'))
                        <div class="mt-3 rounded bg-white/70 border border-amber-200 p-3">
                            <div class="font-medium text-sm text-amber-800 mb-2">გამოტოვებული ჩანაწერები</div>
                            <ul class="list-disc pl-5 text-sm text-amber-900 space-y-1 max-h-40 overflow-auto">
                                @foreach((array) session('import_errors') as $importError)
                                    <li>{{ $importError }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                </div>

                <form id="treesForm" method="POST" action="{{ route('projects.tyekafis.updateTreeRows', [$project, $tyekafi]) }}" class="space-y-8">
                    @csrf
                    @method('PUT')

                    <input type="hidden" name="rank_method" id="rankMethodHidden" value="{{ old('rank_method', $rankMethod ?? 'h') }}">

                    <div class="border rounded-lg">
                        <div class="px-4 py-3 border-b bg-gray-50 rounded-t-lg">
                            <div class="flex items-center justify-between gap-3">
                                <div>
                                    <div class="font-semibold">ძირითადი მონაცემები</div>
                                    <div class="text-xs text-gray-500">
                                        სახეობა / საშ. Dt / მეთოდი: H ან მექანიკურად / თანრიგი
                                    </div>
                                </div>

                                <button type="button" id="addAnalysisRow" class="px-4 py-2 bg-gray-200 rounded">
                                    + სახეობის დამატება
                                </button>
                            </div>
                        </div>

                        <div class="p-4 overflow-x-auto">
                            <table class="min-w-full text-sm">
                                <thead class="sticky top-0 bg-gray-100 z-10">
                                    <tr class="border-b text-gray-700">
                                    <th class="text-left py-2 pr-2 w-12">N</th>
                                    <th class="text-left py-2 min-w-[260px]">სახეობა</th>
                                    <th class="text-left py-2 min-w-[130px]">საშ. Dt</th>
                                    <th class="text-left py-2 min-w-[130px]">H</th>
                                    <th class="text-left py-2 min-w-[200px]">თანრიგი გამოთვლით</th>
                                    <th class="text-left py-2 min-w-[220px]">თანრიგი მექანიკურად</th>
                                    <th class="py-2 w-24"></th>
                                </tr>
                                </thead>

                                <tbody id="analysisBody">
                                @php
                                    $summ = $summaries ?? collect();
                                    $ids = $analysisSpeciesIds ?? [];
                                @endphp

                                @if(count($ids) === 0)
                                    <tr class="border-b analysisRow" data-sid="">
                                        <td class="py-2 pr-2 text-gray-500 analysisNo">1</td>
                                        <td class="py-2">
                                            <select class="analysisSpeciesSel border rounded p-2 w-full" name="analysis_species_ids[]">
                                                <option value="">—</option>
                                                @foreach($species as $s)
                                                    <option value="{{ $s->id }}">{{ $s->name }}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td class="py-2">
                                            <span class="avgDtLive text-gray-500" data-sid="">—</span>
                                        </td>
                                        <td class="py-2">
                                            <div class="flex items-center gap-2 mb-1">
                                                <label class="inline-flex items-center gap-1 text-xs text-gray-600">
                                                    <input type="radio" class="methodRadio" value="h">
                                                    H მეთოდი
                                                </label>
                                            </div>
                                            <input type="number" step="0.1" min="0"
                                                   class="border rounded p-2 w-28 analysisSummaryInp heightInp"
                                                   data-field="height_m"
                                                   name=""
                                                   value=""
                                                   placeholder="H"
                                                   disabled>
                                        </td>
                                        <td class="py-2">
                                            <span class="rankOut text-gray-500">—</span>
                                        </td>
                                        <td class="py-2">
                                            <div class="flex items-center gap-2 mb-1">
                                                <label class="inline-flex items-center gap-1 text-xs text-gray-600">
                                                    <input type="radio" class="methodRadio" value="manual">
                                                    თანრიგი მექანიკურად
                                                </label>
                                            </div>
                                            <select class="border rounded p-2 w-48 analysisSummaryInp manualRankSel"
                                                    data-field="manual_rank_num"
                                                    name=""
                                                    disabled>
                                                <option value="">—</option>
                                            </select>
                                        </td>
                                        <td class="py-2 text-right">
                                            <button type="button" class="removeAnalysisRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
                                        </td>
                                    </tr>
                                @else
                                    @foreach($ids as $idx => $sid)
                                        @php $s = $summ->get((int)$sid); @endphp
                                        <tr class="border-b analysisRow" data-sid="{{ (int)$sid }}">
                                            <td class="py-2 pr-2 text-gray-500 analysisNo">{{ $idx + 1 }}</td>
                                            <td class="py-2">
                                                <select class="analysisSpeciesSel border rounded p-2 w-full" name="analysis_species_ids[]">
                                                    <option value="">—</option>
                                                    @foreach($species as $sp)
                                                        <option value="{{ $sp->id }}" @selected((int)$sp->id === (int)$sid)>{{ $sp->name }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td class="py-2">
                                                <span class="avgDtLive text-gray-900" data-sid="{{ (int)$sid }}">
                                                    @if(!is_null($s?->avg_diameter_cm))
                                                        {{ number_format((float)$s->avg_diameter_cm, 0) }}
                                                    @else
                                                        —
                                                    @endif
                                                </span>
                                            </td>
                                            <td class="py-2">
                                                <div class="flex items-center gap-2 mb-1">
                                                    <label class="inline-flex items-center gap-1 text-xs text-gray-600">
                                                        <input type="radio" class="methodRadio" value="h">
                                                        H მეთოდი
                                                    </label>
                                                </div>
                                                <input type="number" step="0.1" min="0"
                                                       class="border rounded p-2 w-28 analysisSummaryInp heightInp"
                                                       data-field="height_m"
                                                       name="summaries[{{ (int)$sid }}][height_m]"
                                                       value="{{ $s?->height_m ?? '' }}"
                                                       placeholder="H">
                                            </td>
                                            <td class="py-2">
                                                <span class="rankOut text-gray-900">{{ $s?->rank?->name ?? '—' }}</span>
                                            </td>
                                            <td class="py-2">
                                                <div class="flex items-center gap-2 mb-1">
                                                    <label class="inline-flex items-center gap-1 text-xs text-gray-600">
                                                        <input type="radio" class="methodRadio" value="manual">
                                                        თანრიგი მექანიკურად
                                                    </label>
                                                </div>
                                                <select class="border rounded p-2 w-48 analysisSummaryInp manualRankSel"
                                                        data-field="manual_rank_num"
                                                        name="summaries[{{ (int)$sid }}][manual_rank_num]"
                                                        data-current="{{ $s?->manual_rank_num ?? '' }}">
                                                    <option value="">—</option>
                                                </select>
                                            </td>
                                            <td class="py-2 text-right">
                                                <button type="button" class="removeAnalysisRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="border rounded-lg">
                        <div class="px-4 py-3 border-b bg-gray-50 rounded-t-lg">
                            <div class="flex items-center justify-between gap-3">
                                <div>
                                    <div class="font-semibold">8 სმ-ზე ნაკლები</div>
                                    <div class="text-xs text-gray-500">სახეობა / რაოდენობა / მოცულობა = რაოდენობა × 0.001</div>
                                </div>

                                <button type="button"
                                        id="addSmallRow"
                                        class="px-4 py-2 rounded text-black"
                                        style="background:#fde68a;"
                                        onmouseover="this.style.background='#fcd34d'"
                                        onmouseout="this.style.background='#fde68a'">
                                    + ჩანაწერის დამატება
                                </button>
                            </div>
                        </div>

                        <div class="p-4 overflow-x-auto">
                            <table class="min-w-full text-sm">
                                <thead class="sticky top-0 bg-gray-100 z-10">
                                    <tr class="border-b text-gray-700">
                                        <th class="text-left py-2 pr-2 w-12">N</th>
                                        <th class="text-left py-2 min-w-[260px]">სახეობა</th>
                                        <th class="text-left py-2 min-w-[160px]">რაოდენობა</th>
                                        <th class="text-left py-2 min-w-[160px]">მოცულობა</th>
                                        <th class="py-2 w-24"></th>
                                    </tr>
                                </thead>

                                <tbody id="smallRowsBody">
                                @foreach(($smallRows ?? collect()) as $i => $smallRow)
                                    @php
                                        $smallQty = is_null($smallRow->quantity) ? '' : (int) $smallRow->quantity;
                                        $smallVolume = $smallQty === '' ? 0 : ((int) $smallQty * 0.001);
                                    @endphp
                                    <tr class="border-b smallRowItem">
                                        <td class="py-2 pr-2 text-gray-500 smallRowNo">{{ $i + 1 }}</td>

                                        <td class="py-2">
                                            <select class="smallSpeciesSel border rounded p-2 w-full"
                                                    name="small_rows[{{ $i }}][tree_species_id]"
                                                    data-current="{{ (int)($smallRow->tree_species_id ?? 0) }}">
                                                <option value="">—</option>
                                                @foreach($species as $s)
                                                    <option value="{{ $s->id }}" @selected((int)$s->id === (int)($smallRow->tree_species_id ?? 0))>{{ $s->name }}</option>
                                                @endforeach
                                            </select>
                                        </td>

                                        <td class="py-2">
                                            <input type="number"
                                                   min="0"
                                                   step="1"
                                                   class="smallQtyInp border rounded p-2 w-full"
                                                   name="small_rows[{{ $i }}][quantity]"
                                                   value="{{ old('small_rows.'.$i.'.quantity', $smallQty) }}"
                                                   placeholder="რაოდენობა">
                                        </td>

                                        <td class="py-2">
                                            <span class="smallVolumeOut">{{ number_format($smallVolume, 3, '.', '') }}</span>
                                        </td>

                                        <td class="py-2 text-right">
                                            <button type="button" class="removeSmallRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="border rounded-lg">
                        <div class="px-4 py-3 border-b bg-gray-50 rounded-t-lg">
                            <div class="flex items-center justify-between gap-3">
                                <div>
                                    <div class="font-semibold">ხეების დამატება</div>
                                    <div class="text-xs text-gray-500">N / სახეობა / ხარისხი (1 ან 2) / დიამეტრი / შენიშვნა</div>
                                </div>

                                
                            </div>
                        </div>

                        <div class="p-4 overflow-x-auto">
                            <table class="min-w-full text-sm">
                                <thead class="sticky top-0 bg-gray-100 z-10">
                                    <tr class="border-b text-gray-700">
                                    <th class="text-left py-2 pr-2 w-12">N</th>
                                    <th class="text-left py-2 min-w-[240px]">სახეობა</th>
                                    <th class="text-left py-2 min-w-[140px]">ხარისხი</th>
                                    <th class="text-left py-2 min-w-[140px]">დიამეტრი</th>
                                    <th class="text-left py-2 min-w-[220px]">შენიშვნა</th>
                                    <th class="py-2 w-24"></th>
                                </tr>
                                </thead>

                                <tbody id="rowsBody">
                                @foreach($rows as $i => $row)
                                    @php
                                        $q = $row->quality;
                                        $q = is_null($q) ? '' : (string)$q;
                                        if (!in_array($q, ['1','2'], true)) $q = '';
                                    @endphp
                                    <tr class="border-b rowItem">
                                        <td class="py-2 pr-2 text-gray-500 rowNo">{{ $i + 1 }}</td>

                                        <td class="py-2">
                                            <select class="speciesSel border rounded p-2 w-full"
                                                    name="rows[{{ $i }}][tree_species_id]"
                                                    data-current="{{ (int)($row->tree_species_id ?? 0) }}">
                                                <option value="">—</option>
                                            </select>
                                        </td>

                                        <td class="py-2">
                                            <select class="qualitySel border rounded p-2 w-full"
                                                    name="rows[{{ $i }}][quality]"
                                                    data-current="{{ $q }}">
                                                <option value="">—</option>
                                                <option value="1" @selected($q === '1')>1</option>
                                                <option value="2" @selected($q === '2')>2</option>
                                            </select>
                                        </td>

                                        <td class="py-2">
                                            <select class="diameterSel border rounded p-2 w-full"
                                                    name="rows[{{ $i }}][diameter_cm]"
                                                    data-current="{{ (int)($row->diameter_cm ?? 0) }}">
                                                <option value="">—</option>
                                            </select>
                                        </td>

                                        <td class="py-2">
                                            <input type="text"
                                                   class="noteInp border rounded p-2 w-full"
                                                   name="rows[{{ $i }}][note]"
                                                   value="{{ old('rows.'.$i.'.note', $row->note ?? '') }}"
                                                   placeholder="შენიშვნა">
                                        </td>

                                        <td class="py-2 text-right">
                                            <button type="button" class="removeRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
                                        </td>

                                        <td class="hidden">
                                            <input type="hidden" class="treesCountInp" name="rows[{{ $i }}][trees_count]" value="{{ $row->trees_count ?: 1 }}">
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>

                            <div class="mt-4">
                                <div class="mb-3 flex flex-wrap gap-2">

    <button type="button"
            class="addRowsBtn px-4 py-2 text-black rounded"
            data-count="1"
            style="background:#facc15;">
        +1 ხე
    </button>

    <button type="button"
            class="addRowsBtn px-4 py-2 text-black rounded"
            data-count="10"
            style="background:#facc15;">
        +10 ხე
    </button>

    <button type="button"
            class="addRowsBtn px-4 py-2 text-black rounded"
            data-count="50"
            style="background:#facc15;">
        +50 ხე
    </button>

    <button type="button"
            class="addRowsBtn px-4 py-2 text-black rounded"
            data-count="100"
            style="background:#facc15;">
        +100 ხე
    </button>

</div>

                                <div class="flex flex-wrap gap-3 items-center">
                                    <div class="text-sm text-gray-500">
                                        შენახვა გამოიყენე ზედა მწვანე ღილაკით.
                                    </div>

                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    @includeIf('tyekafis.partials.trees_visual_results_block')
                </form>
            @endcan
        </div>
    </div>
</div>

<script>
(function () {
    const analysisBody = document.getElementById('analysisBody');
    const rowsBody = document.getElementById('rowsBody');
    const smallRowsBody = document.getElementById('smallRowsBody');
    const addAnalysisRowBtn = document.getElementById('addAnalysisRow');
    const addRowsBtns = document.querySelectorAll('.addRowsBtn');
    const addSmallRowBtn = document.getElementById('addSmallRow');

    const ALL_SPECIES = @json(($species ?? collect())->map(fn($s) => ['id' => (int)$s->id, 'name' => (string)$s->name])->values()->all());
    const RANK_OPTIONS_BY_SPECIES = @json($rankOptionsBySpecies ?? []);
    const GLOBAL_DIAMETERS = [];
for (let d = 8; d <= 300; d += 4) {
    GLOBAL_DIAMETERS.push(d);
}

    let currentRankMethod = (document.getElementById('rankMethodHidden')?.value === 'manual') ? 'manual' : 'h';

    function calcG(d) {
        if (!d || isNaN(d)) return 0;
        return (Math.PI * d * d) / 40000;
    }

    function escapeHtml(str) {
        return String(str || '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function renumberAnalysisRows() {
        analysisBody.querySelectorAll('.analysisRow').forEach((tr, i) => {
            const no = tr.querySelector('.analysisNo');
            if (no) no.textContent = String(i + 1);
        });
    }

    function renumberRawRows() {
        rowsBody.querySelectorAll('.rowItem').forEach((tr, i) => {
            const no = tr.querySelector('.rowNo');
            if (no) no.textContent = String(i + 1);

            const speciesSel = tr.querySelector('.speciesSel');
            const qualitySel = tr.querySelector('.qualitySel');
            const diameterSel = tr.querySelector('.diameterSel');
            const countInp = tr.querySelector('.treesCountInp');
            const noteInp = tr.querySelector('.noteInp');

            if (speciesSel) speciesSel.name = `rows[${i}][tree_species_id]`;
            if (qualitySel) qualitySel.name = `rows[${i}][quality]`;
            if (diameterSel) diameterSel.name = `rows[${i}][diameter_cm]`;
            if (countInp) countInp.name = `rows[${i}][trees_count]`;
            if (noteInp) noteInp.name = `rows[${i}][note]`;
        });
    }

    function renumberSmallRows() {
        if (!smallRowsBody) return;

        smallRowsBody.querySelectorAll('.smallRowItem').forEach((tr, i) => {
            const no = tr.querySelector('.smallRowNo');
            const speciesSel = tr.querySelector('.smallSpeciesSel');
            const qtyInp = tr.querySelector('.smallQtyInp');

            if (no) no.textContent = String(i + 1);
            if (speciesSel) speciesSel.name = `small_rows[${i}][tree_species_id]`;
            if (qtyInp) qtyInp.name = `small_rows[${i}][quantity]`;
        });
    }

    function bindSmallRow(tr) {
        const removeBtn = tr.querySelector('.removeSmallRow');
        const speciesSel = tr.querySelector('.smallSpeciesSel');
        const qtyInp = tr.querySelector('.smallQtyInp');
        const volumeOut = tr.querySelector('.smallVolumeOut');

        function updateSmallVolume() {
            const qty = parseInt(qtyInp?.value || 0, 10);
            const volume = Number.isFinite(qty) && qty > 0 ? qty * 0.001 : 0;
            if (volumeOut) volumeOut.textContent = volume.toFixed(3);
        }

        speciesSel?.addEventListener('change', () => {
            speciesSel.setAttribute('data-current', speciesSel.value || '');
        });

        qtyInp?.addEventListener('input', () => {
            if (qtyInp.value === '') {
                updateSmallVolume();
                return;
            }
            const v = parseInt(qtyInp.value, 10);
            if (!Number.isFinite(v) || v < 0) {
                qtyInp.value = '';
            }
            updateSmallVolume();
        });

        removeBtn?.addEventListener('click', () => {
            const rows = smallRowsBody.querySelectorAll('.smallRowItem');
            if (rows.length <= 1) {
                if (speciesSel) speciesSel.value = '';
                if (qtyInp) qtyInp.value = '';
                updateSmallVolume();
                return;
            }
            tr.remove();
            renumberSmallRows();
        });

        updateSmallVolume();
    }

    function createSmallRow() {
        if (!smallRowsBody) return;

        const tr = document.createElement('tr');
        tr.className = 'border-b smallRowItem';
        tr.innerHTML = `
            <td class="py-2 pr-2 text-gray-500 smallRowNo"></td>
            <td class="py-2">
                <select class="smallSpeciesSel border rounded p-2 w-full" data-current="">
                    <option value="">—</option>
                    ${ALL_SPECIES.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join('')}
                </select>
            </td>
            <td class="py-2">
                <input type="number" min="0" step="1" class="smallQtyInp border rounded p-2 w-full" value="" placeholder="რაოდენობა">
            </td>
            <td class="py-2">
                <span class="smallVolumeOut">0.000</span>
            </td>
            <td class="py-2 text-right">
                <button type="button" class="removeSmallRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
            </td>
        `;
        smallRowsBody.appendChild(tr);
        bindSmallRow(tr);
        renumberSmallRows();
    }

    function buildRawSpeciesOptionsHtml(allowedIds) {
        const set = new Set(allowedIds.map(Number));
        let html = `<option value="">—</option>`;
        ALL_SPECIES.forEach(s => {
            if (set.has(Number(s.id))) {
                html += `<option value="${s.id}">${escapeHtml(s.name)}</option>`;
            }
        });
        return html;
    }

    function getSelectedAnalysisIds() {
        const ids = [];
        analysisBody.querySelectorAll('select.analysisSpeciesSel').forEach(sel => {
            const v = Number(sel.value);
            if (Number.isFinite(v) && v > 0) ids.push(v);
        });
        return Array.from(new Set(ids));
    }

    function fillManualRankSelect(sel, speciesId, current) {
        sel.innerHTML = '<option value="">—</option>';
        const sid = Number(speciesId || 0);
        if (!Number.isFinite(sid) || sid <= 0) return;

        const ranks = RANK_OPTIONS_BY_SPECIES[sid] || [];
        const cur = String(current || sel.getAttribute('data-current') || '').trim();

        ranks.forEach(r => {
            const opt = document.createElement('option');
            opt.value = String(r);
            opt.textContent = String(r);
            if (cur && String(r) === cur) opt.selected = true;
            sel.appendChild(opt);
        });
    }

    function fillDiameterSelect(sel, speciesId, current) {
        sel.innerHTML = '<option value="">—</option>';

        const sid = Number(speciesId || 0);
        if (!Number.isFinite(sid) || sid <= 0) return;

        const cur = String(current || sel.getAttribute('data-current') || '').trim();

        GLOBAL_DIAMETERS.forEach(d => {
            const opt = document.createElement('option');
            opt.value = String(d);
            opt.textContent = String(d);
            if (cur && String(d) === cur) opt.selected = true;
            sel.appendChild(opt);
        });
    }

    function applyRankMethodToRow(tr) {
        const heightInp = tr.querySelector('.heightInp');
        const manualSel = tr.querySelector('.manualRankSel');
        const radios = tr.querySelectorAll('input.methodRadio');

        radios.forEach(r => r.checked = (r.value === currentRankMethod));

        if (currentRankMethod === 'manual') {
            if (heightInp) {
                heightInp.value = '';
                heightInp.setAttribute('disabled', 'disabled');
            }
            if (manualSel) manualSel.removeAttribute('disabled');
        } else {
            if (manualSel) {
                manualSel.value = '';
                manualSel.setAttribute('disabled', 'disabled');
            }
            if (heightInp) heightInp.removeAttribute('disabled');
        }

        const hidden = document.getElementById('rankMethodHidden');
        if (hidden) hidden.value = currentRankMethod;
    }

    function applyRankMethodToAll(method) {
        currentRankMethod = (method === 'manual') ? 'manual' : 'h';
        analysisBody.querySelectorAll('.analysisRow').forEach(tr => applyRankMethodToRow(tr));
    }

    function syncAnalysisRowSummaryInputs(tr, newSid) {
        const sid = Number(newSid || 0);
        tr.setAttribute('data-sid', sid > 0 ? String(sid) : '');

        tr.querySelectorAll('.analysisSummaryInp').forEach(inp => {
            const field = inp.getAttribute('data-field') || '';
            if (!field) return;

            if (sid > 0) inp.setAttribute('name', `summaries[${sid}][${field}]`);
            else inp.setAttribute('name', '');
        });

        const manualSel = tr.querySelector('.manualRankSel');
        if (manualSel) fillManualRankSelect(manualSel, sid, manualSel.getAttribute('data-current') || manualSel.value);

        if (sid > 0) applyRankMethodToRow(tr);
    }

    function updateRawSpeciesDropdowns() {
        const allowed = getSelectedAnalysisIds();
        const optionsHtml = buildRawSpeciesOptionsHtml(allowed);

        rowsBody.querySelectorAll('tr.rowItem').forEach(tr => {
            const speciesSel = tr.querySelector('select.speciesSel');
            const diameterSel = tr.querySelector('select.diameterSel');
            const qualitySel = tr.querySelector('select.qualitySel');

            if (!speciesSel) return;

            const currentSpecies = Number(speciesSel.getAttribute('data-current') || speciesSel.value || 0);

            speciesSel.innerHTML = optionsHtml;

            if (allowed.includes(currentSpecies)) {
                speciesSel.value = String(currentSpecies);
                speciesSel.setAttribute('data-current', String(currentSpecies));
            } else {
                speciesSel.value = '';
                speciesSel.setAttribute('data-current', '');
            }

            fillDiameterSelect(
                diameterSel,
                speciesSel.value,
                diameterSel?.getAttribute('data-current') || diameterSel?.value || ''
            );

            if (!speciesSel.value) {
                if (diameterSel) {
                    diameterSel.value = '';
                    diameterSel.setAttribute('data-current', '');
                }
                if (qualitySel) qualitySel.value = '';
            }
        });
    }

    function bindAnalysisRow(tr) {
        const sel = tr.querySelector('.analysisSpeciesSel');
        const removeBtn = tr.querySelector('.removeAnalysisRow');

        if (sel) syncAnalysisRowSummaryInputs(tr, sel.value);

        sel?.addEventListener('change', () => {
            syncAnalysisRowSummaryInputs(tr, sel.value);
            updateRawSpeciesDropdowns();
        });

        tr.querySelectorAll('.methodRadio').forEach(r => {
            r.addEventListener('change', () => {
                if (r.checked) applyRankMethodToAll(r.value);
            });
        });

        const manualSel = tr.querySelector('.manualRankSel');
        manualSel?.addEventListener('change', () => {
            manualSel.setAttribute('data-current', manualSel.value);

            if ((manualSel.value || '').trim() !== '') {
                applyRankMethodToAll('manual');
            }
        });

        const heightInp = tr.querySelector('.heightInp');
        heightInp?.addEventListener('input', () => {
            if ((heightInp.value || '').trim() !== '') {
                applyRankMethodToAll('h');
            }
        });

        removeBtn?.addEventListener('click', () => {
            const rows = analysisBody.querySelectorAll('.analysisRow');
            if (rows.length <= 1) {
                alert('მინიმუმ 1 სახეობა უნდა დარჩეს.');
                return;
            }
            tr.remove();
            renumberAnalysisRows();
            updateRawSpeciesDropdowns();
        });
    }

    function bindRawRow(tr) {
        const speciesSel = tr.querySelector('.speciesSel');
        const diameterSel = tr.querySelector('.diameterSel');
        const qualitySel = tr.querySelector('.qualitySel');
        const removeBtn = tr.querySelector('.removeRow');

        speciesSel?.addEventListener('change', () => {
            speciesSel.setAttribute('data-current', speciesSel.value || '');
            if (diameterSel) {
                diameterSel.setAttribute('data-current', '');
                fillDiameterSelect(diameterSel, speciesSel.value, '');
            }
            if (qualitySel && !speciesSel.value) qualitySel.value = '';
        });

        diameterSel?.addEventListener('change', () => {
            diameterSel.setAttribute('data-current', diameterSel.value || '');
        });

        qualitySel?.addEventListener('change', () => {
            qualitySel.setAttribute('data-current', qualitySel.value || '');
        });

        removeBtn?.addEventListener('click', () => {
            const rows = rowsBody.querySelectorAll('.rowItem');
            if (rows.length <= 1) {
                alert('მინიმუმ 1 სტრიქონი უნდა დარჩეს.');
                return;
            }
            tr.remove();
            renumberRawRows();
        });

        if (speciesSel && diameterSel) {
            fillDiameterSelect(
                diameterSel,
                speciesSel.getAttribute('data-current') || speciesSel.value || '',
                diameterSel.getAttribute('data-current') || diameterSel.value || ''
            );
        }

    }

    function createAnalysisRow() {
        const tr = document.createElement('tr');
        tr.className = 'border-b analysisRow';
        tr.setAttribute('data-sid', '');
        tr.innerHTML = `
            <td class="py-2 pr-2 text-gray-500 analysisNo"></td>
            <td class="py-2">
                <select class="analysisSpeciesSel border rounded p-2 w-full" name="analysis_species_ids[]">
                    <option value="">—</option>
                    ${ALL_SPECIES.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join('')}
                </select>
            </td>
            <td class="py-2">
                <span class="avgDtLive text-gray-500" data-sid="">—</span>
            </td>
            <td class="py-2">
                <div class="flex items-center gap-2 mb-1">
                    <label class="inline-flex items-center gap-1 text-xs text-gray-600">
                        <input type="radio" class="methodRadio" value="h">
                        H მეთოდი
                    </label>
                </div>
                <input type="number" step="0.1" min="0"
                       class="border rounded p-2 w-28 analysisSummaryInp heightInp"
                       data-field="height_m"
                       name=""
                       value=""
                       placeholder="H">
            </td>
            <td class="py-2">
                <span class="rankOut text-gray-500">—</span>
            </td>
            <td class="py-2">
                <div class="flex items-center gap-2 mb-1">
                    <label class="inline-flex items-center gap-1 text-xs text-gray-600">
                        <input type="radio" class="methodRadio" value="manual">
                        თანრიგი მექანიკურად
                    </label>
                </div>
                <select class="border rounded p-2 w-48 analysisSummaryInp manualRankSel"
                        data-field="manual_rank_num"
                        name="">
                    <option value="">—</option>
                </select>
            </td>
            <td class="py-2 text-right">
                <button type="button" class="removeAnalysisRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
            </td>
        `;
        analysisBody.appendChild(tr);
        bindAnalysisRow(tr);
        renumberAnalysisRows();
        applyRankMethodToRow(tr);
        updateRawSpeciesDropdowns();
    }

    function createRawRow() {
        const lastRow = rowsBody.querySelector('tr.rowItem:last-child');
        const lastSpecies = lastRow?.querySelector('.speciesSel')?.value || lastRow?.querySelector('.speciesSel')?.getAttribute('data-current') || '';
        const lastQuality = lastRow?.querySelector('.qualitySel')?.value || lastRow?.querySelector('.qualitySel')?.getAttribute('data-current') || '';

        const tr = document.createElement('tr');
        tr.className = 'border-b rowItem';
        tr.innerHTML = `
            <td class="py-2 pr-2 text-gray-500 rowNo"></td>
            <td class="py-2">
                <select class="speciesSel border rounded p-2 w-full" data-current="${escapeHtml(lastSpecies)}">
                    <option value="">—</option>
                </select>
            </td>
            <td class="py-2">
                <select class="qualitySel border rounded p-2 w-full" data-current="${escapeHtml(lastQuality)}">
                    <option value="">—</option>
                    <option value="1" ${String(lastQuality) === '1' ? 'selected' : ''}>1</option>
                    <option value="2" ${String(lastQuality) === '2' ? 'selected' : ''}>2</option>
                </select>
            </td>
            <td class="py-2">
                <select class="diameterSel border rounded p-2 w-full" data-current="">
                    <option value="">—</option>
                </select>
            </td>
            <td class="py-2">
                <input type="text"
                       class="noteInp border rounded p-2 w-full"
                       value=""
                       placeholder="შენიშვნა">
            </td>
            <td class="py-2 text-right">
                <button type="button" class="removeRow px-3 py-1 bg-red-600 text-white rounded">წაშლა</button>
            </td>
            <td class="hidden">
                <input type="hidden" class="treesCountInp" value="1">
            </td>
        `;
        rowsBody.appendChild(tr);
        bindRawRow(tr);
        renumberRawRows();
        updateRawSpeciesDropdowns();

        const speciesSel = tr.querySelector('.speciesSel');
        const qualitySel = tr.querySelector('.qualitySel');

        if (speciesSel && lastSpecies) {
            speciesSel.value = String(lastSpecies);
            speciesSel.setAttribute('data-current', String(lastSpecies));
        }
        if (qualitySel && lastQuality) {
            qualitySel.value = String(lastQuality);
            qualitySel.setAttribute('data-current', String(lastQuality));
        }

        const diameterSel = tr.querySelector('.diameterSel');
        if (diameterSel && speciesSel) {
            fillDiameterSelect(diameterSel, speciesSel.value, '');
            diameterSel.value = '';
            diameterSel.setAttribute('data-current', '');
        }

    }

    analysisBody.querySelectorAll('.analysisRow').forEach(tr => bindAnalysisRow(tr));
    rowsBody.querySelectorAll('.rowItem').forEach(tr => bindRawRow(tr));

    addAnalysisRowBtn?.addEventListener('click', createAnalysisRow);
    if (addSmallRowBtn) {
        addSmallRowBtn.addEventListener('click', createSmallRow);
    }

    smallRowsBody?.querySelectorAll('.smallRowItem').forEach(bindSmallRow);

    addRowsBtns.forEach(btn => {
    btn.addEventListener('click', () => {

        const count = parseInt(btn.dataset.count);

        for (let i = 0; i < count; i++) {
            createRawRow();
        }

    });
});

    applyRankMethodToAll(currentRankMethod);
    renumberAnalysisRows();
    renumberRawRows();
    updateRawSpeciesDropdowns();
})();
</script>