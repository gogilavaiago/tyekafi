{{-- resources/views/tyekafis/partials/trees_visual_results_block.blade.php --}}

@php
    use App\Models\TariffSpeciesMapping;
    use App\Models\TariffValue;

    $rowsCollection = collect($rows ?? []);
    $summariesCollection = $summaries instanceof \Illuminate\Support\Collection ? $summaries : collect($summaries ?? []);
    $speciesCollection = collect($species ?? []);

    $speciesNameById = $speciesCollection
        ->keyBy('id')
        ->map(fn ($s) => (string) $s->name);

    $speciesRedListById = $speciesCollection
        ->keyBy('id')
        ->map(function ($s) {
            $value = trim((string) ($s->red_list ?? ''));
            return in_array(mb_strtolower($value, 'UTF-8'), ['1', 'true', 'yes', 'y', 'red', 'red list', 'წითელი ნუსხა'], true);
        });

    /**
     * Standard tariff lookup by species + actual Dt,
     * using saved summary method:
     * - h => nearest dt + height band
     * - manual => nearest dt + selected manual rank
     */
    $getStandardTariffForSpeciesDt = function (int $speciesId, int $dt) use ($speciesNameById, $summariesCollection) {
        $speciesName = $speciesNameById[$speciesId] ?? null;
        if (!$speciesName || $dt <= 0) {
            return null;
        }

        $mapping = TariffSpeciesMapping::query()
            ->where('species_name', $speciesName)
            ->first();

        if (!$mapping) {
            return null;
        }

        $tariffTableId = (int) $mapping->tariff_table_id;

        $summary = $summariesCollection->get($speciesId);

        $rankMethod = $summary?->rank_method;
        $rankMethod = ($rankMethod === '' || is_null($rankMethod)) ? 'h' : (string) $rankMethod;
        if (!in_array($rankMethod, ['h', 'manual'], true)) {
            $rankMethod = 'h';
        }

        $height = $summary?->height_m;
        $height = ($height === '' || is_null($height)) ? null : (float) $height;

        $manualRankNum = null;
        if ($summary && $summary->relationLoaded('rank') && $summary->rank && !is_null($summary->rank->rank_num)) {
            $manualRankNum = (int) $summary->rank->rank_num;
        } elseif (!is_null($summary?->manual_rank_num) && is_numeric($summary->manual_rank_num)) {
            $manualRankNum = (int) $summary->manual_rank_num;
        }

        $canCalc =
            ($rankMethod === 'h' && !is_null($height) && $height > 0)
            || ($rankMethod === 'manual' && !is_null($manualRankNum) && $manualRankNum > 0);

        if (!$canCalc) {
            return null;
        }

        $nearestDt = TariffValue::query()
            ->where('tariff_table_id', $tariffTableId)
            ->select('dt_cm')
            ->distinct()
            ->orderByRaw('ABS(CAST(dt_cm AS SIGNED) - ?) asc', [$dt])
            ->value('dt_cm');

        if (is_null($nearestDt)) {
            return null;
        }

        $tvQuery = TariffValue::query()
            ->where('tariff_table_id', $tariffTableId)
            ->where('dt_cm', (int) $nearestDt);

        if ($rankMethod === 'h') {
            $tvQuery = $tvQuery
                ->where(function ($q) use ($height) {
                    $q->whereNull('h_min_m')->orWhere('h_min_m', '<=', $height);
                })
                ->where(function ($q) use ($height) {
                    $q->whereNull('h_max_m')->orWhere('h_max_m', '>=', $height);
                })
                ->orderByRaw('COALESCE(h_min_m, -999) desc');
        } else {
            $tvQuery = $tvQuery
                ->where('rank', (int) $manualRankNum)
                ->orderByRaw('COALESCE(h_min_m, -999) desc');
        }

        return $tvQuery->first();
    };

    /*
    |--------------------------------------------------------------------------
    | 1 blok
    | თითო შეყვანილი ხე ცალკე ხაზად
    | თუ trees_count = 5 => 5 ცალკე ჩანაწერი
    |--------------------------------------------------------------------------
    */
    $block1Rows = collect();

    foreach ($rowsCollection as $sourceRow) {
        $speciesId = (int) ($sourceRow->tree_species_id ?? 0);
        $dt = (int) round((float) ($sourceRow->diameter_cm ?? 0));

        if ($speciesId <= 0 || $dt <= 0) {
            continue;
        }

        $speciesName = $speciesNameById[$speciesId] ?? '—';

        $count = (int) ($sourceRow->trees_count ?? 1);
        if ($count < 1) {
            $count = 1;
        }

        $quality = is_null($sourceRow->quality) || $sourceRow->quality === ''
            ? '—'
            : (string) $sourceRow->quality;

        $tv = $getStandardTariffForSpeciesDt($speciesId, $dt);

        $perLiquid = !is_null($tv?->liquid_m3) ? (float) $tv->liquid_m3 : 0.0;
        $perFirewood = !is_null($tv?->crown_firewood_m3) ? (float) $tv->crown_firewood_m3 : 0.0;
        $perTotal = $perLiquid + $perFirewood;

        $manualNote = trim((string) ($sourceRow->note ?? ''));
        $isRedList = (bool) ($speciesRedListById[$speciesId] ?? false);

        $noteLines = [];
        if ($isRedList) {
            $noteLines[] = 'წითელი ნუსხა';
        }
        if ($manualNote !== '') {
            $noteLines[] = $manualNote;
        }

        $finalNote = implode("\n", $noteLines);

        for ($i = 0; $i < $count; $i++) {
            $q1Liquid = $quality === '1' ? $perLiquid : 0.0;
            $q1Firewood = $quality === '1' ? $perFirewood : 0.0;
            $q1Total = $quality === '1' ? $perTotal : 0.0;

            $q2Liquid = $quality === '2' ? $perLiquid : 0.0;
            $q2Firewood = $quality === '2' ? $perFirewood : 0.0;
            $q2Total = $quality === '2' ? $perTotal : 0.0;

            $grandTotal = $q1Total + $q2Total;

            $block1Rows->push([
                'species' => $speciesName,
                'dt' => $dt,
                'quality' => $quality,
                'q1_liquid' => $q1Liquid,
                'q1_firewood' => $q1Firewood,
                'q1_total' => $q1Total,
                'q2_liquid' => $q2Liquid,
                'q2_firewood' => $q2Firewood,
                'q2_total' => $q2Total,
                'grand_total' => $grandTotal,
                'note' => $finalNote,
            ]);
        }
    }

    $block1Rows = $block1Rows
        ->values()
        ->map(function ($r, $i) {
            $r['n'] = $i + 1;
            return $r;
        });

    $block1Totals = [
        'q1_liquid' => $block1Rows->sum(fn ($r) => (float) ($r['q1_liquid'] ?? 0)),
        'q1_firewood' => $block1Rows->sum(fn ($r) => (float) ($r['q1_firewood'] ?? 0)),
        'q1_total' => $block1Rows->sum(fn ($r) => (float) ($r['q1_total'] ?? 0)),
        'q2_liquid' => $block1Rows->sum(fn ($r) => (float) ($r['q2_liquid'] ?? 0)),
        'q2_firewood' => $block1Rows->sum(fn ($r) => (float) ($r['q2_firewood'] ?? 0)),
        'q2_total' => $block1Rows->sum(fn ($r) => (float) ($r['q2_total'] ?? 0)),
        'grand_total' => $block1Rows->sum(fn ($r) => (float) ($r['grand_total'] ?? 0)),
    ];

    /*
    |--------------------------------------------------------------------------
    | 2 blok
    | species + Dt + quality მიხედვით
    |--------------------------------------------------------------------------
    */
    $block2Rows = $rowsCollection
        ->filter(function ($r) {
            return !is_null($r->tree_species_id)
                && !is_null($r->diameter_cm)
                && (float) $r->diameter_cm > 0;
        })
        ->groupBy(function ($r) {
            $sid = (int) $r->tree_species_id;
            $dt = (int) round((float) $r->diameter_cm);
            $q = is_null($r->quality) || $r->quality === '' ? '—' : (string) $r->quality;
            return $sid . '|' . $dt . '|' . $q;
        })
        ->map(function ($group) use ($speciesNameById, $getStandardTariffForSpeciesDt) {
            $first = $group->first();

            $speciesId = (int) $first->tree_species_id;
            $speciesName = $speciesNameById[$speciesId] ?? '—';
            $dt = (int) round((float) $first->diameter_cm);
            $quality = is_null($first->quality) || $first->quality === ''
                ? '—'
                : (string) $first->quality;

            $quantity = (int) $group->sum(function ($r) {
                $c = (int) ($r->trees_count ?? 1);
                return $c > 0 ? $c : 1;
            });

            $tv = $getStandardTariffForSpeciesDt($speciesId, $dt);

            $perLiquid = !is_null($tv?->liquid_m3) ? (float) $tv->liquid_m3 : 0.0;
            $perFirewood = !is_null($tv?->crown_firewood_m3) ? (float) $tv->crown_firewood_m3 : 0.0;

            $liquid = $perLiquid * $quantity;
            $firewood = $perFirewood * $quantity;

            $q1Total = $quality === '1' ? ($liquid + $firewood) : 0.0;
            $q2Total = $quality === '2' ? ($liquid + $firewood) : 0.0;
            $grandTotal = $liquid + $firewood;

            return [
                'species' => $speciesName,
                'dt' => $dt,
                'quality' => $quality,
                'quantity' => $quantity,
                'liquid' => $liquid,
                'firewood' => $firewood,
                'q1_total' => $q1Total,
                'q2_total' => $q2Total,
                'grand_total' => $grandTotal,
            ];
        })
        ->sortBy([
            ['species', 'asc'],
            ['dt', 'asc'],
            ['quality', 'asc'],
        ])
        ->values();

    $block2Grouped = $block2Rows->groupBy('species');

    $block2GrandTotals = [
        'quantity' => $block2Rows->sum(fn ($r) => (int) ($r['quantity'] ?? 0)),
        'liquid' => $block2Rows->sum(fn ($r) => (float) ($r['liquid'] ?? 0)),
        'firewood' => $block2Rows->sum(fn ($r) => (float) ($r['firewood'] ?? 0)),
        'q1_total' => $block2Rows->sum(fn ($r) => (float) ($r['q1_total'] ?? 0)),
        'q2_total' => $block2Rows->sum(fn ($r) => (float) ($r['q2_total'] ?? 0)),
        'grand_total' => $block2Rows->sum(fn ($r) => (float) ($r['grand_total'] ?? 0)),
    ];
@endphp

<div class="border rounded-lg">
    <div class="px-4 py-3 border-b bg-gray-50 rounded-t-lg">
        <div class="font-semibold text-center">1 blok</div>
    </div>

    <div class="p-4 overflow-x-auto">
        <table class="min-w-full text-sm border-collapse">
            <thead>
                <tr class="border-b text-gray-700">
                    <th class="border px-2 py-2 text-center">tree N</th>
                    <th class="border px-2 py-2 text-center">species</th>
                    <th class="border px-2 py-2 text-center">Dt</th>
                    <th class="border px-2 py-2 text-center">quality</th>
                    <th class="border px-2 py-2 text-center">1 qualiti licuid</th>
                    <th class="border px-2 py-2 text-center">1 qualiti firewood</th>
                    <th class="border px-2 py-2 text-center">1 ხარისხი ჯამი</th>
                    <th class="border px-2 py-2 text-center">2 qualiti licuid</th>
                    <th class="border px-2 py-2 text-center">2 qualiti firewood</th>
                    <th class="border px-2 py-2 text-center">2 ხარისხი ჯამი</th>
                    <th class="border px-2 py-2 text-center">სულ ჯამი</th>
                    <th class="border px-2 py-2 text-center">Note</th>
                </tr>
            </thead>
            <tbody>
                @forelse($block1Rows as $r)
                    <tr class="border-b">
                        <td class="border px-2 py-2 text-center">{{ $r['n'] }}</td>
                        <td class="border px-2 py-2">{{ $r['species'] }}</td>
                        <td class="border px-2 py-2 text-center">{{ $r['dt'] }}</td>
                        <td class="border px-2 py-2 text-center">{{ $r['quality'] }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q1_liquid'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q1_firewood'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q1_total'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q2_liquid'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q2_firewood'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q2_total'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $r['grand_total'], 4) }}</td>
                        <td class="border px-2 py-2 whitespace-pre-line break-words min-w-[140px]">{{ $r['note'] }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="12" class="border px-2 py-3 text-center text-gray-500">მონაცემები არ არის.</td>
                    </tr>
                @endforelse
            </tbody>

            @if($block1Rows->count() > 0)
                <tfoot>
                    <tr class="font-semibold border-t bg-gray-50">
                        <td colspan="4" class="border px-2 py-2 text-right">ჯამი</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['q1_liquid'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['q1_firewood'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['q1_total'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['q2_liquid'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['q2_firewood'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['q2_total'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block1Totals['grand_total'], 4) }}</td>
                        <td class="border px-2 py-2"></td>
                    </tr>
                </tfoot>
            @endif
        </table>
    </div>
</div>

<div class="border rounded-lg mt-6">
    <div class="px-4 py-3 border-b bg-gray-50 rounded-t-lg">
        <div class="font-semibold text-center">2 blok</div>
    </div>

    <div class="p-4 overflow-x-auto">
        <table class="min-w-full text-sm border-collapse">
            <thead>
                <tr class="border-b text-gray-700">
                    <th class="border px-2 py-2 text-center">species</th>
                    <th class="border px-2 py-2 text-center">Dt</th>
                    <th class="border px-2 py-2 text-center">qualiti</th>
                    <th class="border px-2 py-2 text-center">Quantity</th>
                    <th class="border px-2 py-2 text-center">licuid</th>
                    <th class="border px-2 py-2 text-center">firewood</th>
                    <th class="border px-2 py-2 text-center">1 ხარისხი ჯამი</th>
                    <th class="border px-2 py-2 text-center">2 ხარისხი ჯამი</th>
                    <th class="border px-2 py-2 text-center">სულ ჯამი</th>
                </tr>
            </thead>
            <tbody>
                @forelse($block2Grouped as $speciesName => $speciesRows)
                    @foreach($speciesRows as $r)
                        <tr class="border-b">
                            <td class="border px-2 py-2">{{ $r['species'] }}</td>
                            <td class="border px-2 py-2 text-center">{{ $r['dt'] }}</td>
                            <td class="border px-2 py-2 text-center">{{ $r['quality'] }}</td>
                            <td class="border px-2 py-2 text-center">{{ $r['quantity'] }}</td>
                            <td class="border px-2 py-2 text-right">{{ number_format((float) $r['liquid'], 4) }}</td>
                            <td class="border px-2 py-2 text-right">{{ number_format((float) $r['firewood'], 4) }}</td>
                            <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q1_total'], 4) }}</td>
                            <td class="border px-2 py-2 text-right">{{ number_format((float) $r['q2_total'], 4) }}</td>
                            <td class="border px-2 py-2 text-right">{{ number_format((float) $r['grand_total'], 4) }}</td>
                        </tr>
                    @endforeach

                    @php
                        $speciesQtyTotal = $speciesRows->sum(fn ($r) => (int) ($r['quantity'] ?? 0));
                        $speciesLiquidTotal = $speciesRows->sum(fn ($r) => (float) ($r['liquid'] ?? 0));
                        $speciesFirewoodTotal = $speciesRows->sum(fn ($r) => (float) ($r['firewood'] ?? 0));
                        $speciesQ1Total = $speciesRows->sum(fn ($r) => (float) ($r['q1_total'] ?? 0));
                        $speciesQ2Total = $speciesRows->sum(fn ($r) => (float) ($r['q2_total'] ?? 0));
                        $speciesGrandTotal = $speciesRows->sum(fn ($r) => (float) ($r['grand_total'] ?? 0));
                    @endphp

                    <tr class="bg-gray-50 font-semibold border-b">
                        <td colspan="3" class="border px-2 py-2 text-right">ჯამი სახეობის მიხედვით — {{ $speciesName }}</td>
                        <td class="border px-2 py-2 text-center">{{ $speciesQtyTotal }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $speciesLiquidTotal, 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $speciesFirewoodTotal, 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $speciesQ1Total, 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $speciesQ2Total, 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $speciesGrandTotal, 4) }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="border px-2 py-3 text-center text-gray-500">მონაცემები არ არის.</td>
                    </tr>
                @endforelse
            </tbody>

            @if($block2Rows->count() > 0)
                <tfoot>
                    <tr class="font-bold border-t bg-gray-100">
                        <td colspan="3" class="border px-2 py-2 text-right">მთლიანი ჯამი</td>
                        <td class="border px-2 py-2 text-center">{{ $block2GrandTotals['quantity'] }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block2GrandTotals['liquid'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block2GrandTotals['firewood'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block2GrandTotals['q1_total'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block2GrandTotals['q2_total'], 4) }}</td>
                        <td class="border px-2 py-2 text-right">{{ number_format((float) $block2GrandTotals['grand_total'], 4) }}</td>
                    </tr>
                </tfoot>
            @endif
        </table>
    </div>
</div>
