<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    ტყეკაფები — პროექტი: {{ $project->name }}
                </h2>
                <div class="text-sm text-gray-500 mt-1">
                    პროექტის ID: #{{ $project->id }}
                </div>
            </div>

            <div class="flex gap-2">
                <a href="{{ route('projects.show', $project) }}" class="px-4 py-2 bg-gray-200 rounded">
                    პროექტზე დაბრუნება
                </a>

                @can('perm.edit')
                    <a href="{{ route('projects.tyekafis.create', $project) }}"
                       class="inline-flex items-center px-4 py-2 bg-gray-800 text-white rounded">
                        + ტყეკაფის შექმნა
                    </a>
                @endcan
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('status'))
                <div class="mb-4 p-3 bg-green-100 rounded">
                    {{ session('status') }}
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 overflow-x-auto">

                    @if ($tyekafis->count() === 0)
                        <div class="text-gray-600">
                            ჯერ ტყეკაფი არ გაქვს შექმნილი.
                        </div>
                    @else
                        <table class="min-w-full text-sm">
                            <thead>
                                <tr class="border-b">
                                    <th class="text-left py-2">ID</th>
                                    <th class="text-left py-2">ტყეკაფი / რეგიონი</th>
                                    <th class="text-left py-2">შექმნის თარიღი</th>
                                    <th class="text-left py-2">ქმედება</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($tyekafis as $t)
                                    <tr class="border-b align-top">
                                        <td class="py-3">{{ $t->id }}</td>

                                        <td class="py-3 font-medium">
                                            <a class="underline" href="{{ route('projects.tyekafis.show', [$project, $t]) }}">
                                                {{ $t->name }}
                                            </a>

                                            <div class="text-xs text-gray-500 mt-1">
                                                რეგიონი:
                                                {{ $t->forestDistrict->governingBody->name ?? '-' }}
                                            </div>
                                        </td>

                                        <td class="py-3 text-gray-600">
                                            {{ $t->created_at->format('Y-m-d H:i') }}
                                        </td>

                                        <td class="py-3">
                                            <div class="flex items-center gap-2">
                                                <a href="{{ route('projects.tyekafis.show', [$project, $t]) }}" class="px-3 py-1 bg-gray-200 rounded">
                                                    Open
                                                </a>

                                                @can('perm.edit')
                                                    <form method="POST" action="{{ route('projects.tyekafis.destroy', [$project, $t]) }}"
                                                          onsubmit="return confirm('წავშალო Tyekafi?');">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button class="px-3 py-1 bg-red-600 text-white rounded">
                                                            წაშლა
                                                        </button>
                                                    </form>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                        <div class="mt-4">
                            {{ $tyekafis->links() }}
                        </div>
                    @endif

                </div>
            </div>

        </div>
    </div>
</x-app-layout>