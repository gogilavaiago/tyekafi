<x-app-layout>
    <x-slot name="header">
    <div class="flex items-center justify-between">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            ტყეკაფი — {{ $tyekafi->name }}
        </h2>

        <div class="flex gap-2 items-center flex-wrap">
            <a href="{{ route('projects.tyekafis.index', $project) }}"
               style="display:inline-block;padding:10px 16px;background:#e5e7eb;color:#111827;text-decoration:none;border-radius:6px;font-weight:600;border:1px solid #d1d5db;">
                ტყეკაფების სია
            </a>

            <a href="{{ route('projects.show', $project) }}"
               style="display:inline-block;padding:10px 16px;background:#e5e7eb;color:#111827;text-decoration:none;border-radius:6px;font-weight:600;border:1px solid #d1d5db;">
                პროექტზე დაბრუნება
            </a>

            <div class="relative inline-block text-left" id="reportsDropdownWrap">
                <button
                    type="button"
                    id="reportsDropdownBtn"
                    style="display:inline-flex;align-items:center;gap:8px;padding:10px 16px;background:#2563eb;color:#ffffff;border-radius:6px;font-weight:700;border:1px solid #1d4ed8;"
                >
                    📄 რეპორტები
                    <span style="font-size:12px;">▼</span>
                </button>

                <div
                    id="reportsDropdownMenu"
                    style="display:none;position:absolute;right:0;top:calc(100% + 6px);min-width:240px;background:#ffffff;border:1px solid #d1d5db;border-radius:8px;box-shadow:0 10px 25px rgba(0,0,0,0.12);padding:6px;z-index:50;"
                >
                    <a href="{{ route('projects.tyekafis.reportPdfN1', [$project, $tyekafi]) }}"
                       target="_blank"
                       style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                        📄 დანართი N1
                    </a>

                    <a href="{{ route('projects.tyekafis.reportPdfN11', [$project, $tyekafi]) }}"
                       target="_blank"
                       style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                        📄 დანართი N11
                    </a>

                    <div class="relative" id="compensationSubmenuWrap">
                        <button
                            type="button"
                            id="compensationSubmenuBtn"
                            style="display:flex;align-items:center;justify-content:space-between;width:100%;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;border:none;cursor:pointer;"
                        >
                            <span>💰 კომპენსაცია</span>
                            <span style="font-size:12px;">▶</span>
                        </button>

                        <div
                            id="compensationSubmenu"
                            style="display:none;position:absolute;left:calc(100% + 6px);top:0;min-width:140px;background:#ffffff;border:1px solid #d1d5db;border-radius:8px;box-shadow:0 10px 25px rgba(0,0,0,0.12);padding:6px;z-index:60;"
                        >
                            <a href="{{ route('projects.tyekafis.reportPdfCompensation', [$project, $tyekafi]) }}?years_range=0-5"
                               target="_blank"
                               style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                                0-5
                            </a>

                            <a href="{{ route('projects.tyekafis.reportPdfCompensation', [$project, $tyekafi]) }}?years_range=6-15"
                               target="_blank"
                               style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                                6-15
                            </a>

                            <a href="{{ route('projects.tyekafis.reportPdfCompensation', [$project, $tyekafi]) }}?years_range=16-30"
                               target="_blank"
                               style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                                16-30
                            </a>

                            <a href="{{ route('projects.tyekafis.reportPdfCompensation', [$project, $tyekafi]) }}?years_range=31-49"
                               target="_blank"
                               style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                                31-49
                            </a>
                        </div>
                    </div>

                    <a href="{{ route('projects.tyekafis.reportExcel', [$project, $tyekafi]) }}"
                       style="display:block;padding:10px 12px;border-radius:6px;text-decoration:none;font-weight:600;color:#1f2937;background:#ffffff;">
                        📊 Excel ექსპორტი
                    </a>
                </div>
            </div>
        </div>
    </div>
</x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if (session('status'))
                <div class="p-3 bg-green-100 rounded">
                    {{ session('status') }}
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="text-sm text-gray-500 mb-2">აღწერა</div>
                    <div class="whitespace-pre-wrap">
                        {{ $tyekafi->description ?: '—' }}
                    </div>
                </div>
            </div>

            <div class="sticky top-4 z-30">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                    <div class="p-4 sm:p-6">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                            <div>
                                <div class="text-lg font-semibold text-gray-900">ძირითადი მონაცემები</div>
                                <div class="text-sm text-gray-500">გადააერთე ბლოკებზე ტაბებით</div>
                            </div>

                            <div class="flex flex-wrap gap-2">
                                <button
                                    type="button"
                                    id="tabBtnForm"
                                    class="px-4 py-2 rounded border bg-gray-900 text-white"
                                    aria-selected="true"
                                >
                                    FORM_IN
                                </button>

                                <button
                                    type="button"
                                    id="tabBtnTrees"
                                    class="px-4 py-2 rounded border bg-gray-100 text-gray-800"
                                    aria-selected="false"
                                >
                                    ხეები
                                </button>

                                @can('perm.edit')
                                    <button
                                        type="submit"
                                        id="formSaveBtn"
                                        form="formInForm"
                                        class="inline-flex items-center justify-center min-w-[140px] px-4 py-2 rounded border border-green-700 bg-green-600 text-white font-semibold shadow hover:bg-green-700 transition"
                                    >
                                        შენახვა
                                    </button>
                                @endcan
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="tabFormIn" class="space-y-6">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <div class="flex items-center justify-between mb-4">
                            <div>
                                <div class="text-lg font-semibold">FORM_IN</div>
                                <div class="text-sm text-gray-500"></div>
                            </div>
                        </div>

                        @can('perm.edit')
                            @php
                                $selectedLiterIds = $tyekafi->liters?->pluck('id')->map(fn($v)=> (int)$v)->values() ?? collect();
                            @endphp

                            <form id="formInForm" method="POST" action="{{ route('projects.tyekafis.updateFormIn', [$project, $tyekafi]) }}" class="space-y-6">
                                @csrf
                                @method('PUT')

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">თარიღი</div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ტყეკაფის მონიშვნის დაწყების თარიღი</label>
                                            <input type="date" name="marking_start_date" value="{{ $tyekafi->marking_start_date }}" class="w-full border rounded p-2">
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ტყეკაფის მონიშვნის დასრულების თარიღი</label>
                                            <input type="date" name="marking_end_date" value="{{ $tyekafi->marking_end_date }}" class="w-full border rounded p-2">
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">მართვა / საფუძველი</div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ტყითსარგებლობის საფუძველი</label>
                                            <select name="forest_use_basis" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($forestUseBases as $b)
                                                    <option value="{{ $b->code }}" @selected($tyekafi->forest_use_basis === $b->code)>
                                                        {{ $b->title }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">ტყითმოსარგებლე</div>

                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ტყითმოსარგებლე</label>
                                            <input name="forest_user_name" value="{{ $tyekafi->forest_user_name }}" class="w-full border rounded p-2" placeholder="ტექსტი">
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">საინდენთიფიკაციო კოდი/პირადი ნომერი</label>
                                            <input name="forest_user_id_code" value="{{ $tyekafi->forest_user_id_code }}" class="w-full border rounded p-2" placeholder="ტექსტი">
                                        </div>

                                        <div class="md:col-span-3">
                                            <label class="block text-sm text-gray-600 mb-1">ტყითმოსარგებლის მისამართი</label>
                                            <input name="forest_user_address" value="{{ $tyekafi->forest_user_address }}" class="w-full border rounded p-2" placeholder="ტექსტი">
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">დამისამართება</div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">მართვის ორგანო</label>
                                            <select id="gb" name="governing_body_id" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($governingBodies as $gb)
                                                    <option value="{{ $gb->id }}" @selected($tyekafi->governing_body_id === $gb->id)>
                                                        {{ $gb->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">რეგიონი</label>
                                            <select id="region" name="region_id" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">სატყეო უბანი</label>
                                            <select id="district" name="forest_district_id" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">სატყეო</label>
                                            <select id="forest" name="forest_id" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">კვარტალი (ხელით)</label>
                                            <input type="text" name="manual_quarter" value="{{ old('manual_quarter', $tyekafi->manual_quarter) }}" class="w-full border rounded p-2" placeholder="მაგ: 12">
                                            <div class="text-xs text-gray-500 mt-1">თუ შეავსებ, ყველა რეპორტში ეს მნიშვნელობა გამოჩნდება.</div>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ლიტერი / ლიტერები (ხელით)</label>
                                            <input type="text" name="manual_liters" value="{{ old('manual_liters', $tyekafi->manual_liters) }}" class="w-full border rounded p-2" placeholder="მაგ: 3, 3ა, 4ბ">
                                        </div>

                                        <div class="md:col-span-2">
                                            <label class="block text-sm text-gray-600 mb-1">ფართობი (ჰა)</label>
                                            <input 
                                                type="text" 
                                                name="area_ha" 
                                                value="{{ ($tyekafi->area_ha !== null && $tyekafi->area_ha !== '') ? number_format((float) $tyekafi->area_ha, 4, '.', '') : '' }}"
                                                class="w-full border rounded p-2"
                                                inputmode="decimal"
                                                placeholder="მაგ: 2.6200"
                                            >
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">ჭრის პარამეტრები</div>

                                    <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ჭრის მიზანი</label>
                                            <select name="cut_purpose" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['cut_purpose'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->cut_purpose === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ჭრის სახე</label>
                                            <select name="cut_type" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['cut_type'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->cut_type === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ჭრის %</label>
                                            <select name="cut_percent" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['cut_percent'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->cut_percent === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ს.ზ.დ.</label>
                                            <select name="szd" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['szd'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->szd === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">სიხშირე / მოზარდი</div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">სიხშირე (ფაქტობრივი)</label>
                                            <select name="frequency_actual" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['frequency'] as $opt)
                                                    <option value="{{ $opt }}" @selected((string)$tyekafi->frequency_actual === (string)$opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">სიხშირე (ტყეთმოწყობით)</label>
                                            <select name="frequency_plan" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['frequency'] as $opt)
                                                    <option value="{{ $opt }}" @selected((string)$tyekafi->frequency_plan === (string)$opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">მოზარდ/აღმონაცენის რაოდენობა (ფაქტობრივი)</label>
                                            <input name="regen_count_actual" value="{{ $tyekafi->regen_count_actual }}" class="w-full border rounded p-2" placeholder="ტექსტი">
                                        </div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">მოზარდ/აღმონაცენის რაოდენობა (ტყეთმოწყობით)</label>
                                            <input name="regen_count_plan" value="{{ $tyekafi->regen_count_plan }}" class="w-full border rounded p-2" placeholder="ტექსტი">
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">ხნოვანება / ექსპოზიცია / დაქანება</div>

                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ხნოვანება (ფაქტობრივი)</label>
                                            <select name="age_actual" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['age'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->age_actual === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ხნოვანება (ტყეთმოწყობით)</label>
                                            <select name="age_plan" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['age'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->age_plan === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div></div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ექსპოზიცია (ფაქტობრივი)</label>
                                            <select name="exposure_actual" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['exposure'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->exposure_actual === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">ექსპოზიცია (ტყეთმოწყობით)</label>
                                            <select name="exposure_plan" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['exposure'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->exposure_plan === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div></div>

                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">დაქანება (ფაქტობრივი)</label>
                                            <select name="slope_actual" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['slope'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->slope_actual === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 mb-1">დაქანება (ტყეთმოწყობით)</label>
                                            <select name="slope_plan" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['slope'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->slope_plan === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">GPS</div>

                                    <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">X1</label>
                                    <input
                                     name="gps_x1"
                                     value="{{ old('gps_x1', $tyekafi->gps_x1) }}"
                                     class="w-full border rounded p-2"
                                     inputmode="numeric"
                                     maxlength="6"
                                     pattern="\d{6}"
                                     placeholder="მაგ: 123456"
                                     oninput="this.value = this.value.replace(/\D/g, '').slice(0, 6)">
                                </div>

                                <div>
                                    <label class="block text-sm text-gray-600 mb-1">Y1</label>
                                    <input
                                     name="gps_y1"
                                     value="{{ old('gps_y1', $tyekafi->gps_y1) }}"
                                     class="w-full border rounded p-2"
                                     inputmode="numeric"
                                     maxlength="7"
                                     pattern="\d{7}"
                placeholder="მაგ: 1234567"
                oninput="this.value = this.value.replace(/\D/g, '').slice(0, 7)">
        </div>

        <div>
            <label class="block text-sm text-gray-600 mb-1">X2</label>
            <input
                name="gps_x2"
                value="{{ old('gps_x2', $tyekafi->gps_x2) }}"
                class="w-full border rounded p-2"
                inputmode="numeric"
                maxlength="6"
                pattern="\d{6}"
                placeholder="მაგ: 123456"
                oninput="this.value = this.value.replace(/\D/g, '').slice(0, 6)">
        </div>

        <div>
            <label class="block text-sm text-gray-600 mb-1">Y2</label>
            <input
                name="gps_y2"
                value="{{ old('gps_y2', $tyekafi->gps_y2) }}"
                class="w-full border rounded p-2"
                inputmode="numeric"
                maxlength="7"
                pattern="\d{7}"
                placeholder="მაგ: 1234567"
                oninput="this.value = this.value.replace(/\D/g, '').slice(0, 7)">
        </div>
    </div>

    @error('gps_x1')
        <div class="mt-2 text-sm text-red-600">{{ $message }}</div>
    @enderror
    @error('gps_y1')
        <div class="mt-2 text-sm text-red-600">{{ $message }}</div>
    @enderror
    @error('gps_x2')
        <div class="mt-2 text-sm text-red-600">{{ $message }}</div>
    @enderror
    @error('gps_y2')
        <div class="mt-2 text-sm text-red-600">{{ $message }}</div>
    @enderror
</div>

                                <div class="border rounded p-4">
                                    <div class="font-semibold mb-3">აღრიცხვის მეთოდი</div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div class="md:col-span-2">
                                            <select id="inventory_method" name="inventory_method" class="w-full border rounded p-2">
                                                <option value="">—</option>
                                                @foreach($options['inventory_method'] as $opt)
                                                    <option value="{{ $opt }}" @selected($tyekafi->inventory_method === $opt)>{{ $opt }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div id="sample_plot_fields" class="mt-4">
                                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                            <div>
                                                <label class="block text-sm text-gray-600 mb-1">სანიმუშო ფართობის სახე</label>
                                                <select name="sample_plot_type" class="w-full border rounded p-2">
                                                    <option value="">—</option>
                                                    @foreach($options['sample_plot_type'] as $opt)
                                                        <option value="{{ $opt }}" @selected($tyekafi->sample_plot_type === $opt)>{{ $opt }}</option>
                                                    @endforeach
                                                </select>
                                            </div>

                                            <div>
                                                <label class="block text-sm text-gray-600 mb-1">სანიმუშო ფართობის ფართობი</label>
                                                <input type="number" step="0.0001" name="sample_plot_area" value="{{ $tyekafi->sample_plot_area }}" class="w-full border rounded p-2">
                                            </div>

                                            <div>
                                                <label class="block text-sm text-gray-600 mb-1">გადამრავლების კოეფიციენტი</label>
                                                <input type="number" step="0.0001" name="multiplier_coeff" value="{{ $tyekafi->multiplier_coeff }}" class="w-full border rounded p-2">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="flex flex-col sm:flex-row gap-3">
    <button class="px-4 py-2 bg-gray-800 text-white rounded">
        FORM_IN შენახვა
    </button>

    <button type="button" id="jumpToTrees" class="px-4 py-2 bg-gray-200 rounded">
        შემდეგი: ხეები →
    </button>
</div>
                            </form>
                        @else
                            <div class="text-sm text-gray-600">ფორმის შეცვლა არ გაქვს უფლებით. (perm.edit)</div>
                        @endcan
                    </div>
                </div>
            </div>

            @include('tyekafis.partials.trees_visual')

        </div>
    </div>

    <script>
        const tabBtnForm = document.getElementById('tabBtnForm');
        const tabBtnTrees = document.getElementById('tabBtnTrees');
        const tabFormIn = document.getElementById('tabFormIn');
        const tabTrees = document.getElementById('tabTrees');

        const jumpToTrees = document.getElementById('jumpToTrees');
        const jumpToForm = document.getElementById('jumpToForm');
        const formSaveBtn = document.getElementById('formSaveBtn');

        function setActiveTab(tab) {
            const isForm = tab === 'form';

            tabFormIn.classList.toggle('hidden', !isForm);
            tabTrees.classList.toggle('hidden', isForm);

            tabBtnForm.classList.toggle('bg-gray-900', isForm);
            tabBtnForm.classList.toggle('text-white', isForm);
            tabBtnForm.classList.toggle('bg-gray-100', !isForm);
            tabBtnForm.classList.toggle('text-gray-800', !isForm);

            tabBtnTrees.classList.toggle('bg-gray-900', !isForm);
            tabBtnTrees.classList.toggle('text-white', !isForm);
            tabBtnTrees.classList.toggle('bg-gray-100', isForm);
            tabBtnTrees.classList.toggle('text-gray-800', isForm);

            tabBtnForm.setAttribute('aria-selected', isForm ? 'true' : 'false');
            tabBtnTrees.setAttribute('aria-selected', isForm ? 'false' : 'true');

            if (formSaveBtn) {
                formSaveBtn.setAttribute('form', isForm ? 'formInForm' : 'treesForm');
                formSaveBtn.setAttribute('type', 'submit');
                formSaveBtn.textContent = 'შენახვა';
            }

            window.location.hash = isForm ? '#form' : '#trees';
        }

        tabBtnForm.addEventListener('click', () => setActiveTab('form'));
        tabBtnTrees.addEventListener('click', () => setActiveTab('trees'));
        if (jumpToTrees) jumpToTrees.addEventListener('click', () => setActiveTab('trees'));
        if (jumpToForm) jumpToForm.addEventListener('click', () => setActiveTab('form'));

        (function initTabs() {
            if (window.location.hash === '#trees') setActiveTab('trees');
            else setActiveTab('form');
        })();

        (function initHierarchy() {
            const selected = {
                region: @json($tyekafi->region_id),
                district: @json($tyekafi->forest_district_id),
                forest: @json($tyekafi->forest_id),
                quarter: @json($tyekafi->quarter_id),
                literIds: @json($selectedLiterIds),
            };

            const gbEl = document.getElementById('gb');
            const regionEl = document.getElementById('region');
            const districtEl = document.getElementById('district');
            const forestEl = document.getElementById('forest');
            const quarterEl = document.getElementById('quarter');
            const literEl = document.getElementById('liter');

            if (!gbEl || !regionEl || !districtEl || !forestEl) return;

            function setSingleOptions(select, items, selectedId) {
                select.innerHTML = '<option value="">—</option>';
                (items || []).forEach(i => {
                    const opt = document.createElement('option');
                    opt.value = i.id;
                    opt.textContent = i.name;
                    if (selectedId && String(selectedId) === String(i.id)) opt.selected = true;
                    select.appendChild(opt);
                });
            }

            function setMultiOptions(select, items, selectedIds) {
                select.innerHTML = '';
                const set = new Set((selectedIds || []).map(String));
                (items || []).forEach(i => {
                    const opt = document.createElement('option');
                    opt.value = i.id;
                    opt.textContent = i.name;
                    if (set.has(String(i.id))) opt.selected = true;
                    select.appendChild(opt);
                });
            }

            async function loadRegions() {
                setSingleOptions(regionEl, [], null);
                setSingleOptions(districtEl, [], null);
                setSingleOptions(forestEl, [], null);
                if (quarterEl) setSingleOptions(quarterEl, [], null);
                if (literEl) setMultiOptions(literEl, [], []);

                if (!gbEl.value) return;

                const res = await fetch(`{{ route('api.hierarchy.regions') }}?governing_body_id=${gbEl.value}`);
                const data = await res.json();
                setSingleOptions(regionEl, data, selected.region);
            }

            async function loadDistricts() {
                setSingleOptions(districtEl, [], null);
                setSingleOptions(forestEl, [], null);
                if (quarterEl) setSingleOptions(quarterEl, [], null);
                if (literEl) setMultiOptions(literEl, [], []);

                if (!regionEl.value) return;

                const res = await fetch(`{{ route('api.hierarchy.districts') }}?region_id=${regionEl.value}`);
                const data = await res.json();
                setSingleOptions(districtEl, data, selected.district);
            }

            async function loadForests() {
                setSingleOptions(forestEl, [], null);
                if (quarterEl) setSingleOptions(quarterEl, [], null);
                if (literEl) setMultiOptions(literEl, [], []);

                if (!districtEl.value) return;

                const res = await fetch(`{{ route('api.hierarchy.forests') }}?forest_district_id=${districtEl.value}`);
                const data = await res.json();
                setSingleOptions(forestEl, data, selected.forest);
            }

            async function loadQuarters() {
                if (!quarterEl || !literEl) return;

                setSingleOptions(quarterEl, [], null);
                setMultiOptions(literEl, [], []);

                if (!forestEl.value) return;

                const res = await fetch(`{{ route('api.hierarchy.quarters') }}?forest_id=${forestEl.value}`);
                const data = await res.json();
                setSingleOptions(quarterEl, data, selected.quarter);
            }

            async function loadLiters() {
                if (!quarterEl || !literEl) return;

                setMultiOptions(literEl, [], []);

                if (!quarterEl.value) return;

                const res = await fetch(`{{ route('api.hierarchy.liters') }}?quarter_id=${quarterEl.value}`);
                const data = await res.json();
                setMultiOptions(literEl, data, selected.literIds);
            }

            gbEl.addEventListener('change', async () => {
                selected.region = null;
                selected.district = null;
                selected.forest = null;
                selected.quarter = null;
                selected.literIds = [];
                await loadRegions();
            });

            regionEl.addEventListener('change', async () => {
                selected.district = null;
                selected.forest = null;
                selected.quarter = null;
                selected.literIds = [];
                await loadDistricts();
            });

            districtEl.addEventListener('change', async () => {
                selected.forest = null;
                selected.quarter = null;
                selected.literIds = [];
                await loadForests();
            });

            forestEl.addEventListener('change', async () => {
                selected.quarter = null;
                selected.literIds = [];
                await loadQuarters();
            });

            if (quarterEl) {
                quarterEl.addEventListener('change', async () => {
                    selected.literIds = [];
                    await loadLiters();
                });
            }

            (async function boot() {
                await loadRegions();
                if (regionEl.value || selected.region) await loadDistricts();
                if (districtEl.value || selected.district) await loadForests();
                if (quarterEl && (forestEl.value || selected.forest)) await loadQuarters();
                if (quarterEl && (quarterEl.value || selected.quarter)) await loadLiters();
            })();
        })();

        (function initFormAutosave() {
            const form = document.getElementById('formInForm');
            const saveBtn = document.getElementById('formSaveBtn');
            if (!form || !saveBtn) return;

            let isDirty = false;
            let isSaving = false;
            let autosaveTimer = null;
            let lastSerialized = serializeForm();

            function serializeForm() {
                const formData = new FormData(form);
                return new URLSearchParams(formData).toString();
            }

            function applyBtnClasses(state) {
                saveBtn.classList.remove(
                    'bg-green-600', 'hover:bg-green-700', 'border-green-700',
                    'bg-blue-600', 'hover:bg-blue-700', 'border-blue-700',
                    'bg-yellow-400', 'hover:bg-yellow-500', 'border-yellow-500',
                    'text-white', 'text-gray-900',
                    'opacity-70', 'cursor-not-allowed'
                );

                saveBtn.classList.add(
                    'inline-flex', 'items-center', 'justify-center', 'min-w-[140px]',
                    'px-4', 'py-2', 'rounded', 'border', 'font-semibold', 'shadow', 'transition'
                );

                if (state === 'idle') {
                    saveBtn.classList.add('bg-green-600', 'hover:bg-green-700', 'border-green-700', 'text-white');
                } else if (state === 'saving') {
                    saveBtn.classList.add('bg-blue-600', 'hover:bg-blue-700', 'border-blue-700', 'text-white', 'opacity-70', 'cursor-not-allowed');
                } else if (state === 'error') {
                    saveBtn.classList.add('bg-yellow-400', 'hover:bg-yellow-500', 'border-yellow-500', 'text-gray-900');
                }
            }

            function setBtnIdle() {
                applyBtnClasses('idle');
                saveBtn.textContent = isDirty ? 'შენახვა *' : 'შენახვა';
                saveBtn.disabled = false;
            }

            function setBtnSaving() {
                applyBtnClasses('saving');
                saveBtn.textContent = 'ინახება...';
                saveBtn.disabled = true;
            }

            function setBtnSavedAuto() {
                applyBtnClasses('idle');
                saveBtn.textContent = 'შენახულია ✓';
                saveBtn.disabled = false;

                setTimeout(() => {
                    if (!isDirty && !isSaving) {
                        applyBtnClasses('idle');
                        saveBtn.textContent = 'შენახვა';
                    }
                }, 1600);
            }

            function setBtnError() {
                applyBtnClasses('error');
                saveBtn.textContent = 'ვერ შეინახა';
                saveBtn.disabled = false;

                setTimeout(() => {
                    if (!isSaving) {
                        setBtnIdle();
                    }
                }, 2200);
            }

            function markDirty() {
                isDirty = true;
                setBtnIdle();

                if (autosaveTimer) clearTimeout(autosaveTimer);

                autosaveTimer = setTimeout(() => {
                    saveForm(true);
                }, 5000);
            }

            async function saveForm(isAuto = false) {
                if (isSaving) return;

                const currentSerialized = serializeForm();
                if (isAuto && currentSerialized === lastSerialized) {
                    return;
                }

                isSaving = true;
                setBtnSaving();

                try {
                    const response = await fetch(form.action, {
                        method: 'POST',
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'text/html,application/xhtml+xml'
                        },
                        body: new FormData(form),
                        credentials: 'same-origin'
                    });

                    if (!response.ok) {
                        throw new Error('Save failed');
                    }

                    isDirty = false;
                    lastSerialized = currentSerialized;
                    setBtnSavedAuto();
                } catch (error) {
                    isDirty = true;
                    setBtnError();
                } finally {
                    isSaving = false;
                }
            }

            form.querySelectorAll('input, select, textarea').forEach((el) => {
                el.addEventListener('input', markDirty);
                el.addEventListener('change', markDirty);
            });

            form.addEventListener('submit', async function (e) {
                e.preventDefault();
                if (autosaveTimer) clearTimeout(autosaveTimer);
                await saveForm(false);
            });

            window.addEventListener('beforeunload', function (e) {
                if (isDirty || isSaving) {
                    e.preventDefault();
                    e.returnValue = '';
                }
            });

            setBtnIdle();
        })();

        (function initInventoryToggle() {
            const invEl = document.getElementById('inventory_method');
            const blockEl = document.getElementById('sample_plot_fields');
            if (!invEl || !blockEl) return;

            function clearSamplePlotFields() {
                const typeEl = document.querySelector('[name="sample_plot_type"]');
                const areaEl = document.querySelector('[name="sample_plot_area"]');
                const coeffEl = document.querySelector('[name="multiplier_coeff"]');
                if (typeEl) typeEl.value = '';
                if (areaEl) areaEl.value = '';
                if (coeffEl) coeffEl.value = '';
            }

            function toggle() {
                const v = (invEl.value || '').trim();
                const show = (v === 'სანიმუშო ფართობები');
                blockEl.style.display = show ? 'block' : 'none';
                if (!show) clearSamplePlotFields();
            }

            invEl.addEventListener('change', toggle);
            toggle();
        })();

        (function initReportsDropdown() {
            const wrap = document.getElementById('reportsDropdownWrap');
            const btn = document.getElementById('reportsDropdownBtn');
            const menu = document.getElementById('reportsDropdownMenu');
            const compensationWrap = document.getElementById('compensationSubmenuWrap');
            const compensationBtn = document.getElementById('compensationSubmenuBtn');
            const compensationMenu = document.getElementById('compensationSubmenu');

            if (!wrap || !btn || !menu) return;

            function closeSubmenu() {
                if (compensationMenu) {
                    compensationMenu.style.display = 'none';
                }
            }

            function closeMenu() {
                menu.style.display = 'none';
                closeSubmenu();
            }

            function toggleMenu() {
                menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
                if (menu.style.display !== 'block') {
                    closeSubmenu();
                }
            }

            btn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                toggleMenu();
            });

            if (compensationWrap && compensationBtn && compensationMenu) {
                compensationBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    compensationMenu.style.display = compensationMenu.style.display === 'block' ? 'none' : 'block';
                });

                compensationWrap.addEventListener('mouseenter', function () {
                    compensationMenu.style.display = 'block';
                    compensationBtn.style.background = '#f3f4f6';
                });

                compensationWrap.addEventListener('mouseleave', function () {
                    compensationMenu.style.display = 'none';
                    compensationBtn.style.background = '#ffffff';
                });
            }

            document.addEventListener('click', function (e) {
                if (!wrap.contains(e.target)) {
                    closeMenu();
                }
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') {
                    closeMenu();
                }
            });

            Array.from(menu.querySelectorAll('a, button')).forEach(function (node) {
                node.addEventListener('mouseenter', function () {
                    if (this !== compensationBtn) {
                        this.style.background = '#f3f4f6';
                    }
                });
                node.addEventListener('mouseleave', function () {
                    if (this !== compensationBtn || !compensationMenu || compensationMenu.style.display !== 'block') {
                        this.style.background = '#ffffff';
                    }
                });
            });

            Array.from(menu.querySelectorAll('a')).forEach(function (link) {
                link.addEventListener('click', function () {
                    closeMenu();
                });
            });
        })();

    </script>
</x-app-layout>