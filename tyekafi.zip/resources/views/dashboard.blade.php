<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    კეთილი იყოს შენი მობრძანება!
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="text-lg font-semibold mb-3">მოქმედებები</div>

                    <div class="flex flex-wrap gap-3">
                        @can('admin')
                            <a href="{{ route('admin.users.index') }}" class="px-4 py-2 bg-gray-800 text-white rounded">
                                ადმინი: მომხმარებლები
                            </a>
                        @endcan

                        @can('perm.view')
                            <span class="px-4 py-2 bg-gray-100 rounded">დათვალიერება ✅</span>
                        @endcan

                        @can('perm.edit')
                            <span class="px-4 py-2 bg-gray-100 rounded">რედაქტირება ✅</span>
                        @endcan

                        @can('perm.import_export')
                            <span class="px-4 py-2 bg-gray-100 rounded">იმპორტ/ექსპორტი ✅</span>
                        @endcan

                        @can('perm.report_export')
                            <span class="px-4 py-2 bg-gray-100 rounded">რეპორტების ექსპორტი ✅</span>
                        @endcan

                        @cannot('perm.view')
                            <span class="px-4 py-2 bg-yellow-50 text-yellow-800 rounded">
                                შენ ჯერ არ გაქვს მინიჭებული უფლებები (permission-ები)
                            </span>
                        @endcannot
                    </div>

                    <div class="mt-4 text-sm text-gray-500">
                        შემდეგ ეტაპებზე აქ ჩაჯდება რეალური ღილაკები (Projects, Tyekafi, Import, Reports) და ავტომატურად დაიმალება/დაიბლოკება უფლებების მიხედვით.
                    </div>
                </div>
            </div>

        </div>
    </div>
</x-app-layout>
