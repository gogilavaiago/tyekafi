<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                პროექტი — {{ $project->name }}
            </h2>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            {{-- პროექტის ინფორმაცია --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="text-sm text-gray-500 mb-1">აღწერა</div>
                    <div class="text-gray-800">
                        {{ $project->description ?: '—' }}
                    </div>
                </div>
            </div>

            {{-- პროექტის ჯამები --}}
            <div class="overflow-x-auto">
                <div style="display:grid; grid-template-columns:repeat(6, minmax(170px, 1fr)); gap:16px; min-width:1140px;">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-1">მთლიანი ფართობი</div>
                            <div class="text-2xl font-semibold text-gray-900">
                                {{ number_format((float) $projectTotalArea, 4) }} ჰა
                            </div>
                        </div>
                    </div>

                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-1">1 ხარისხი</div>
                            <div class="text-2xl font-semibold text-gray-900">
                                {{ number_format((float) $projectTotalQuality1Volume, 3) }} მ³
                            </div>
                        </div>
                    </div>

                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-1">2 ხარისხი</div>
                            <div class="text-2xl font-semibold text-gray-900">
                                {{ number_format((float) $projectTotalQuality2Volume, 3) }} მ³
                            </div>
                        </div>
                    </div>

                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-1">8 სმ-ზე ნაკლები</div>
                            <div class="text-2xl font-semibold text-gray-900">
                                {{ number_format((float) ($projectTotalSmallVolume ?? 0), 3) }} მ³
                            </div>
                        </div>
                    </div>

                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-1">მთლიანი მოცულობა</div>
                            <div class="text-2xl font-semibold text-gray-900">
                                {{ number_format((float) $projectTotalVolume, 3) }} მ³
                            </div>
                        </div>
                    </div>

                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border">
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-1">ტყეკაფების რაოდენობა</div>
                            <div class="text-2xl font-semibold text-gray-900">
                                {{ $tyekafis->total() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- სახეობების მიხედვით ჯამები --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between mb-4">
                        <div>
                            <div class="text-lg font-semibold">ჯამური მონაცემები</div>
                            <div class="text-sm text-gray-500">
                                პროექტის ყველა ტყეკაფის ჯამური მოცულობა სახეობების, ხარისხებისა და 8 სმ-ზე ნაკლები ბლოკის მიხედვით
                            </div>
                        </div>

                        <a
                            href="{{ route('projects.totals', $project) }}"
                            class="inline-flex items-center justify-center gap-3 self-start rounded-xl bg-green-600 px-6 py-4 text-base font-bold text-white shadow-sm transition hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 min-w-[240px] sm:min-w-[270px]">
                            <span class="text-2xl leading-none">📊</span>
                            <span>ჯამური მონაცემები</span>
                        </a>
                    </div>
                </div>
            </div>

            {{-- ტყეკაფების სია --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <div class="text-lg font-semibold">ტყეკაფები</div>
                            <div class="text-sm text-gray-500">
                                ამ პროექტის ტყეკაფის ჩანაწერები
                            </div>
                        </div>

                        @can('perm.edit')
                            <form method="POST" action="{{ url('/projects/'.$project->id.'/tyekafis') }}">
                                @csrf
                                <input type="hidden" name="name" value="ტყეკაფი {{ now()->format('Y-m-d H:i') }}">
                                <input type="hidden" name="description" value="">

                                <x-ui-button type="submit" variant="add" icon="+">
                                    დამატება
                                </x-ui-button>
                            </form>
                        @endcan
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full table-auto text-sm">
                            <thead>
                                <tr class="border-b align-middle text-left">
                                    <th class="px-4 py-3 font-semibold text-gray-700">
                                        მართვის ორგანო
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700">
                                        რეგიონი
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700">
                                        სატყეო უბანი
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700">
                                        სატყეო
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap w-24">
                                        კვარტალი
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">
                                        ლიტერი
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap w-24">
                                        ფართობი (ჰა)
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700 w-16 text-center leading-tight">
                                        მთლიანი<br>მოცულობა
                                    </th>

                                    <th class="px-4 py-3 font-semibold text-gray-700 text-right whitespace-nowrap w-56">
                                        ქმედება
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                @forelse($tyekafis as $t)
                                    <tr class="border-b align-middle hover:bg-gray-50 transition">

                                        <td class="px-4 py-3">
                                            {{ $t->governingBody?->name ?: '—' }}
                                        </td>

                                        <td class="px-4 py-3">
                                            {{ $t->forestDistrict?->region?->name ?: '—' }}
                                        </td>

                                        <td class="px-4 py-3">
                                            {{ $t->forestDistrict?->name ?: '—' }}
                                        </td>

                                        <td class="px-4 py-3">
                                            {{ $t->forest?->name ?: '—' }}
                                        </td>

                                        <td class="px-4 py-3 whitespace-nowrap">
                                            {{ $t->display_quarter }}
                                        </td>

                                        <td class="px-4 py-3">
                                            {{ $t->display_liters }}
                                        </td>

                                        <td class="px-4 py-3 whitespace-nowrap">
                                            {{ !is_null($t->area_ha) ? number_format((float) $t->area_ha, 4) : '—' }}
                                        </td>

                                        <td class="px-4 py-3 whitespace-nowrap">
                                            {{ number_format((float) ($t->trees_total_volume ?? 0), 3) }}
                                        </td>

                                        <td class="px-4 py-3 text-right">
                                            <div class="inline-flex flex-wrap justify-end gap-2">

                                                <x-ui-button
                                                    :href="url('/projects/'.$project->id.'/tyekafis/'.$t->id)"
                                                    variant="open"
                                                    size="sm"
                                                    icon="↗">
                                                    გახსნა
                                                </x-ui-button>

                                                @can('perm.edit')
                                                    <x-ui-button
                                                        :href="url('/projects/'.$project->id.'/tyekafis/'.$t->id.'/edit')"
                                                        variant="edit"
                                                        size="sm"
                                                        icon="✎">
                                                        რედაქტირება
                                                    </x-ui-button>

                                                    <form method="POST"
                                                        action="{{ url('/projects/'.$project->id.'/tyekafis/'.$t->id) }}"
                                                        class="inline"
                                                        onsubmit="return confirm('დარწმუნებული ხარ რომ გინდა წაშლა?');">
                                                        @csrf
                                                        @method('DELETE')

                                                        <x-ui-button
                                                            type="submit"
                                                            variant="delete"
                                                            size="sm"
                                                            icon="🗑">
                                                            წაშლა
                                                        </x-ui-button>
                                                    </form>
                                                @endcan

                                            </div>
                                        </td>

                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="12" class="px-6 py-6 text-center text-gray-500">
                                            ამ პროექტში ჯერ ტყეკაფი არ არის დამატებული.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6">
                        {{ $tyekafis->links() }}
                    </div>

                </div>
            </div>

        </div>
    </div>
</x-app-layout>