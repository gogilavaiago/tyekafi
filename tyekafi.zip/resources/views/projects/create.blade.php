<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            პროექტის შექმნა
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    @if ($errors->any())
                        <div class="mb-4 p-3 bg-red-100 rounded">
                            <ul class="list-disc pl-5">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('projects.store') }}">
                        @csrf

                        <div class="mb-4">
                            <label class="block mb-1">პროექტის სახელი *</label>
                            <input name="name" value="{{ old('name') }}" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-6">
                            <label class="block mb-1">აღწერა</label>
                            <textarea name="description" class="w-full border rounded p-2" rows="5">{{ old('description') }}</textarea>
                        </div>

                        <div class="flex gap-3">
                            <button class="px-4 py-2 bg-gray-800 text-white rounded">
                                შენახვა
                            </button>

                            <a href="{{ route('projects.index') }}" class="px-4 py-2 bg-gray-200 rounded">
                                გაუქმება
                            </a>
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
</x-app-layout>
