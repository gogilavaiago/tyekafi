<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                პროექტები
            </h2>

            @can('perm.edit')
                <x-ui-button :href="route('projects.create')" variant="add" icon="+">
                    პროექტის შექმნა
                </x-ui-button>
            @endcan
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-x-auto">
                <div class="p-8 text-gray-900">

                    {{-- ✅ ცხრილი (scroll-ის გარეშე) --}}
                    <div class="overflow-x-hidden">
                        <table class="w-full table-auto text-sm">
                            <thead>
                                <tr class="border-b text-left align-middle">
                                    <th class="px-6 py-3 font-semibold text-gray-700 whitespace-nowrap w-16">
                                        ID
                                    </th>

                                    <th class="px-6 py-3 font-semibold text-gray-700 whitespace-nowrap">
                                        პროექტის<br>შემქმნელი
                                    </th>

                                    <th class="px-6 py-3 font-semibold text-gray-700 whitespace-nowrap">
                                        პროექტის<br>სახელი
                                    </th>

                                    <th class="px-6 py-3 font-semibold text-gray-700 whitespace-nowrap w-40">
                                        შექმნის<br>თარიღი
                                    </th>

                                    {{-- ქმედებები: ცოტა ფართო, რომ ღილაკები ჩაეტიოს --}}
                                    <th class="px-6 py-3 font-semibold text-gray-700 text-right whitespace-nowrap w-64">
                                        ქმედება
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach($projects as $project)
                                    <tr class="border-b align-middle hover:bg-gray-50 transition">
                                        <td class="px-6 py-3 align-middle whitespace-nowrap">
                                            {{ $project->id }}
                                        </td>

                                        <td class="px-6 py-3 align-middle whitespace-nowrap">
                                            {{ optional($project->user)->name ?? ('User #'.$project->user_id) }}
                                        </td>

                                        <td class="px-6 py-3 align-middle">
                                            {{ $project->name }}
                                        </td>

                                        <td class="px-6 py-3 align-middle whitespace-nowrap">
                                            <div class="leading-tight">
                                                <div>{{ $project->created_at?->format('Y-m-d') }}</div>
                                                <div class="text-xs text-gray-500">{{ $project->created_at?->format('H:i') }}</div>
                                            </div>
                                        </td>

                                        {{-- ✅ ღილაკები აღარ “გაიქცევა” — wrap-ს ვაძლევთ --}}
                                        <td class="px-6 py-3 align-middle text-right">
                                            <div class="inline-flex flex-wrap justify-end gap-2">
                                                <x-ui-button :href="route('projects.show', $project)" variant="open" size="sm" icon="↗">
                                                    გახსნა
                                                </x-ui-button>

                                                @can('perm.edit')
                                                    <x-ui-button :href="route('projects.edit', $project)" variant="edit" size="sm" icon="✎">
                                                        რედაქტირება
                                                    </x-ui-button>

                                                    <form method="POST"
                                                          action="{{ route('projects.destroy', $project) }}"
                                                          class="inline"
                                                          onsubmit="return confirm('დარწმუნებული ხარ რომ გინდა წაშლა?');">
                                                        @csrf
                                                        @method('DELETE')

                                                        <x-ui-button type="submit" variant="delete" size="sm" icon="🗑">
                                                            წაშლა
                                                        </x-ui-button>
                                                    </form>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6">
                        {{ $projects->links() }}
                    </div>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
