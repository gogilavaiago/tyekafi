<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between gap-4">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                პროექტი — {{ $project->name }} — ჯამური მონაცემები
            </h2>

            <a
                href="{{ route('projects.show', $project) }}"
                class="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold shadow-sm transition focus:outline-none"
                style="background-color:#1f2937;color:#ffffff;text-decoration:none;"
            >
                <span>პროექტზე დაბრუნება</span>
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8">

            <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                <div class="p-6">
                    <div class="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
                        <div>
                            <div class="text-sm font-semibold text-gray-800">სარგებლობის ვადა</div>
                            <div class="text-sm text-gray-500">
                                კომპენსაციის ჯამური თანხა ითვლება არჩეული ინტერვალით.
                            </div>
                        </div>

                        <div class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-end">
                            <form method="GET" class="flex items-center gap-3">
                                <select
                                    name="years_range"
                                    onchange="this.form.submit()"
                                    class="min-w-[110px] rounded-lg border-gray-300 text-sm shadow-sm focus:border-green-500 focus:ring-green-500"
                                >
                                    <option value="0-5" {{ ($yearsRange ?? '0-5') === '0-5' ? 'selected' : '' }}>0-5</option>
                                    <option value="6-15" {{ ($yearsRange ?? '0-5') === '6-15' ? 'selected' : '' }}>6-15</option>
                                    <option value="16-30" {{ ($yearsRange ?? '0-5') === '16-30' ? 'selected' : '' }}>16-30</option>
                                    <option value="31-49" {{ ($yearsRange ?? '0-5') === '31-49' ? 'selected' : '' }}>31-49</option>
                                </select>
                            </form>

                            <div class="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                                <a
                                    href="{{ route('projects.reportPdfCompensationByBody', ['project' => $project, 'years_range' => ($yearsRange ?? '0-5')]) }}"
                                    target="_blank"
                                    class="inline-flex min-w-[220px] items-center justify-center rounded-xl px-4 py-2.5 text-sm font-semibold shadow-sm transition focus:outline-none"
                                    style="background-color:#b91c1c;color:#ffffff !important;text-decoration:none;border:1px solid #991b1b;"
                                >
                                    PDF რეპორტი
                                </a>

                                <a
                                    href="{{ route('projects.reportExcelCompensationByBody', ['project' => $project, 'years_range' => ($yearsRange ?? '0-5')]) }}"
                                    class="inline-flex min-w-[220px] items-center justify-center rounded-xl px-4 py-2.5 text-sm font-semibold shadow-sm transition focus:outline-none"
                                    style="background-color:#15803d;color:#ffffff !important;text-decoration:none;border:1px solid #166534;"
                                >
                                    Excel რეპორტი
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-6">
                <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-gray-500">მთლიანი ფართობი</div>
                        <div class="text-2xl font-semibold text-gray-900">{{ number_format((float) $projectTotalArea, 4) }} ჰა</div>
                    </div>
                </div>

                <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-gray-500">1 ხარისხი</div>
                        <div class="text-2xl font-semibold text-gray-900">{{ number_format((float) $projectTotalQuality1Volume, 3) }} მ³</div>
                    </div>
                </div>

                <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-gray-500">2 ხარისხი</div>
                        <div class="text-2xl font-semibold text-gray-900">{{ number_format((float) $projectTotalQuality2Volume, 3) }} მ³</div>
                    </div>
                </div>

                <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-gray-500">8 სმ-ზე ნაკლები</div>
                        <div class="text-2xl font-semibold text-gray-900">{{ number_format((float) ($projectTotalSmallVolume ?? 0), 3) }} მ³</div>
                    </div>
                </div>

                <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-gray-500">მთლიანი მოცულობა</div>
                        <div class="text-2xl font-semibold text-gray-900">{{ number_format((float) $projectTotalVolume, 3) }} მ³</div>
                    </div>
                </div>

                <div class="overflow-hidden rounded-lg border bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-gray-500">ტყეკაფების რაოდენობა</div>
                        <div class="text-2xl font-semibold text-gray-900">{{ $tyekafis->count() }}</div>
                    </div>
                </div>

                <div class="overflow-hidden rounded-lg border border-green-200 bg-white shadow-sm">
                    <div class="p-6">
                        <div class="mb-1 text-sm text-green-600">კომპენსაცია</div>
                        <div class="text-2xl font-bold text-green-800">{{ number_format((float) ($totalCompensation ?? 0), 3) }} ₾</div>
                    </div>
                </div>
            </div>

            <div class="overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="p-6 text-gray-900">
                    <div class="mb-4">
                        <div class="text-lg font-semibold">სახეობების მიხედვით ჯამური მონაცემები</div>
                        <div class="text-sm text-gray-500">
                            პროექტის ყველა ტყეკაფის ჯამური მოცულობა სახეობების, ხარისხებისა და 8 სმ-ზე ნაკლები ბლოკის მიხედვით.
                        </div>
                    </div>

                    @if(count($projectSpeciesTotals))
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto text-sm">
                                <thead>
                                    <tr class="border-b text-left">
                                        <th class="px-4 py-3 font-semibold text-gray-700">სახეობა</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">1 ხარისხი (მ³)</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">2 ხარისხი (მ³)</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">8 სმ-ზე ნაკლები (მ³)</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">მთლიანი მოცულობა (მ³)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($projectSpeciesTotals as $speciesName => $volumes)
                                        <tr class="border-b transition hover:bg-gray-50">
                                            <td class="px-4 py-3">{{ $speciesName }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['quality_1'] ?? 0), 3) }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['quality_2'] ?? 0), 3) }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['small'] ?? 0), 3) }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['total'] ?? 0), 3) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr class="bg-gray-50 font-semibold">
                                        <td class="px-4 py-3">სულ მთლიანი ჯამი</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectTotalQuality1Volume, 3) }}</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectTotalQuality2Volume, 3) }}</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($projectTotalSmallVolume ?? 0), 3) }}</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectTotalVolume, 3) }}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    @else
                        <div class="text-sm text-gray-500">სახეობების მიხედვით ჯამები ჯერ არ არის.</div>
                    @endif
                </div>
            </div>

            <div class="overflow-hidden rounded-lg border border-red-100 bg-white shadow-sm">
                <div class="p-6 text-gray-900">
                    <div class="mb-5 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div>
                            <div class="text-lg font-semibold text-red-700">წითელი ნუსხის სახეობების რეპორტი</div>
                            <div class="text-sm text-gray-500">
                                აქ ჩანს მხოლოდ ის სახეობები, რომელთაც სახეობების კატალოგში red_list მნიშვნელობა აქვთ შევსებული.
                            </div>
                        </div>

                        <div class="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:min-w-[560px]">
                            <div class="rounded-xl border border-red-100 bg-red-50 px-4 py-3">
                                <div class="text-xs text-red-600">სახეობების რაოდენობა</div>
                                <div class="mt-1 text-xl font-bold text-red-800">{{ $projectRedListSpeciesCount }}</div>
                            </div>
                            <div class="rounded-xl border border-red-100 bg-red-50 px-4 py-3">
                                <div class="text-xs text-red-600">1 ხარისხი</div>
                                <div class="mt-1 text-xl font-bold text-red-800">{{ number_format((float) $projectRedListQuality1Volume, 3) }} მ³</div>
                            </div>
                            <div class="rounded-xl border border-red-100 bg-red-50 px-4 py-3">
                                <div class="text-xs text-red-600">2 ხარისხი</div>
                                <div class="mt-1 text-xl font-bold text-red-800">{{ number_format((float) $projectRedListQuality2Volume, 3) }} მ³</div>
                            </div>
                            <div class="rounded-xl border border-red-100 bg-red-50 px-4 py-3">
                                <div class="text-xs text-red-600">მთლიანი მოცულობა</div>
                                <div class="mt-1 text-xl font-bold text-red-800">{{ number_format((float) $projectRedListTotalVolume, 3) }} მ³</div>
                            </div>
                        </div>
                    </div>

                    @if(count($projectRedListSpeciesTotals))
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto text-sm">
                                <thead>
                                    <tr class="border-b text-left">
                                        <th class="px-4 py-3 font-semibold text-gray-700">სახეობა</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">სტატუსი</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">1 ხარისხი (მ³)</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">2 ხარისხი (მ³)</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">8 სმ-ზე ნაკლები (მ³)</th>
                                        <th class="px-4 py-3 font-semibold text-gray-700 whitespace-nowrap">მთლიანი მოცულობა (მ³)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($projectRedListSpeciesTotals as $speciesName => $volumes)
                                        <tr class="border-b transition hover:bg-red-50/40">
                                            <td class="px-4 py-3 font-medium text-gray-900">{{ $speciesName }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap font-semibold text-red-700">{{ $volumes['red_list_label'] ?? 'წითელი ნუსხა' }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['quality_1'] ?? 0), 3) }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['quality_2'] ?? 0), 3) }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) ($volumes['small'] ?? 0), 3) }}</td>
                                            <td class="px-4 py-3 whitespace-nowrap font-semibold">{{ number_format((float) ($volumes['total'] ?? 0), 3) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr class="bg-red-50 font-semibold">
                                        <td colspan="2" class="px-4 py-3">სულ წითელი ნუსხის ჯამი</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectRedListQuality1Volume, 3) }}</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectRedListQuality2Volume, 3) }}</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectRedListSmallVolume, 3) }}</td>
                                        <td class="px-4 py-3 whitespace-nowrap">{{ number_format((float) $projectRedListTotalVolume, 3) }}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    @else
                        <div class="rounded-xl border border-dashed border-red-200 bg-red-50 px-4 py-5 text-sm text-red-700">
                            ამ პროექტში წითელი ნუსხის სახეობებისთვის მოცულობის ჩანაწერები ჯერ არ არის.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>