<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>კომპენსაცია</title>
    <style>
        @page {
            size: A4 portrait;
            margin: 14mm 11mm 12mm 11mm;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 9.4px;
            color: #111;
            margin: 0;
            padding: 0;
            line-height: 1.2;
        }

        .report-type {
            text-align: right;
            font-size: 10px;
            font-weight: 700;
            margin-bottom: 12px;
        }

        .title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            margin: 8px 0 12px 0;
            letter-spacing: 0.2px;
        }

        .meta-grid,
        .gps-table,
        .report-table,
        .summary-table {
            width: 100%;
            border-collapse: collapse;
        }

        .meta-grid {
            margin-bottom: 10px;
        }

        .meta-grid td {
            vertical-align: top;
            padding: 2px 4px;
            font-size: 10px;
            line-height: 1.38;
        }

        .meta-label {
            font-weight: 700;
            display: inline-block;
            min-width: 108px;
        }

        .gps-table,
        .report-table,
        .summary-table {
            margin-bottom: 12px;
        }

        .gps-table td,
        .gps-table th,
        .report-table td,
        .report-table th,
        .summary-table td,
        .summary-table th {
            border: 1px solid #222;
            padding: 4px 5px;
            vertical-align: middle;
        }

        .header-green {
            background: #d9ead3;
            font-weight: 700;
            text-align: center;
        }

        .section-title {
            font-size: 11px;
            font-weight: 700;
            margin: 10px 0 4px 4px;
        }

        .center { text-align: center; }
        .right { text-align: right; }
        .bold { font-weight: 700; }
        .latin {
            display: block;
            font-size: 7.8px;
            font-style: italic;
            margin-top: 1px;
        }
        .small { font-size: 8.2px; }
        .nowrap { white-space: nowrap; }
        .h-blank td { height: 18px; }

        .summary-label {
            font-weight: 700;
            width: 58%;
        }
    </style>
</head>
<body>
    @php
        $regionName = $tyekafi->region?->name ?? $tyekafi->forestDistrict?->region?->name ?? '—';
        $forestName = $tyekafi->forest?->name ?? '—';
        $forestDistrictName = $tyekafi->forestDistrict?->name ?? '—';
        $quarterName = $tyekafi->display_quarter;
        $litersText = $tyekafi->display_liters;
        $yearsText = trim((string) ($compensation['years_range'] ?? ''));
        $speciesRows = $compensation['species_rows'] ?? [];
        $yearMultiplier = (float) ($compensation['year_multiplier'] ?? 1);
        $woodCompensation = (float) (($compensation['wood_compensation'] ?? 0) * $yearMultiplier);
        $areaCompensation = (float) ($compensation['area_compensation'] ?? 0);
        $totalCompensation = (float) ($woodCompensation + $areaCompensation);
        $gps = [
            $tyekafi->gps_x1 ?: '—',
            $tyekafi->gps_y1 ?: '—',
            $tyekafi->gps_x2 ?: '—',
            $tyekafi->gps_y2 ?: '—',
        ];
    @endphp

    <div class="report-type">რეპორტი: კომპენსაცია</div>
    <div class="title">კომპენსაციის ანგარიში</div>

    <table class="meta-grid">
        <tr>
            <td style="width:33%;">
                <span class="meta-label">მართვის ორგანო:</span> {{ $tyekafi->governingBody?->name ?: '—' }}<br>
                <span class="meta-label">სატყეო უბანი:</span> {{ $forestDistrictName }}<br>
                <span class="meta-label">კვარტალი:</span> {{ $quarterName }}
            </td>
            <td style="width:33%;">
                <span class="meta-label">რეგიონი:</span> {{ $regionName }}<br>
                <span class="meta-label">სატყეო:</span> {{ $forestName }}<br>
                <span class="meta-label">ლიტერ(ებ)ი:</span> {{ $litersText }}
            </td>
            <td style="width:34%;">
                <span class="meta-label">სარგებლობის ვადა:</span> {{ $yearsText !== '' ? $yearsText : '—' }}<br>
                <span class="meta-label">ფართობი:</span>
                {{ !is_null($tyekafi->area_ha) ? number_format((float) $tyekafi->area_ha, 4, '.', '') . ' ჰა' : '—' }}<br>
                <span class="meta-label">თარიღი:</span> {{ now()->format('d.m.Y') }}
            </td>
        </tr>
    </table>

    <table class="gps-table">
        <tr>
            <th class="header-green nowrap" style="width:22%;">GPS კოორდინატები:</th>
            <th class="header-green" style="width:19.5%;">X1</th>
            <th class="header-green" style="width:19.5%;">Y1</th>
            <th class="header-green" style="width:19.5%;">X2</th>
            <th class="header-green" style="width:19.5%;">Y2</th>
        </tr>
        <tr>
            <td class="center">კოორდინატები</td>
            @foreach($gps as $value)
                <td class="center">{{ $value }}</td>
            @endforeach
        </tr>
    </table>

    <div class="section-title">I. ხემცენარეების მიხედვით საკომპენსაციო თანხა</div>
    <table class="report-table">
        <thead>
            <tr>
                <th class="header-green" style="width:4%;">N</th>
                <th class="header-green" style="width:22%;">სახეობა</th>
                <th class="header-green" style="width:12%;">მოცულობა<br>(მ³)</th>
                <th class="header-green" style="width:12%;">ჯგუფი</th>
                <th class="header-green" style="width:16%;">ერთეულის<br>ღირებულება</th>
                <th class="header-green" style="width:11%;">K მართვის<br>ორგანო / სახეობა</th>
                <th class="header-green" style="width:11%;">K სარგებლობის<br>ვადა</th>
                <th class="header-green" style="width:12%;">კომპენსაცია<br>(ლარი)</th>
            </tr>
        </thead>
        <tbody>
            @forelse($speciesRows as $index => $row)
                <tr>
                    <td class="center">{{ $index + 1 }}</td>
                    <td>
                        {{ $row['species_name'] ?? '—' }}
                        @if(!empty($row['species_latin_name']))
                            <span class="latin">{{ $row['species_latin_name'] }}</span>
                        @endif
                    </td>
                    <td class="center">{{ number_format((float) ($row['volume'] ?? 0), 3, '.', '') }}</td>
                    <td class="center">{{ $row['money_group'] ?? '—' }}</td>
                    <td class="center">{{ number_format((float) ($row['base_rate'] ?? 0), 3, '.', '') }}</td>
                    <td class="center">{{ number_format((float) ($row['body_multiplier'] ?? 0), 3, '.', '') }}</td>
                    <td class="center">{{ number_format($yearMultiplier, 3, '.', '') }}</td>
                    <td class="center">{{ number_format((float) ($row['compensation'] ?? 0), 3, '.', '') }}</td>
                </tr>
            @empty
                <tr class="h-blank">
                    <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
                </tr>
            @endforelse
            <tr>
                <td colspan="7" class="right bold">ხემცენარეების კომპენსაცია სულ</td>
                <td class="center bold">{{ number_format($woodCompensation, 3, '.', '') }}</td>
            </tr>
        </tbody>
    </table>

    <div class="section-title">II. ფართობის მიხედვით საკომპენსაციო თანხა</div>
    <table class="summary-table">
        <tr>
            <th class="header-green summary-label">ფართობი (კვ.მ)</th>
            <td class="center">{{ number_format((float) ($compensation['area_m2'] ?? 0), 0, '.', '') }}</td>
        </tr>
        <tr>
            <th class="header-green summary-label">საბაზისო კომპენსაცია ფართობის ცხრილის მიხედვით</th>
            <td class="center">{{ number_format((float) ($compensation['area_base_compensation'] ?? 0), 3, '.', '') }}</td>
        </tr>
        <tr>
            <th class="header-green summary-label">წლების კოეფიციენტი (K)</th>
            <td class="center">{{ number_format($yearMultiplier, 3, '.', '') }}</td>
        </tr>
        <tr>
            <th class="header-green summary-label">ფართობის კომპენსაცია</th>
            <td class="center">{{ number_format($areaCompensation, 3, '.', '') }}</td>
        </tr>
    </table>

    <div class="section-title">III. ჯამური შედეგი</div>
    <table class="summary-table">
        <tr>
            <th class="header-green summary-label">ხემცენარეების კომპენსაცია</th>
            <td class="center">{{ number_format($woodCompensation, 3, '.', '') }}</td>
        </tr>
        <tr>
            <th class="header-green summary-label">ფართობის კომპენსაცია</th>
            <td class="center">{{ number_format($areaCompensation, 3, '.', '') }}</td>
        </tr>
        <tr>
            <th class="header-green summary-label">სულ გადასახდელი კომპენსაცია</th>
            <td class="center bold">{{ number_format($totalCompensation, 3, '.', '') }}</td>
        </tr>
    </table>
</body>
</html>
