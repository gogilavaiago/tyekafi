<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>დანართი №1</title>
    <style>
        @page { size: A4 portrait; margin: 6mm 6mm 7mm 6mm; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 7.15px; color: #000; margin: 0; padding: 0; }
        table { width: 100%; border-collapse: collapse; table-layout: fixed; margin: 0; }
        th, td { border: 1px solid #000; padding: 1.2px 1.95px; vertical-align: middle; word-wrap: break-word; overflow-wrap: break-word; line-height: 0.96; }
        th { text-align: center; font-weight: bold; }
        .header-table td { border: none !important; padding: 0; }
        .brand-cell { width: 232px; }
        .brand-wrap { width: 100%; }
        .brand-logo-cell { width: 64px; vertical-align: middle; }
        .brand-text-cell { vertical-align: middle; padding-left: 8px !important; }
        .brand-text { font-size: 9.9px; font-weight: bold; line-height: 1.1; white-space: pre-line; }
        .logo-img { display: block; max-width: 58px; max-height: 58px; width: auto; height: auto; object-fit: contain; }
        .header-title { text-align: center; font-size: 15.35px; font-weight: bold; letter-spacing: 0.03px; }
        .header-annex { width: 110px; text-align: right; font-size: 10px; font-weight: bold; vertical-align: top; }
        .outer { border: 1.25px solid #000; }
        .head-green { background: #E2EFDA; }
        .head-green-dark { background: #C6E0B4; }
        .center { text-align: center; }
        .left { text-align: left; }
        .right { text-align: right; }
        .wrap { white-space: pre-line; }
        .bold { font-weight: bold; }
        .section-caption { border: 1.25px solid #000; border-bottom: 0; text-align: center; font-size: 9px; font-weight: bold; padding: 2.0px 3.3px; margin-top: 4px; line-height: 1.06; }
        .meta td { font-size: 7.9px; }
        .page-break { page-break-before: always; }
        .signature-box { min-height: 60px; text-align: center; }
        .signature-image { display: block; margin: 0 auto 6px auto; max-width: 240px; max-height: 55px; width: auto; height: auto; object-fit: contain; }
        .signature-line { width: 220px; max-width: 100%; border-top: 1px solid #000; margin: 0 auto; height: 1px; }
        .footer-note { border: 1.25px solid #000; border-top: 0; font-size: 8px; line-height: 1.2; padding: 4px 5px; white-space: pre-line; }
        .tiny { font-size: 6.45px; }
        .latin-name {
            display: block;
            font-style: italic;
            font-size: 6.15px;
            line-height: 0.9;
            text-align: center;
            margin-top: 1px;
        }
        .subtotal { background:#E2EFDA; font-weight:bold; }
        .tight td, .tight th { padding-top: 1px; padding-bottom: 1px; }
        .h16 td, .h16 th { height: 16px; }
        .h18 td, .h18 th { height: 16px; }
        .h20 td, .h20 th { height: 18px; }
        .h22 td, .h22 th { height: 19.75px; }
        .h24 td, .h24 th { height: 22px; }
        .meta-row td { padding-top: 1.5px; padding-bottom: 1.5px; }
        .header-top th { vertical-align: middle; padding-top: 0.95px; padding-bottom: 0.95px; }
        .header-sub th { font-size: 5.85px; line-height: 0.92; padding-top: 0.45px; padding-bottom: 0.45px; }
        .subtotal-row td { background:#E2EFDA; font-weight:bold; line-height:0.96; border-top-width:1.3px; border-bottom-width:1.2px; }
        .grandtotal-row td { background:#D8E4BC; font-weight:bold; line-height:0.96; border-top-width:1.5px; border-bottom-width:1.5px; }
        .label-cell { font-weight:bold; }

        .meta td { line-height: 1.04; }
        .meta .label-cell, .meta .bold { font-size: 7.9px; }
        .thin-top td, .thin-top th { border-top-width: 0.8px; }
        .thick-bottom td, .thick-bottom th { border-bottom-width: 1.4px; }
        .narrow td, .narrow th { padding-left: 1.8px; padding-right: 1.8px; }
        .detail-table td, .detail-table th { border-color:#000; }
        .summary-table td, .summary-table th { border-color:#000; }
        .meta .label-cell { letter-spacing: 0.01px; }

        .meta-compact td { padding-top: 1.35px; padding-bottom: 1.35px; }
        .section-table th { letter-spacing: 0.01px; }
        .species-cell { line-height: 1.0; }
        .note-cell { line-height: 0.98; font-size: 6.7px; }
        .meta-label-tight { letter-spacing: 0; }
        .subtotal-accent td { border-top-width: 1.35px; }
        .grandtotal-accent td { border-bottom-width: 1.6px; }

        .summary-species-cell {
            text-align: center;
            line-height: 1.0;
        }
    </style>
</head>
<body>
@php
    $common = $pdf_common ?? [];
    $n1 = $pdf_n1 ?? [];
    $detailChunks = $n1['detail_chunks'] ?? [[]];
    $heightRankRows = $n1['height_rank_rows'] ?? [];
    $compositionRows = $n1['composition_rows'] ?? [];
    $smallRows = $n1['small_rows'] ?? [];
    $sectionThreeRows = $n1['section_three_rows'] ?? [];
    $smallCountTotal = $n1['small_count_total'] ?? 0;
    $smallVolumeTotal = $n1['small_volume_total'] ?? 0;
    $markerDisplay = $n1['marker_display'] ?? '—';
    $signatureBase64 = $n1['signature_base64'] ?? null;
    $noteText = $n1['note_text'] ?? '';
    $forestUseBasisTitle = $n1['forest_use_basis_title'] ?? '—';
    $logoBase64 = $common['logo_base64'] ?? null;
    $companyDisplayName = $common['company_display_name'] ?? "საქართველოს\nსატყეო სერვისები";

    $latinBySpecies = [];
    foreach ($sectionThreeRows as $row) {
        $geo = trim((string) ($row['species_name'] ?? ''));
        $lat = trim((string) ($row['species_latin_name'] ?? ''));
        if ($geo !== '' && $lat !== '' && !isset($latinBySpecies[$geo])) {
            $latinBySpecies[$geo] = $lat;
        }
    }
    foreach ($smallRows as $row) {
        $geo = trim((string) ($row['species_name'] ?? ''));
        $lat = trim((string) ($row['species_latin_name'] ?? ''));
        if ($geo !== '' && $lat !== '' && !isset($latinBySpecies[$geo])) {
            $latinBySpecies[$geo] = $lat;
        }
    }
    foreach ($detailChunks as $chunk) {
        foreach ($chunk as $row) {
            $geo = trim((string) ($row['species_name'] ?? ''));
            $lat = trim((string) ($row['species_latin_name'] ?? ''));
            if ($geo !== '' && $lat !== '' && !isset($latinBySpecies[$geo])) {
                $latinBySpecies[$geo] = $lat;
            }
        }
    }

    $toRoman = static function ($value): string {
        $value = trim((string) $value);
        if ($value === '' || $value === '—') {
            return '—';
        }

        $normalized = mb_strtoupper($value);
        if (preg_match('/^[IVXLCDM]+$/u', $normalized)) {
            return $normalized;
        }

        if (!is_numeric($value)) {
            return $value;
        }

        $number = (int) $value;
        if ($number <= 0) {
            return '—';
        }

        $map = [
            1000 => 'M',
            900 => 'CM',
            500 => 'D',
            400 => 'CD',
            100 => 'C',
            90 => 'XC',
            50 => 'L',
            40 => 'XL',
            10 => 'X',
            9 => 'IX',
            5 => 'V',
            4 => 'IV',
            1 => 'I',
        ];

        $result = '';
        foreach ($map as $arabic => $roman) {
            while ($number >= $arabic) {
                $result .= $roman;
                $number -= $arabic;
            }
        }

        return $result !== '' ? $result : '—';
    };
@endphp

<table class="header-table">
    <tr>
        <td class="brand-cell">
            <table class="header-table brand-wrap">
                <tr>
                    <td class="brand-logo-cell">
                        @if($logoBase64)
                            <img src="{{ $logoBase64 }}" alt="Logo" class="logo-img">
                        @endif
                    </td>
                    <td class="brand-text-cell">
                        <div class="brand-text">{{ $companyDisplayName }}</div>
                    </td>
                </tr>
            </table>
        </td>
        <td class="header-title">ტყეკაფის აღრიცხვის უწყისი</td>
        <td class="header-annex">დანართი №1</td>
    </tr>
</table>

<table class="outer meta meta-compact">
    <colgroup>
        <col style="width:26%">
        <col style="width:24%">
        <col style="width:22%">
        <col style="width:28%">
    </colgroup>
    <tr>
        <td class="left bold">ტყითსარგებლობის საფუძველი:</td>
        <td class="left">{{ $forestUseBasisTitle }}</td>
        <td class="left bold">რეგიონი:</td>
        <td class="left">{{ $tyekafi->forestDistrict?->region?->name ?: '—' }}</td>
    </tr>
    <tr>
        <td class="left bold">ტყითმოსარგებლე:</td>
        <td class="left">{{ $tyekafi->forest_user_name ?: '—' }}</td>
        <td class="left bold">ს/კ:</td>
        <td class="left">{{ $tyekafi->forest_user_id_code ?: '—' }}</td>
    </tr>
    <tr>
        <td class="left bold">მართვის ორგანო:</td>
        <td class="left">{{ $tyekafi->governingBody?->name ?: '—' }}</td>
        <td class="left bold">სატყეო უბანი / სატყეო:</td>
        <td class="left">{{ $tyekafi->forestDistrict?->name ?: '—' }} / {{ $tyekafi->forest?->name ?: '—' }}</td>
    </tr>
    <tr>
        <td class="left bold">კვარტალი / ლიტერი:</td>
        <td class="left">{{ $tyekafi->display_quarter }} / {{ $tyekafi->display_liters }}</td>
        <td class="left bold">აღრიცხვის თარიღი:</td>
        <td class="center">{{ $reportDate }}</td>
    </tr>
</table>

<div class="section-caption head-green-dark">თანრიგი / შემადგენლობა</div>

<table class="outer summary-table">
    <colgroup>
        <col style="width:30%">
        <col style="width:50%">
        <col style="width:20%">
    </colgroup>

    <thead>
        <tr class="head-green h20">
            <th>შემადგენლობა</th>
            <th>სახეობა (ჯიში)</th>
            <th>თანრიგი</th>
        </tr>
    </thead>

    <tbody>

        @php $detailRowCount = max(1, count($heightRankRows), count($compositionRows)); @endphp

        @for($i = 0; $i < $detailRowCount; $i++)

            @php
                $compositionUnit = trim((string) ($compositionRows[$i]['unit'] ?? ''));
                $compositionSpecies = trim((string) ($compositionRows[$i]['species'] ?? ''));
                $speciesName = trim((string) ($heightRankRows[$i]['species'] ?? ($compositionSpecies ?: '—')));
                $latinName = trim((string) ($heightRankRows[$i]['species_latin_name'] ?? ($latinBySpecies[$speciesName] ?? '')));
                $rankValue = trim((string) ($heightRankRows[$i]['rank'] ?? '—'));
                $compositionDisplay = $compositionUnit !== '' ? $compositionUnit : ($compositionSpecies !== '' ? '+' : '—');
                $rankDisplay = $toRoman($rankValue);
            @endphp

            <tr>
                <td class="center">{{ $compositionDisplay }}</td>
                <td class="summary-species-cell">
                    {{ $speciesName }}
                    @if($latinName !== '')
                        <span class="latin-name">{{ $latinName }}</span>
                    @endif
                </td>
                <td class="center">{{ $rankDisplay }}</td>
            </tr>

        @endfor

    </tbody>
</table>

<div class="section-caption head-green-dark">ხეების დეტალური უწყისი</div>

@foreach($detailChunks as $chunkIndex => $chunk)
    @if($chunkIndex > 0)
        <div class="page-break"></div>
        <table class="header-table">
            <tr>
                <td class="brand-cell">
                    <table class="header-table brand-wrap">
                        <tr>
                            <td class="brand-logo-cell">
                                @if($logoBase64)
                                    <img src="{{ $logoBase64 }}" alt="Logo" class="logo-img">
                                @endif
                            </td>
                            <td class="brand-text-cell">
                                <div class="brand-text">{{ $companyDisplayName }}</div>
                            </td>
                        </tr>
                    </table>
                </td>
                <td class="header-title">ტყეკაფის აღრიცხვის უწყისი</td>
                <td class="header-annex">დანართი №1</td>
            </tr>
        </table>
        <div class="section-caption head-green-dark">ხეების დეტალური უწყისი — გაგრძელება</div>
    @endif

    <table class="outer detail-table section-table">
        <colgroup>
            <col style="width:4.3%">
            <col style="width:24.4%">
            <col style="width:6.2%">
            <col style="width:6.2%">
            <col style="width:10.2%">
            <col style="width:10.2%">
            <col style="width:9.3%">
            <col style="width:9.3%">
            <col style="width:10.7%">
            <col style="width:9.2%">
        </colgroup>
        <thead>
            <tr class="head-green header-top h20">
                <th rowspan="2">№</th>
                <th rowspan="2">სახეობა (ჯიში)</th>
                <th colspan="2">დიამეტრი</th>
                <th colspan="2">მოცულობა</th>
                <th colspan="3">ჯამი</th>
                <th rowspan="2">შენიშვნა</th>
            </tr>
            <tr class="head-green tiny tight header-sub h18">
                <th>I ხარისხი</th>
                <th>II ხარისხი</th>
                <th>ლიკვიდი</th>
                <th>შეშა ვარჯიდან</th>
                <th>I ხარისხი</th>
                <th>II ხარისხი</th>
                <th>სულ</th>
            </tr>
        </thead>
        <tbody>
            @forelse($chunk as $row)
                @php
                    $q1Liquid = (float) ($row['q1_liquid'] ?? 0);
                    $q1Firewood = (float) ($row['q1_firewood'] ?? 0);
                    $q2Liquid = (float) ($row['q2_liquid'] ?? 0);
                    $q2Firewood = (float) ($row['q2_firewood'] ?? 0);
                    $allLiquid = (float) ($row['all_liquid'] ?? ($q1Liquid + $q2Liquid));
                    $allFirewood = (float) ($row['all_firewood'] ?? ($q1Firewood + $q2Firewood));
                    $q1Total = (float) ($row['q1_total'] ?? ($q1Liquid + $q1Firewood));
                    $q2Total = (float) ($row['q2_total'] ?? ($q2Liquid + $q2Firewood));
                    $grandTotal = (float) ($row['all_total'] ?? ($q1Total + $q2Total));
                    $speciesText = trim((string) ($row['species_name'] ?? ''));
                    $latinText = trim((string) ($row['species_latin_name'] ?? ''));
                    $diameterText = trim((string) ($row['diameter_cm'] ?? ''));
                    $q1DiameterText = !empty($row['q1_count']) ? $diameterText : '';
                    $q2DiameterText = !empty($row['q2_count']) ? $diameterText : '';
                @endphp
                <tr>
                    <td class="center">{{ $row['row_no'] ?? '' }}</td>
                    <td class="left wrap species-cell">{{ $speciesText ?: '—' }}@if($latinText !== '')<span class="latin-name">{{ $latinText }}</span>@endif</td>
                    <td class="center">{{ $q1DiameterText }}</td>
                    <td class="center">{{ $q2DiameterText }}</td>
                    <td class="right">{{ $allLiquid != 0.0 ? number_format($allLiquid, 3, '.', '') : '' }}</td>
                    <td class="right">{{ $allFirewood != 0.0 ? number_format($allFirewood, 3, '.', '') : '' }}</td>
                    <td class="right">{{ $q1Total != 0.0 ? number_format($q1Total, 3, '.', '') : '' }}</td>
                    <td class="right">{{ $q2Total != 0.0 ? number_format($q2Total, 3, '.', '') : '' }}</td>
                    <td class="right">{{ $grandTotal != 0.0 ? number_format($grandTotal, 3, '.', '') : '' }}</td>
                    <td class="left wrap">{{ trim((string) ($row['note'] ?? '')) }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="10" class="center">მონაცემები არ არის</td>
                </tr>
            @endforelse
            @if($loop->last)
                <tr class="grandtotal-row h18">
                    <td colspan="4" class="center bold">სულ ჯამში</td>
                    <td class="right bold">{{ number_format((float) (($totals['all_liquid'] ?? 0)), 3, '.', '') }}</td>
                    <td class="right bold">{{ number_format((float) (($totals['all_firewood'] ?? 0)), 3, '.', '') }}</td>
                    <td class="right bold">{{ number_format((float) ($totals['q1_total'] ?? 0), 3, '.', '') }}</td>
                    <td class="right bold">{{ number_format((float) ($totals['q2_total'] ?? 0), 3, '.', '') }}</td>
                    <td class="right bold">{{ number_format((float) ($totals['all_total'] ?? 0), 3, '.', '') }}</td>
                    <td></td>
                </tr>
            @endif
        </tbody>
    </table>
@endforeach

<div class="page-break"></div>

<table class="header-table">
    <tr>
        <td class="brand-cell">
            <table class="header-table brand-wrap">
                <tr>
                    <td class="brand-logo-cell">
                        @if($logoBase64)
                            <img src="{{ $logoBase64 }}" alt="Logo" class="logo-img">
                        @endif
                    </td>
                    <td class="brand-text-cell">
                        <div class="brand-text">{{ $companyDisplayName }}</div>
                    </td>
                </tr>
            </table>
        </td>
        <td class="header-title">ტყეკაფის აღრიცხვის უწყისი</td>
        <td class="header-annex">დანართი №1</td>
    </tr>
</table>

<div class="section-caption head-green-dark">გარდა ამისა ტერიტორიაზე აღრიცხული 8 სმ-მდე ტაქსაციური დიამეტრის მქონე ხე მცენარეები</div>
<table class="outer">
    <colgroup>
        <col style="width:5%">
        <col style="width:61%">
        <col style="width:16%">
        <col style="width:18%">
    </colgroup>
    <thead>
        <tr class="head-green h20">
            <th>№</th>
            <th>სახეობა (ჯიში)</th>
            <th>ხეთა რაოდენობა</th>
            <th>მოცულობა</th>
        </tr>
    </thead>
    <tbody>
        @forelse($smallRows as $idx => $row)
            <tr>
                <td class="center">{{ $idx + 1 }}</td>
                <td class="left wrap">{{ trim((string) ($row['species_name'] ?? '')) }}@if(!empty($row['species_latin_name']))<span class="latin-name">{{ $row['species_latin_name'] }}</span>@endif</td>
                <td class="center">{{ (int) ($row['count'] ?? 0) ?: '' }}</td>
                <td class="right">{{ number_format((float) ($row['volume'] ?? 0), 3, '.', '') }}</td>
            </tr>
        @empty
            <tr><td colspan="4" class="center">მონაცემები არ არის</td></tr>
        @endforelse
        <tr class="grandtotal-row h18">
            <td colspan="2" class="center bold">სულ ჯამში</td>
            <td class="center bold">{{ $smallCountTotal ?: '' }}</td>
            <td class="right bold">{{ number_format((float) $smallVolumeTotal, 3, '.', '') }}</td>
        </tr>
    </tbody>
</table>

<div class="section-caption head-green-dark">ჯამური მონაცემები</div>
<table class="outer">
    <colgroup>
        <col style="width:4.5%">
        <col style="width:24.5%">
        <col style="width:8.5%">
        <col style="width:10.5%">
        <col style="width:10.5%">
        <col style="width:10%">
        <col style="width:10%">
        <col style="width:11%">
        <col style="width:10.5%">
    </colgroup>
    <thead>
        <tr class="head-green header-top h20">
            <th rowspan="2">№</th>
            <th rowspan="2">სახეობა (ჯიში)</th>
            <th rowspan="2">ხეების ოდენობა</th>
            <th colspan="2">გასაცემი მერქანი</th>
            <th colspan="2">8 სმ-ზე ნაკლები დიამეტრი</th>
            <th rowspan="2">გაცემა</th>
            <th rowspan="2">შენიშვნა</th>
        </tr>
        <tr class="head-green tiny tight header-sub h18">
            <th>I ხარისხი</th>
            <th>II ხარისხი</th>
            <th>რაოდენობა</th>
            <th>მოცულობა</th>
        </tr>
    </thead>
    <tbody>
        @forelse($sectionThreeRows as $idx => $row)
            <tr>
                <td class="center">{{ $idx + 1 }}</td>
                <td class="left wrap">{{ trim((string) ($row['species_name'] ?? '')) }}@if(!empty($row['species_latin_name']))<span class="latin-name">{{ $row['species_latin_name'] }}</span>@endif</td>
                <td class="center">{{ ((int) ($row['q1_count'] ?? 0) + (int) ($row['q2_count'] ?? 0)) ?: '' }}</td>
                <td class="right">{{ number_format((float) ($row['q1_total'] ?? 0), 3, '.', '') }}</td>
                <td class="right">{{ number_format((float) ($row['q2_total'] ?? 0), 3, '.', '') }}</td>
                <td class="center">{{ (int) ($row['small_count'] ?? 0) ?: '' }}</td>
                <td class="right">{{ number_format((float) ($row['small_volume'] ?? 0), 3, '.', '') }}</td>
                <td class="right">{{ number_format((float) ($row['grand_total'] ?? 0), 3, '.', '') }}</td>
                <td class="left wrap">{{ $row['note'] ?: '' }}</td>
            </tr>
        @empty
            <tr><td colspan="9" class="center">მონაცემები არ არის</td></tr>
        @endforelse
        <tr class="grandtotal-row h18">
            <td colspan="2" class="center bold">სულ ჯამში</td>
            <td class="center bold">{{ ((int) ($totals['q1_count'] ?? 0) + (int) ($totals['q2_count'] ?? 0)) ?: '' }}</td>
            <td class="right bold">{{ number_format((float) ($totals['q1_total'] ?? 0), 3, '.', '') }}</td>
            <td class="right bold">{{ number_format((float) ($totals['q2_total'] ?? 0), 3, '.', '') }}</td>
            <td class="center bold">{{ $smallCountTotal ?: '' }}</td>
            <td class="right bold">{{ number_format((float) $smallVolumeTotal, 3, '.', '') }}</td>
            <td class="right bold">{{ number_format((float) (($totals['all_total'] ?? 0) + $smallVolumeTotal), 3, '.', '') }}</td>
            <td></td>
        </tr>
    </tbody>
</table>

<table class="outer meta" style="margin-top:4px;">
    <colgroup>
        <col style="width:18%">
        <col style="width:32%">
        <col style="width:20%">
        <col style="width:30%">
    </colgroup>
    <tr>
        <td class="left bold">ტყეკაფის მომნიშნავი:</td>
        <td class="left wrap">{{ $markerDisplay }}</td>
        <td class="left bold">უწყისის შედგენის თარიღი:</td>
        <td class="center">{{ $reportDate }}</td>
    </tr>
    <tr>
        <td class="left bold">ხელმოწერა:</td>
        <td colspan="3" class="signature-box">
            @if($signatureBase64)
                <img src="{{ $signatureBase64 }}" alt="ხელმოწერა" class="signature-image">
            @endif
            <div class="signature-line"></div>
        </td>
    </tr>
</table>

<div class="footer-note">{{ $noteText }}</div>
</body>
</html>