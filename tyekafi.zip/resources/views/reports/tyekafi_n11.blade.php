<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>დანართი №11</title>
    <style>
        @page {
            size: A4 portrait;
            margin: 6mm 6mm 7mm 6mm;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 7.15px;
            color: #000;
            margin: 0;
            padding: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin: 0;
        }

        td, th {
            border: 0.8px solid #000;
            padding: 1.1px 1.9px;
            vertical-align: middle;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.02;
        }

        th {
            font-weight: bold;
            text-align: center;
        }

        .no-border td,
        .no-border th {
            border: none !important;
        }

        .outer {
            border: 1.4px solid #000;
        }

        .center { text-align: center; }
        .left { text-align: left; }
        .right { text-align: right; }
        .top { vertical-align: top; }
        .middle { vertical-align: middle; }
        .bold { font-weight: bold; }
        .wrap { white-space: pre-line; }
        .nowrap { white-space: nowrap; }

        .green {
            background: #E2EFDA;
        }

        .green-dark {
            background: #C6E0B4;
        }

        .header-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin: 0 0 2px 0;
        }

        .header-table td {
            border: none !important;
            vertical-align: middle;
            padding: 0;
        }

        .brand-cell {
            width: 272px;
        }

        .brand-wrap {
            width: 100%;
        }

        .brand-logo-cell {
            width: 64px;
            vertical-align: middle;
        }

        .brand-text-cell {
            vertical-align: middle;
            padding-left: 8px;
        }

        .brand-text {
            font-size: 9.9px;
            font-weight: bold;
            line-height: 1.1;
            text-align: left;
            white-space: pre-line;
        }

        .header-title {
            font-size: 15.5px;
            font-weight: bold;
            text-align: center;
            vertical-align: middle;
        }

        .header-annex {
            width: 110px;
            font-size: 10px;
            font-weight: bold;
            text-align: right;
            vertical-align: top;
        }

        .logo-img {
            display: block;
            max-width: 58px;
            max-height: 58px;
            width: auto;
            height: auto;
            object-fit: contain;
        }

        .latin-name {
            display: block;
            font-style: italic;
        }

        .subtotal-label {
            line-height: 1.05;
        }

        .nowrap { white-space: nowrap; }

        .meta-tight td { padding-top: 1.3px; padding-bottom: 1.3px; }
        .subtotal-row td { border-top-width: 1.3px; border-bottom-width: 1.2px; }
        .grandtotal-row td { border-top-width: 1.45px; border-bottom-width: 1.45px; }
        .species-cell { line-height: 0.99; }
        .note-cell { line-height: 0.97; font-size: 6.65px; }

        .meta td {
            font-size: 7.6px;
            padding: 1.2px 2px;
            vertical-align: middle;
            line-height: 1.05;
            display: table-cell;
        }

        .meta .label {
            font-weight: bold;
            white-space: nowrap;
        }

                .section-title {
            font-size: 9.1px;
            font-weight: bold;
            text-align: center;
            padding: 2.7px 3px;
            letter-spacing: 0.05px;
            line-height: 1.08;
        }

        .header-top th { vertical-align: middle; padding-top: 1.3px; padding-bottom: 1.3px; }
        .header-sub th { font-size: 5.95px; line-height: 0.94; padding-top: 0.55px; padding-bottom: 0.55px; }
        .subtotal-row td { background: #E2EFDA; font-weight: bold; line-height: 0.98; border-top-width:1.25px; border-bottom-width:1.15px; }
        .grandtotal-row td { background: #D8E4BC; font-weight: bold; line-height: 0.98; border-top-width:1.45px; border-bottom-width:1.45px; }
        .meta-row td { padding-top: 1.2px; padding-bottom: 1.2px; height: 18px; }

.small {
            font-size: 7px;
        }

        .tiny {
            font-size: 6.7px;
        }

        .h16 td, .h16 th { height: 16px; }
        .h18 td, .h18 th { height: 18px; }
        .h20 td, .h20 th { height: 19px; }
        .h22 td, .h22 th { height: 20.5px; }
        .h24 td, .h24 th { height: 23px; }
        .h26 td, .h26 th { height: 26px; }
        .h54 td, .h54 th { height: 52px; }

        tr {
            page-break-inside: avoid;
        }

        thead {
            display: table-header-group;
        }

        .meta td { line-height: 1.04; vertical-align: middle !important; }
        .tight td, .tight th { padding-top: 1px; padding-bottom: 1px; }
        .label-wide { letter-spacing: 0.01px; }
        .quality-table td, .quality-table th { border-color:#000; }
        .small-table td, .small-table th { border-color:#000; }
        .summary-table td, .summary-table th { border-color:#000; }

    
.wrap-label {
    white-space: normal;
    line-height: 1.1;
    text-align: center;
    vertical-align: middle;
}
</style>
</head>
<body>
@php
    $forestUseBasisTitle = \App\Models\ForestUseBasis::query()
        ->where('code', $tyekafi->forest_use_basis)
        ->value('title') ?: '—';

    $logoBase64 = null;
    foreach ([
        public_path('images/logo.png'),
        public_path('images/company-logo.png'),
        public_path('img/logo.png'),
        public_path('logo.png'),
    ] as $logoFile) {
        if (file_exists($logoFile)) {
            $ext = strtolower(pathinfo($logoFile, PATHINFO_EXTENSION));
            $mime = $ext === 'png' ? 'image/png' : 'image/' . $ext;
            $logoBase64 = 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($logoFile));
            break;
        }
    }

    $companyDisplayName = "საქართველოს
სატყეო სერვისები";

    $formatSpeciesLabel = static function (string $speciesName, string $latinName = ''): string {
        $speciesName = trim($speciesName);
        $latinName = trim($latinName);

        return e($speciesName) . ($latinName !== '' ? '<span class="latin-name">' . e($latinName) . '</span>' : '');
    };

    $normalizeRedListNote = static function ($note): string {
        $parts = array_values(array_filter(array_map(
            static fn ($value) => trim((string) $value),
            preg_split('/\R+/', trim((string) $note)) ?: []
        )));

        return in_array('წითელი ნუსხა', $parts, true) ? 'წითელი ნუსხა' : '';
    };

    $markerPosition = trim((string) ($tyekafi->user?->position ?? ''));
    $markerFullName = trim(collect([
        $tyekafi->user?->name,
        $tyekafi->user?->surname,
    ])->filter(fn ($v) => trim((string) $v) !== '')->implode(' '));

    $markerDisplay = trim(implode("\n", array_values(array_filter([
        $markerPosition,
        $markerFullName,
    ]))));
    if ($markerDisplay === '') {
        $markerDisplay = '—';
    }

    $qualityGroups = [];
    $qualityTotals = [
        'q1_count' => 0,
        'q1_liquid' => 0.0,
        'q1_firewood' => 0.0,
        'q2_count' => 0,
        'q2_liquid' => 0.0,
        'q2_firewood' => 0.0,
        'all_total' => 0.0,
    ];

    foreach (($reportRows ?? []) as $row) {
        $speciesName = trim((string) ($row['species_name'] ?? ''));
        if ($speciesName === '') {
            continue;
        }

        $speciesLatinName = trim((string) ($row['species_latin_name'] ?? ''));
        $diameter = (string) ($row['diameter_cm'] ?? '—');

        if (!isset($qualityGroups[$speciesName])) {
            $qualityGroups[$speciesName] = [
                'species_name' => $speciesName,
                'species_latin_name' => $speciesLatinName,
                'rows' => [],
                'q1_count' => 0,
                'q1_liquid' => 0.0,
                'q1_firewood' => 0.0,
                'q2_count' => 0,
                'q2_liquid' => 0.0,
                'q2_firewood' => 0.0,
                'all_total' => 0.0,
                'notes' => [],
            ];
        }

        if (!isset($qualityGroups[$speciesName]['rows'][$diameter])) {
            $qualityGroups[$speciesName]['rows'][$diameter] = [
                'diameter_cm' => $diameter,
                'q1_count' => 0,
                'q1_liquid' => 0.0,
                'q1_firewood' => 0.0,
                'q2_count' => 0,
                'q2_liquid' => 0.0,
                'q2_firewood' => 0.0,
                'all_total' => 0.0,
                'notes' => [],
            ];
        }

        foreach (['q1_count', 'q2_count'] as $k) {
            $value = (int) ($row[$k] ?? 0);
            $qualityGroups[$speciesName]['rows'][$diameter][$k] += $value;
            $qualityGroups[$speciesName][$k] += $value;
            $qualityTotals[$k] += $value;
        }

        foreach (['q1_liquid', 'q1_firewood', 'q2_liquid', 'q2_firewood', 'all_total'] as $k) {
            $value = (float) ($row[$k] ?? 0);
            $qualityGroups[$speciesName]['rows'][$diameter][$k] += $value;
            $qualityGroups[$speciesName][$k] += $value;
            $qualityTotals[$k] += $value;
        }

        if ($qualityGroups[$speciesName]['species_latin_name'] === '' && $speciesLatinName !== '') {
            $qualityGroups[$speciesName]['species_latin_name'] = $speciesLatinName;
        }

        $note = $normalizeRedListNote($row['note'] ?? '');
        if ($note !== '') {
            $qualityGroups[$speciesName]['rows'][$diameter]['notes'] = array_values(array_unique(array_merge(
                $qualityGroups[$speciesName]['rows'][$diameter]['notes'],
                [$note]
            )));
            $qualityGroups[$speciesName]['notes'] = array_values(array_unique(array_merge(
                $qualityGroups[$speciesName]['notes'],
                [$note]
            )));
        }
    }

    ksort($qualityGroups, SORT_NATURAL);

    foreach ($qualityGroups as &$group) {
        ksort($group['rows'], SORT_NATURAL);

        foreach ($group['rows'] as &$item) {
            $item['note'] = implode("\n", $item['notes']);
        }
        unset($item);

        $group['note'] = implode("\n", $group['notes']);
        $group['rows'] = array_values($group['rows']);
    }
    unset($group);

    $smallDiameterTotals = [
        'count' => 0,
        'volume' => 0.0,
    ];

    foreach (($smallDiameterRows ?? []) as $smallRow) {
        $smallDiameterTotals['count'] += (int) ($smallRow['count'] ?? 0);
        $smallDiameterTotals['volume'] += (float) ($smallRow['volume'] ?? 0);
    }

    $summaryCombined = [];

    foreach (($speciesSummaryRows ?? []) as $row) {
        $speciesName = trim((string) ($row['species_name'] ?? '—'));
        $summaryCombined[$speciesName] = [
            'species_name' => $speciesName,
            'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
            'note' => $normalizeRedListNote($row['note'] ?? ''),
            'all_count' => (int) ($row['all_count'] ?? 0),
            'q1_total' => (float) ($row['q1_total'] ?? 0),
            'q2_total' => (float) ($row['q2_total'] ?? 0),
            'small_count' => 0,
            'small_volume' => 0.0,
        ];
    }

    foreach (($smallDiameterRows ?? []) as $row) {
        $speciesName = trim((string) ($row['species_name'] ?? '—'));
        if (!isset($summaryCombined[$speciesName])) {
            $summaryCombined[$speciesName] = [
                'species_name' => $speciesName,
                'species_latin_name' => trim((string) ($row['species_latin_name'] ?? '')),
                'note' => '',
                'all_count' => 0,
                'q1_total' => 0.0,
                'q2_total' => 0.0,
                'small_count' => 0,
                'small_volume' => 0.0,
            ];
        }

        if (($summaryCombined[$speciesName]['species_latin_name'] ?? '') === '' && trim((string) ($row['species_latin_name'] ?? '')) !== '') {
            $summaryCombined[$speciesName]['species_latin_name'] = trim((string) ($row['species_latin_name'] ?? ''));
        }

        $summaryCombined[$speciesName]['small_count'] += (int) ($row['count'] ?? 0);
        $summaryCombined[$speciesName]['small_volume'] += (float) ($row['volume'] ?? 0);
    }

    ksort($summaryCombined, SORT_NATURAL);
@endphp

<table class="header-table">
    <tr style="height:18px;">
        <td colspan="2" class="header-annex">დანართი № 11</td>
    </tr>
    <tr style="height:32px;">
        <td colspan="2" class="header-title">ტყეკაფის პასპორტი</td>
    </tr>
    <tr style="height:20px;">
        <td colspan="2" class="center bold">ტყეკაფი №</td>
    </tr>
</table>

<table class="outer meta meta-compact">
    <colgroup>
        <col style="width:3.1%">
        <col style="width:6.5%">
        <col style="width:9.8%">
        <col style="width:8.8%">
        <col style="width:8.1%">
        <col style="width:8.3%">
        <col style="width:7.7%">
        <col style="width:8.1%">
        <col style="width:8.3%">
        <col style="width:7.7%">
        <col style="width:9.0%">
        <col style="width:6.7%">
        <col style="width:7.9%">
    </colgroup>

    <tr class="h18 meta-row">
        <td colspan="4" class="label left">1. ტყითსარგებლობის საფუძველი:</td>
        <td colspan="9" class="left">{{ $forestUseBasisTitle }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">2. ტყითმოსარგებლე:</td>
        <td colspan="4" class="left">{{ $tyekafi->forest_user_name ?: '—' }}</td>
        <td colspan="2" class="label center">ს/ნ</td>
        <td colspan="3" class="left">{{ $tyekafi->forest_user_id_code ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">3. ტყითმოსარგებლის მისამართი:</td>
        <td colspan="9" class="left">{{ $tyekafi->forest_user_address ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">4. მართვის ორგანო:</td>
        <td colspan="9" class="left">{{ $tyekafi->governingBody?->name ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">5. რეგიონი:</td>
        <td colspan="9" class="left">{{ $tyekafi->region?->name ?: ($tyekafi->forestDistrict?->region?->name ?: '—') }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">6. სატყეო უბანი:</td>
        <td colspan="3" class="left">{{ $tyekafi->forestDistrict?->name ?: '—' }}</td>
        <td colspan="2" class="label left">7. სატყეო:</td>
        <td colspan="4" class="left">{{ $tyekafi->forest?->name ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">8. კვარტალი №:</td>
        <td colspan="3" class="left">{{ $tyekafi->display_quarter }}</td>
        <td colspan="2" class="label left">9. ლიტერ(ებ)ი №:</td>
        <td colspan="4" class="left">{{ $tyekafi->display_liters }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">10. ტყეკაფის ფართობი:</td>
        <td colspan="3" class="left">{{ number_format((float) ($tyekafi->area_ha ?? 0), 4, '.', '') }}</td>
        <td colspan="2" class="label left">11. ჭრის მიზანი:</td>
        <td colspan="4" class="left">{{ $tyekafi->cut_purpose ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">12. ჭრის სახე:</td>
        <td colspan="3" class="left">{{ $tyekafi->cut_type ?: '—' }}</td>
        <td colspan="3" class="label wrap-label left">13. ტყეკაფის მონიშვნის<br>წარდგენის თარიღი:</td>
        <td colspan="3" class="left"></td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">14. ტყეკაფის მომნიშნავი:</td>
        <td colspan="3" class="left wrap">{{ $markerDisplay }}</td>
        <td colspan="3" class="label left">15. ხეთა რაოდენობა:</td>
        <td colspan="3" class="left">{{ ($totals['all_count'] ?? 0) ? (($totals['all_count'] ?? 0) . ' ძირი') : '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">16. სიხშირე:</td>
        <td colspan="3" class="left">{{ $tyekafi->frequency_actual ?: '—' }}</td>
        <td colspan="3" class="label left">17. ხნოვანება:</td>
        <td colspan="3" class="left">{{ $tyekafi->age_actual ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">18. მოზარდ-აღმონაცენი:</td>
        <td colspan="9" class="left">{{ $tyekafi->regen_count_actual ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">19. ს.ზ.დ.:</td>
        <td colspan="3" class="left">{{ $tyekafi->szd ?: '—' }}</td>
        <td colspan="3" class="label left">20. დაქანება:</td>
        <td colspan="3" class="left">{{ $tyekafi->slope_actual ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">21. ექსპოზიცია:</td>
        <td colspan="9" class="left">{{ $tyekafi->exposure_actual ?: '—' }}</td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">22. ტყეკაფის დახურვის<br>(ათვისების დასრულების) თარიღი:</td>
        <td colspan="9" class="left"></td>
    </tr>

    <tr class="h18">
        <td colspan="4" class="label left">23. ტყეკაფის გაუქმების თარიღი:</td>
        <td colspan="9" class="left"></td>
    </tr>

    <tr class="h18">
        <td colspan="4" rowspan="2" class="label left middle">24. GPS კოორდინატები </td>
        <td colspan="2" class="center bold">X1</td>
        <td colspan="2" class="center bold">X2</td>
        <td colspan="2" class="center bold">Y1</td>
        <td colspan="3" class="center bold">Y2</td>
    </tr>
    <tr class="h18">
        <td colspan="2" class="center">{{ $tyekafi->gps_x1 ?: '—' }}</td>
        <td colspan="2" class="center">{{ $tyekafi->gps_x2 ?: '—' }}</td>
        <td colspan="2" class="center">{{ $tyekafi->gps_y1 ?: '—' }}</td>
        <td colspan="3" class="center">{{ $tyekafi->gps_y2 ?: '—' }}</td>
    </tr>
</table>

<table class="outer" style="margin-top:4px;">
    <colgroup>
        <col style="width:25%">
        <col style="width:50%">
        <col style="width:25%">
    </colgroup>
    <tr class="green-dark">
        <td colspan="3" class="section-title">კორომის შემადგენლობა</td>
    </tr>
    <tr class="green h18">
        <th>ერთეული</th>
        <th>სახეობა (ჯიში)</th>
        <th>თანრიგი</th>
    </tr>

    @forelse(($pdf_n11['composition_rows'] ?? []) as $row)
        <tr class="h18">
            <td class="center">{{ $row['unit'] ?? '+' }}</td>
            <td class="center wrap">
                {{ $row['species'] ?? '—' }}
                @if(!empty($row['species_latin_name']))
                    <span class="latin-name">{{ $row['species_latin_name'] }}</span>
                @endif
            </td>
            <td class="center">{{ $row['rank'] ?? '—' }}</td>
        </tr>
    @empty
        <tr class="h18">
            <td colspan="3" class="center">მონაცემები არ არის</td>
        </tr>
    @endforelse
</table>

<table class="outer quality-table section-table" style="margin-top:4px;">
    <colgroup>
        <col style="width:3.2%">
        <col style="width:6.6%">
        <col style="width:9.4%">
        <col style="width:9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.7%">
        <col style="width:6.6%">
        <col style="width:7.1%">
    </colgroup>
    <tr class="green-dark">
        <td colspan="13" class="section-title">ხის ხარისხის მიხედვით</td>
    </tr>
    <tr class="green h18 header-top">
        <th rowspan="3">№</th>
        <th colspan="2" rowspan="3">სახეობა (ჯიში)</th>
        <th rowspan="3">დიამეტრი</th>
        <th colspan="3">I ხარისხი</th>
        <th colspan="3">II ხარისხი</th>
        <th rowspan="3">გასაცემი მერქანი სულ</th>
        <th colspan="2" rowspan="3">შენიშვნა</th>
    </tr>
    <tr class="green h18">
        <th colspan="3">ხის ხარისხის მიხედვით</th>
        <th colspan="3">ხის ხარისხის მიხედვით</th>
    </tr>
    <tr class="green h22 tiny header-sub">
        <th>ხეთა რაოდენობა</th>
        <th>ლიკვიდური მერქანი</th>
        <th>შეშა ვარჯიდან</th>
        <th>ხეთა რაოდენობა</th>
        <th>ლიკვიდური მერქანი</th>
        <th>შეშა ვარჯიდან</th>
    </tr>

    @php $qualityIndex = 1; @endphp
    @forelse($qualityGroups as $group)
        @foreach($group['rows'] as $item)
            <tr class="h18">
                <td class="center">{{ $qualityIndex++ }}</td>
                <td colspan="2" class="left wrap species-cell">{!! $formatSpeciesLabel($group['species_name'], $group['species_latin_name'] ?? '') !!}</td>
                <td class="center">{{ $item['diameter_cm'] ?: '—' }}</td>
                <td class="center">{{ $item['q1_count'] ?: '' }}</td>
                <td class="center">{{ number_format((float) $item['q1_liquid'], 3, '.', '') }}</td>
                <td class="center">{{ number_format((float) $item['q1_firewood'], 3, '.', '') }}</td>
                <td class="center">{{ $item['q2_count'] ?: '' }}</td>
                <td class="center">{{ number_format((float) $item['q2_liquid'], 3, '.', '') }}</td>
                <td class="center">{{ number_format((float) $item['q2_firewood'], 3, '.', '') }}</td>
                <td class="center">{{ number_format((float) $item['all_total'], 3, '.', '') }}</td>
                <td colspan="2" class="left wrap note-cell">{{ $normalizeRedListNote($item['note'] ?? '') }}</td>
            </tr>
        @endforeach

        <tr class="subtotal-row h18">
            <td colspan="3" class="left bold subtotal-label">სულ - "{{ $group['species_name'] }}"@if(!empty($group['species_latin_name']))<span class="latin-name">{{ $group['species_latin_name'] }}</span>@endif</td>
            <td></td>
            <td class="center bold">{{ $group['q1_count'] ?: '' }}</td>
            <td class="center bold">{{ number_format((float) $group['q1_liquid'], 3, '.', '') }}</td>
            <td class="center bold">{{ number_format((float) $group['q1_firewood'], 3, '.', '') }}</td>
            <td class="center bold">{{ $group['q2_count'] ?: '' }}</td>
            <td class="center bold">{{ number_format((float) $group['q2_liquid'], 3, '.', '') }}</td>
            <td class="center bold">{{ number_format((float) $group['q2_firewood'], 3, '.', '') }}</td>
            <td class="center bold">{{ number_format((float) $group['all_total'], 3, '.', '') }}</td>
            <td colspan="2" class="left wrap bold">{{ $normalizeRedListNote($group['note'] ?? '') }}</td>
        </tr>
    @empty
        <tr class="h18">
            <td colspan="13" class="center">მონაცემები არ არის</td>
        </tr>
    @endforelse

    <tr class="grandtotal-row h18">
        <td colspan="3" class="left bold">სულ ჯამში</td>
        <td></td>
        <td class="center bold">{{ $qualityTotals['q1_count'] ?: '' }}</td>
        <td class="center bold">{{ number_format((float) $qualityTotals['q1_liquid'], 3, '.', '') }}</td>
        <td class="center bold">{{ number_format((float) $qualityTotals['q1_firewood'], 3, '.', '') }}</td>
        <td class="center bold">{{ $qualityTotals['q2_count'] ?: '' }}</td>
        <td class="center bold">{{ number_format((float) $qualityTotals['q2_liquid'], 3, '.', '') }}</td>
        <td class="center bold">{{ number_format((float) $qualityTotals['q2_firewood'], 3, '.', '') }}</td>
        <td class="center bold">{{ number_format((float) $qualityTotals['all_total'], 3, '.', '') }}</td>
        <td colspan="2"></td>
    </tr>
</table>

<table class="outer small-table section-table" style="margin-top:4px;">
    <colgroup>
        <col style="width:3.2%">
        <col style="width:6.6%">
        <col style="width:9.4%">
        <col style="width:9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.7%">
        <col style="width:6.6%">
        <col style="width:7.1%">
    </colgroup>
    <tr class="green-dark">
        <td colspan="13" class="section-title">გარდა ამისა ტერიტორიაზე აღრიცხული 8 სმ_მდე ტაქსაციური დიამეტრის ხე მცენარეები</td>
    </tr>
    <tr class="green h18 header-top">
        <th rowspan="2">№</th>
        <th colspan="5" rowspan="2">სახეობა (ჯიში)</th>
        <th colspan="3">რაოდენობა</th>
        <th colspan="4">მოცულობა</th>
    </tr>
    <tr class="green h18 tiny header-sub">
        <th colspan="3">ხეთა რაოდენობა</th>
        <th colspan="4">კუბ.მ</th>
    </tr>

    @forelse(($smallDiameterRows ?? []) as $i => $item)
        <tr class="h18">
            <td class="center">{{ $i + 1 }}</td>
            <td colspan="5" class="left wrap">{!! $formatSpeciesLabel($item['species_name'] ?? '—', $item['species_latin_name'] ?? '') !!}</td>
            <td colspan="3" class="center">{{ (int) ($item['count'] ?? 0) ?: '' }}</td>
            <td colspan="4" class="center">{{ number_format((float) ($item['volume'] ?? 0), 3, '.', '') }}</td>
        </tr>
    @empty
        <tr class="h18">
            <td colspan="13" class="center">მონაცემები არ არის</td>
        </tr>
    @endforelse

    <tr class="grandtotal-row h18">
        <td colspan="6" class="left bold">სულ ჯამში</td>
        <td colspan="3" class="center bold">{{ $smallDiameterTotals['count'] ?: '' }}</td>
        <td colspan="4" class="center bold">{{ number_format((float) $smallDiameterTotals['volume'], 3, '.', '') }}</td>
    </tr>
</table>

<table class="outer summary-table section-table" style="margin-top:4px;">
    <colgroup>
        <col style="width:3.2%">
        <col style="width:6.6%">
        <col style="width:9.4%">
        <col style="width:9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.7%">
        <col style="width:6.6%">
        <col style="width:7.1%">
    </colgroup>
    <tr class="green-dark">
        <td colspan="13" class="section-title">ჯამური მონაცემები</td>
    </tr>
    <tr class="green h18">
        <th rowspan="2">№</th>
        <th colspan="3" rowspan="2">სახეობა (ჯიში)</th>
        <th colspan="2">I ხარისხი</th>
        <th colspan="3">II ხარისხი</th>
        <th colspan="2">8 სმ-მდე</th>
        <th rowspan="2">სულ</th>
        <th rowspan="2">შენიშვნა</th>
    </tr>
    <tr class="green h22 tiny header-sub">
        <th>რაოდ.</th>
        <th>მოცულობა</th>
        <th>რაოდ.</th>
        <th>ლიკვიდი</th>
        <th>შეშა</th>
        <th>რაოდენობა</th>
        <th>მოცულობა</th>
    </tr>

    @php $sumIndex = 1; @endphp
    @forelse($summaryCombined as $row)
        <tr class="h18">
            <td class="center">{{ $sumIndex++ }}</td>
            <td colspan="3" class="left wrap">{!! $formatSpeciesLabel($row['species_name'], $row['species_latin_name'] ?? '') !!}</td>
            <td class="center">{{ $row['all_count'] ?: '' }}</td>
            <td class="center">{{ number_format((float) $row['q1_total'], 3, '.', '') }}</td>
            <td class="center"></td>
            <td class="center">{{ number_format((float) $row['q2_total'], 3, '.', '') }}</td>
            <td class="center">0.000</td>
            <td class="center">{{ $row['small_count'] ?: '' }}</td>
            <td class="center">{{ number_format((float) $row['small_volume'], 3, '.', '') }}</td>
            <td class="center">{{ number_format((float) ($row['q1_total'] + $row['q2_total'] + $row['small_volume']), 3, '.', '') }}</td>
            <td class="left wrap">{{ $normalizeRedListNote($row['note'] ?? '') }}</td>
        </tr>
    @empty
        <tr class="h18">
            <td colspan="13" class="center">მონაცემები არ არის</td>
        </tr>
    @endforelse

    <tr class="grandtotal-row h18">
        <td colspan="4" class="left bold">სულ ჯამში</td>
        <td class="center bold">{{ $totals['q1_count'] ?: '' }}</td>
        <td class="center bold">{{ number_format((float) (($totals['q1_liquid'] ?? 0) + ($totals['q1_firewood'] ?? 0)), 3, '.', '') }}</td>
        <td class="center bold">{{ $totals['q2_count'] ?: '' }}</td>
        <td class="center bold">{{ number_format((float) ($totals['q2_liquid'] ?? 0), 3, '.', '') }}</td>
        <td class="center bold">{{ number_format((float) ($totals['q2_firewood'] ?? 0), 3, '.', '') }}</td>
        <td class="center bold">{{ $smallDiameterTotals['count'] ?: '' }}</td>
        <td class="center bold">{{ number_format((float) $smallDiameterTotals['volume'], 3, '.', '') }}</td>
        <td class="center bold">{{ number_format((float) (($totals['all_total'] ?? 0) + $smallDiameterTotals['volume']), 3, '.', '') }}</td>
        <td></td>
    </tr>
</table>

<table class="outer meta" style="margin-top:4px;">
    <colgroup>
        <col style="width:3.2%">
        <col style="width:6.6%">
        <col style="width:9.4%">
        <col style="width:9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.4%">
        <col style="width:8.4%">
        <col style="width:7.9%">
        <col style="width:8.7%">
        <col style="width:6.6%">
        <col style="width:7.1%">
    </colgroup>
    <tr class="h18">
        <td colspan="4" class="label wrap-label">ტყეკაფის პასპორტის გამცემი<br>უფლებამოსილი პირი:</td>
        <td colspan="9" class="left wrap"></td>
    </tr>
    <tr class="h54">
        <td colspan="4" class="label center middle">ხელმოწერა:</td>
        <td colspan="5" class="middle"></td>
        <td colspan="2" class="label wrap-label">აქტის შედგენის<br>თარიღი:</td>
        <td colspan="2" class="center middle">{{ $reportDate }}</td>
    </tr>
</table>

</body>
</html>