<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <title>კომპენსაციის რეპორტი მართვის ორგანოების მიხედვით</title>
    <style>
        @page { size: A4 portrait; margin: 12mm 10mm 12mm 10mm; }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
            color: #111827;
        }

        .title {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 2px;
        }

        .subtitle {
            text-align: center;
            font-size: 11px;
            margin-bottom: 10px;
        }

        .meta {
            margin-bottom: 10px;
            font-size: 10px;
            line-height: 1.45;
        }

        .section-title {
            font-size: 12px;
            font-weight: bold;
            margin: 12px 0 6px;
            padding: 5px 7px;
            background: #eef6ef;
            border: 1px solid #a7c4a0;
        }

        .subsection-title {
            font-size: 11px;
            font-weight: bold;
            margin: 10px 0 5px;
            padding: 4px 6px;
            background: #f5f5f5;
            border: 1px solid #d1d5db;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 8px;
        }

        th, td {
            border: 1px solid #444;
            padding: 4px 5px;
            vertical-align: middle;
        }

        th {
            background: #f3f4f6;
            font-weight: bold;
        }

        .summary th {
            background: #dff0e1;
        }

        .right { text-align: right; }
        .center { text-align: center; }
        .small { font-size: 9px; }
        .latin { font-style: italic; font-size: 9px; color: #374151; }
        .red-badge { color: #b91c1c; font-weight: bold; }
        .muted { color: #4b5563; }

        .body-summary th {
            background: #f0fdf4;
        }

        .subtotal-row th,
        .subtotal-row td {
            background: #ecfdf5;
            font-weight: bold;
        }

        .red-subtotal-row th,
        .red-subtotal-row td {
            background: #fee2e2;
            font-weight: bold;
        }

        .page-break {
            page-break-before: always;
        }

        .no-border {
            border: none !important;
        }
    </style>
</head>
<body>
    <div class="title">კომპენსაციის რეპორტი მართვის ორგანოების მიხედვით</div>
    <div class="subtitle">პროექტი: {{ $project->name }}</div>

    <div class="meta">
        <strong>რეპორტის თარიღი:</strong> {{ $generatedAt }}<br>
        <strong>სარგებლობის ვადის ინტერვალი:</strong> {{ $yearsRange ?? '0-5' }}<br>
        <strong>მართვის ორგანოების რაოდენობა:</strong> {{ count($governingBodyCompensations ?? []) }}<br>
        <strong>ტყეკაფების რაოდენობა:</strong> {{ count($tyekafiCompensations ?? []) }}
    </div>

    <div class="section-title">I. საერთო შეჯამება</div>

    <table class="summary">
        <thead>
            <tr>
                <th>მართვის ორგანო</th>
                <th class="center">ტყეკაფები</th>
                <th class="center">სახეობები</th>
                <th class="center">Red List</th>
                <th class="right">ფართობი (ჰა)</th>
                <th class="right">ხემცენარეების კომპენსაცია (₾)</th>
                <th class="right">ფართობის კომპენსაცია (₾)</th>
                <th class="right">სულ (₾)</th>
            </tr>
        </thead>
        <tbody>
            @forelse(($governingBodyCompensations ?? []) as $body)
                <tr>
                    <td>{{ $body['name'] ?? '—' }}</td>
                    <td class="center">{{ (int) ($body['tyekafi_count'] ?? 0) }}</td>
                    <td class="center">{{ count((array) ($body['species_rows'] ?? [])) }}</td>
                    <td class="center">{{ (int) ($body['red_list_species_count'] ?? 0) }}</td>
                    <td class="right">{{ number_format((float) ($body['area_ha'] ?? 0), 4, '.', '') }}</td>
                    <td class="right">{{ number_format((float) ($body['wood_compensation'] ?? 0), 3, '.', '') }}</td>
                    <td class="right">{{ number_format((float) ($body['area_compensation'] ?? 0), 3, '.', '') }}</td>
                    <td class="right"><strong>{{ number_format((float) ($body['total_compensation'] ?? 0), 3, '.', '') }}</strong></td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="center">მონაცემები არ არის.</td>
                </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr>
                <th>სულ</th>
                <th class="center">{{ count($tyekafiCompensations ?? []) }}</th>
                <th class="center">{{ collect($governingBodyCompensations ?? [])->sum(fn ($body) => count((array) ($body['species_rows'] ?? []))) }}</th>
                <th class="center">{{ collect($governingBodyCompensations ?? [])->sum('red_list_species_count') }}</th>
                <th class="right">{{ number_format((float) collect($governingBodyCompensations ?? [])->sum('area_ha'), 4, '.', '') }}</th>
                <th class="right">{{ number_format((float) ($woodCompensation ?? 0), 3, '.', '') }}</th>
                <th class="right">{{ number_format((float) ($areaCompensation ?? 0), 3, '.', '') }}</th>
                <th class="right">{{ number_format((float) ($totalCompensation ?? 0), 3, '.', '') }}</th>
            </tr>
        </tfoot>
    </table>

    @foreach(($governingBodyCompensations ?? []) as $body)
        <div class="{{ $loop->first ? '' : 'page-break' }}">
            <div class="section-title">II. მართვის ორგანო: {{ $body['name'] ?? '—' }}</div>

            <table class="body-summary">
                <thead>
                    <tr>
                        <th class="center">ტყეკაფები</th>
                        <th class="center">სახეობები</th>
                        <th class="center">Red List</th>
                        <th class="right">ფართობი (ჰა)</th>
                        <th class="right">ხემცენარეების კომპენსაცია (₾)</th>
                        <th class="right">ფართობის კომპენსაცია (₾)</th>
                        <th class="right">სულ გადასახდელი (₾)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="center">{{ (int) ($body['tyekafi_count'] ?? 0) }}</td>
                        <td class="center">{{ count((array) ($body['species_rows'] ?? [])) }}</td>
                        <td class="center">{{ (int) ($body['red_list_species_count'] ?? 0) }}</td>
                        <td class="right">{{ number_format((float) ($body['area_ha'] ?? 0), 4, '.', '') }}</td>
                        <td class="right">{{ number_format((float) ($body['wood_compensation'] ?? 0), 3, '.', '') }}</td>
                        <td class="right">{{ number_format((float) ($body['area_compensation'] ?? 0), 3, '.', '') }}</td>
                        <td class="right"><strong>{{ number_format((float) ($body['total_compensation'] ?? 0), 3, '.', '') }}</strong></td>
                    </tr>
                </tbody>
            </table>

            <div class="subsection-title">ხემცენარეების მიხედვით საკომპენსაციო თანხა</div>
            <table>
                <thead>
                    <tr>
                        <th>სახეობა</th>
                        <th class="center">ჯგუფი</th>
                        <th class="right">მოცულობა (მ³)</th>
                        <th class="right">ერთეულის ღირებულება</th>
                        <th class="right">K მართვის ორგანო / სახეობა</th>
                        <th class="right">K სარგებლობის ვადა</th>
                        <th class="right">კომპენსაცია (₾)</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $speciesRows = array_values((array) ($body['species_rows'] ?? []));
                        $redListSubtotal = collect($speciesRows)->where('is_red_list', true)->sum('compensation');
                    @endphp

                    @forelse($speciesRows as $row)
                        <tr>
                            <td>
                                {{ $row['species_name'] ?? '—' }}
                                @if(!empty($row['species_latin_name']))
                                    <div class="latin">{{ $row['species_latin_name'] }}</div>
                                @endif
                                @if(!empty($row['is_red_list']))
                                    <div class="red-badge small">წითელი ნუსხა</div>
                                @endif
                            </td>
                            <td class="center">{{ $row['money_group'] ?? '—' }}</td>
                            <td class="right">{{ number_format((float) ($row['volume'] ?? 0), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($row['base_rate'] ?? 0), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($row['body_multiplier'] ?? 0), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($row['year_multiplier'] ?? 1), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($row['compensation'] ?? 0), 3, '.', '') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="center">სახეობების მონაცემები არ არის.</td>
                        </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr class="subtotal-row">
                        <th colspan="6" class="right">ხემცენარეების subtotal</th>
                        <th class="right">{{ number_format((float) ($body['wood_compensation'] ?? 0), 3, '.', '') }}</th>
                    </tr>
                    <tr class="red-subtotal-row">
                        <th colspan="6" class="right">Red List subtotal</th>
                        <th class="right">{{ number_format((float) $redListSubtotal, 3, '.', '') }}</th>
                    </tr>
                </tfoot>
            </table>

            <div class="subsection-title">ფართობის მიხედვით საკომპენსაციო თანხა</div>
            <table>
                <thead>
                    <tr>
                        <th class="right">ფართობი (კვ.მ)</th>
                        <th class="right">საბაზისო კომპენსაცია</th>
                        <th class="right">წლების კოეფიციენტი (K)</th>
                        <th class="right">ფართობის კომპენსაცია (₾)</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $bodyAreaM2 = round(((float) ($body['area_ha'] ?? 0)) * 10000);
                        $bodyYearMultiplier = collect($speciesRows)->pluck('year_multiplier')->filter()->first() ?? 1;
                        $bodyAreaBaseCompensation = $bodyYearMultiplier > 0
                            ? ((float) ($body['area_compensation'] ?? 0) / (float) $bodyYearMultiplier)
                            : (float) ($body['area_compensation'] ?? 0);
                    @endphp
                    <tr>
                        <td class="right">{{ number_format((float) $bodyAreaM2, 0, '.', '') }}</td>
                        <td class="right">{{ number_format((float) $bodyAreaBaseCompensation, 3, '.', '') }}</td>
                        <td class="right">{{ number_format((float) $bodyYearMultiplier, 3, '.', '') }}</td>
                        <td class="right">{{ number_format((float) ($body['area_compensation'] ?? 0), 3, '.', '') }}</td>
                    </tr>
                </tbody>
            </table>

            <div class="subsection-title">ტყეკაფების ჩაშლა</div>
            <table>
                <thead>
                    <tr>
                        <th class="center">ID</th>
                        <th>ტყეკაფი</th>
                        <th>ტყითმოსარგებლე</th>
                        <th class="right">ფართობი (ჰა)</th>
                        <th class="right">ხემცენარეები (₾)</th>
                        <th class="right">ფართობი (₾)</th>
                        <th class="right">Red List (₾)</th>
                        <th class="right">სულ (₾)</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse((array) ($body['tyekafis'] ?? []) as $item)
                        <tr>
                            <td class="center">{{ (int) ($item['tyekafi_id'] ?? 0) }}</td>
                            <td>{{ $item['name'] ?? '—' }}</td>
                            <td>{{ trim((string) ($item['forest_user_name'] ?? '')) !== '' ? $item['forest_user_name'] : '—' }}</td>
                            <td class="right">{{ number_format((float) ($item['area_ha'] ?? 0), 4, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($item['wood_compensation'] ?? 0), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($item['area_compensation'] ?? 0), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($item['red_list_compensation'] ?? 0), 3, '.', '') }}</td>
                            <td class="right">{{ number_format((float) ($item['total_compensation'] ?? 0), 3, '.', '') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="center">ტყეკაფების მონაცემები არ არის.</td>
                        </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr class="subtotal-row">
                        <th colspan="7" class="right">საერთო ჯამი</th>
                        <th class="right">{{ number_format((float) ($body['total_compensation'] ?? 0), 3, '.', '') }}</th>
                    </tr>
                </tfoot>
            </table>

            <div class="subsection-title">ჯამური შედეგი</div>
            <table>
                <thead>
                    <tr>
                        <th>მაჩვენებელი</th>
                        <th class="right">თანხა (₾)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ხემცენარეების კომპენსაცია სულ</td>
                        <td class="right">{{ number_format((float) ($body['wood_compensation'] ?? 0), 3, '.', '') }}</td>
                    </tr>
                    <tr>
                        <td>ფართობის კომპენსაცია</td>
                        <td class="right">{{ number_format((float) ($body['area_compensation'] ?? 0), 3, '.', '') }}</td>
                    </tr>
                    <tr class="subtotal-row">
                        <td>სულ გადასახდელი კომპენსაცია</td>
                        <td class="right">{{ number_format((float) ($body['total_compensation'] ?? 0), 3, '.', '') }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    @endforeach
</body>
</html>