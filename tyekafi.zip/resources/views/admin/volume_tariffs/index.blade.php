<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between gap-4">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    მოცულობის ტარიფები (Excel)
                </h2>
                <div class="text-sm text-gray-500">
                    ტარიფების ცხრილების ატვირთვა და განახლება Excel ფაილიდან
                </div>
            </div>

            <div class="shrink-0">
                <a href="{{ route('admin.tree-catalog.index') }}"
                   class="inline-flex items-center px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition hover:opacity-90"
                   style="background:#2563eb; color:#ffffff; text-decoration:none;">
                    ხეების კატალოგი
                </a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow sm:rounded-lg p-6 space-y-6">

                @if (session('status'))
                    <div class="p-3 rounded bg-green-50 text-green-800 border border-green-200">
                        {{ session('status') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="p-3 rounded bg-red-50 text-red-800 border border-red-200">
                        <div class="font-semibold mb-1">გთხოვ შეასწორო შემდეგი შეცდომები:</div>
                        <ul class="list-disc pl-5 space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="p-4 rounded border bg-white">
                        <div class="text-sm text-gray-500">TariffTables (ჯგუფები)</div>
                        <div class="text-2xl font-semibold">{{ $tablesCount }}</div>
                    </div>

                    <div class="p-4 rounded border bg-white">
                        <div class="text-sm text-gray-500">TariffValues (რიგები)</div>
                        <div class="text-2xl font-semibold">{{ $valuesCount }}</div>
                    </div>

                    <div class="p-4 rounded border bg-white">
                        <div class="text-sm text-gray-500">Species mappings (მიბმები)</div>
                        <div class="text-2xl font-semibold">{{ $mapsCount }}</div>
                    </div>
                </div>

                <div class="p-4 rounded border bg-white">
                    <div class="text-sm text-gray-500">ბოლო განახლება</div>
                    <div class="text-xl font-semibold">
                        {{ $latestUpdatedAt ? $latestUpdatedAt->format('Y-m-d H:i') : '—' }}
                    </div>
                </div>

                <div class="p-5 rounded border bg-white">
                    <h3 class="text-lg font-semibold mb-2">Excel ატვირთვა</h3>

                    <p class="text-sm text-gray-600 mb-4">
                        ატვირთე <b>.xlsx</b> ფაილი. აუცილებელი შიტებია:
                        <b>TariffTables</b>, <b>TariffValues</b>, <b>SpeciesMap</b>.
                        დამატებითი შიტები შეიძლება იყოს, მაგრამ იმპორტში არ გამოიყენება.
                    </p>

                    <div class="mb-4 p-3 rounded bg-blue-50 border border-blue-200 text-sm text-blue-900">
                        <div class="font-semibold mb-1">შენი ამჟამინდელი ფაილი მხარდაჭერილია</div>
                        <div>
                            <b>tanrigebi_1.xlsx</b> სწორ ფორმატშია და ამ გვერდიდან უნდა აიტვირთოს ჩვეულებრივ.
                        </div>
                    </div>

                    <form method="POST"
                          action="{{ route('admin.volume-tariffs.upload') }}"
                          enctype="multipart/form-data"
                          class="space-y-4">
                        @csrf

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">
                                Excel ფაილი
                            </label>
                            <input type="file"
                                   name="file"
                                   accept=".xlsx"
                                   class="block w-full border rounded px-3 py-2 bg-white"
                                   required>
                        </div>

                        @error('file')
                            <div class="text-sm text-red-600">{{ $message }}</div>
                        @enderror

                        <button type="submit"
                                class="inline-flex items-center px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition hover:opacity-90"
                                style="background:#16a34a; color:#ffffff; text-decoration:none;">
                            ატვირთვა და განახლება
                        </button>
                    </form>

                    <div class="mt-4 text-sm text-gray-600 space-y-1">
                        <div>
                            <b>TariffValues</b> სვეტები:
                            table_code, rank, dt_cm, h_min_m, h_max_m, liquid_m3, crown_firewood_m3
                            (სურვილისამებრ: total_m3).
                        </div>
                        <div>
                            თუ <b>total_m3</b> ცარიელია, სისტემა ავტომატურად დაითვლის:
                            <b>liquid_m3 + crown_firewood_m3</b>.
                        </div>
                        <div>
                            <b>SpeciesMap</b>-ში სახეობა უნდა ემთხვეოდეს
                            <b>Admin → ხეების კატალოგი</b>-ში არსებულ სახეობას.
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</x-app-layout>