<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            მომხმარებლის რედაქტირება — #{{ $user->id }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    @if ($errors->any())
                        <div class="mb-4 p-3 bg-red-100 rounded">
                            <ul class="list-disc pl-5">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('admin.users.update', $user) }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="mb-4">
                            <label class="block mb-1">სახელი *</label>
                            <input name="name" value="{{ old('name', $user->name) }}" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">გვარი</label>
                            <input name="surname" value="{{ old('surname', $user->surname) }}" class="w-full border rounded p-2">
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">პირადი ნომერი *</label>
                            <input
                                type="text"
                                name="personal_number"
                                value="{{ old('personal_number', $user->personal_number) }}"
                                class="w-full border rounded p-2"
                                required
                                maxlength="11"
                                inputmode="numeric"
                                pattern="\d{11}"
                            >
                            <div class="text-sm text-gray-500 mt-1">უნდა შედგებოდეს ზუსტად 11 ციფრისგან</div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">თანამდებობა</label>
                            <input name="position" value="{{ old('position', $user->position) }}" class="w-full border rounded p-2">
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">Email *</label>
                            <input type="email" name="email" value="{{ old('email', $user->email) }}" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">როლები *</label>
                            @php
                                $currentRoles = $user->roles->pluck('name')->toArray();
                                $oldRoles = old('roles');
                                $selectedRoles = is_array($oldRoles) ? $oldRoles : $currentRoles;
                            @endphp

                            <div class="flex flex-col gap-2">
                                @foreach ($roles as $role)
                                    <label class="inline-flex items-center gap-2">
                                        <input type="checkbox" name="roles[]"
                                               value="{{ $role->name }}"
                                               @checked(in_array($role->name, $selectedRoles))
                                        >
                                        <span>{{ $role->label ?: $role->name }}</span>
                                    </label>
                                @endforeach
                            </div>
                            <div class="text-sm text-gray-500 mt-1">მინიმუმ 1 როლი უნდა აირჩიო</div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-2 font-semibold">უფლებები (Permissions)</label>

                            @php
                                $currentPerms = $user->permissions->pluck('name')->toArray();
                                $oldPerms = old('permissions');
                                $selectedPerms = is_array($oldPerms) ? $oldPerms : $currentPerms;

                                $hierPermNames = ['hierarchy_manage','hierarchy_import','hierarchy_export'];
                                $hierPerms = $permissions->whereIn('name', $hierPermNames);
                                $otherPerms = $permissions->whereNotIn('name', $hierPermNames);
                            @endphp

                            <div class="mb-4 p-3 border rounded bg-gray-50">
                                <div class="font-semibold mb-2">Hierarchy Permissions</div>

                                <div class="flex flex-col gap-2">
                                    @foreach ($hierPerms as $perm)
                                        <label class="inline-flex items-center gap-2">
                                            <input type="checkbox" name="permissions[]"
                                                   value="{{ $perm->name }}"
                                                   @checked(in_array($perm->name, $selectedPerms))
                                            >
                                            <span>{{ $perm->label ?: $perm->name }}</span>
                                            <span class="text-xs text-gray-500 font-mono">({{ $perm->name }})</span>
                                        </label>
                                    @endforeach
                                </div>

                                <div class="text-xs text-gray-600 mt-2">
                                    hierarchy_manage = მართვა, hierarchy_import = იმპორტი, hierarchy_export = ექსპორტი
                                </div>
                            </div>

                            <div class="p-3 border rounded">
                                <div class="font-semibold mb-2">სხვა Permissions</div>

                                <div class="flex flex-col gap-2">
                                    @foreach ($otherPerms as $perm)
                                        <label class="inline-flex items-center gap-2">
                                            <input type="checkbox" name="permissions[]"
                                                   value="{{ $perm->name }}"
                                                   @checked(in_array($perm->name, $selectedPerms))
                                            >
                                            <span>{{ $perm->label ?: $perm->name }}</span>
                                        </label>
                                    @endforeach
                                </div>

                                <div class="text-sm text-gray-500 mt-2">
                                    Admin როლი თუ აქვს, ყველა უფლება ავტომატურად მიენიჭება.
                                </div>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">ახალი პაროლი (არ არის სავალდებულო)</label>
                            <input type="password" name="password" class="w-full border rounded p-2">
                            <div class="text-sm text-gray-500 mt-1">თუ ცარიელია, პაროლი არ შეიცვლება</div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">ახალი პაროლის გამეორება</label>
                            <input type="password" name="password_confirmation" class="w-full border rounded p-2">
                        </div>

                        <div class="mb-6">
                            <label class="block mb-1">ხელმოწერა (.png)</label>

                            @if ($user->signature_path)
                                <div class="mb-2 text-sm">
                                    <div class="mb-2">
                                        <img src="{{ asset('storage/'.$user->signature_path) }}" alt="signature" class="h-16 border rounded">
                                    </div>
                                    <label class="inline-flex items-center gap-2">
                                        <input type="checkbox" name="remove_signature" value="1">
                                        <span>ხელმოწერის წაშლა</span>
                                    </label>
                                </div>
                            @endif

                            <input type="file" name="signature" accept="image/png" class="w-full">
                            <div class="text-sm text-gray-500 mt-1">მხოლოდ PNG, მაქს 2MB</div>
                        </div>

                        <div class="flex gap-3">
                            <button class="px-4 py-2 bg-gray-800 text-white rounded">
                                შენახვა
                            </button>

                            <a href="{{ route('admin.users.index') }}" class="px-4 py-2 bg-gray-200 rounded">
                                უკან
                            </a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>