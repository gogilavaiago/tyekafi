<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between gap-4">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    ხეების კატალოგი
                </h2>
                <div class="text-sm text-gray-500">
                    ახალი სახეობის დამატება და დასათვლელი ცხრილის არჩევა
                </div>
            </div>

            <div class="shrink-0">
                <a href="{{ route('admin.volume-tariffs.index') }}"
                   class="inline-flex items-center px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition hover:opacity-90"
                   style="background:#2563eb; color:#ffffff; text-decoration:none;">
                    მოცულობის ტარიფები
                </a>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if (session('status'))
                <div class="p-3 bg-green-100 rounded text-green-800">
                    {{ session('status') }}
                </div>
            @endif

            @if ($errors->any())
                <div class="p-3 bg-red-100 rounded text-red-800">
                    <div class="font-semibold mb-1">გთხოვ შეასწორო შემდეგი შეცდომები:</div>
                    <ul class="list-disc pl-5 space-y-1">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="text-lg font-semibold mb-4">ახალი სახეობის დამატება</div>

                    <form method="POST" action="{{ route('admin.tree-catalog.species.store') }}" class="space-y-4">
                        @csrf

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-600 mb-1">სახეობის დასახელება</label>
                                <input
                                    type="text"
                                    name="name"
                                    value="{{ old('name') }}"
                                    placeholder="მაგ: წიფელი"
                                    class="w-full border rounded p-2"
                                    required
                                >
                            </div>

                            <div>
                                <label class="block text-sm text-gray-600 mb-1">შემოკლებული სახელი</label>
                                <input
                                    type="text"
                                    name="short_name"
                                    value="{{ old('short_name') }}"
                                    placeholder="მაგ: წიფ."
                                    class="w-full border rounded p-2"
                                >
                            </div>

                            <div>
                                <label class="block text-sm text-gray-600 mb-1">ლათინური დასახელება</label>
                                <input
                                    type="text"
                                    name="latin_name"
                                    value="{{ old('latin_name') }}"
                                    placeholder="მაგ: Fagus orientalis"
                                    class="w-full border rounded p-2"
                                >
                            </div>

                            <div>
                                <label class="block text-sm text-gray-600 mb-1">დასათვლელი ცხრილი</label>
                                <select name="tariff_table_id" class="w-full border rounded p-2" required>
                                    <option value="">— აირჩიე —</option>
                                    @foreach($tariffTables as $table)
                                        <option value="{{ $table->id }}" @selected(old('tariff_table_id') == $table->id)>
                                            {{ $table->code }} — {{ $table->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div>
                            <button type="submit"
                                    class="inline-flex items-center px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition hover:opacity-90"
                                    style="background:#16a34a; color:#ffffff; text-decoration:none;">
                                სახეობის დამატება
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <div class="text-lg font-semibold">არსებული სახეობები</div>
                            <div class="text-sm text-gray-500">
                                სახეობა, შემოკლებული სახელი, ლათინური დასახელება, წითელი ნუსხა და მიბმული დასათვლელი ცხრილი
                            </div>
                        </div>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full border">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="border p-2 text-left">სახეობა</th>
                                    <th class="border p-2 text-left">შემოკლებული სახელი</th>
                                    <th class="border p-2 text-left">ლათინური დასახელება</th>
                                    <th class="border p-2 text-left">წითელი ნუსხა</th>
                                    <th class="border p-2 text-left">დასათვლელი ცხრილი</th>
                                    <th class="border p-2 text-left w-32">ქმედება</th>
                                </tr>
                            </thead>

                            <tbody>
                                @forelse($species as $sp)
                                    <tr>
                                        <td class="border p-2 font-medium">{{ $sp->name }}</td>
                                        <td class="border p-2">{{ $sp->short_name ?: '—' }}</td>
                                        <td class="border p-2">{{ $sp->latin_name ?: '—' }}</td>
                                        <td class="border p-2">{{ $sp->red_list ?: '—' }}</td>
                                        <td class="border p-2">{{ $sp->tariff_table_code ?: '—' }}</td>
                                        <td class="border p-2">
                                            <form method="POST"
                                                  action="{{ route('admin.tree-catalog.species.destroy', $sp->id) }}"
                                                  onsubmit="return confirm('ნამდვილად გსურს სახეობის წაშლა?')">
                                                @csrf
                                                @method('DELETE')

                                                <button type="submit"
                                                        class="inline-flex items-center px-3 py-1 rounded text-sm font-medium"
                                                        style="background:#dc2626; color:#ffffff;">
                                                    წაშლა
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="border p-4 text-center text-gray-500">
                                            სახეობები არ არის.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</x-app-layout>