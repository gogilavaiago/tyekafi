<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                მომხმარებლები
            </h2>

            <div class="flex items-center gap-2">
                <a href="{{ route('admin.hierarchy.index') }}"
                   class="inline-flex items-center px-4 py-2 bg-gray-200 rounded">
                    დამისამართების მართვა (Admin)
                </a>
                <a href="{{ route('admin.tree-catalog.index') }}"
       class="inline-flex items-center px-4 py-2 bg-gray-200 rounded">
        სახეობები (Admin)
    </a>

                <a href="{{ route('admin.users.create') }}"
                   class="inline-flex items-center px-4 py-2 bg-gray-800 text-white rounded">
                    + მომხმარებლის დამატება
                </a>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('status'))
                <div class="mb-4 p-3 bg-green-100 rounded">
                    {{ session('status') }}
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 overflow-x-auto">

                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="border-b">
                                <th class="text-left py-2">ID</th>
                                <th class="text-left py-2">სახელი</th>
                                <th class="text-left py-2">გვარი</th>
                                <th class="text-left py-2">Email</th>
                                <th class="text-left py-2">როლები</th>
                                <th class="text-left py-2">უფლებები</th>
                                <th class="text-left py-2">ქმედება</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach ($users as $user)
                                <tr class="border-b align-top">
                                    <td class="py-3">{{ $user->id }}</td>
                                    <td class="py-3">{{ $user->name }}</td>
                                    <td class="py-3">{{ $user->surname }}</td>
                                    <td class="py-3">{{ $user->email }}</td>

                                    <td class="py-3">
                                        @php $roles = $user->roles->pluck('name')->values(); @endphp
                                        @if ($roles->isEmpty())
                                            <span class="inline-flex items-center px-2 py-1 rounded bg-gray-100 text-gray-700 text-xs">—</span>
                                        @else
                                            <div class="flex flex-wrap gap-2">
                                                @foreach ($roles as $r)
                                                    @php $isAdmin = ($r === 'admin'); @endphp
                                                    <span class="inline-flex items-center px-2 py-1 rounded text-xs {{ $isAdmin ? 'bg-indigo-100 text-indigo-800' : 'bg-gray-100 text-gray-800' }}">
                                                        {{ $r }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @endif
                                    </td>

                                    <td class="py-3">
                                        @php
                                            $isAdminUser = $user->roles->pluck('name')->contains('admin');
                                            $perms = $user->permissions->pluck('name')->values();
                                        @endphp

                                        @if ($isAdminUser)
                                            <span class="inline-flex items-center px-2 py-1 rounded bg-indigo-50 text-indigo-700 text-xs">
                                                ყველა (admin)
                                            </span>
                                        @elseif ($perms->isEmpty())
                                            <span class="inline-flex items-center px-2 py-1 rounded bg-gray-100 text-gray-700 text-xs">
                                                —
                                            </span>
                                        @else
                                            <div class="flex flex-wrap gap-2">
                                                @foreach ($perms as $p)
                                                    <span class="inline-flex items-center px-2 py-1 rounded bg-emerald-50 text-emerald-700 text-xs">
                                                        {{ $p }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        @endif
                                    </td>

                                    <td class="py-3">
                                        <div class="flex items-center gap-2">
                                            @can('perm.edit')
                                                <a href="{{ route('admin.users.edit', $user) }}"
                                                   class="px-3 py-1 bg-gray-200 rounded">
                                                    რედაქტირება
                                                </a>
                                            @endcan

                                            @can('perm.edit')
                                                @if (auth()->id() !== $user->id)
                                                    <form method="POST" action="{{ route('admin.users.destroy', $user) }}"
                                                          onsubmit="return confirm('წავშალო მომხმარებელი?');">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button class="px-3 py-1 bg-red-600 text-white rounded">
                                                            წაშლა
                                                        </button>
                                                    </form>
                                                @endif
                                            @endcan

                                            @cannot('perm.edit')
                                                <span class="text-gray-400 text-xs">—</span>
                                            @endcannot
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="mt-4">
                        {{ $users->links() }}
                    </div>

                </div>
            </div>

        </div>
    </div>
</x-app-layout>