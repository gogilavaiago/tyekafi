<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            მომხმარებლის დამატება
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    @if ($errors->any())
                        <div class="mb-4 p-3 bg-red-100 rounded">
                            <ul class="list-disc pl-5">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('admin.users.store') }}" enctype="multipart/form-data">
                        @csrf

                        <div class="mb-4">
                            <label class="block mb-1">სახელი *</label>
                            <input name="name" value="{{ old('name') }}" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">გვარი</label>
                            <input name="surname" value="{{ old('surname') }}" class="w-full border rounded p-2">
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">პირადი ნომერი *</label>
                            <input
                                type="text"
                                name="personal_number"
                                value="{{ old('personal_number') }}"
                                class="w-full border rounded p-2"
                                required
                                maxlength="11"
                                inputmode="numeric"
                                pattern="\d{11}"
                            >
                            <div class="text-sm text-gray-500 mt-1">უნდა შედგებოდეს ზუსტად 11 ციფრისგან</div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">თანამდებობა</label>
                            <input name="position" value="{{ old('position') }}" class="w-full border rounded p-2">
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">Email *</label>
                            <input type="email" name="email" value="{{ old('email') }}" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">როლები *</label>
                            <div class="flex flex-col gap-2">
                                @foreach ($roles as $role)
                                    <label class="inline-flex items-center gap-2">
                                        <input type="checkbox" name="roles[]"
                                               value="{{ $role->name }}"
                                               @checked(is_array(old('roles')) && in_array($role->name, old('roles')))
                                        >
                                        <span>{{ $role->label ?: $role->name }}</span>
                                    </label>
                                @endforeach
                            </div>
                            <div class="text-sm text-gray-500 mt-1">მინიმუმ 1 როლი უნდა აირჩიო</div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-2 font-semibold">უფლებები (Permissions)</label>

                            @php
                                $selectedPerms = is_array(old('permissions')) ? old('permissions') : [];
                                $hierPermNames = ['hierarchy_manage','hierarchy_import','hierarchy_export'];
                                $hierPerms = $permissions->whereIn('name', $hierPermNames);
                                $otherPerms = $permissions->whereNotIn('name', $hierPermNames);
                            @endphp

                            <div class="mb-4 p-3 border rounded bg-gray-50">
                                <div class="font-semibold mb-2">Hierarchy Permissions</div>

                                <div class="flex flex-col gap-2">
                                    @foreach ($hierPerms as $perm)
                                        <label class="inline-flex items-center gap-2">
                                            <input type="checkbox" name="permissions[]"
                                                   value="{{ $perm->name }}"
                                                   @checked(in_array($perm->name, $selectedPerms))
                                            >
                                            <span>{{ $perm->label ?: $perm->name }}</span>
                                            <span class="text-xs text-gray-500 font-mono">({{ $perm->name }})</span>
                                        </label>
                                    @endforeach
                                </div>
                            </div>

                            <div class="p-3 border rounded">
                                <div class="font-semibold mb-2">სხვა Permissions</div>

                                <div class="flex flex-col gap-2">
                                    @foreach ($otherPerms as $perm)
                                        <label class="inline-flex items-center gap-2">
                                            <input type="checkbox" name="permissions[]"
                                                   value="{{ $perm->name }}"
                                                   @checked(in_array($perm->name, $selectedPerms))
                                            >
                                            <span>{{ $perm->label ?: $perm->name }}</span>
                                        </label>
                                    @endforeach
                                </div>

                                <div class="text-sm text-gray-500 mt-2">
                                    Admin როლს თუ მონიშნავ, ყველა უფლება ავტომატურად მიენიჭება.
                                </div>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">პაროლი *</label>
                            <input type="password" name="password" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-4">
                            <label class="block mb-1">პაროლის გამეორება *</label>
                            <input type="password" name="password_confirmation" class="w-full border rounded p-2" required>
                        </div>

                        <div class="mb-6">
                            <label class="block mb-1">ხელმოწერა (.png)</label>
                            <input type="file" name="signature" accept="image/png" class="w-full">
                            <div class="text-sm text-gray-500 mt-1">მხოლოდ PNG, მაქს 2MB</div>
                        </div>

                        <div class="flex gap-3">
                            <button class="px-4 py-2 bg-gray-800 text-white rounded">
                                შენახვა
                            </button>

                            <a href="{{ route('admin.users.index') }}" class="px-4 py-2 bg-gray-200 rounded">
                                გაუქმება
                            </a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>