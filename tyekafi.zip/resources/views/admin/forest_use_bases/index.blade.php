<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                ტყითსარგებლობის საფუძვლები (Dropdown)
            </h2>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            @if (session('status'))
                <div class="mb-4 p-3 bg-green-100 rounded">
                    {{ session('status') }}
                </div>
            @endif

            @if($errors->any())
                <div class="mb-4 p-3 bg-red-100 rounded">
                    <ul class="list-disc pl-5">
                        @foreach($errors->all() as $e)
                            <li>{{ $e }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="bg-white p-4 rounded shadow mb-6">
                <h3 class="font-semibold mb-3">დამატება</h3>

                <form method="POST" action="{{ route('admin.forest-use-bases.store') }}" class="grid grid-cols-1 md:grid-cols-4 gap-3">
                    @csrf

                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Code</label>
                        <input name="code" class="w-full border rounded p-2" placeholder="decree_221" value="{{ old('code') }}" required>
                    </div>

                    <div class="md:col-span-2">
                        <label class="block text-sm text-gray-600 mb-1">Title</label>
                        <input name="title" class="w-full border rounded p-2" placeholder="№221..." value="{{ old('title') }}" required>
                    </div>

                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Sort</label>
                        <input name="sort_order" type="number" min="0" class="w-full border rounded p-2" value="{{ old('sort_order', 0) }}">
                    </div>

                    <div class="md:col-span-4 flex items-center gap-2">
                        <input id="is_active_new" type="checkbox" name="is_active" value="1" checked>
                        <label for="is_active_new" class="text-sm text-gray-700">Active</label>

                        <button class="ml-auto inline-flex items-center px-4 py-2 bg-gray-800 text-white rounded">
                            დამატება
                        </button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded shadow overflow-hidden">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="text-left p-3">ID</th>
                            <th class="text-left p-3">Code</th>
                            <th class="text-left p-3">Title</th>
                            <th class="text-left p-3">Sort</th>
                            <th class="text-left p-3">Active</th>
                            <th class="text-left p-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($items as $item)
                            <tr class="border-t">
                                <td class="p-3">{{ $item->id }}</td>

                                <td class="p-3">
                                    <form method="POST" action="{{ route('admin.forest-use-bases.update', $item) }}" class="flex items-center gap-2">
                                        @csrf
                                        @method('PUT')
                                        <input name="code" class="border rounded p-2 w-44" value="{{ $item->code }}" required>
                                </td>

                                <td class="p-3">
                                        <input name="title" class="border rounded p-2 w-full" value="{{ $item->title }}" required>
                                </td>

                                <td class="p-3">
                                        <input name="sort_order" type="number" min="0" class="border rounded p-2 w-24" value="{{ $item->sort_order }}">
                                </td>

                                <td class="p-3">
                                        <input type="checkbox" name="is_active" value="1" @checked($item->is_active)>
                                </td>

                                <td class="p-3 flex gap-2">
                                        <button class="inline-flex items-center px-3 py-2 bg-gray-800 text-white rounded">
                                            Save
                                        </button>
                                    </form>

                                    <form method="POST" action="{{ route('admin.forest-use-bases.destroy', $item) }}"
                                          onsubmit="return confirm('გსურთ გამორთვა? (წაშლა არ ხდება)')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="inline-flex items-center px-3 py-2 bg-red-600 text-white rounded">
                                            Disable
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $items->links() }}
            </div>
        </div>
    </div>
</x-app-layout>