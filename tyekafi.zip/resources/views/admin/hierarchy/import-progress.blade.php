<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                იმპორტის პროგრესი
            </h2>

            <div class="flex items-center gap-2">
                <x-ui-button :href="route('admin.hierarchy.index')" variant="open" icon="↗">
                    უკან იერარქიებზე
                </x-ui-button>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div
                    class="p-6 space-y-4"
                    x-data="hierImportProgress({
                        jobId: @js($jobId),
                        token: @js($token ?? null),
                        statusBaseUrl: @js(route('admin.hierarchy.import.status')),
                        reportCsvBaseUrl: @js(route('admin.hierarchy.import.report.csv')),
                    })"
                    x-init="start()"
                >

                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <div class="text-lg font-semibold text-gray-800">მიმდინარეობს იმპორტი…</div>
                            <div class="text-sm text-gray-500">
                                Job: <span class="font-mono" x-text="jobId"></span>
                            </div>
                        </div>

                        <div class="text-right">
                            <div class="text-2xl font-semibold text-gray-800" x-text="percent + '%'"></div>
                            <div class="text-xs text-gray-500" x-text="statusLabel"></div>
                        </div>
                    </div>

                    <div>
                        <div class="w-full h-3 bg-gray-200 rounded overflow-hidden">
                            <div
                                class="h-3 bg-green-600 transition-all"
                                :style="'width: ' + percent + '%'"
                            ></div>
                        </div>
                        <div class="mt-2 text-sm text-gray-600">
                            <span x-text="done"></span> / <span x-text="total"></span> შესრულდა
                        </div>
                    </div>

                    <div class="rounded border bg-gray-50 p-3 text-sm text-gray-700">
                        <span class="font-semibold">სტატუსი:</span>
                        <span x-text="message"></span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                        <div class="rounded border p-3">
                            <div class="font-semibold text-gray-800 mb-1">Created</div>
                            <div>მართვის ორგანო: <b x-text="created.governing_bodies"></b></div>
                            <div>რეგიონი: <b x-text="created.regions"></b></div>
                            <div>უბანი: <b x-text="created.districts"></b></div>
                            <div>სატყეო: <b x-text="created.forests"></b></div>
                            <div>კვარტალი: <b x-text="created.quarters"></b></div>
                            <div>ლიტერი: <b x-text="created.liters"></b></div>
                        </div>

                        <div class="rounded border p-3">
                            <div class="font-semibold text-gray-800 mb-1">Actions</div>

                            <div class="flex flex-wrap gap-2">
                                <x-ui-button :href="route('admin.hierarchy.index')" variant="open" icon="↗">
                                    იერარქიები
                                </x-ui-button>

                                <template x-if="token">
                                    <div class="flex flex-wrap gap-2">
                                        <a
                                            class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50 transition"
                                            :href="reportCsv('skipped')"
                                        >
                                            ⬇ Skipped CSV
                                        </a>

                                        <a
                                            class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50 transition"
                                            :href="reportCsv('file_duplicates')"
                                        >
                                            ⬇ Duplicates CSV
                                        </a>
                                    </div>
                                </template>
                            </div>

                            <div class="text-xs text-gray-500 mt-2">
                                Report ლინკები იმუშავებს მხოლოდ მაშინ, თუ token გადმოეცა.
                            </div>
                        </div>
                    </div>

                    <template x-if="status === 'done'">
                        <div class="rounded border border-green-200 bg-green-50 p-4 text-green-800 text-sm">
                            ✅ იმპორტი დასრულდა წარმატებით!
                        </div>
                    </template>

                    <template x-if="status === 'error'">
                        <div class="rounded border border-red-200 bg-red-50 p-4 text-red-800 text-sm">
                            ❌ იმპორტისას დაფიქსირდა შეცდომა. იხილე სტატუსის ტექსტი ზემოთ.
                        </div>
                    </template>

                </div>
            </div>

            <script>
                function hierImportProgress({ jobId, token, statusBaseUrl, reportCsvBaseUrl }) {
                    return {
                        jobId,
                        token,
                        statusBaseUrl,
                        reportCsvBaseUrl,

                        status: 'queued',
                        statusLabel: 'queued',
                        message: 'ვიტვირთები…',
                        done: 0,
                        total: 0,
                        percent: 0,
                        created: {
                            governing_bodies: 0,
                            regions: 0,
                            districts: 0,
                            forests: 0,
                            quarters: 0,
                            liters: 0,
                        },

                        timer: null,

                        start() {
                            this.fetchStatus();

                            this.timer = setInterval(() => {
                                this.fetchStatus();
                            }, 1000);
                        },

                        stop() {
                            if (this.timer) clearInterval(this.timer);
                            this.timer = null;
                        },

                        buildStatusUrl() {
                            const u = new URL(this.statusBaseUrl, window.location.origin);
                            u.searchParams.set('job', this.jobId);
                            return u.toString();
                        },

                        async fetchStatus() {
                            try {
                                const res = await fetch(this.buildStatusUrl(), {
                                    headers: { 'Accept': 'application/json' }
                                });

                                const data = await res.json();

                                this.status = data.status || 'unknown';
                                this.message = data.message || '';
                                this.done = parseInt(data.done || 0);
                                this.total = parseInt(data.total || 0);
                                this.percent = parseInt(data.percent || 0);

                                if (data.created) {
                                    this.created = {
                                        governing_bodies: parseInt(data.created.governing_bodies || 0),
                                        regions: parseInt(data.created.regions || 0),
                                        districts: parseInt(data.created.districts || 0),
                                        forests: parseInt(data.created.forests || 0),
                                        quarters: parseInt(data.created.quarters || 0),
                                        liters: parseInt(data.created.liters || 0),
                                    };
                                }

                                this.statusLabel = this.status;

                                if (this.status === 'done' || this.status === 'error') {
                                    this.stop();
                                }
                            } catch (e) {
                                this.status = 'unknown';
                                this.statusLabel = 'unknown';
                                this.message = 'ვერ წავიკითხე progress სტატუსი (ქსელი/სერვერი).';
                            }
                        },

                        reportCsv(type) {
                            const u = new URL(this.reportCsvBaseUrl, window.location.origin);
                            u.searchParams.set('token', this.token);
                            u.searchParams.set('type', type);
                            return u.toString();
                        },
                    }
                }
            </script>

        </div>
    </div>
</x-app-layout>