<!doctype html>
<html lang="ka">
<head>
    <meta charset="utf-8">
    <title>{{ $title }}</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color:#111; }
        h2 { margin: 0 0 10px 0; }
        .muted { color:#666; font-size: 10px; margin-bottom: 10px; }

        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 5px; vertical-align: top; }
        th { background: #f3f4f6; font-weight: bold; text-align: left; }

        .w-row { width: 38px; }
        .w-first { width: 55px; }
        .w-code { width: 55px; }
        .reason { width: 140px; }
    </style>
</head>
<body>
    <h2>{{ $title }}</h2>
    <div class="muted">Generated at: {{ now()->format('Y-m-d H:i:s') }}</div>

    <table>
        <thead>
        <tr>
            <th class="w-row">Row</th>
            <th class="reason">Reason</th>
            <th class="w-first">First row</th>

            <th class="w-code">GB code</th>
            <th>Governing body</th>

            <th class="w-code">R code</th>
            <th>Region</th>

            <th class="w-code">D code</th>
            <th>District</th>

            <th class="w-code">F code</th>
            <th>Forest</th>

            <th class="w-code">Q code</th>
            <th>Quarter</th>

            <th class="w-code">L code</th>
            <th>Liter</th>
        </tr>
        </thead>
        <tbody>
        @forelse($rows as $r)
            @php
                $d = $r['data'] ?? [];
            @endphp
            <tr>
                <td>{{ $r['row'] ?? '' }}</td>
                <td>{{ $r['reason'] ?? '' }}</td>
                <td>{{ $r['first_row'] ?? '' }}</td>

                <td>{{ $d[0] ?? '' }}</td>
                <td>{{ $d[1] ?? '' }}</td>

                <td>{{ $d[2] ?? '' }}</td>
                <td>{{ $d[3] ?? '' }}</td>

                <td>{{ $d[4] ?? '' }}</td>
                <td>{{ $d[5] ?? '' }}</td>

                <td>{{ $d[6] ?? '' }}</td>
                <td>{{ $d[7] ?? '' }}</td>

                <td>{{ $d[8] ?? '' }}</td>
                <td>{{ $d[9] ?? '' }}</td>

                <td>{{ $d[10] ?? '' }}</td>
                <td>{{ $d[11] ?? '' }}</td>
            </tr>
        @empty
            <tr>
                <td colspan="15" style="text-align:center;color:#666;padding:14px;">
                    მონაცემი არ არის
                </td>
            </tr>
        @endforelse
        </tbody>
    </table>
</body>
</html>