<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Import დეტალები #{{ $log->id }}
            </h2>

            <x-ui-button :href="route('admin.hierarchy.import.form')" variant="open" icon="↩">
                უკან იმპორტზე
            </x-ui-button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white shadow-sm rounded-lg p-6 space-y-4">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                    <div class="space-y-1">
                        <div><b>ფაილი:</b> {{ $log->filename ?? '—' }}</div>
                        <div><b>მომხმარებელი:</b> {{ $log->user?->name ?? '—' }}</div>
                        <div><b>სტატუსი:</b> {{ $log->status ?? '—' }}</div>
                        <div><b>Job ID:</b> <span class="font-mono">{{ $log->job_id ?? '—' }}</span></div>
                        <div><b>Token:</b> <span class="font-mono">{{ $log->token ?? '—' }}</span></div>
                        <div><b>დაწყება:</b> {{ $log->started_at?->format('Y-m-d H:i:s') ?? '—' }}</div>
                        <div><b>დასრულება:</b> {{ $log->finished_at?->format('Y-m-d H:i:s') ?? '—' }}</div>
                    </div>

                    <div class="space-y-1">
                        <div><b>Total rows:</b> {{ (int)($log->rows_total ?? 0) }}</div>
                        <div><b>Ready:</b> {{ (int)($log->rows_ready ?? 0) }}</div>
                        <div><b>Skipped:</b> {{ (int)($log->rows_skipped ?? 0) }}</div>
                        <div><b>File duplicates:</b> {{ (int)($log->rows_file_duplicates ?? 0) }}</div>

                        @if($log->time)
                            <div class="mt-2 text-xs text-gray-600">
                                <div>Preview sec: <b>{{ $log->time['preview_seconds'] ?? '' }}</b></div>
                                <div>Per row ms: <b>{{ $log->time['per_row_ms'] ?? '' }}</b></div>
                                <div>Est import sec: <b>{{ $log->time['estimated_import_seconds'] ?? '' }}</b></div>
                            </div>
                        @endif
                    </div>
                </div>

                @if($log->error_message)
                    <div class="bg-red-50 border border-red-200 text-red-700 p-3 rounded text-sm">
                        <b>Error:</b> {{ $log->error_message }}
                    </div>
                @endif

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mt-2">

                    <div class="border rounded p-4 bg-gray-50">
                        <div class="font-semibold mb-2">Preview (NEW)</div>
                        @forelse(($log->stats_create ?? []) as $k => $v)
                            <div>{{ $k }}: <b>{{ $v }}</b></div>
                        @empty
                            <div class="text-gray-500">—</div>
                        @endforelse
                    </div>

                    <div class="border rounded p-4 bg-gray-50">
                        <div class="font-semibold mb-2">Preview (EXISTS)</div>
                        @forelse(($log->stats_exists ?? []) as $k => $v)
                            <div>{{ $k }}: <b>{{ $v }}</b></div>
                        @empty
                            <div class="text-gray-500">—</div>
                        @endforelse
                    </div>

                    <div class="border rounded p-4 bg-gray-50">
                        <div class="font-semibold mb-2">რეალურად შეიქმნა (Created)</div>
                        @forelse(($log->stats_created ?? []) as $k => $v)
                            <div>{{ $k }}: <b>{{ $v }}</b></div>
                        @empty
                            <div class="text-gray-500">—</div>
                        @endforelse
                    </div>

                </div>

            </div>

        </div>
    </div>
</x-app-layout>