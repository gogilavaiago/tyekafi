<x-app-layout>
    <x-slot name="header">
        @php
            $status = $status ?? request('status', 'active');
            $canManage = auth()->check() && auth()->user()->can('perm.hierarchy.manage');
            $canImport = auth()->check() && auth()->user()->can('perm.hierarchy.import');
            $canExport = auth()->check() && auth()->user()->can('perm.hierarchy.export');

            $editGb = request('edit_gb') ? $governingBodies->firstWhere('id', (int) request('edit_gb')) : null;
            $editRegion = request('edit_region') ? $regions->firstWhere('id', (int) request('edit_region')) : null;
            $editDistrict = request('edit_district') ? $districts->firstWhere('id', (int) request('edit_district')) : null;
            $editForest = request('edit_forest') ? $forests->firstWhere('id', (int) request('edit_forest')) : null;
            $editQuarter = request('edit_quarter') ? $quarters->firstWhere('id', (int) request('edit_quarter')) : null;
            $editLiter = request('edit_liter') ? $liters->firstWhere('id', (int) request('edit_liter')) : null;

            $cleanEditQuery = request()->except(['edit_gb','edit_region','edit_district','edit_forest','edit_quarter','edit_liter']);
            $isDeleted = fn($m) => $m && (method_exists($m, 'trashed') ? $m->trashed() : !is_null($m->deleted_at));
        @endphp

        <div class="flex flex-col gap-3">
            <div class="flex items-center justify-between">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">იერარქიები</h2>
                <div class="flex items-center gap-2">
                    @if ($canImport)
                        <x-ui-button :href="route('admin.hierarchy.import.form')" variant="open" icon="⬆">იმპორტი</x-ui-button>
                    @endif
                    @if ($canExport)
                        <x-ui-button :href="route('admin.hierarchy.export.csv')" variant="open" icon="⬇">ექსპორტი CSV</x-ui-button>
                        <x-ui-button :href="route('admin.hierarchy.export.xlsx')" variant="open" icon="⬇">ექსპორტი XLSX</x-ui-button>
                    @endif
                </div>
            </div>

            <div class="flex items-center gap-2">
                <a href="{{ route('admin.hierarchy.index', ['status' => 'active']) }}" class="px-3 py-1 rounded border text-sm {{ $status==='active' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white text-gray-700' }}">აქტიური</a>
                <a href="{{ route('admin.hierarchy.index', ['status' => 'deleted']) }}" class="px-3 py-1 rounded border text-sm {{ $status==='deleted' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white text-gray-700' }}">წაშლილი</a>
                <a href="{{ route('admin.hierarchy.index', ['status' => 'all']) }}" class="px-3 py-1 rounded border text-sm {{ $status==='all' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white text-gray-700' }}">ყველა</a>
                <div class="text-sm text-gray-500 ml-2">რედაქტირება ახლა იხსნება ცალკე ერთჯერადი ფორმით და არა თითოეულ row-ში.</div>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            @if (session('success'))
                <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif
            @if (session('error'))
                <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded">{{ session('error') }}</div>
            @endif
            @if ($errors->any())
                <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded">
                    <div class="font-semibold mb-1">შეცდომაა:</div>
                    <ul class="list-disc pl-5">
                        @foreach ($errors->all() as $e)
                            <li>{{ $e }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- Governing Bodies --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 space-y-4">
                    <div class="flex items-center justify-between">
                        <div class="font-semibold text-gray-800">მართვის ორგანო</div>
                        @if ($canManage)
                            <form method="POST" action="{{ route('admin.hierarchy.governing-bodies.store') }}" class="flex flex-wrap items-center gap-2">
                                @csrf
                                <input name="code" class="border rounded px-3 py-2 text-sm w-40" placeholder="კოდი (ცარიელი = auto)">
                                <input name="name" class="border rounded px-3 py-2 text-sm w-80" placeholder="სახელი" required>
                                <x-ui-button type="submit" variant="add" icon="+">დამატება</x-ui-button>
                            </form>
                        @endif
                    </div>

                    @if ($canManage && $editGb)
                        <div class="rounded-lg border bg-gray-50 p-4">
                            <div class="font-medium mb-3">მართვის ორგანოს რედაქტირება: {{ $editGb->name }}</div>
                            <form method="POST" action="{{ route('admin.hierarchy.governing-bodies.update', $editGb) }}" class="flex flex-wrap items-center gap-2">
                                @csrf @method('PUT')
                                <input name="code" class="border rounded px-3 py-2 text-sm w-40" value="{{ $editGb->code }}" placeholder="კოდი">
                                <input name="name" class="border rounded px-3 py-2 text-sm w-80" value="{{ $editGb->name }}" placeholder="სახელი" required>
                                <x-ui-button type="submit" variant="open" icon="💾">შენახვა</x-ui-button>
                                <a href="{{ route('admin.hierarchy.index', $cleanEditQuery) }}" class="px-3 py-2 rounded border text-sm bg-white">გაუქმება</a>
                            </form>
                        </div>
                    @endif

                    <div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="border-b bg-gray-50"><th class="py-2 px-2 text-left w-16">ID</th><th class="py-2 px-2 text-left w-32">კოდი</th><th class="py-2 px-2 text-left">სახელი</th><th class="py-2 px-2 text-left w-28">სტატუსი</th><th class="py-2 px-2 text-right w-64">ქმედება</th></tr></thead><tbody>
                    @foreach ($governingBodies as $gb)
                        @php $rowDeleted = $isDeleted($gb); @endphp
                        <tr class="border-b {{ $rowDeleted ? 'bg-gray-50 text-gray-500' : '' }}"><td class="py-2 px-2">{{ $gb->id }}</td><td class="py-2 px-2 font-mono">{{ $gb->code ?? '—' }}</td><td class="py-2 px-2">{{ $gb->name }}</td><td class="py-2 px-2">@if($rowDeleted)<span class="px-2 py-1 rounded text-xs bg-gray-200 text-gray-800">წაშლილია</span>@else<span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">აქტიური</span>@endif</td><td class="py-2 px-2 text-right space-x-2">@if($canManage) @if($rowDeleted)<form method="POST" action="{{ route('admin.hierarchy.governing-bodies.restore', $gb->id) }}" class="inline">@csrf<x-ui-button type="submit" variant="add" size="sm" icon="↩">აღდგენა</x-ui-button></form>@else<a href="{{ route('admin.hierarchy.index', array_merge(request()->query(), ['edit_gb' => $gb->id])) }}" class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50">✏️ რედაქტირება</a><form method="POST" action="{{ route('admin.hierarchy.governing-bodies.destroy', $gb) }}" class="inline" onsubmit="return confirm('წავშალოთ? ეს წაშლის ყველა შვილსაც (soft).');">@csrf @method('DELETE')<x-ui-button type="submit" variant="delete" size="sm" icon="🗑">წაშლა</x-ui-button></form>@endif @else — @endif</td></tr>
                    @endforeach
                    </tbody></table></div>
                </div>
            </div>

            {{-- Regions --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6 space-y-4">
                <div class="flex items-center justify-between"><div class="font-semibold text-gray-800">რეგიონი</div>
                    @if ($canManage)
                        <form method="POST" action="{{ route('admin.hierarchy.regions.store') }}" class="flex flex-wrap items-center gap-2">@csrf
                            <select name="governing_body_id" class="border rounded px-3 py-2 text-sm w-56" required><option value="">— აირჩიე მართვის ორგანო —</option>@foreach($activeGoverningBodyOptions as $opt)<option value="{{ $opt['value'] }}">{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" placeholder="კოდი (ცარიელი = auto)">
                            <input name="name" class="border rounded px-3 py-2 text-sm w-80" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="add" icon="+">დამატება</x-ui-button>
                        </form>
                    @endif
                </div>
                @if ($canManage && $editRegion)
                    <div class="rounded-lg border bg-gray-50 p-4"><div class="font-medium mb-3">რეგიონის რედაქტირება: {{ $editRegion->name }}</div>
                        <form method="POST" action="{{ route('admin.hierarchy.regions.update', $editRegion) }}" class="flex flex-wrap items-center gap-2">@csrf @method('PUT')
                            <select name="governing_body_id" class="border rounded px-3 py-2 text-sm w-56" required>@foreach($activeGoverningBodyOptions as $opt)<option value="{{ $opt['value'] }}" @selected((int)$opt['value']===(int)$editRegion->governing_body_id)>{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" value="{{ $editRegion->code }}" placeholder="კოდი">
                            <input name="name" class="border rounded px-3 py-2 text-sm w-80" value="{{ $editRegion->name }}" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="open" icon="💾">შენახვა</x-ui-button><a href="{{ route('admin.hierarchy.index', $cleanEditQuery) }}" class="px-3 py-2 rounded border text-sm bg-white">გაუქმება</a>
                        </form></div>
                @endif
                <div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="border-b bg-gray-50"><th class="py-2 px-2 text-left w-16">ID</th><th class="py-2 px-2 text-left">მართვის ორგანო</th><th class="py-2 px-2 text-left w-32">კოდი</th><th class="py-2 px-2 text-left">სახელი</th><th class="py-2 px-2 text-left w-28">სტატუსი</th><th class="py-2 px-2 text-right w-64">ქმედება</th></tr></thead><tbody>
                @foreach($regions as $region)
                    @php $rowDeleted = $isDeleted($region); @endphp
                    <tr class="border-b {{ $rowDeleted ? 'bg-gray-50 text-gray-500' : '' }}"><td class="py-2 px-2">{{ $region->id }}</td><td class="py-2 px-2">{{ $region->governingBody?->name ?? '—' }}</td><td class="py-2 px-2 font-mono">{{ $region->code ?? '—' }}</td><td class="py-2 px-2">{{ $region->name }}</td><td class="py-2 px-2">{{ $rowDeleted ? 'წაშლილია' : 'აქტიური' }}</td><td class="py-2 px-2 text-right space-x-2">@if($canManage) @if($rowDeleted)<form method="POST" action="{{ route('admin.hierarchy.regions.restore', $region->id) }}" class="inline">@csrf<x-ui-button type="submit" variant="add" size="sm" icon="↩">აღდგენა</x-ui-button></form>@else<a href="{{ route('admin.hierarchy.index', array_merge(request()->query(), ['edit_region' => $region->id])) }}" class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50">✏️ რედაქტირება</a><form method="POST" action="{{ route('admin.hierarchy.regions.destroy', $region) }}" class="inline" onsubmit="return confirm('წავშალოთ? ეს წაშლის ყველა შვილსაც (soft).');">@csrf @method('DELETE')<x-ui-button type="submit" variant="delete" size="sm" icon="🗑">წაშლა</x-ui-button></form>@endif @else — @endif</td></tr>
                @endforeach
                </tbody></table></div>
            </div></div>

            {{-- Districts --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6 space-y-4">
                <div class="flex items-center justify-between"><div class="font-semibold text-gray-800">სატყეო უბანი</div>
                    @if ($canManage)
                        <form method="POST" action="{{ route('admin.hierarchy.districts.store') }}" class="flex flex-wrap items-center gap-2">@csrf
                            <select name="governing_body_id" class="border rounded px-3 py-2 text-sm w-56" required><option value="">— მართვის ორგანო —</option>@foreach($activeGoverningBodyOptions as $opt)<option value="{{ $opt['value'] }}">{{ $opt['label'] }}</option>@endforeach</select>
                            <select name="region_id" class="border rounded px-3 py-2 text-sm w-72" required><option value="">— რეგიონი —</option>@foreach($activeRegionOptions as $opt)<option value="{{ $opt['value'] }}">{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" placeholder="კოდი (ცარიელი = auto)">
                            <input name="name" class="border rounded px-3 py-2 text-sm w-80" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="add" icon="+">დამატება</x-ui-button>
                        </form>
                    @endif
                </div>
                @if ($canManage && $editDistrict)
                    <div class="rounded-lg border bg-gray-50 p-4"><div class="font-medium mb-3">სატყეო უბნის რედაქტირება: {{ $editDistrict->name }}</div>
                        <form method="POST" action="{{ route('admin.hierarchy.districts.update', $editDistrict) }}" class="flex flex-wrap items-center gap-2">@csrf @method('PUT')
                            <select name="governing_body_id" class="border rounded px-3 py-2 text-sm w-56" required>@foreach($activeGoverningBodyOptions as $opt)<option value="{{ $opt['value'] }}" @selected((int)$opt['value']===(int)$editDistrict->governing_body_id)>{{ $opt['label'] }}</option>@endforeach</select>
                            <select name="region_id" class="border rounded px-3 py-2 text-sm w-72" required>@foreach($activeRegionOptions as $opt)<option value="{{ $opt['value'] }}" @selected((int)$opt['value']===(int)$editDistrict->region_id)>{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" value="{{ $editDistrict->code }}" placeholder="კოდი"><input name="name" class="border rounded px-3 py-2 text-sm w-80" value="{{ $editDistrict->name }}" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="open" icon="💾">შენახვა</x-ui-button><a href="{{ route('admin.hierarchy.index', $cleanEditQuery) }}" class="px-3 py-2 rounded border text-sm bg-white">გაუქმება</a>
                        </form></div>
                @endif
                <div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="border-b bg-gray-50"><th class="py-2 px-2 text-left w-16">ID</th><th class="py-2 px-2 text-left">მართვის ორგანო</th><th class="py-2 px-2 text-left">რეგიონი</th><th class="py-2 px-2 text-left w-32">კოდი</th><th class="py-2 px-2 text-left">სახელი</th><th class="py-2 px-2 text-left w-56">სტატუსი</th><th class="py-2 px-2 text-right w-72">ქმედება</th></tr></thead><tbody>
                @foreach($districts as $d)
                    @php $rowDeleted = $isDeleted($d); $gbDeleted = $isDeleted($d->governingBody); $regionDeleted = $isDeleted($d->region); $canRestore = $rowDeleted && !$gbDeleted && !$regionDeleted; @endphp
                    <tr class="border-b {{ $rowDeleted ? 'bg-gray-50 text-gray-500' : '' }}"><td class="py-2 px-2">{{ $d->id }}</td><td class="py-2 px-2">{{ $d->governingBody?->name ?? '—' }}</td><td class="py-2 px-2">{{ $d->region?->name ?? '—' }}</td><td class="py-2 px-2 font-mono">{{ $d->code ?? '—' }}</td><td class="py-2 px-2">{{ $d->name }}</td><td class="py-2 px-2">@if($rowDeleted)<span class="px-2 py-1 rounded text-xs bg-gray-200 text-gray-800">წაშლილია</span>@else<span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">აქტიური</span>@endif @if($gbDeleted || $regionDeleted)<span class="px-2 py-1 rounded text-xs bg-amber-100 text-amber-900">Parent წაშლილია</span>@endif</td><td class="py-2 px-2 text-right space-x-2">@if($canManage) @if($rowDeleted) @if($canRestore)<form method="POST" action="{{ route('admin.hierarchy.districts.restore', $d->id) }}" class="inline">@csrf<x-ui-button type="submit" variant="add" size="sm" icon="↩">აღდგენა</x-ui-button></form>@else<span class="text-xs text-gray-500">ჯერ Parent აღადგინე</span>@endif @else<a href="{{ route('admin.hierarchy.index', array_merge(request()->query(), ['edit_district' => $d->id])) }}" class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50">✏️ რედაქტირება</a><form method="POST" action="{{ route('admin.hierarchy.districts.destroy', $d) }}" class="inline" onsubmit="return confirm('წავშალოთ?');">@csrf @method('DELETE')<x-ui-button type="submit" variant="delete" size="sm" icon="🗑">წაშლა</x-ui-button></form>@endif @else — @endif</td></tr>
                @endforeach
                </tbody></table></div>
            </div></div>

            {{-- Forests --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6 space-y-4">
                <div class="flex items-center justify-between"><div class="font-semibold text-gray-800">სატყეო</div>
                    @if ($canManage)
                        <form method="POST" action="{{ route('admin.hierarchy.forests.store') }}" class="flex flex-wrap items-center gap-2">@csrf
                            <select name="forest_district_id" class="border rounded px-3 py-2 text-sm w-[36rem]" required><option value="">— აირჩიე სატყეო უბანი —</option>@foreach($activeDistrictOptions as $opt)<option value="{{ $opt['value'] }}">{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" placeholder="კოდი (ცარიელი = auto)"><input name="name" class="border rounded px-3 py-2 text-sm w-80" placeholder="სახელი" required><x-ui-button type="submit" variant="add" icon="+">დამატება</x-ui-button>
                        </form>
                    @endif
                </div>
                @if ($canManage && $editForest)
                    <div class="rounded-lg border bg-gray-50 p-4"><div class="font-medium mb-3">სატყეოს რედაქტირება: {{ $editForest->name }}</div>
                        <form method="POST" action="{{ route('admin.hierarchy.forests.update', $editForest) }}" class="flex flex-wrap items-center gap-2">@csrf @method('PUT')
                            <select name="forest_district_id" class="border rounded px-3 py-2 text-sm w-[36rem]" required>@foreach($activeDistrictOptions as $opt)<option value="{{ $opt['value'] }}" @selected((int)$opt['value']===(int)$editForest->forest_district_id)>{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" value="{{ $editForest->code }}" placeholder="კოდი"><input name="name" class="border rounded px-3 py-2 text-sm w-80" value="{{ $editForest->name }}" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="open" icon="💾">შენახვა</x-ui-button><a href="{{ route('admin.hierarchy.index', $cleanEditQuery) }}" class="px-3 py-2 rounded border text-sm bg-white">გაუქმება</a>
                        </form></div>
                @endif
                <div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="border-b bg-gray-50"><th class="py-2 px-2 text-left w-16">ID</th><th class="py-2 px-2 text-left w-[36rem]">სატყეო უბანი</th><th class="py-2 px-2 text-left w-32">კოდი</th><th class="py-2 px-2 text-left">სახელი</th><th class="py-2 px-2 text-left w-56">სტატუსი</th><th class="py-2 px-2 text-right w-72">ქმედება</th></tr></thead><tbody>
                @foreach($forests as $f)
                    @php $rowDeleted = $isDeleted($f); $d = $f->district; $dDeleted = $isDeleted($d); $gbDeleted = $isDeleted($d?->governingBody); $canRestore = $rowDeleted && !$dDeleted && !$gbDeleted; @endphp
                    <tr class="border-b {{ $rowDeleted ? 'bg-gray-50 text-gray-500' : '' }}"><td class="py-2 px-2">{{ $f->id }}</td><td class="py-2 px-2">{{ $d?->governingBody?->name ?? '—' }} → {{ $d?->region?->name ?? '—' }} → {{ $d?->name ?? '—' }}</td><td class="py-2 px-2 font-mono">{{ $f->code ?? '—' }}</td><td class="py-2 px-2">{{ $f->name }}</td><td class="py-2 px-2">@if($rowDeleted)<span class="px-2 py-1 rounded text-xs bg-gray-200 text-gray-800">წაშლილია</span>@else<span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">აქტიური</span>@endif @if($dDeleted || $gbDeleted)<span class="px-2 py-1 rounded text-xs bg-amber-100 text-amber-900">Parent წაშლილია</span>@endif</td><td class="py-2 px-2 text-right space-x-2">@if($canManage) @if($rowDeleted) @if($canRestore)<form method="POST" action="{{ route('admin.hierarchy.forests.restore', $f->id) }}" class="inline">@csrf<x-ui-button type="submit" variant="add" size="sm" icon="↩">აღდგენა</x-ui-button></form>@else<span class="text-xs text-gray-500">ჯერ Parent აღადგინე</span>@endif @else<a href="{{ route('admin.hierarchy.index', array_merge(request()->query(), ['edit_forest' => $f->id])) }}" class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50">✏️ რედაქტირება</a><form method="POST" action="{{ route('admin.hierarchy.forests.destroy', $f) }}" class="inline" onsubmit="return confirm('წავშალოთ?');">@csrf @method('DELETE')<x-ui-button type="submit" variant="delete" size="sm" icon="🗑">წაშლა</x-ui-button></form>@endif @else — @endif</td></tr>
                @endforeach
                </tbody></table></div>
            </div></div>

            {{-- Quarters --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6 space-y-4">
                <div class="flex items-center justify-between"><div class="font-semibold text-gray-800">კვარტალი</div>
                    @if ($canManage)
                        <form method="POST" action="{{ route('admin.hierarchy.quarters.store') }}" class="flex flex-wrap items-center gap-2">@csrf
                            <select name="forest_id" class="border rounded px-3 py-2 text-sm w-[36rem]" required><option value="">— აირჩიე სატყეო —</option>@foreach($activeForestOptions as $opt)<option value="{{ $opt['value'] }}">{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" placeholder="კოდი (ცარიელი = auto)"><input name="name" class="border rounded px-3 py-2 text-sm w-80" placeholder="სახელი" required><x-ui-button type="submit" variant="add" icon="+">დამატება</x-ui-button>
                        </form>
                    @endif
                </div>
                @if ($canManage && $editQuarter)
                    <div class="rounded-lg border bg-gray-50 p-4"><div class="font-medium mb-3">კვარტლის რედაქტირება: {{ $editQuarter->name }}</div>
                        <form method="POST" action="{{ route('admin.hierarchy.quarters.update', $editQuarter) }}" class="flex flex-wrap items-center gap-2">@csrf @method('PUT')
                            <select name="forest_id" class="border rounded px-3 py-2 text-sm w-[36rem]" required>@foreach($activeForestOptions as $opt)<option value="{{ $opt['value'] }}" @selected((int)$opt['value']===(int)$editQuarter->forest_id)>{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" value="{{ $editQuarter->code }}" placeholder="კოდი"><input name="name" class="border rounded px-3 py-2 text-sm w-80" value="{{ $editQuarter->name }}" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="open" icon="💾">შენახვა</x-ui-button><a href="{{ route('admin.hierarchy.index', $cleanEditQuery) }}" class="px-3 py-2 rounded border text-sm bg-white">გაუქმება</a>
                        </form></div>
                @endif
                <div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="border-b bg-gray-50"><th class="py-2 px-2 text-left w-16">ID</th><th class="py-2 px-2 text-left w-[36rem]">სატყეო</th><th class="py-2 px-2 text-left w-28">კოდი</th><th class="py-2 px-2 text-left">სახელი</th><th class="py-2 px-2 text-left w-56">სტატუსი</th><th class="py-2 px-2 text-right w-72">ქმედება</th></tr></thead><tbody>
                @foreach($quarters as $q)
                    @php $rowDeleted = $isDeleted($q); $f = $q->forest; $fDeleted = $isDeleted($f); $d = $f?->district; $dDeleted = $isDeleted($d); $gbDeleted = $isDeleted($d?->governingBody); $canRestore = $rowDeleted && !$fDeleted && !$dDeleted && !$gbDeleted; @endphp
                    <tr class="border-b {{ $rowDeleted ? 'bg-gray-50 text-gray-500' : '' }}"><td class="py-2 px-2">{{ $q->id }}</td><td class="py-2 px-2">{{ $gbDeleted ? '—' : ($d?->governingBody?->name ?? '—') }} → {{ $d?->name ?? '—' }} → {{ $f?->name ?? '—' }}</td><td class="py-2 px-2 font-mono">{{ $q->code ?? '—' }}</td><td class="py-2 px-2">{{ $q->name }}</td><td class="py-2 px-2">@if($rowDeleted)<span class="px-2 py-1 rounded text-xs bg-gray-200 text-gray-800">წაშლილია</span>@else<span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">აქტიური</span>@endif @if($fDeleted || $dDeleted || $gbDeleted)<span class="px-2 py-1 rounded text-xs bg-amber-100 text-amber-900">Parent წაშლილია</span>@endif</td><td class="py-2 px-2 text-right space-x-2">@if($canManage) @if($rowDeleted) @if($canRestore)<form method="POST" action="{{ route('admin.hierarchy.quarters.restore', $q->id) }}" class="inline">@csrf<x-ui-button type="submit" variant="add" size="sm" icon="↩">აღდგენა</x-ui-button></form>@else<span class="text-xs text-gray-500">ჯერ Parent აღადგინე</span>@endif @else<a href="{{ route('admin.hierarchy.index', array_merge(request()->query(), ['edit_quarter' => $q->id])) }}" class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50">✏️ რედაქტირება</a><form method="POST" action="{{ route('admin.hierarchy.quarters.destroy', $q) }}" class="inline" onsubmit="return confirm('წავშალოთ?');">@csrf @method('DELETE')<x-ui-button type="submit" variant="delete" size="sm" icon="🗑">წაშლა</x-ui-button></form>@endif @else — @endif</td></tr>
                @endforeach
                </tbody></table></div>
            </div></div>

            {{-- Liters --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6 space-y-4">
                <div class="flex items-center justify-between"><div class="font-semibold text-gray-800">ლიტერი</div>
                    @if ($canManage)
                        <form method="POST" action="{{ route('admin.hierarchy.liters.store') }}" class="flex flex-wrap items-center gap-2">@csrf
                            <select name="quarter_id" class="border rounded px-3 py-2 text-sm w-[36rem]" required><option value="">— აირჩიე კვარტალი —</option>@foreach($activeQuarterOptions as $opt)<option value="{{ $opt['value'] }}">{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" placeholder="კოდი (ცარიელი = auto)"><input name="name" class="border rounded px-3 py-2 text-sm w-80" placeholder="სახელი" required><x-ui-button type="submit" variant="add" icon="+">დამატება</x-ui-button>
                        </form>
                    @endif
                </div>
                @if ($canManage && $editLiter)
                    <div class="rounded-lg border bg-gray-50 p-4"><div class="font-medium mb-3">ლიტერის რედაქტირება: {{ $editLiter->name }}</div>
                        <form method="POST" action="{{ route('admin.hierarchy.liters.update', $editLiter) }}" class="flex flex-wrap items-center gap-2">@csrf @method('PUT')
                            <select name="quarter_id" class="border rounded px-3 py-2 text-sm w-[36rem]" required>@foreach($activeQuarterOptions as $opt)<option value="{{ $opt['value'] }}" @selected((int)$opt['value']===(int)$editLiter->quarter_id)>{{ $opt['label'] }}</option>@endforeach</select>
                            <input name="code" class="border rounded px-3 py-2 text-sm w-40" value="{{ $editLiter->code }}" placeholder="კოდი"><input name="name" class="border rounded px-3 py-2 text-sm w-80" value="{{ $editLiter->name }}" placeholder="სახელი" required>
                            <x-ui-button type="submit" variant="open" icon="💾">შენახვა</x-ui-button><a href="{{ route('admin.hierarchy.index', $cleanEditQuery) }}" class="px-3 py-2 rounded border text-sm bg-white">გაუქმება</a>
                        </form></div>
                @endif
                <div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr class="border-b bg-gray-50"><th class="py-2 px-2 text-left w-16">ID</th><th class="py-2 px-2 text-left w-[40rem]">კვარტალი</th><th class="py-2 px-2 text-left w-28">კოდი</th><th class="py-2 px-2 text-left">სახელი</th><th class="py-2 px-2 text-left w-56">სტატუსი</th><th class="py-2 px-2 text-right w-72">ქმედება</th></tr></thead><tbody>
                @foreach($liters as $l)
                    @php $rowDeleted = $isDeleted($l); $q = $l->quarter; $qDeleted = $isDeleted($q); $f = $q?->forest; $fDeleted = $isDeleted($f); $d = $f?->district; $dDeleted = $isDeleted($d); $gbDeleted = $isDeleted($d?->governingBody); $canRestore = $rowDeleted && !$qDeleted && !$fDeleted && !$dDeleted && !$gbDeleted; @endphp
                    <tr class="border-b {{ $rowDeleted ? 'bg-gray-50 text-gray-500' : '' }}"><td class="py-2 px-2">{{ $l->id }}</td><td class="py-2 px-2">{{ $d?->governingBody?->name ?? '—' }} → {{ $d?->name ?? '—' }} → {{ $f?->name ?? '—' }} → {{ $q?->name ?? '—' }}</td><td class="py-2 px-2 font-mono">{{ $l->code ?? '—' }}</td><td class="py-2 px-2">{{ $l->name }}</td><td class="py-2 px-2">@if($rowDeleted)<span class="px-2 py-1 rounded text-xs bg-gray-200 text-gray-800">წაშლილია</span>@else<span class="px-2 py-1 rounded text-xs bg-green-100 text-green-800">აქტიური</span>@endif @if($qDeleted || $fDeleted || $dDeleted || $gbDeleted)<span class="px-2 py-1 rounded text-xs bg-amber-100 text-amber-900">Parent წაშლილია</span>@endif</td><td class="py-2 px-2 text-right space-x-2">@if($canManage) @if($rowDeleted) @if($canRestore)<form method="POST" action="{{ route('admin.hierarchy.liters.restore', $l->id) }}" class="inline">@csrf<x-ui-button type="submit" variant="add" size="sm" icon="↩">აღდგენა</x-ui-button></form>@else<span class="text-xs text-gray-500">ჯერ Parent აღადგინე</span>@endif @else<a href="{{ route('admin.hierarchy.index', array_merge(request()->query(), ['edit_liter' => $l->id])) }}" class="inline-flex items-center gap-2 px-3 py-2 rounded border text-sm bg-white hover:bg-gray-50">✏️ რედაქტირება</a><form method="POST" action="{{ route('admin.hierarchy.liters.destroy', $l) }}" class="inline" onsubmit="return confirm('წავშალოთ?');">@csrf @method('DELETE')<x-ui-button type="submit" variant="delete" size="sm" icon="🗑">წაშლა</x-ui-button></form>@endif @else — @endif</td></tr>
                @endforeach
                </tbody></table></div>
            </div></div>
        </div>
    </div>
</x-app-layout>
