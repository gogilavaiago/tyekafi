<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Hierarchy Export
            </h2>

            <div class="flex items-center gap-2">
                <x-ui-button :href="route('admin.hierarchy.index')" variant="open" icon="↩">
                    უკან (Hierarchy)
                </x-ui-button>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if($errors->any())
                <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded">
                    <div class="font-semibold mb-1">შეცდომაა:</div>
                    <ul class="list-disc pl-5">
                        @foreach($errors->all() as $e)
                            <li>{{ $e }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 space-y-4">

                    <form method="GET" action="{{ route('admin.hierarchy.export.form') }}" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <div class="text-sm text-gray-700 mb-1">Governing Body</div>
                                <select name="gb_id" class="border rounded px-3 py-2 text-sm w-full">
                                    <option value="">— ყველა —</option>
                                    @foreach($gbs as $gb)
                                        <option value="{{ $gb->id }}" @selected((string)request('gb_id') === (string)$gb->id)>
                                            {{ $gb->name }} ({{ $gb->code }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div>
                                <div class="text-sm text-gray-700 mb-1">District</div>
                                <select name="district_id" class="border rounded px-3 py-2 text-sm w-full">
                                    <option value="">— ყველა —</option>
                                    @foreach($districts as $d)
                                        <option value="{{ $d->id }}" @selected((string)request('district_id') === (string)$d->id)>
                                            {{ $d->governingBody?->name ?? '—' }} → {{ $d->name }} ({{ $d->code }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div>
                                <div class="text-sm text-gray-700 mb-1">Forest</div>
                                <select name="forest_id" class="border rounded px-3 py-2 text-sm w-full">
                                    <option value="">— ყველა —</option>
                                    @foreach($forests as $f)
                                        <option value="{{ $f->id }}" @selected((string)request('forest_id') === (string)$f->id)>
                                            {{ $f->district?->governingBody?->name ?? '—' }} → {{ $f->district?->name ?? '—' }} → {{ $f->name }} ({{ $f->code }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div>
                                <div class="text-sm text-gray-700 mb-1">Quarter</div>
                                <select name="quarter_id" class="border rounded px-3 py-2 text-sm w-full">
                                    <option value="">— ყველა —</option>
                                    @foreach($quarters as $q)
                                        <option value="{{ $q->id }}" @selected((string)request('quarter_id') === (string)$q->id)>
                                            {{ $q->forest?->district?->governingBody?->name ?? '—' }} → {{ $q->forest?->district?->name ?? '—' }} → {{ $q->forest?->name ?? '—' }} → {{ $q->name }} ({{ $q->code }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="flex flex-wrap gap-6">
                            <label class="flex items-center gap-2 text-sm">
                                <input type="checkbox" name="include_codes" value="1" @checked(request('include_codes'))>
                                Include codes
                            </label>

                            <label class="flex items-center gap-2 text-sm">
                                <input type="checkbox" name="include_full_chain" value="1" @checked(request('include_full_chain'))>
                                Include full code chain
                            </label>

                            <label class="flex items-center gap-2 text-sm">
                                <input type="checkbox" name="include_deleted" value="1" @checked(request('include_deleted'))>
                                Include deleted (trashed)
                            </label>
                        </div>

                        <div class="flex items-center gap-2">
                            <x-ui-button type="submit" variant="open" icon="🔎">ფილტრის გამოყენება</x-ui-button>

                            <div class="text-sm text-gray-500">
                                ჯერ აირჩიე ფილტრები, მერე ჩამოტვირთე CSV/XLSX.
                            </div>
                        </div>
                    </form>

                    <div class="border-t pt-4 flex flex-wrap items-center gap-2">
                        <x-ui-button :href="route('admin.hierarchy.export.csv', request()->query())" variant="open" icon="⬇">
                            Download CSV
                        </x-ui-button>

                        <x-ui-button :href="route('admin.hierarchy.export.xlsx', request()->query())" variant="open" icon="⬇">
                            Download XLSX
                        </x-ui-button>
                    </div>

                </div>
            </div>

        </div>
    </div>
</x-app-layout>