<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                იერარქიების იმპორტი (XLSX/CSV)
            </h2>

            <x-ui-button :href="route('admin.hierarchy.index')" variant="open" icon="↗">
                უკან იერარქიებზე
            </x-ui-button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if ($errors->any())
                <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded">
                    <div class="font-semibold mb-2">შეცდომაა:</div>
                    <ul class="list-disc pl-5 space-y-1 text-sm">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-3">
                        <div class="font-semibold text-gray-800">იმპორტის ისტორია (ბოლო 20)</div>
                        <div class="text-xs text-gray-500">queued / running / done / error</div>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                            <tr class="border-b bg-gray-50">
                                <th class="py-2 px-2 text-left w-16">ID</th>
                                <th class="py-2 px-2 text-left w-28">თარიღი</th>
                                <th class="py-2 px-2 text-left w-32">მომხმარებელი</th>
                                <th class="py-2 px-2 text-left">ფაილი</th>
                                <th class="py-2 px-2 text-left w-24">სტატუსი</th>
                                <th class="py-2 px-2 text-left w-56">Rows</th>
                                <th class="py-2 px-2 text-left w-56">Created</th>
                                <th class="py-2 px-2 text-right w-64">ქმედება</th>
                            </tr>
                            </thead>

                            <tbody>
                            @forelse(($logs ?? []) as $log)
                                @php
                                    $status = $log->status ?? 'unknown';

                                    $badge = match($status) {
                                        'queued' => 'bg-gray-200 text-gray-800',
                                        'running' => 'bg-yellow-200 text-yellow-900',
                                        'done' => 'bg-green-200 text-green-900',
                                        'error' => 'bg-red-200 text-red-900',
                                        default => 'bg-gray-200 text-gray-800',
                                    };

                                    $created = $log->stats_created ?? [];
                                @endphp

                                <tr class="border-b">
                                    <td class="py-2 px-2">{{ $log->id }}</td>

                                    <td class="py-2 px-2">
                                        <div class="text-xs text-gray-800">{{ $log->created_at?->format('Y-m-d') }}</div>
                                        <div class="text-xs text-gray-500">{{ $log->created_at?->format('H:i') }}</div>
                                    </td>

                                    <td class="py-2 px-2">
                                        {{ $log->user?->name ?? '—' }}
                                    </td>

                                    <td class="py-2 px-2">
                                        <div class="text-xs">{{ $log->filename ?? '—' }}</div>
                                        <div class="text-xs text-gray-500 font-mono">
                                            job={{ $log->job_id ?? '—' }}
                                        </div>

                                        @if($status === 'error' && $log->error_message)
                                            <div class="text-xs text-red-700 mt-1">
                                                {{ $log->error_message }}
                                            </div>
                                        @endif
                                    </td>

                                    <td class="py-2 px-2">
                                        <span class="px-2 py-1 rounded text-xs {{ $badge }}">{{ $status }}</span>
                                    </td>

                                    <td class="py-2 px-2 text-xs">
                                        total={{ (int)($log->rows_total ?? 0) }},
                                        ready={{ (int)($log->rows_ready ?? 0) }},
                                        skipped={{ (int)($log->rows_skipped ?? 0) }},
                                        dup={{ (int)($log->rows_file_duplicates ?? 0) }}
                                    </td>

                                    <td class="py-2 px-2 text-xs">
                                        GB={{ (int)($created['governing_bodies'] ?? 0) }},
                                        R={{ (int)($created['regions'] ?? 0) }},
                                        D={{ (int)($created['districts'] ?? 0) }},
                                        F={{ (int)($created['forests'] ?? 0) }},
                                        Q={{ (int)($created['quarters'] ?? 0) }},
                                        L={{ (int)($created['liters'] ?? 0) }}
                                    </td>

                                    <td class="py-2 px-2 text-right">
                                        <div class="flex items-center justify-end gap-2 flex-wrap">

                                            <x-ui-button :href="route('admin.hierarchy.import.log.show', $log)" variant="open" size="sm" icon="🔍">
                                                ნახვა
                                            </x-ui-button>

                                            @if(!empty($log->report_csv_path))
                                                <x-ui-button
                                                    :href="route('admin.hierarchy.import.final.csv', ['log_id' => $log->id])"
                                                    variant="open"
                                                    size="sm"
                                                    icon="⬇">
                                                    Summary CSV
                                                </x-ui-button>
                                            @endif

                                            @if(!empty($log->report_pdf_path))
                                                <x-ui-button
                                                    :href="route('admin.hierarchy.import.final.pdf', ['log_id' => $log->id])"
                                                    variant="open"
                                                    size="sm"
                                                    icon="⬇">
                                                    Summary PDF
                                                </x-ui-button>
                                            @endif

                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="8" class="py-6 text-center text-gray-500">
                                        ჯერ ისტორია არ არის.
                                    </td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="text-xs text-gray-500 mt-3">
                        Note: თუ სტატუსი “queued”-ზეა გაჩერებული, ნიშნავს რომ queue worker არ მუშაობს (`php artisan queue:work`).
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 space-y-4">
                    <div class="text-sm text-gray-600">
                        ფაილში უნდა იყოს ზუსტად 12 სვეტი ამ მიმდევრობით:
                        <div class="mt-2 font-mono text-xs bg-gray-50 border rounded p-3">
                            GB code | GB | R code | Region | D code | District | F code | Forest | Q code | Quarter | L code | Liter
                        </div>
                    </div>

                    <form method="POST" action="{{ route('admin.hierarchy.import.preview') }}" enctype="multipart/form-data" class="flex flex-wrap items-center gap-3">
                        @csrf
                        <input type="file" name="file" class="border rounded px-3 py-2 text-sm" required>
                        <x-ui-button type="submit" variant="add" icon="🔎">
                            Dry run (Preview)
                        </x-ui-button>
                    </form>
                </div>
            </div>

            @if(!empty($preview))
                @php
                    $stats = $preview['stats'] ?? [];
                    $time  = $preview['time'] ?? [];

                    $create = $stats['create'] ?? [];
                    $exists = $stats['exists'] ?? [];

                    $duplicateRows = [];
                    $firstRowMap = [];
                    foreach (($preview['file_duplicates'] ?? []) as $dup) {
                        if (isset($dup['row'])) $duplicateRows[(int)$dup['row']] = true;
                        if (isset($dup['row'], $dup['first_row'])) $firstRowMap[(int)$dup['row']] = (int)$dup['first_row'];
                    }
                @endphp

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 space-y-5">

                        <div class="flex items-start justify-between gap-4 flex-wrap">
                            <div>
                                <div class="text-lg font-semibold text-gray-800">Preview შედეგი</div>
                                <div class="text-xs text-gray-500">
                                    Token: <span class="font-mono">{{ $preview['token'] ?? '' }}</span>
                                </div>
                            </div>

                            <div class="text-xs text-gray-500 text-right">
                                <div>Preview დრო: <b>{{ data_get($time,'preview_seconds',0) }}</b> წმ</div>
                                <div>შეფასებული Import: <b>{{ data_get($time,'estimated_import_seconds',0) }}</b> წმ</div>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div class="rounded border bg-gray-50 p-4">
                                <div class="font-semibold mb-2">შეიქმნება (NEW)</div>
                                <div>მართვის ორგანო: <b>{{ (int)($create['governing_bodies'] ?? 0) }}</b></div>
                                <div>რეგიონი: <b>{{ (int)($create['regions'] ?? 0) }}</b></div>
                                <div>უბანი: <b>{{ (int)($create['districts'] ?? 0) }}</b></div>
                                <div>სატყეო: <b>{{ (int)($create['forests'] ?? 0) }}</b></div>
                                <div>კვარტალი: <b>{{ (int)($create['quarters'] ?? 0) }}</b></div>
                                <div>ლიტერი: <b>{{ (int)($create['liters'] ?? 0) }}</b></div>
                            </div>

                            <div class="rounded border bg-gray-50 p-4">
                                <div class="font-semibold mb-2">უკვე არსებობს (DB-ში)</div>
                                <div>მართვის ორგანო: <b>{{ (int)($exists['governing_bodies'] ?? 0) }}</b></div>
                                <div>რეგიონი: <b>{{ (int)($exists['regions'] ?? 0) }}</b></div>
                                <div>უბანი: <b>{{ (int)($exists['districts'] ?? 0) }}</b></div>
                                <div>სატყეო: <b>{{ (int)($exists['forests'] ?? 0) }}</b></div>
                                <div>კვარტალი: <b>{{ (int)($exists['quarters'] ?? 0) }}</b></div>
                                <div>ლიტერი: <b>{{ (int)($exists['liters'] ?? 0) }}</b></div>
                            </div>
                        </div>

                        <div class="rounded border p-4 text-sm">
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                                <div>Rows total: <b>{{ (int)($stats['rows_total'] ?? 0) }}</b></div>
                                <div>Ready: <b>{{ (int)($stats['rows_ready'] ?? 0) }}</b></div>
                                <div>Skipped: <b>{{ (int)($stats['rows_skipped'] ?? 0) }}</b></div>
                                <div>File duplicates: <b>{{ (int)($stats['rows_file_duplicates'] ?? 0) }}</b></div>
                            </div>

                            <div class="mt-3 flex flex-wrap gap-2">
                                <x-ui-button :href="route('admin.hierarchy.import.report.csv', ['token' => $preview['token'], 'type' => 'skipped'])" variant="open" size="sm" icon="⬇">
                                    Skipped CSV
                                </x-ui-button>

                                <x-ui-button :href="route('admin.hierarchy.import.report.csv', ['token' => $preview['token'], 'type' => 'file_duplicates'])" variant="open" size="sm" icon="⬇">
                                    Duplicates CSV
                                </x-ui-button>

                                <x-ui-button :href="route('admin.hierarchy.import.report.pdf', ['token' => $preview['token'], 'type' => 'skipped'])" variant="open" size="sm" icon="⬇">
                                    Skipped PDF
                                </x-ui-button>

                                <x-ui-button :href="route('admin.hierarchy.import.report.pdf', ['token' => $preview['token'], 'type' => 'file_duplicates'])" variant="open" size="sm" icon="⬇">
                                    Duplicates PDF
                                </x-ui-button>
                            </div>
                        </div>

                        <form method="POST" action="{{ route('admin.hierarchy.import.confirm') }}">
                            @csrf
                            <input type="hidden" name="token" value="{{ $preview['token'] }}">

                            <x-ui-button type="submit" variant="add" icon="✅">
                                Confirm & დაიწყე Import
                            </x-ui-button>
                        </form>

                        <div class="border rounded">
                            <div class="px-4 py-2 border-b bg-gray-50 font-semibold text-sm">
                                Sample (პირველი 50 რიგი) — დუბლიკატები წითლად გამოინიშნება
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-xs">
                                    <thead>
                                    <tr class="border-b bg-gray-50">
                                        <th class="py-2 px-2 text-left">#</th>
                                        <th class="py-2 px-2 text-left">GB code</th>
                                        <th class="py-2 px-2 text-left">GB</th>
                                        <th class="py-2 px-2 text-left">R code</th>
                                        <th class="py-2 px-2 text-left">Region</th>
                                        <th class="py-2 px-2 text-left">D code</th>
                                        <th class="py-2 px-2 text-left">District</th>
                                        <th class="py-2 px-2 text-left">F code</th>
                                        <th class="py-2 px-2 text-left">Forest</th>
                                        <th class="py-2 px-2 text-left">Q code</th>
                                        <th class="py-2 px-2 text-left">Quarter</th>
                                        <th class="py-2 px-2 text-left">L code</th>
                                        <th class="py-2 px-2 text-left">Liter</th>
                                        <th class="py-2 px-2 text-left">Status</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    @foreach(($preview['sample'] ?? []) as $i => $r)
                                        @php
                                            $rowNo = (int)($r['row'] ?? 0);
                                            $isDup = isset($duplicateRows[$rowNo]);
                                            $firstRow = $firstRowMap[$rowNo] ?? null;
                                        @endphp

                                        <tr class="border-b {{ $isDup ? 'bg-red-50' : '' }}">
                                            <td class="py-2 px-2">{{ $rowNo ?: ($i+1) }}</td>

                                            <td class="py-2 px-2 font-mono">{{ $r['gb_code'] ?? '' }}</td>
                                            <td class="py-2 px-2">{{ $r['gb_name'] ?? '' }}</td>

                                            <td class="py-2 px-2 font-mono">{{ $r['region_code'] ?? '' }}</td>
                                            <td class="py-2 px-2">{{ $r['region_name'] ?? '' }}</td>

                                            <td class="py-2 px-2 font-mono">{{ $r['district_code'] ?? '' }}</td>
                                            <td class="py-2 px-2">{{ $r['district_name'] ?? '' }}</td>

                                            <td class="py-2 px-2 font-mono">{{ $r['forest_code'] ?? '' }}</td>
                                            <td class="py-2 px-2">{{ $r['forest_name'] ?? '' }}</td>

                                            <td class="py-2 px-2 font-mono">{{ $r['quarter_code'] ?? '' }}</td>
                                            <td class="py-2 px-2">{{ $r['quarter_name'] ?? '' }}</td>

                                            <td class="py-2 px-2 font-mono">{{ $r['liter_code'] ?? '' }}</td>
                                            <td class="py-2 px-2">{{ $r['liter_name'] ?? '' }}</td>

                                            <td class="py-2 px-2">
                                                @if($isDup)
                                                    <span class="inline-flex items-center px-2 py-1 rounded bg-red-600 text-white text-[11px]">
                                                        Duplicate
                                                    </span>
                                                    @if($firstRow)
                                                        <span class="text-[11px] text-gray-600 ml-2">
                                                            (First: {{ $firstRow }})
                                                        </span>
                                                    @endif
                                                @else
                                                    <span class="inline-flex items-center px-2 py-1 rounded bg-green-600 text-white text-[11px]">
                                                        OK
                                                    </span>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach

                                    @if(empty($preview['sample']))
                                        <tr>
                                            <td colspan="14" class="py-6 text-center text-gray-500">
                                                sample ცარიელია
                                            </td>
                                        </tr>
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            @endif

        </div>
    </div>
</x-app-layout>