<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ყოველდღე ღამის 03:30-ზე — cleanup
Schedule::command('tyekafi:cleanup-hierarchy-files --days=30')->dailyAt('03:30');