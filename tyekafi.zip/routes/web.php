<?php

use App\Http\Controllers\Admin\ForestUseBasisController;
use App\Http\Controllers\Admin\HierarchyController;
use App\Http\Controllers\Admin\HierarchyExportController;
use App\Http\Controllers\Admin\HierarchyImportController;
use App\Http\Controllers\Admin\TreeCatalogController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Admin\VolumeTariffController;
use App\Http\Controllers\HierarchyApiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProjectCompensationReportController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\TariffApiController;
use App\Http\Controllers\TreeCatalogApiController;
use App\Http\Controllers\TyekafiController;
use App\Http\Controllers\TyekafiReportController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware(['auth'])->group(function () {

    Route::get('/api/tariffs/lookup', [TariffApiController::class, 'lookup'])
        ->middleware('can:perm.view')
        ->name('api.tariffs.lookup');

    Route::get('/api/tree-catalog/ranks', [TreeCatalogApiController::class, 'ranks'])
        ->middleware('can:perm.view')
        ->name('api.tree-catalog.ranks');

    Route::get('/api/tree-catalog/rank-lookup', [TreeCatalogApiController::class, 'rankLookup'])
        ->middleware('can:perm.view')
        ->name('api.tree-catalog.rankLookup');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::prefix('admin')->name('admin.')->group(function () {

        Route::middleware(['can:admin'])->group(function () {
            Route::get('/users', [AdminUserController::class, 'index'])->name('users.index');
            Route::get('/users/create', [AdminUserController::class, 'create'])->name('users.create');
            Route::post('/users', [AdminUserController::class, 'store'])->name('users.store');
            Route::get('/users/{user}/edit', [AdminUserController::class, 'edit'])->name('users.edit');
            Route::put('/users/{user}', [AdminUserController::class, 'update'])->name('users.update');
            Route::delete('/users/{user}', [AdminUserController::class, 'destroy'])->name('users.destroy');

            Route::get('/forest-use-bases', [ForestUseBasisController::class, 'index'])->name('forest-use-bases.index');
            Route::post('/forest-use-bases', [ForestUseBasisController::class, 'store'])->name('forest-use-bases.store');
            Route::put('/forest-use-bases/{forestUseBasis}', [ForestUseBasisController::class, 'update'])->name('forest-use-bases.update');
            Route::delete('/forest-use-bases/{forestUseBasis}', [ForestUseBasisController::class, 'destroy'])->name('forest-use-bases.destroy');

            Route::get('/tree-catalog', [TreeCatalogController::class, 'index'])->name('tree-catalog.index');
            Route::post('/tree-catalog/species', [TreeCatalogController::class, 'storeSpecies'])->name('tree-catalog.species.store');
            Route::delete('/tree-catalog/species/{treeSpecies}', [TreeCatalogController::class, 'destroySpecies'])->name('tree-catalog.species.destroy');
            Route::post('/tree-catalog/ranks', [TreeCatalogController::class, 'storeRank'])->name('tree-catalog.ranks.store');
            Route::delete('/tree-catalog/ranks/{treeRank}', [TreeCatalogController::class, 'destroyRank'])->name('tree-catalog.ranks.destroy');

            Route::get('/volume-tariffs', [VolumeTariffController::class, 'index'])->name('volume-tariffs.index');
            Route::post('/volume-tariffs/upload', [VolumeTariffController::class, 'upload'])->name('volume-tariffs.upload');
        });

        Route::middleware(['can:perm.hierarchy.view'])->group(function () {
            Route::get('/hierarchy', [HierarchyController::class, 'index'])->name('hierarchy.index');
        });

        Route::middleware(['can:perm.hierarchy.manage'])->group(function () {
            Route::post('/hierarchy/governing-bodies', [HierarchyController::class, 'storeGoverningBody'])->name('hierarchy.governing-bodies.store');
            Route::put('/hierarchy/governing-bodies/{governingBody}', [HierarchyController::class, 'updateGoverningBody'])->name('hierarchy.governing-bodies.update');
            Route::delete('/hierarchy/governing-bodies/{governingBody}', [HierarchyController::class, 'destroyGoverningBody'])->name('hierarchy.governing-bodies.destroy');
            Route::post('/hierarchy/governing-bodies/{governingBody}/restore', [HierarchyController::class, 'restoreGoverningBody'])->name('hierarchy.governing-bodies.restore');

            Route::post('/hierarchy/regions', [HierarchyController::class, 'storeRegion'])->name('hierarchy.regions.store');
            Route::put('/hierarchy/regions/{region}', [HierarchyController::class, 'updateRegion'])->name('hierarchy.regions.update');
            Route::delete('/hierarchy/regions/{region}', [HierarchyController::class, 'destroyRegion'])->name('hierarchy.regions.destroy');
            Route::post('/hierarchy/regions/{region}/restore', [HierarchyController::class, 'restoreRegion'])->name('hierarchy.regions.restore');

            Route::post('/hierarchy/districts', [HierarchyController::class, 'storeDistrict'])->name('hierarchy.districts.store');
            Route::put('/hierarchy/districts/{forestDistrict}', [HierarchyController::class, 'updateDistrict'])->name('hierarchy.districts.update');
            Route::delete('/hierarchy/districts/{forestDistrict}', [HierarchyController::class, 'destroyDistrict'])->name('hierarchy.districts.destroy');
            Route::post('/hierarchy/districts/{forestDistrict}/restore', [HierarchyController::class, 'restoreDistrict'])->name('hierarchy.districts.restore');

            Route::post('/hierarchy/forests', [HierarchyController::class, 'storeForest'])->name('hierarchy.forests.store');
            Route::put('/hierarchy/forests/{forest}', [HierarchyController::class, 'updateForest'])->name('hierarchy.forests.update');
            Route::delete('/hierarchy/forests/{forest}', [HierarchyController::class, 'destroyForest'])->name('hierarchy.forests.destroy');
            Route::post('/hierarchy/forests/{forest}/restore', [HierarchyController::class, 'restoreForest'])->name('hierarchy.forests.restore');

            Route::post('/hierarchy/quarters', [HierarchyController::class, 'storeQuarter'])->name('hierarchy.quarters.store');
            Route::put('/hierarchy/quarters/{quarter}', [HierarchyController::class, 'updateQuarter'])->name('hierarchy.quarters.update');
            Route::delete('/hierarchy/quarters/{quarter}', [HierarchyController::class, 'destroyQuarter'])->name('hierarchy.quarters.destroy');
            Route::post('/hierarchy/quarters/{quarter}/restore', [HierarchyController::class, 'restoreQuarter'])->name('hierarchy.quarters.restore');

            Route::post('/hierarchy/liters', [HierarchyController::class, 'storeLiter'])->name('hierarchy.liters.store');
            Route::put('/hierarchy/liters/{liter}', [HierarchyController::class, 'updateLiter'])->name('hierarchy.liters.update');
            Route::delete('/hierarchy/liters/{liter}', [HierarchyController::class, 'destroyLiter'])->name('hierarchy.liters.destroy');
            Route::post('/hierarchy/liters/{liter}/restore', [HierarchyController::class, 'restoreLiter'])->name('hierarchy.liters.restore');
        });

        Route::middleware(['can:perm.hierarchy.import'])->group(function () {
            Route::get('/hierarchy/import', [HierarchyImportController::class, 'showForm'])->name('hierarchy.import.form');
            Route::post('/hierarchy/import/preview', [HierarchyImportController::class, 'preview'])->name('hierarchy.import.preview');
            Route::post('/hierarchy/import/confirm', [HierarchyImportController::class, 'confirm'])->name('hierarchy.import.confirm');

            Route::get('/hierarchy/import/progress', [HierarchyImportController::class, 'progress'])->name('hierarchy.import.progress');
            Route::get('/hierarchy/import/status', [HierarchyImportController::class, 'status'])->name('hierarchy.import.status');

            Route::get('/hierarchy/import/report/csv', [HierarchyImportController::class, 'downloadReportCsv'])->name('hierarchy.import.report.csv');
            Route::get('/hierarchy/import/report/pdf', [HierarchyImportController::class, 'downloadReportPdf'])->name('hierarchy.import.report.pdf');

            Route::get('/hierarchy/import/log/{log}', [HierarchyImportController::class, 'showLog'])->name('hierarchy.import.log.show');

            Route::get('/hierarchy/import/final/csv', [HierarchyImportController::class, 'downloadFinalSummaryCsv'])->name('hierarchy.import.final.csv');
            Route::get('/hierarchy/import/final/pdf', [HierarchyImportController::class, 'downloadFinalSummaryPdf'])->name('hierarchy.import.final.pdf');
        });

        Route::middleware(['can:perm.hierarchy.export'])->group(function () {
            Route::get('/hierarchy/export', [HierarchyExportController::class, 'showForm'])->name('hierarchy.export.form');
            Route::get('/hierarchy/export/csv', [HierarchyExportController::class, 'exportCsv'])->name('hierarchy.export.csv');
            Route::get('/hierarchy/export/xlsx', [HierarchyExportController::class, 'exportXlsx'])->name('hierarchy.export.xlsx');
        });
    });

    Route::get('/projects', [ProjectController::class, 'index'])->middleware('can:perm.view')->name('projects.index');
    Route::get('/projects/create', [ProjectController::class, 'create'])->middleware('can:perm.edit')->name('projects.create');
    Route::post('/projects', [ProjectController::class, 'store'])->middleware('can:perm.edit')->name('projects.store');
    Route::get('/projects/{project}', [ProjectController::class, 'show'])->middleware('can:perm.view')->name('projects.show');
    Route::get('/projects/{project}/totals', [ProjectController::class, 'totals'])->middleware('can:perm.view')->name('projects.totals');

    Route::get('/projects/{project}/report-pdf-compensation-by-body', [ProjectCompensationReportController::class, 'byGoverningBody'])
        ->middleware('can:perm.view')
        ->name('projects.reportPdfCompensationByBody');

    Route::get('/projects/{project}/report-excel-compensation-by-body', [ProjectCompensationReportController::class, 'exportByGoverningBody'])
        ->middleware('can:perm.view')
        ->name('projects.reportExcelCompensationByBody');

    Route::get('/projects/{project}/edit', [ProjectController::class, 'edit'])->middleware('can:perm.edit')->name('projects.edit');
    Route::put('/projects/{project}', [ProjectController::class, 'update'])->middleware('can:perm.edit')->name('projects.update');
    Route::delete('/projects/{project}', [ProjectController::class, 'destroy'])->middleware('can:perm.edit')->name('projects.destroy');

    Route::get('/projects/{project}/tyekafis', [TyekafiController::class, 'index'])->middleware('can:perm.view')->name('projects.tyekafis.index');
    Route::get('/projects/{project}/tyekafis/create', [TyekafiController::class, 'create'])->middleware('can:perm.edit')->name('projects.tyekafis.create');
    Route::post('/projects/{project}/tyekafis', [TyekafiController::class, 'store'])->middleware('can:perm.edit')->name('projects.tyekafis.store');
    Route::get('/projects/{project}/tyekafis/{tyekafi}', [TyekafiController::class, 'show'])->middleware('can:perm.view')->name('projects.tyekafis.show');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-n1', [TyekafiReportController::class, 'reportN1'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportN1');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-n11', [TyekafiReportController::class, 'reportN11'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportN11');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-excel', [TyekafiReportController::class, 'exportExcel'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportExcel');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-pdf-spreadsheet', [TyekafiReportController::class, 'exportPdf'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportPdfSpreadsheet');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-pdf-n1', [TyekafiReportController::class, 'exportPdfN1'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportPdfN1');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-pdf-n11', [TyekafiReportController::class, 'exportPdfN11'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportPdfN11');

    Route::get('/projects/{project}/tyekafis/{tyekafi}/report-pdf-compensation', [TyekafiReportController::class, 'reportCompensation'])
        ->middleware('can:perm.view')
        ->name('projects.tyekafis.reportPdfCompensation');

    Route::put('/projects/{project}/tyekafis/{tyekafi}/form-in', [TyekafiController::class, 'updateFormIn'])
        ->middleware('can:perm.edit')
        ->name('projects.tyekafis.updateFormIn');

    Route::put('/projects/{project}/tyekafis/{tyekafi}/tree-rows', [TyekafiController::class, 'updateTreeRows'])
        ->middleware('can:perm.edit')
        ->name('projects.tyekafis.updateTreeRows');

    Route::post('/projects/{project}/tyekafis/{tyekafi}/tree-rows/import', [TyekafiController::class, 'importTreeRows'])
        ->middleware('can:perm.edit')
        ->name('projects.tyekafis.importTreeRows');

    Route::post('/projects/{project}/tyekafis/{tyekafi}/tree-rows/preview', [TyekafiController::class, 'previewTreeRows'])
        ->middleware('can:perm.edit')
        ->name('projects.tyekafis.previewTreeRows');

    Route::delete('/projects/{project}/tyekafis/{tyekafi}', [TyekafiController::class, 'destroy'])
        ->middleware('can:perm.edit')
        ->name('projects.tyekafis.destroy');

    Route::get('/api/hierarchy/regions', [HierarchyApiController::class, 'regions'])->middleware('can:perm.view')->name('api.hierarchy.regions');
    Route::get('/api/hierarchy/districts', [HierarchyApiController::class, 'districts'])->middleware('can:perm.view')->name('api.hierarchy.districts');
    Route::get('/api/hierarchy/forests', [HierarchyApiController::class, 'forests'])->middleware('can:perm.view')->name('api.hierarchy.forests');
    Route::get('/api/hierarchy/quarters', [HierarchyApiController::class, 'quarters'])->middleware('can:perm.view')->name('api.hierarchy.quarters');
    Route::get('/api/hierarchy/liters', [HierarchyApiController::class, 'liters'])->middleware('can:perm.view')->name('api.hierarchy.liters');
});

require __DIR__ . '/auth.php';